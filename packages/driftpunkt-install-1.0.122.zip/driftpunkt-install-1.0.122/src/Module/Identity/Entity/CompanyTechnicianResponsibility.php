<?php

declare(strict_types=1);

namespace App\Module\Identity\Entity;

use App\Module\Shared\Entity\TimestampableTrait;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity]
#[ORM\Table(name: 'company_technician_responsibilities')]
#[ORM\UniqueConstraint(name: 'uniq_company_technician_responsibility', columns: ['company_id', 'technician_id'])]
#[ORM\HasLifecycleCallbacks]
class CompanyTechnicianResponsibility
{
    use TimestampableTrait;

    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\ManyToOne(targetEntity: Company::class, inversedBy: 'technicianResponsibilities')]
    #[ORM\JoinColumn(nullable: false, onDelete: 'CASCADE')]
    private Company $company;

    #[ORM\ManyToOne(targetEntity: User::class)]
    #[ORM\JoinColumn(nullable: false, onDelete: 'CASCADE')]
    private User $technician;

    #[ORM\Column(options: ['default' => false])]
    private bool $isPrimary = false;

    public function __construct(Company $company, User $technician, bool $isPrimary = false)
    {
        $this->company = $company;
        $this->technician = $technician;
        $this->isPrimary = $isPrimary;
    }

    public function getId(): ?int { return $this->id; }
    public function getCompany(): Company { return $this->company; }
    public function getTechnician(): User { return $this->technician; }
    public function isPrimary(): bool { return $this->isPrimary; }
    public function setPrimary(bool $isPrimary): self { $this->isPrimary = $isPrimary; return $this; }
}
