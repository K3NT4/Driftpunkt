<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

final class Version20260917110000 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Adds primary and secondary technician responsibility teams for company groups';
    }

    public function up(Schema $schema): void
    {
        if (!$schema->hasTable('companies') || !$schema->hasTable('users') || $schema->hasTable('company_technician_responsibilities')) {
            return;
        }

        $table = $schema->createTable('company_technician_responsibilities');
        $table->addColumn('id', 'integer', ['autoincrement' => true]);
        $table->addColumn('company_id', 'integer');
        $table->addColumn('technician_id', 'integer');
        $table->addColumn('is_primary', 'boolean', ['default' => false]);
        $table->addColumn('created_at', 'datetime_immutable');
        $table->addColumn('updated_at', 'datetime_immutable');
        $table->setPrimaryKey(['id']);
        $table->addUniqueIndex(['company_id', 'technician_id'], 'uniq_company_technician_responsibility');
        $table->addIndex(['technician_id'], 'idx_company_technician_responsibility_technician');
        $table->addForeignKeyConstraint('companies', ['company_id'], ['id'], ['onDelete' => 'CASCADE']);
        $table->addForeignKeyConstraint('users', ['technician_id'], ['id'], ['onDelete' => 'CASCADE']);
    }

    public function down(Schema $schema): void
    {
        if ($schema->hasTable('company_technician_responsibilities')) {
            $schema->dropTable('company_technician_responsibilities');
        }
    }
}
