# Driftpunkt

**Version 2.0.4** · [Install (English)](INSTALL.md) · [Upgrade (English)](docs/upgrade_to_2_0_1.md) · [Se gränssnittet](#skärmbilder)

<p align="center">
  <picture>
    <source media="(prefers-color-scheme: dark)" srcset="docs/public-assets/branding/logo-wide-v2-dark.svg">
    <img src="docs/public-assets/branding/logo-wide-v2.svg" alt="Driftpunkt" width="520">
  </picture>
</p>

<p align="center">
  Symfony-baserat ticketsystem för drift, support och kunddialog.
</p>

Driftpunkt är ett Symfony-baserat support- och driftsystem med publik webb, kundportal, teknikerportal och adminyta i samma produkt.

**Inför uppgradering till 2.0:** följ [liveserverns uppgraderingschecklista](docs/upgrade_to_2_0_0.md). Där beskrivs också hur superadmin aktiverar teknikerns och ärendekoordinatorns personliga val mellan klassisk och ny layout genom att söka efter **Portalens layout** i inställningarna.

README:n beskriver Driftpunkt **2.0.4**, som bygger vidare på den stabila 2.0-utgåvan med omarbetade portaler och bevarade arbetsflöden för ticketing, kunddialog, e-postingest, kundstyrda inventarielistor, SharePoint/CSV-import med skuggpersoner, driftstatus, kundanpassad rapportering, administration, loggcenter, språkstyrning, flerteam-stöd för intern personal, tekniker- och koordinatoranpassning och release/driftarbete. Miljöspecifika integrationer och viss intern driftsetup kan fortfarande leva utanför repo eller exportflöde.

Admin och superadmin kan under **Företag → Inventarielistor** välja vilka kundanvändare som får läsa datorlistan respektive **Hantera** den. Hantera ger även läsåtkomst och låter användaren lägga till, redigera och kommentera datorer i sitt eget företag. Kundens borttagning arkiverar datorn; raden och ändringsloggen sparas, men datorn döljs i vanliga listor och exporter. Nya hanteringsbehörigheter är avstängda tills de uttryckligen tilldelas. Aktivering, CSV-import och permanent radering av hela listor ligger fortsatt hos superadmin.

När en ärendekoordinator skriver en kundsynlig kommentar finns valet **Tilldela ärendet till mig**, förvalt om ärendet saknar ansvarig. Befintlig ansvarig behålls om koordinatorn inte väljer att ta över. Interna anteckningar ändrar aldrig tilldelningen. Koordinatorer kan även väljas som ansvariga i tilldelningsformulären och får uppföljningsnotiser med länkar till koordinatorvyn.

Tekniker med åtkomst till ärendet samt ärendekoordinatorer kan välja **Öppna mejl** på bifogade `.eml`- och Outlook `.msg`-filer. Läsaren visar ämne, avsändare, mottagare, datum och hela den läsbara mejltexten. Mejl inuti mejl kan öppnas och deras bilagor laddas ner. Originalfilen kan alltid laddas ner enligt ordinarie bilagebehörighet. HTML visas som text utan externa bilder. Även ZIP-arkiverade mejlbilagor stöds. Läsaren har en gräns på 20 MB per originalfil samt gränser för nästling och uppackat innehåll; krypterade och skadade mejl kan behöva hanteras manuellt. Bilagefunktionen och dess vanliga uppladdningsgräns gäller fortfarande.

Mejlläsaren använder [jhumanj/email-parser](https://github.com/JhumanJ/php-email-parser) med låsta Composer-beroenden och kräver 64-bitars PHP med mbstring och iconv. Installera uppdaterade beroenden vid driftsättning (`composer install --no-dev --optimize-autoloader`).

Ytterligare stöd för kundmejl:

- Bilagor som inte kan tas in visas för tekniker och koordinator med filnamn och orsak, exempelvis filtyp, storlek eller lagringsfel. Dubbletter räknas separat och utlöser ingen vidarebefordring.
- Originalmejlet skickas som `.eml` till den allmänna koordinatoradressen i triageinställningarna. Om den saknas används uttryckligen valda, aktiva interna triagemottagare. Om ingen mottagare är vald eller utskicket misslyckas visas felet i ärendet och i notifieringsloggen. Om råmejlet saknas märks bilagan tydligt som en rekonstruerad kopia.
- `app:mail:poll` gör upp till tre utskicksförsök, med minst fem minuter mellan försöken. Handläggaren kan därefter välja **Försök vidarebefordra igen** i ärendet. Redan skickade vidarebefordringar skickas inte på nytt vid ett vanligt återförsök. SMTP-leverans och serverns storleksgränser behöver verifieras i drift. Återkommande vidarebefordringar känns igen via headers och ignoreras av importen för att bryta mejlloopar.
- Inklistrade CID-bilder visas vid sin plats i konversationen via ärendets skyddade bildvisning. Signaturlogotyper och externa spårningsbilder hämtas inte.
- **Visa PDF** öppnar en verifierad PDF på högst 20 MB i webbläsaren. Större originalfiler kan fortfarande laddas ner. Samma ärendeåtkomst krävs som för övriga interna bilagevyer, även för ZIP-arkiverade filer.
- **Skapa separat ärende** i mejlläsaren kräver bekräftad kund, företag och kontrollerat innehåll. Ett internt ärende skapas som standard; handläggaren kan uttryckligen välja kundsynlighet. Originalmejlet sparas som bilaga, ärendena länkas och inget kundmejl skickas. Dubbelklick på samma mejl skapar inte två ärenden.
- Vanliga filer i `winmail.dat` packas upp vid import och kan även laddas ner från **Öppna winmail.dat**. Originalbehållaren behålls. Filtyp- och storleksregler gäller även uppackade filer. Skadade behållare eller inbäddade objekt som inte kan extraheras som vanliga filer rapporteras för manuell hantering, med originalet vidarebefordrat enligt ovan.

Databasändringarna finns i `Version20261105120000`, `Version20261105130000` och `Version20261105140000` och behöver appliceras före driftsättning av dessa ändringar. Före produktionsacceptans återstår prov med verkliga Outlook-mejl, kundinkorgar och utgående SMTP.


## Nytt i 2.0.4

- Öppna-knapparna i koordinatorns kö behåller rätt textfärg i alla teman.
- Koordinatorguiden beskriver kön, okända avsändare, telefonärenden, sammanslagning och personliga inställningar på svenska, engelska och norska.
- En separat teknikerguide beskriver ärendearbete, kunddialog, bilagor, uppföljning och inställningar på samma tre språk.
- Tekniker och ärendekoordinatorer kan markera sin guide som läst och välja att dölja den i menyn. Guiden kan öppnas och visas igen under **Inställningar**. Valen gäller det egna kontot och fungerar i båda layouterna.
- Inga nya databasmigreringar. Följ [uppgraderingschecklistan](docs/upgrade_to_2_0_1.md).

Se [versionsnyheterna](release-notes/2.0.4.md).

## Nytt i 2.0.3

- Tekniker och ärendekoordinatorer kan välja årstidsteman: **Vår**, **Sommar**, **Höst**, **Vinter** och **Årstid**, som byter automatiskt under året.
- Under **Inställningar** finns en personlig **Årstidsdekoration** som visar jul och nyår kring helgerna och annars årstiden. Den är avstängd som standard och påverkar inte färgtemat.
- Under **Din arbetsdag** väljer teknikern vilken sida som öppnas efter inloggning (Översikt, Mina ärenden eller, för koordinatorer, Koordinatorkön) och kan dölja nyckelrutorna på startsidan. Ärendekoordinatorn väljer vilket urval kön visar först. En länk med uttryckligt urval gäller alltid.
- **Återställ till standard** återställer startsidan, kön och listorna men behåller tema, dekoration och språk. Alla nya val har dagens beteende som standard.
- Superadmin kan låta säsongsutseendet för startsidan och kundportalen följa både årstider och högtider automatiskt med läget **Automatiskt efter årstid och högtider**.
- Inga databasmigreringar. Uppgradera med uppgraderingspaketet och följ [uppgraderingen till 2.0.1](docs/upgrade_to_2_0_1.md).

Se [versionsnyheterna](release-notes/2.0.3.md).

## Nytt i 2.0.2

- Tekniker kan under **Inställningar** välja om **Teamets senaste** ska visas under **Mina ärenden** på startsidan. Delen visas som standard; när den döljs ligger Mina ärenden kvar oförändrat.
- Tekniker kan välja att menyns siffror vid **Översikt** och **Ärenden** bara räknar ärenden som är tilldelade dem, i stället för hela teamets öppna ärenden. Valet är avstängt som standard och siffrorna i den utfällda ärendemenyn påverkas inte.
- Båda valen är personliga, fungerar i både modern och klassisk teknikervy och påverkar inte ärendekoordinatorns meny.
- Inga databasmigreringar. Uppgradera med uppgraderingspaketet och följ [uppgraderingen till 2.0.1](docs/upgrade_to_2_0_1.md).

Se [versionsnyheterna](release-notes/2.0.2.md).

## Nytt i 2.0.1

- Egna text- och länkpaneler skapas som `addon.json`, med exempel, schema och CLI-stöd. Superadmin kan validera, förhandsvisa på svenska/engelska/norska, importera inaktivt och uttryckligen aktivera en version.
- Paneler stöds på publik startsida, kundöversikt och teknikeröversikt. Teknikerpanelen fungerar i både klassisk och modern vy. Kundpaneler är gemensamma för kundkonton över företagsgränser och ska inte innehålla konfidentiella uppgifter.
- Versionsbyte, återgång, avstängning, borttagning av inaktiva versioner och tydliga lagringsfel underlättar administrationen.
- Körbara PHP-/Twig-addons från ZIP är avvecklade. JSON-formatet kör ingen kod, laddar inga egna filer och får ingen databas-, API- eller nätverksåtkomst.
- Utökad nyhetsredigering och telefonstöd är inbyggda funktioner med reglage under **Funktioner**. Tidigare val, innehåll och historik bevaras.
- SupportDesk med AnyDesk-/TeamViewer-genvägar och inställningsyta är borttaget. Företagens supportkort med QR och PDF/SVG-export finns kvar.
- Uppdateringskommandot förladdar relevanta konsollyssnare före cachebyte. Äldre redan startade uppdateringsprocesser behöver fortfarande kontrolleras enligt uppgraderingsguiden.

Se [versionsnyheterna](release-notes/2.0.1.md), [guiden för egna addons](docs/addons.md), [teknisk tilläggsguide](docs/addon_build_and_release_guide.md) och [uppgradering till 2.0.1](docs/upgrade_to_2_0_1.md).

Verifierat för funktionskoden: **1 289 tester / 29 047 assertions**, inga fel och ett överhoppat PDF-textprov som kräver ett externt verktyg. Visuella snapshots ingår inte i standardsviten. NAS-uppgradering är bekräftad; separat Debian-test täcker webbuppdatering, rollkonton, tilläggens livscykel, funktionsreglage och isolerad återläsning av SQL och filer. Riktig e-post, produktions-HTTPS och last måste verifieras i respektive miljö.

## Nytt i 2.0.0

- Ny responsiv design för publika sidor, kundportal, tekniker, ärendekoordinator och administration.
- Tydligare ärendelistor, sökning, företagsmärken och kundens nästa steg. Privatkunder kan skapa ärenden utan företagskoppling.
- Personliga färgteman fungerar i personalportalerna. Publika sidor bevarar installationens profilfärger och kan följa enhetens ljusa/mörka tema; admin kan stänga av systemtemat och diskreta högtidsinslag.
- Tekniker och koordinatorer kan välja klassisk eller ny layout när superadmin aktiverar **Portalens layout**. Kunden använder den nya portalen med egna färgteman.
- Tydligare textredigerare: grundverktygen är synliga, fler verktyg är hopfällda och hela verktygsfältet kan döljas.
- Företagsbundna supportkort med återkallelig QR-länk och PDF/SVG-export, internrapporter och läsande versionsavisering från officiella stabila releaser.
- Enklare installationsguider för Debian 13 och NAS samt rättning av uppdateringens slutregistrering efter cachebyte.
- Befintliga konton, ärenden, mejlinställningar, profilfärger och privata miljöfiler ska bevaras vid uppgradering. Bevara även `APP_SECRET` och separata krypteringsnycklar. Använd **upgrade-paketet**, aldrig färskinstallation på befintliga data.

Se [releaseinformationen för 2.0.0](release-notes/2.0.0.md), [installationsguiden](INSTALL.md) och [uppgraderingschecklistan](docs/upgrade_to_2_0_0.md).

Verifierat: **1 238 automatiska tester / 28 859 assertions**, följt av riktade releaseprov, samt roll- och webbläsarprov med syntetiska data. Riktig e-post, HTTPS och full backupåterställning ingick inte i releaseacceptansen och måste verifieras i respektive driftmiljö. Detta ska inte förväxlas med ett intyg om färdig produktionskonfiguration.

## Skärmbilder

Driftpunkt 2.0.0 med syntetiska demonstrationsuppgifter. Bilderna visar det faktiska gränssnittet; färger och innehåll kan anpassas per installation.

![Driftpunkt 2.0 – startsidan](docs/public-assets/screenshots/homepage.png)

| Kundens översikt | Ärende och konversation |
| --- | --- |
| ![Kundportal](docs/public-assets/screenshots/customer-portal.png) | ![Kundens ärendevy](docs/public-assets/screenshots/customer-ticket.png) |

| Teknikerns arbetsyta | Teknikerns ärendekö |
| --- | --- |
| ![Teknikeröversikt](docs/public-assets/screenshots/technician-overview.png) | ![Teknikerärenden](docs/public-assets/screenshots/technician-tickets.png) |

| Ärendekoordinator | Administration |
| --- | --- |
| ![Koordinatorportal](docs/public-assets/screenshots/coordinator-portal.png) | ![Adminöversikt](docs/public-assets/screenshots/admin-dashboard.png) |

<details>
<summary>Visa publika sidor och mobilvy</summary>

| Driftstatus | Kontakta support |
| --- | --- |
| ![Driftstatus](docs/public-assets/screenshots/public-status.png) | ![Kontakt](docs/public-assets/screenshots/contact-page.png) |

| Kundportal på mobil | Underhållsläge |
| --- | --- |
| ![Mobil kundportal](docs/public-assets/screenshots/customer-mobile.png) | ![Underhållsläge](docs/public-assets/screenshots/maintenance-mode.png) |

</details>

## Nytt i 1.0.133

- Tio Symfony-komponenter uppdateras till 8.1.11 med säkerhetsrättningar från den 4 november 2026. Cacheuppvärmningen vid installation och uppgradering får en separat minnesbudget på 512 MB.

- Kundens sökning från översikten omfattar företagets och underbolagens tillgängliga ärenden när företagsvyn är aktiverad.
- Utvalda kunder kan hantera datorlistan, med arkivering som bevarar historiken. Koordinatorer kan tilldelas ärenden och välja att ta ansvar när de skriver kundsynliga kommentarer.
- Läsare för EML/MSG och nästlade mejl, PDF-visning, inklistrade CID-bilder, vanliga filer i winmail.dat samt separata länkade ärenden från bifogade mejl.
- Bilagefel visas tydligt och originalmejlet kan vidarebefordras till koordinatorn med återförsök och loopskydd.
- Tydligare interna ärendevyer med mottagningsinformation, mejlkopplingsorsak, behörighetsstyrda dubblettförslag, kompaktare bilagor och planerade mejlmottagare. Granskningen visar en sammanfattning och stoppar fel kund-/företagskombination.
- Koncernansvariga kunder kan få separat läsåtkomst till alla kundsynliga ärenden i hela underbolagsträdet, även privata och avslutade ärenden. Interna ärenden och interna anteckningar förblir dolda.
- Tre nya migrationer jämfört med 1.0.132: `Version20261105120000`, `Version20261105130000` och `Version20261105140000`. Se [releaseinformationen](release-notes/1.0.133.md) för uppgraderingskrav och efterkontroller.

## Koncernansvarigs åtkomst till privata ärenden

Superadmin kan under **Företag → Företagsärenden i kundportalen** ge en utvald kundanvändare på moderbolaget läsåtkomst till alla kundsynliga ärenden i hela underbolagsträdet, även privata ärenden och avslutade ärenden. Underbolagen behöver inte aktiveras ett i taget. Interna ärenden och interna anteckningar visas aldrig. Den nya tilldelningen utökar inte skrivbehörigheter och kräver migrationen `Version20261105140000` före användning. Se [koncernansvarigs läsåtkomst](docs/company_hierarchy_ticket_access.md).

## Förbättrad mottagning och intern ärendevy

Tekniker och koordinatorer ser nu samlad mottagningsinformation, sparad orsak till mejlkoppling och bilagevarningar högt upp i ärendet. Möjliga dubbletter föreslås inom samma företag och befintlig läsbehörighet; sammanslagning görs fortsatt manuellt. Konversation, bilagor och svarsruta har tydligare presentation med planerade mejlmottagare. Admin och koordinator får en sammanfattning före godkännande av mejlgranskning, och felaktig kombination av kund och företag stoppas på serversidan. Inga nya migrationer eller beroenden tillkommer för dessa förbättringar. Se [mottagning och intern ärendevy](docs/ticket_intake_and_presentation.md).

## Nytt i 1.0.132

- Kunder kan välja språk högst upp på alla sidor i kundportalen. Det aktiva språket markeras tydligt och valet sparas på kontot till nästa inloggning. Samma val styr språket i kundens mejl.
- Kundportalen är översatt till engelska och norska, inklusive ärendeformulär, ärendevy, säkerhetssida, statusar, aktivitetshistorik, inventarielistor, kommentarseditor, filväljare samt fel- och bekräftelsemeddelanden.
- Tecken utanför ASCII i inbäddad CSS och JavaScript skrivs inte längre om till HTML-entiteter på engelska och norska sidor. På äldre libxml, bland annat i Docker-imagen, kunde `&#9662;` visas i stället för menypilen.
- Språknamnen i språkväljarna visas alltid på sitt eget språk.
- Ingen ny databasmigration tillkommer jämfört med 1.0.131. Se [releaseinformationen för 1.0.132](release-notes/1.0.132.md).

## Nytt i 1.0.131

- Ärenden kan ha ett frivilligt kontakttelefonnummer. Kunden anger det på nytt ärende och kan ändra det på sitt eget ärende, numret förifylls från kundens senaste ärende och det publika formuläret sparar det i samma fält i stället för i beskrivningen. Koordinatorn kan ange det på telefonärenden.
- Tekniker och koordinatorer ser numret som en klickbar telefonlänk och kan ändra det på ärendet. Kollegor som ser ett delat företagsärende ser inte numret.
- Kritiska, höga och låga ärenden markeras tydligt i tekniker- och koordinatorvyerna. Normala, lösta och stängda ärenden samt kundvyer markeras inte.
- Kommentarseditorn har grupperade knappar med text och nya val för understruken, genomstruken, gul överstrykning och skiljelinje. Kodknapparna visas bara för tekniker.
- Värden i portalens CSV-exporter som börjar med `=`, `+`, `-` eller `@` får en inledande apostrof så att kalkylprogram inte kör kundtext som formler.
- `symfony/mime` uppdateras till 8.1.10, som rättar sårbarheten CVE-2026-45070 (injektion i e-postheaders).
- Ny databasmigration tillkommer jämfört med 1.0.130: `Version20261030120000` lägger till den frivilliga kolumnen `tickets.contact_phone`. Se [releaseinformationen för 1.0.131](release-notes/1.0.131.md).

## Nytt i 1.0.130

- Kundportalens **Företagets ärenden**: sammanfattningskorten följer valt företag och kortet för öppna ärenden visar hur många som väntar på kund. Tomt läge länkar till stängda ärenden när sådana finns.
- Företagsöversikten sorteras så att företag med ärenden som väntar på kund eller är öppna visas först, och visar summor inklusive underbolag.
- Sökbart företagsval, företagsnamn i ärenderaderna och export av den filtrerade listan som CSV. Valda filter sparas i sessionen och senast använda företag är förvalt när ett nytt ärende skapas. Företagsvalet vid nytt ärende visar hela hierarkin.
- Svar från kunder läggs som tidigare på det befintliga ärendet när ärendenumret finns i ämne eller text, eller när ämnet entydigt matchar ett aktivt ärende hos företaget. En känd kund som svarar (SV:/RE:) utan att svaret kan kopplas till något ärende får nu ett vanligt nytt ärende i stället för ett utkast i granskning. Matchar ämnet flera aktiva ärenden gissar systemet inte, utan mejlet går till granskning.
- Ärendekoordinatorn notifieras för alla typer av mejlgranskning, även när avsändaren är känd, på samma sätt som för nya ärenden som behöver tilldelas. Granskningen anger varför automatisk kundregistrering inte skedde.
- Radbrott som webbläsaren lägger i `div`-element behålls när kommentarer sparas och i kundmejl.
- Ingen ny databasmigration tillkommer jämfört med 1.0.129. Se [releaseinformationen för 1.0.130](release-notes/1.0.130.md).

## Nytt i 1.0.129

- Kunder, tekniker och ärendekoordinatorer kan bifoga flera filer samtidigt när de skapar ärenden eller skriver kommentarer, även i det publika ärendeformuläret. Varje fil valideras för sig och dubbletter hoppas över.
- Ny filväljare som tydligt visar att flera filer kan väljas, listar valda filer med storlek, låter användaren lägga till fler eller ta bort enskilda filer och stöder dra och släpp.
- ZIP-filer är alltid tillåtna som bilagor oavsett konfigurerad filtypslista, men får vara högst 1 MB. Övriga filer följer fortsatt gränsen per fil.
- Ärendekoordinatorer kan öppna originalmejlet på ärendesidan, som tekniker redan kunde, med nedladdning av `.eml`.
- Ingen ny databasmigration tillkommer jämfört med 1.0.128. Se [releaseinformationen för 1.0.129](release-notes/1.0.129.md).

## Nytt i 1.0.128

- Symfony uppdateras till 8.1.9 tillsammans med totalt 56 patchuppdateringar av Composer-paket, inklusive säkerhetsrättningar i HttpFoundation och YAML.
- Servern måste använda PHP 8.4.27+ inom 8.4-serien eller PHP 8.5.12+ inom 8.5-serien. PHP-motorn ska uppdateras och verifieras före uppgraderingspaketet; apppaketet uppdaterar inte serverns PHP.
- Docker använder PHP 8.4.27 och kontrollerar PHP-versionen vid bygge. Både webb och schemaläggare behöver återskapas med den uppdaterade imagen.
- Debian-installationen och driftguiderna beskriver PHP-uppdatering, omstarter och separata kontroller av CLI respektive webbserverns PHP.
- Ingen ny databasmigration tillkommer jämfört med 1.0.127. Befintlig miljökonfiguration och `APP_SECRET` ska bevaras.

Applikationsändringarna har verifierats med 859 tester och 8 966 assertions på PHP 8.4.27. Se [releaseinformationen för 1.0.128](release-notes/1.0.128.md) för serverförberedelser, uppgraderingsordning och efterkontroller, samt [testning och kvalitet](docs/testing_and_quality.md) för verifieringen.

## Nytt i 1.0.127

- Ärendekoordinatorer kan stänga aktiva och lösta ärenden direkt på ärendesidan, även när ärendet saknar tilldelad tekniker. En lösning krävs. Status blir **Stängd**, stängningstid registreras och inget kundmejl skickas.
- Sparad lösning visas i en separat läsvy, även efter stängning. Ett redan stängt ärende ändras inte vid upprepad stängning. Befintlig återöppning med intern orsak finns kvar.
- Ärendekoordinatorer kan ändra prioritet utan att ändra status, lösning, tilldelning eller SLA-policy.
- Stängning och prioritetsändringar loggas med användare och före-/eftervärden i ärendehistoriken. Åtgärderna kräver koordinatorbehörighet och giltigt CSRF-skydd. Sammanslagna källärenden är fortsatt skrivskyddade; ändringar görs i huvudärendet.
- Koordinatorguiden beskriver de nya åtgärderna på svenska, engelska och norska. Ingen ny databasmigration tillkommer jämfört med 1.0.126.

Releasekontrollen omfattade 859 tester. Två datumkänsliga MFA-tester korrigerades till kalenderdagar, varefter samtliga 18 MFA-tester passerade vid omkörning. Övriga 857 tester passerade i den fullständiga körningen. Se [testning och kvalitet](docs/testing_and_quality.md) för resultat och [releaseinformationen](release-notes/1.0.127.md) för driftkrav och efterkontroller.

## Nytt i 1.0.126

- Vidarebefordrade mejl (`Fwd:`, `FW:`, `VB:`) och vidarebefordrade studsrapporter behåller det vidarebefordrade innehållet under kundens egen text. Kundens signatur tas fortfarande bort.
- Studskopior klipps vid "This is a copy of the message", så råa headers och kodade meddelanden hamnar inte i ärenden. Outlooks varningsbanner "Du får inte ofta e-post från…" och kvarblivna streckrader före signaturen tas bort.
- Tekniker kan öppna **Visa originalmejl** under ärendebeskrivningen och ladda ner hela mejlet som `.eml`. Mejl från sammanslagna ärenden tas med. Samma visning finns i **Okända ärenden**.
- Loopskydd: autosvar, frånvaromeddelanden och studsar blir inte ärenden utan loggas som **Automatiskt mejl ignorerat**. Larm och andra automatiska utskick blir ärenden men får ingen bekräftelse. Bekräftelser skickas med `Auto-Submitted: auto-replied` och högst 5 per avsändare och timme.
- `app:mail:ingest <inkorg> --eml <fil>` läser in en sparad `.eml`-fil genom den vanliga parsern.
- Databasmigrationen `Version20261008120000` lägger till `original_body`, `raw_message_path` och `automatic_kind` på `incoming_mails`.

Releasen har verifierats med 847 tester och 8 510 assertions. Se [releaseinformationen](release-notes/1.0.126.md) för driftkrav och efterkontroller.

## Nytt i 1.0.125

- Företagsbadges visar symbol och företagsnamn utan det synliga prefixet `Företag:`.
- Nya granskningsutkast från okända mejlavsändare skickar en notis enligt triageinställningarna, med avsändare, inkorg, granskningsorsak och länk till rätt utkast under **Okända ärenden**.
- Utskicksfel och saknade eller avstängda mottagare loggas under `unknown_sender_review_created`. Utkastet finns kvar även om mejlet inte kan skickas.
- Befintliga utkast får ingen retroaktiv notis. Misslyckade utskick försöks inte automatiskt igen.
- Företag kan ha egna e-postdomäner. En moderbolagsinkorg kan då koppla okända avsändare och automatiskt registrerade kunder till rätt dotterbolag.
- Bilagor i interna kommentarer skyddas från kundåtkomst och mejlsvar följer portalens behörighetsregler.
- Inloggning och MFA har kontobaserade försöksgränser. Publika formulär har en extra IP-gräns, och utdataescapning, filändelser samt hantering av felutdata vid databasbackup och återställning har förbättrats.
- Databasmigrationen `Version20261001120000` lägger till företagens e-postdomäner.

Releasen har verifierats med 830 tester och 8 465 assertions. Installations- och uppgraderingspaketens innehåll, checksummor och produktionscache har kontrollerats. Se [testning och kvalitet](docs/testing_and_quality.md) för testmiljö och omfattning samt [releaseinformationen](release-notes/1.0.125.md) för driftkrav och efterkontroller.

## Nytt i 1.0.124

- Tekniker och ärendekoordinatorer kan spara en säker personlig signatur som endast läggs i kundmejl, inte i ärendehistoriken.
- Superadmin kan slå på eller stänga av personliga e-postsignaturer globalt under **Systeminställningar → Ärenden & filer**. Sparade signaturer bevaras när funktionen är av.
- Vid kundsvar går det att skicka en separat, loggad kopia till den egna kontoadressen.
- Företag visas med en gemensam tydlig badge i relevanta tekniker- och koordinatorvyer.
- Databasmigration krävs för de nya signaturfälten.

## Nytt i 1.0.123

- **Mina kundansvar** är avstängt som standard för alla tekniker.
- Tekniker kan aktivera visningen individuellt under **Inställningar → Teknikeröversikt**.
- Inställningen sparas per tekniker och kräver ingen databasmigration.

## Nytt i 1.0.122

- Företagskoncerner kan ha en huvudansvarig tekniker och flera medansvariga tekniker.
- Ansvarsteamet prioriteras vid tilldelning och visas på teknikerns startsida.
- Internrapportering accepterar nu endast fel och förbättringsförslag; äldre rapporter av typen saknad kund bevaras.
- Databasmigration krävs för ansvarsteamet.

## Nytt i 1.0.121

- Uppdaterarens obligatoriska och manuella cachesteg använder Symfonys `cache:clear` med uppvärmning i produktionsläge. Direkt radering av den aktiva cachekatalogen med `rm -rf` har tagits bort.
- Composer-låsfilens innehållshash är synkroniserad med versionen utan ändrade beroendeversioner.
- Ingen ny databasmigration tillkommer jämfört med 1.0.120. Om dess migration redan lyckats körs den inte igen.

## Nytt i 1.0.120

- Företagsinkorgar kan automatiskt registrera nya kundpersoner från tillåtna avsändardomäner och skapa privata ärenden.
- Superadmin kan välja **Behåll tidigare mejlhantering** för ett företag och hela dess underföretagsträd. Undantaget har företräde över inkorgarnas automatik.
- Automatiskt skapade mejlkunder får ingen portalåtkomst förrän administratören aktiverar den separat.
- Transaktioner, gemensamt lås och granskningsloggar skyddar mejlregistreringen vid samtidiga körningar och fel.
- Företagsspecifika namn och domäner har ersatts med neutrala uppgifter i testdata och avtalsgeneratorer; mejlparserns företagsspecifika specialregler har tagits bort.
- Databasmigration krävs. Automatiken är avstängd som standard och befintliga konton behåller sin portalåtkomst. Se [konfigurationsguiden](docs/automatic-mail-customer-registration.md).

## Nytt i 1.0.119

- Teknikerportalen har en ny separat kö, **Extra tekniker**, med direktlänk och egen räknare i sidomenyn.
- **Mina ärenden** visar nu ärenden där teknikern är huvudansvarig, medan **Extra tekniker** visar ärenden där teknikern är extra tilldelad.
- Den nya kön finns även bland snabbfiltren och har egen rubrik och förklarande text på svenska, engelska och norska.
- Ingen databasmigration krävs. Cache refresh och PHP/OPcache-reload rekommenderas efter applicerad uppdatering.

## Nytt i 1.0.115

- MFA är fortsatt frivilligt som standard. Uppgraderingen gör inte MFA obligatoriskt för någon roll eller befintlig användare.
- Superadmin kan under **Inställningar → Åtkomst → MFA-policy** styra tillgänglighet och krav separat för alla sex roller, med individuell aktiveringsfrist på 14 dagar.
- Betrodda enheter kan stängas av eller gälla 1, 7, 14 eller 30 dagar. Standard för nya cookies är 14 dagar; befintliga sjudagarscookies behåller sin ursprungliga sluttid.
- MFA-krypteringsnyckeln genereras, importeras och roteras i superadminvyn och omsluts med en säker `APP_SECRET`. `DRIFTPUNKT_MFA_SECRET_KEY` används inte längre.
- Nyinstallation skapar aldrig användarkonton. Det första superadminkontot skapas separat med dold lösenordsinmatning.
- Bilagevisning, CSV-export, rate limiting, inventariedatum, planerat underhåll, schedulerlås, processtimeouter och mobil-/PWA-läge har säkerhets- och stabilitetskorrigerats.

## Nytt i 1.0.114

- Dator-, skrivar-, skärm- och kortterminallistor visar nu endast de viktigaste arbetskolumnerna direkt, vilket ger bättre läsbarhet utan trånga och kraftigt radbrutna rubriker.
- Varje inventarierad öppnas med **Visa detaljer** för övriga sparade fält. Detaljerna kan döljas igen utan att lämna listan.
- Datorer och skärmar har ett frivilligt ordernummer för koppling till externa order- eller inköpssystem. Ordernumret är sökbart och följer med import och export.
- Flera skärmar får använda samma serienummer vid manuell registrering och CSV-import, medan dubblettskyddet ligger kvar för datorers hostname, skrivares IP-adress och kortterminalers terminal-ID.
- All befintlig information är fortsatt tillgänglig i detaljvyn och redigeringen. Sökning, sortering, CSV- och Excel-export använder fortsatt hela datamängden.
- Utskriftsläget inkluderar automatiskt detaljinformationen även när detaljerna är stängda på skärmen.
- En bakåtkompatibel databasmigration lägger till det frivilliga ordernumret utan att ändra befintliga inventarier. Cache refresh och PHP/OPcache-reload rekommenderas efter applicerad uppdatering.

## Nytt i 1.0.113

Version 1.0.113 är verifierad och driftsatt. Databasmigrationerna är uppdelade i ett schema- och ett datasteg så att uppdateringen kan köras säkert även om ett tidigare uppdateringsförsök redan hunnit skapa delar av schemat.

- Dator-, skrivar-, skärm- och kortterminalinventarier har fått strukturerade snabbval, tydligare statusar och bakåtkompatibel hantering av redan sparade värden och äldre CSV-rubriker.
- Datorinventeringen skiljer på enhetstyp, användare, inloggningsnamn och placering. Äldre OS-värden bevaras och utgångna Windows-generationer varningsmarkeras.
- Skärminventeringen har snabbval för storlek, upplösning, primär anslutning och driftstatus.
- Skrivarlistan har skrivartyp, fabrikat, utskriftstyp, anslutning, IP-adress/hostname, toner-/bläckmodell och tydlig status. Dubbletter av IP-adresser blockeras fortsatt per kundlista.
- Kortterminaler och basstationer kan registreras med enhetstyp, namn, område, basstationsuppgifter, anslutningssätt, Pay@Table och administratörskort.
- Teknikers **Inventarielistor** och ärendekoordinators **Företagsdata** använder nu en kompakt, responsiv företagsmatris med totalsummor, typfilter, innehållssökning, sortering, nyligen öppnade listor och bevarad navigeringskontext.
- En bakåtkompatibel databasmigration lägger till de nya inventariefälten och översätter tidigare booleanvärden för trasig/tillgänglig till de nya statusarna utan att radera inventariedata.

## Nytt i 1.0.112

- Nuvarande ansvarig tekniker kan lämna över ett ärende direkt till en annan aktiv tekniker. Överlämningen uppdaterar ansvarigt team, tar bort eventuell dubbel extra tilldelning, revisionsloggas och aviserar den nya ägaren.
- Sammanslagna källärenden, inaktiva mottagare och manipulerade överlämningar blockeras av serverns behörighets- och CSRF-kontroller.
- Kundstyrda inventarielistor finns nu även för skärmar och kortterminaler med samma aktivering, användarstyrda läsbehörighet, teknikerredigering och koordinatorläge som datorer och skrivare.
- Skärmar kan registreras med användare/avdelning, placering, fabrikat, modell, serienummer, storlek, upplösning, anslutning, felstatus och kommentar.
- Kortterminaler kan registreras med terminal-ID, leverantör, modell, serienummer, placering, anslutning, driftstatus, kommentarsfält och en separat kryssruta för **Pay@Table (bordsbetalning)**.
- De nya listorna stöder sökning, sortering, utskrift, CSV-import samt CSV- och Excel-export. Serienummer är unikt per skärmlista och terminal-ID per kortterminallista.
- En ny databasmigration lägger till de nya inventariefälten utan att konvertera eller radera befintliga inventarier. Cache refresh och PHP/OPcache-reload rekommenderas efter applicerad uppdatering.

## Nytt i 1.0.111

- Tekniker- och kundvyn visar nu det senast sparade svaret överst och därefter äldre kommentarer nedåt. Koordinatorvyn behåller samma nyast-först-princip.
- Kundens svarspanel ligger före konversationen på ärendedetaljen, så kunden kan svara utan att först bläddra genom hela dialogen.
- Bilagor och externa delningslänkar ligger i en kompakt utfällbar del i kundens svarspanel.
- Kunden kan öppna **Visa hela ärendehistoriken** för kundtillåtna aktivitetsposter, medan samtliga kundsynliga kommentarer fortsatt visas i dialogen och interna kommentarer alltid förblir dolda.
- Superadmins interna rapportlista döljer automatiskt rapporter med status **Klar**. De ligger kvar och kan visas med filtret **Visa klara**, medan öppna rapporter och misslyckade e-postleveranser fortsatt syns för uppföljning.
- Ett skickat kundsvar leder fortsatt direkt till den sparade kommentaren via dess stabila ankare.
- Logotypen på inloggnings-, MFA-, registrerings- och lösenordsåterställningssidorna visas på en ljus, lätt upphöjd yta så att den förblir tydlig mot toppraden oavsett logotypens färger.
- Ingen ny databasmigration krävs. Cache refresh och PHP/OPcache-reload rekommenderas efter applicerad uppdatering.

## Nytt i 1.0.110

- Kundens ärendedetalj visar en tydligt rubricerad kronologisk konversation med alla kundsynliga portal- och mejlsvar, medan interna kommentarer fortsatt är dolda.
- Kundens egna svar markeras som **Du**, och ett skickat portalsvar leder direkt till den sparade kommentaren utan att sidan automatiskt hoppar förbi konversationen.
- Koordinatorns siffror för **Ej tilldelade**, **Tilldelade**, **Under arbete**, **Övriga kunder** och **Avslutade ärenden** använder samma serverberäknade underlag på alla koordinatorsidor, inklusive nollvärden.
- **Okända ärenden** heter nu **Övriga kunder** och granskningssidans introduktion beskriver tydligt hur avsändaren kopplas, godkänns eller avvisas.
- Rubriken **Sammanslagna källärenden** har förenklats till **Sammanslagna ärenden**. Den befintliga säkra länkningsmodellen och all historik bevaras oförändrade.
- Superadmin kan placera startsidans logotyp i den blå toppraden, till vänster på det ljusa fältet eller centrerad ovanför välkomsttexten. Innehållsfattiga startsidor använder samtidigt en bättre balanserad kompakt layout.
- Den separata flikikonen kan fortsatt bytas oberoende av logotypen, och adminhjälpen förklarar att den används i webbläsarflikar och bokmärken.
- Säsongsutseendet är nu tydligare men fortsatt statiskt och bildfritt, med korrigerad lagerordning och en direkt förhandsvisning i administrationen.
- Ingen ny databasmigration krävs. Cache refresh och PHP/OPcache-reload rekommenderas efter applicerad uppdatering.

## Nytt i 1.0.109

- Ärendekoordinatorns sidomeny visar samma menyval i samma ordning på översikten, nytt ärende, ärendedetaljer, okända ärenden och rapporter.
- **Okända ärenden**, **Tilldelade** och **Under arbete** försvinner inte längre vid navigering mellan koordinatorns sidor.
- Antalet vid **Avslutade ärenden** använder samma globala koordinatoromfattning på alla sidor och räknar både lösta och stängda ärenden.
- Ett nytt säkert underhållskommando kan förhandsvisa och ta bort gamla `[Utkast]`-/`[Draft]`-prefix från avslutade ärenden. Väntande granskningar hoppas alltid över och sparning kräver ett uttryckligt urval.
- Ingen ny databasmigration krävs. Cache refresh och PHP/OPcache-reload rekommenderas efter applicerad uppdatering.

## Nytt i 1.0.108

- Teknikerns ärendedetalj är ombyggd till en fokuserad tvåkolumnsvy med svar och konversation i huvudytan samt status, lösning, ansvar och metadata i en kompakt sidokolumn.
- Lösningen kan uppdateras och revisionsloggas utan statusbyte. Kundmejl skickas fortsatt endast vid faktisk övergång till **Löst**.
- Teknikerns **Mina ärenden** har tydligare snabbsökning, statusgenvägar och ärenderader så pågående arbete blir lättare att hitta utan att lämna avgränsningen till egna ärenden.
- Menyalternativet **Rapportera** ligger kvar när tekniker och ärendekoordinatorer navigerar mellan portalens sidor.
- Kundportalen har personliga val för systemtema, ljust, mörkt och högkontrasttema samt en förenklad meny med tydligare genväg för att skapa ärende.
- Superadmin kan aktivera ett tydligt men lugnt, statiskt säsongsutseende på startsidan, i kundportalen, på båda platserna eller ingenstans och se en direkt förhandsvisning före aktivering. Funktionen är avstängd som standard och använder inga bilder eller animationer.
- Språkväljaren för oinloggade behåller sin diskreta fasta placering även när säsongsutseendet är aktivt.
- Databasmigration krävs för kundportalens personliga utseendeinställningar. Cache refresh och PHP/OPcache-reload rekommenderas efter applicerad uppdatering.

## Nytt i 1.0.107

- Superadmin kan styra exempeltexter separat för tekniker, ärendekoordinatorer och kunder; samtliga val är avstängda som standard.
- Koordinatorns och teknikerns väljare för extra tekniker är kompaktare, och koordinatorns högerspalt visar tilldelning först samt sammanslagning sist.
- Teknikerns vy **Mina ärenden** har samma fullständiga, hopfällbara filtrering som ärendeöversikten och behåller avgränsningen till egna ärenden.
- Okända inkommande avsändare får en okopplad skuggperson och ett tydligt `[Utkast]`-ärende som väntar på säker granskning.
- Ärendekoordinatorer har fått en separat behörighetskontrollerad kö där okända ärenden kan godkännas eller avvisas utan åtkomst till mailservrar, OAuth eller övrig adminadministration.
- Godkännande tar bort utkastsprefixet och bevarar valda kund-, företags-, tilldelnings- och dirigeringsuppgifter; avvisning revisionsloggas och rensar endast en fortfarande okopplad e-postskuggperson.
- Databasmigration krävs för klassificering av granskningsposter. Cache refresh och PHP/OPcache-reload rekommenderas efter applicerad uppdatering.

## Nytt i 1.0.106

- Kundportalens toppfält har nu en alltid synlig och tydligt märkt **Logga ut**-knapp bredvid användarmenyn.
- Utloggning finns även kvar i användarmenyn så funktionen är lätt att hitta både på desktop och mobil.
- Toppfältets lagerordning är korrigerad så den utfällda användarmenyn visas ovanpå portalens innehåll.
- Ett funktionellt regressionstest säkerställer att den direkta utloggningslänken finns på kundsidorna.
- Ingen ny databasmigration krävs jämfört med 1.0.105.
- Cache refresh och PHP/OPcache-reload rekommenderas efter applicerad uppdatering.

## Nytt i 1.0.105

- Företagets ärenden visar nu totalsiffror för öppna, väntande och stängda ärenden före filtren.
- Statusflikar, sökning och företagsval ligger före företagskatalogen så kunden når ärendelistan utan att först scrolla genom samtliga företag.
- Företagskatalogen är kompakt och utfällbar, har lokal företagssökning och begränsad höjd.
- Företag utan ärenden döljs som standard men blir sökbara och kan visas med ett uttryckligt val.
- Den valda företagsraden markeras tydligt och företagens statusräknare fortsätter öppna förfiltrerade listor.
- Kundportalens innehåll har fått en begränsad läsbredd för bättre överblick på stora och högupplösta skärmar.
- Svenska, engelska och norska texter samt funktionella regressionstester är uppdaterade.
- Ingen ny databasmigration krävs jämfört med 1.0.104.
- Cache refresh och PHP/OPcache-reload rekommenderas efter applicerad uppdatering.

## Nytt i 1.0.104

- Kundportalens startsida utgår konsekvent från kundens egna ärenden och skiljer dessa från företagets ärenden.
- Startsidan prioriterar väntande återkoppling, har ärendesökning över både aktiva och avslutade egna ärenden och visar en kompakt personlig sammanställning.
- Behöriga företagskunder får en hierarkisk företagsöversikt med öppna, väntande och stängda ärenden samt senaste aktivitet per företag och underföretag.
- Företagsöversiktens räknare öppnar förfiltrerade listor, och det nya statusfiltret **Väntar på kund** kan kombineras med företag, sökning och sortering.
- Kundnavigeringen är förenklad, säkerhetsinställningarna ligger i användarmenyn och mobilnavigeringen är kompakt och utfällbar.
- Personliga stängda ärenden blandas inte längre med andra kundsynliga företagsärenden.
- Svenska, engelska och norska texter samt funktionella regressionstester är uppdaterade.
- Ingen ny databasmigration krävs jämfört med 1.0.103.
- Cache refresh och PHP/OPcache-reload rekommenderas efter applicerad uppdatering.

## Nytt i 1.0.103

- Utvalda huvudbolagsanvändare kan välja huvudbolaget eller ett underbolag med full moderbolagsåtkomst när de skapar ett kundärende.
- Företagsvalet valideras på serversidan och manipulerade försök att skapa ärenden för andra koncerner eller ej tillåtna underbolag nekas.
- Ärendet använder det valda företagets koppling och eventuella egna ärendeprefix, medan huvudbolagsanvändaren bevaras som beställare.
- Företagets och kundens avslutade ärendelistor visar högst 20 ärenden per sida med tydlig träff- och sidräkning.
- Listkorten är kompaktare, behåller status och viktig metadata och visar högst två rader av sammanfattningen.
- Sökning, sortering, företagsval och statusfilter bevaras när kunden bläddrar mellan sidor.
- Ingen ny databasmigration krävs jämfört med 1.0.102.
- Cache refresh och PHP/OPcache-reload rekommenderas efter applicerad uppdatering.

## Nytt i 1.0.102

- Behöriga huvudbolagsanvändare kan filtrera **Företagets ärenden** på ett specifikt huvud- eller underbolag inom den egna tillåtna företagshierarkin.
- Företagsvyn kan växla mellan öppna, stängda/lösta och samtliga ärenden utan att lämna sidan.
- Sökning och sortering kan kombineras med företags- och statusfiltren.
- Företagsfiltret visar även behöriga underbolag som saknar aktuella ärenden, men aldrig företag från andra koncerner.
- Sidomenyns räknare för öppna och stängda/lösta ärenden beräknas nu konsekvent från hela den tillåtna ärendemängden på alla kundportalsidor.
- Ingen ny databasmigration krävs jämfört med 1.0.101.
- Cache refresh och PHP/OPcache-reload rekommenderas efter applicerad uppdatering.

## Nytt i 1.0.101

- Ärendekoordinatorn kan slå samman två kompatibla aktiva ärenden genom att välja ett huvudärende och uttryckligen bekräfta åtgärden.
- Källärendet stängs och blir skrivskyddat, medan historik och bilagor bevaras och sammanslagningen revisionsloggas i båda ärendena.
- Kundsvar via källärendets tidigare portaladress eller e-postreferens styrs till huvudärendet utan automatiska sammanslagningsmejl.
- Huvudärenden med sammanslagna källärenden skyddas mot fristående radering.
- Primärt ansvarig tekniker kan lägga till och ta bort tilldelningsbara extra tekniker från teknikerportalen.
- Nytillagda extra tekniker notifieras, borttagningar skickar inget mejl och samtliga förändringar revisionsloggas.
- Utvalda kundanvändare i ett huvudbolag kan se alla kundsynliga ärenden från de underbolag som uttryckligen tillåter full moderbolagsåtkomst; andra koncerner och interna ärenden förblir dolda.
- Databasmigration krävs för den nya beständiga sammanslagningsrelationen och underbolagens nya åtkomstval.
- Cache refresh och PHP/OPcache-reload rekommenderas efter applicerad uppdatering.

## Nytt i 1.0.100

- Huvudansvarig tekniker döljs och inaktiveras i koordinatorns lista över extra tekniker.
- Om huvudteknikern ändras uppdateras extralistan direkt och en tidigare extramarkering tas bort automatiskt.
- Ärendeentiteten blockerar dubbeltilldelning även från andra kodflöden eller manipulerade formuläranrop.
- Befintliga tilldelnings-, notifierings- och koordinatorflöden har verifierats med utökade regressionstester.
- Ingen ny databasmigration krävs jämfört med 1.0.99.
- Cache refresh och PHP/OPcache-reload rekommenderas efter applicerad uppdatering.

## Nytt i 1.0.99

- Ärendekoordinatorn kan lägga till, behålla och ta bort flera extra tekniker samtidigt som en tydlig huvudansvarig tekniker behålls.
- Koordinatoröversikten visar huvudteknikerns namn och antal extra tekniker, medan detaljvyn visar samtliga namn.
- Extra tekniker väljs i en sökbar och tangentbordsanvändbar kryssrutelista som även fungerar utan JavaScript.
- Koordinatorns fritextsökning hittar ärenden via extra teknikers namn och e-postadress.
- Nytillagda extra tekniker notifieras, ändringar auditloggas och notifieringsfel loggas utan att en sparad tilldelning rullas tillbaka.
- Tilldelningsflödet avvisar inaktiva eller otillåtna användare och normaliserar dubletter samt huvudteknikern säkert.
- Svenska, engelska och norska gränssnittstexter samt funktionella regressionstester är uppdaterade.
- Ingen ny databasmigration krävs jämfört med 1.0.98.
- Cache refresh och PHP/OPcache-reload rekommenderas efter applicerad uppdatering.

## Nytt i 1.0.98

- IMAP-meddelanden identifieras med UIDVALIDITY och UID och behandlas isolerat per supportinkorg.
- Lyckade, avvisade och utkastskapande mejl flyttas till en konfigurerbar mapp för behandlade meddelanden.
- Tekniska fel får ett första försök och två senare återförsök innan mejlet flyttas till inkorgens felmapp.
- Ett trasigt mejl blockerar inte längre senare mejl eller andra kundinkorgar.
- Microsoft 365 fortsätter använda Entra/XOAUTH2 och Google Workspace kan auktoriseras med OAuth per inkorg.
- Google OAuth konfigureras valfritt av superadmin och refresh tokens krypteras automatiskt med installationens APP_SECRET.
- Databasmigration krävs för IMAP-spårning, inkorgsmappar och Google OAuth-status.
- Cache refresh och omstart av polling-worker eller PHP/OPcache rekommenderas efter uppdateringen.

## Nytt i 1.0.97

- Symfony 8.1-beroendena är uppdaterade till de senaste kompatibla patchversionerna, inklusive FrameworkBundle 8.1.4.
- DoctrineBundle är uppdaterat till 3.3.1 och Doctrine ORM till 3.6.8.
- PHPUnit och relaterade utvecklingsberoenden är uppdaterade till de senaste kompatibla versionerna.
- Transitiva paket för ramverk, Twig, Doctrine och kompatibilitet innehåller aktuella fel- och säkerhetsrättningar.
- Ingen ny databasmigration krävs jämfört med 1.0.96.
- Cache refresh och omstart av container eller PHP/OPcache rekommenderas efter applicerad uppdatering.

## Nytt i 1.0.96

- Koordinatorns tidigare arbetsfilter `Öppna ärenden` heter nu `Under arbete`, så namnet motsvarar den faktiska ärendestatus som visas.
- Koordinatorguidens beskrivningar är uppdaterade på svenska, engelska och norska för att skilja status från tilldelning.
- Det personliga portaltemat `Bordeaux` har lagts till med vinröda accenter, mörk vinröd sidomeny och ljusa rosétonade bakgrunder.
- Aktiva menyval, primära knappar, markeringar och koordinatorfält använder temats accentfärger mer konsekvent.
- Inga nya databasmigrationer krävs jämfört med 1.0.95.
- Cache refresh och PHP/OPcache-reload rekommenderas efter applicerad uppdatering.

## Nytt i 1.0.95

- Valt företag bevaras när en ärendeimport torrkörs och visas fortsatt i importformuläret.
- Företagsvalet följer med från förhandsgranskning till verkställning och sätts på samtliga importerade ärenden i batchen.
- JSON- och CSV-import använder samma företagskopplade flöde.
- Dubblettkontrollen av externreferens samt ämne och avsändare avgränsas till valt företag.
- Samma externa ärendenummer kan importeras som ett nytt ärende för ett annat företag, även när dubblettstrategin är inställd på att hoppa över dubbletter.
- Inga nya databasmigrationer krävs jämfört med 1.0.94.
- Cache refresh och PHP/OPcache-reload rekommenderas efter applicerad uppdatering.

## Nytt i 1.0.94

- E-postservrar, inkorgar och utgående profiler har fått kompakta, serverrenderade administrationslistor med sökning, filter och sidindelning om 25 poster.
- Skapa och redigera e-postkonfiguration öppnas i responsiva sidopaneler, medan leverantörsguider är stängda som standard och visas vid behov.
- Lösenord och OAuth-hemligheter skickas inte tillbaka i HTML och tomma hemlighetsfält vid redigering behåller sparade värden.
- Säker borttagning av e-postkonfiguration kräver inaktiv status och blockerar server- eller inkorgsradering när beroenden eller bevarad historik finns.
- Användaradministrationen har fått en kompakt tabell med sökning, kombinerbara filter, snabbfilter, sortering och sidindelning om 25 användare.
- Skapa, redigera, MFA-nödåtgärder och avancerad radering renderas endast för vald användare i en responsiv sidopanel.
- Användarfiltrering, räkning, sortering och paginering sker i databasen, och raderingsanalys beräknas endast för vald användare.
- Aktiva sökningar, filter, sortering och sida bevaras genom relevanta administrativa åtgärder.
- Inga nya databasmigrationer krävs jämfört med 1.0.93.
- Cache refresh och PHP/OPcache-reload rekommenderas efter applicerad uppdatering.

## Nytt i 1.0.93

- **Användare & företag** är uppdelad i fokuserade flikar för användare, företagskunder, team & roller, utseende och triage.
- Standardsidan visar endast skapande och hantering av användarkonton i stället för samtliga identitets- och utseendeinställningar samtidigt.
- Företag fortsätter ha en separat paginerad sida och nås nu tydligt från fliknavigationen.
- Vald flik sparas under admins session så formulär skickar tillbaka användaren till rätt arbetsyta.
- Superadminflikarna för företagskunder, utseende och triage är fortsatt behörighetsskyddade.
- Inga nya databasmigrationer krävs jämfört med 1.0.92.
- Cache refresh och PHP/OPcache-reload rekommenderas efter applicerad uppdatering.

## Nytt i 1.0.92

- Superadmin har fått ett separat, förenklat flöde för att skapa upp till 25 företagskunder åt gången.
- Företaget väljs en gång och samtliga skapade kundkonton kopplas automatiskt till det företaget.
- Starka tillfälliga lösenord skapas automatiskt, men superadmin kan visa, kopiera, byta eller skriva över dem före skapandet.
- Alla kundrader valideras innan något konto sparas, bland annat namn, unik e-postadress och manuellt angivet lösenord på minst 12 tecken.
- Nya konton måste byta sitt tillfälliga lösenord vid första inloggningen.
- Inga nya databasmigrationer krävs jämfört med 1.0.91.
- Cache refresh och PHP/OPcache-reload rekommenderas efter applicerad uppdatering.

## Nytt i 1.0.91

- Fel och önskemål skickas centralt med säker rapportreferens, installationsadress och sanerad käll-URL, medan saknade kunder stannar lokalt hos superadmin.
- Superadmin kan ändra central mottagare och Reply-To direkt i den operativa cockpit-vyn; värdena sparas i systeminställningarna och börjar gälla utan omstart.
- Svar från den centrala mottagaren importeras från en aktiv IMAP-inkorg till rapporttråden och notifierar rapportören.
- Misslyckade notifieringar får schemalagda och manuella återförsök, tydlig konfigurationsstatus samt säker loggning.
- Superadmin kan hämta en sanerad GitHub-mall för fel och önskemål utan rapportörens e-post, installationsadress eller käll-URL.
- Rapportinskick har rate limiting och känsliga URL-parametrar tas bort före lagring.
- Releasebyggaren kräver framöver ett sekventiellt `major.minor.patch`-steg och motsvarande release notes innan ordinarie paket kan byggas.
- Databasmigration, cache refresh och PHP/OPcache-reload krävs eller rekommenderas efter applicerad uppdatering.

## Nytt i 1.0.90

- Teknikerportalen döljer SLA-kort, köer, fält, tidslinjer, massåtgärder och SLA-texter när SLA inte är aktiverat och faktiskt används.
- Tekniker och ärendekoordinatorer har fått menyalternativet **Rapportera** för att skicka felrapporter, förbättringsförslag/önskemål och önskemål om saknade kunder.
- Rapportören kan följa status och läsa superadmins återkoppling på sina senaste rapporter.
- Superadmin ser nya interna rapporter på sin översikt och kan markera dem som nya, pågående eller klara samt lämna en intern återkoppling.
- Rapportskapande och statusändringar skrivs till systemets auditlogg.
- Databasmigration krävs för den nya tabellen `internal_reports`.
- Cache refresh och PHP/OPcache-reload rekommenderas efter applicerad uppdatering.

## Nytt i 1.0.89

- Den globala språkväljaren visas bara för utloggade besökare och döljs konsekvent efter inloggning.
- Tekniker och ärendekoordinatorer med aktiv MFA kan välja att lita på en privat enhet i sju dagar innan MFA behöver bekräftas igen.
- MFA-aktivering bekräftas med en engångskod i användarens autentiserade säkerhetssida; QR/hemlighet visas aldrig vid inloggning eller i adminlistan, och superadmin kan säkert återställa eller inaktivera MFA vid utelåsning.
- Ärendekoordinatorns ärendekort visar alltid en kort, läsbar förhandsvisning av ärendebeskrivningen.
- Koordinatorrapporter har ett tydligare arbetsflöde för rapporttyp, kund och period, med kundsäkrare rapportskapande och snabbval för datum.
- Kundrapporten kräver ett valt företag innan rapportdata, utskrift eller export visas.
- SLA-information visas och exporteras bara när SLA är aktiverat och används av det aktuella urvalet.
- Koordinatorguiden har byggts ut med direktnavigering och praktiska steg för tilldelning, öppna ärenden, kommentarstyper, avslutade ärenden och återöppning.
- Svenska, engelska och norska översättningar samt funktionella regressionstester är uppdaterade.
- Inga nya databasmigrationer krävs jämfört med 1.0.88.
- Cache refresh och PHP/OPcache-reload rekommenderas efter applicerad uppdatering.

## Nytt i 1.0.88

- Ärendebeskrivningar i teknikeröversikten, kundportalens ärendelista och ärendekoordinatorns utförliga ärendekort begränsas till en kort, enhetlig förhandsvisning.
- Förhandsvisningen normaliserar radbrytningar och överflödiga blanksteg, kapas vid ett helt ord när det är möjligt och avslutas med ellips.
- Den fullständiga ärendebeskrivningen visas fortfarande oförändrad inne i ärendets detaljvy.
- Inga nya databasmigrationer krävs jämfört med 1.0.87.
- Cache refresh och PHP/OPcache-reload rekommenderas efter applicerad uppdatering.

## Nytt i 1.0.87

- Ärendekoordinatorns aktiva ärendelistor sorteras konsekvent med senast skapade ärende först, även när äldre ärenden har högre riskpoäng eller prioritet.
- Riskmarkeringar, uppföljningspanel och riskfilter finns kvar utan att påverka den kronologiska listordningen.
- SLA-menyer, filtret `SLA-risk`, `Försenade` och tillhörande SLA-fält visas bara när SLA är aktiverat och faktiskt konfigurerat eller används av ett aktivt ärende.
- Filtret `Mina team` visas bara för ärendekoordinatorer som tillhör minst ett primärt eller extra team.
- Ärendekoordinatorn kan skicka kundsvar med mejl, lägga kundsynliga kommentarer utan mejl och skriva interna anteckningar före eller efter teknikertilldelning.
- Intern anteckning är fortsatt förvald, och kunddialog blockeras för avslutade, interna och kundlösa ärenden både i gränssnittet och server-side.
- Koordinatorflödet har regressionstest för sortering, paginering, kundmejl, statusändring, synlighet, auditlogg och manipulerade formuläranrop.
- Inga nya databasmigrationer krävs jämfört med 1.0.86.
- Cache refresh och PHP/OPcache-reload rekommenderas efter applicerad uppdatering.

## Nytt i 1.0.86

- Inkommande e-post rensar Outlook-signaturer och kampanjfotrar bättre innan ärendetexten sparas.
- Signaturloggor som ligger som inlinebilder i e-post importeras inte längre som ärendebilagor.
- Kund-, tekniker-, koordinator- och lösenordsåterställningsmail använder nu tabellbaserade HTML-mallar med Outlook-säkra knappar.
- Inga nya databasmigrationer krävs jämfört med 1.0.85.
- Cache refresh och PHP/OPcache-reload rekommenderas efter applicerad uppdatering.

## Nytt i 1.0.85

- Allmän triage-epost fungerar nu som aktivt huvudläge och inaktiverar mottagarlistan visuellt i admin.
- När allmän triage-epost sparas rensas personliga triagemottagare så nya notiser bara går till den delade inkorgen.
- Triage-notiser till den allmänna adressen fortsätter använda vanlig koordinatorlänk som kräver inloggning med eget ärendekoordinatorkonto.
- Inga nya databasmigrationer krävs jämfört med 1.0.84.
- Cache refresh och PHP/OPcache-reload rekommenderas efter applicerad uppdatering.

## Nytt i 1.0.84

- Admin kan ange en allmän triage-epost för delad koordinatorinkorg.
- När allmän triage-epost är ifylld inaktiveras den personliga mottagarlistan.
- Triage-notiser till den allmänna adressen innehåller en vanlig koordinatorlänk som kräver inloggning med eget ärendekoordinatorkonto.
- Personliga triagemottagare behåller personliga inloggningslänkar, medan fallback till aktiva ärendekoordinatorer bara används när varken mottagare eller allmän adress är vald.
- Notifieringsloggen visar utskick till den allmänna triage-adressen utan att knyta dem till en enskild användare.
- Inga nya databasmigrationer krävs jämfört med 1.0.83.
- Cache refresh och PHP/OPcache-reload rekommenderas efter applicerad uppdatering.

## Nytt i 1.0.83

- Koordinatorns formulär för nytt ärende visar `Nytt ärende` i stället för telefonärende-texter.
- Överflödiga hjälprader i koordinatorns nytt ärende-formulär är borttagna.
- Skapa-knappen i koordinatorns nytt ärende-formulär heter nu `Skapa och tilldela ärende`.
- Koordinatorns ärendedetalj visar kommentarer med senaste kommentaren överst.
- Inga nya databasmigrationer krävs jämfört med 1.0.82.
- Cache refresh och PHP/OPcache-reload rekommenderas efter applicerad uppdatering.

## Nytt i 1.0.82

- Företagsfiltret i koordinatorns öppna ärenden behåller aktuell kö när ett företag väljs.
- Företagsdropdownen i avslutade koordinatorärenden visas ovanpå sidopanelen i stället för bakom den.
- Startsidan och inloggningssidan har renare toppbar utan extra navigationsknappar.
- Inga nya databasmigrationer krävs jämfört med 1.0.81.
- Cache refresh och PHP/OPcache-reload rekommenderas efter applicerad uppdatering.

## Nytt i 1.0.81

- Ärendekoordinatorns topbar visar inte längre `Startsida` i koordinatorvyer.
- Ärendedetaljen för koordinatorn använder rubriken `Ärendebeskrivning`, mindre beskrivningstext och visar inte längre hjälpraden under rubriken.
- Koordinatorns ärendedetalj döljer ålders- och inaktivitetschippar som `Ingen aktivitet X dagar` och `Gammalt X dagar`.
- Företagsfiltret i öppna och avslutade koordinatorärenden använder samma sökbara företagsväljare som nytt ärende.
- Startsidan och inloggningssidan har renare toppbar utan extra navigationsknappar.
- Inga nya databasmigrationer krävs jämfört med 1.0.80.
- Cache refresh och PHP/OPcache-reload rekommenderas efter applicerad uppdatering.

## Nytt i 1.0.80

- Ärendekoordinatorns meny visar nu `Nytt ärende` i stället för `Nytt telefonärende`.
- Länken till nytt ärende finns kvar i koordinatorns sidomeny även från andra koordinatorvyer som guide, rapporter, företagsdata och inställningar.
- Formuläret för nytt telefonärende är renare: överflödiga hjälprader och knappen `Föreslå tekniker` är borttagna.
- Prioritet visas alltid direkt i formuläret i stället för att ligga under `Fler inställningar`.
- Kundsektionen använder tydligare rubriker: `Företag/Kund` och `Kundkontakt`.
- Inga nya databasmigrationer krävs jämfört med 1.0.79.
- Cache refresh och PHP/OPcache-reload rekommenderas efter applicerad uppdatering.

## Nytt i 1.0.79

- Superadmin kan styra om kundinloggningen ska visa rutan `Sök hjälp först`; den är avstängd som standard även när den publika kunskapsbasen är aktiv.
- Superadmin kan visa eller dölja startsidans `Behöver du hjälp?`-ruta utan att ändra hjälplänkarna som kontaktsidan använder.
- Superadmin kan visa eller dölja startsidans `Systemstatus`-ruta utan att påverka driftstatussidan eller monitorerna.
- Startsidan hanterar kombinationer där nyheter, hjälpruta och systemstatus visas eller döljs utan tomma layoutytor.
- Inga nya databasmigrationer krävs jämfört med 1.0.78.
- Cache refresh och PHP/OPcache-reload rekommenderas efter applicerad uppdatering.

## Nytt i 1.0.78

- Ärendekoordinatorns "Behöver åtgärd" är förenklat till samma arbetskö som ej tilldelade ärenden och visas som `Ej tilldelade ärenden`.
- Koordinatorns sidomeny är renare: `Översikt` visas inte längre och `Mina team` är borttaget från koordinatorns filterval.
- Signalraden under varje koordinatorärende är avstängd som standard och kan slås på i koordinatorns portalinställningar.
- `SLA-risk` och `Försenade` döljs konsekvent i koordinatorvyer när SLA inte används.
- Direkta gamla länkar till `scope=needs_attention`, `scope=sla_risk`, `scope=overdue` och `scope=my_teams` hanteras fortsatt utan att bredda startsidans standardkö.
- Inga nya databasmigrationer krävs jämfört med 1.0.77.
- Cache refresh och PHP/OPcache-reload rekommenderas efter applicerad uppdatering.

## Nytt i 1.0.77

- Ärendekoordinatorns startsida är förenklad och visar ej tilldelade ärenden som standard.
- Koordinatorsökningen söker i alla öppna ärenden när man söker utan explicit filter, samtidigt som ett valt filter fortfarande respekteras.
- Den dubblerande knappraden och den långa introduktionstexten är borttagna från koordinatorns vanliga startsida.
- Koordinatorns arbetsfilter visas som `Öppna ärenden` där knappen och menyn används, utan att ändra den interna statusen `Under arbete`.
- Inga nya databasmigrationer krävs jämfört med 1.0.76.
- Cache refresh och PHP/OPcache-reload rekommenderas efter applicerad uppdatering.

## Nytt i 1.0.76

- Releasepaketen är ombyggda från den verifierade 1.0.75-kodbasen med ny versionsmetadata för `1.0.76`.
- NAS/Docker-dokumentationen för adminuppdateringar är förtydligad: köade koduppdateringar måste plockas upp av en worker eller köras manuellt med `app:code-update:apply-run`.
- Driftstegen beskriver hur `var/` och loggfiler ägarrättas till `www-data` när en Docker-baserad testserver stoppar på skrivbehörighet i `var/log`.
- Adminytan, Composer-metadata, zip-filnamn och paketens `release-metadata.json` pekar på samma aktuella versionsnummer.
- Uppgraderingspaketet är fortsatt kumulativt och kan användas direkt från äldre Driftpunkt 1.x-installationer.
- Inga nya databasmigrationer krävs jämfört med 1.0.75.
- Cache refresh och PHP/OPcache-reload rekommenderas efter applicerad uppdatering.

## Nytt i 1.0.75

- Symfony-beroendena är uppgraderade från 8.0-serien till Symfony 8.1.
- Twig, Symfony Flex och relaterade Composer-beroenden är uppdaterade i låsfilen för den nya Symfony-versionen.
- Symfony-konfigurationsreferensen är uppdaterad för 8.1 så lokala config-kontroller matchar installerade paket.
- Testsviten är anpassad till Symfony 8.1:s aktuella testklient- och response-beteende.
- Inga nya databasmigrationer krävs jämfört med 1.0.74.
- Cache refresh och PHP/OPcache-reload rekommenderas efter applicerad uppdatering.

## Nytt i 1.0.74

- Kundunika utgående mailprofiler ärvs nu via företagshierarkin, så underbolag utan egen profil använder närmaste huvudbolags aktiva mailprofil.
- Inkommande inkorgar visar tydligare när valt företag fungerar som huvudbolag och hur många underbolag som omfattas av samma inkorgsstandard.
- Kända avsändare som mailar en huvudbolagsinkorg skapar fortsatt ärenden på avsändarens faktiska underbolag, medan okända avsändare får huvudbolaget som standard i utkastgranskningen.
- Mailadmin visar nu `Företag / huvudbolag` och `Gäller även X underbolag` för både inkorgar och utgående profiler.
- Inga nya databasmigrationer krävs jämfört med 1.0.73.
- Cache refresh och PHP/OPcache-reload rekommenderas efter applicerad uppdatering.

## Nytt i 1.0.73

- Releasepaketen är ombyggda från den verifierade 1.0.72-kodbasen med ny versionsmetadata för `1.0.73`.
- Adminytan, Composer-metadata, zip-filnamn och paketens `release-metadata.json` pekar nu på samma aktuella versionsnummer.
- Koordinatorns formulär för nytt telefonärende initierar nu kund- och företagssökningen efter att formuläret har renderats, så förslagslistorna visas precis som i teknikervyn.
- Uppgraderingspaketet är fortsatt kumulativt och kan användas direkt från äldre Driftpunkt 1.x-installationer.
- Inga nya databasmigrationer krävs jämfört med 1.0.72.
- Cache refresh och PHP/OPcache-reload rekommenderas efter applicerad uppdatering.

## Nytt i 1.0.72

- Kundväljare visar nu namn, e-post och företagskontext med moder-/dotterbolag där det behövs för att skilja liknande kundnamn åt.
- Samma tydligare etiketter används när tekniker skapar ärenden, admin byter beställare, koordinator skapar telefonärenden, mailutkast godkänns och skuggpersoner kopplas.
- Skuggpersoner kan fortsatt kopplas via den synliga kundetiketten och har regressionstest för kunder i dotterbolag.
- Adminytans användarformulär gör skillnaden tydligare mellan `Kund (företag krävs)` och `Privatkund (utan företag)`.
- Inga nya databasmigrationer krävs jämfört med 1.0.71.
- Cache refresh och PHP/OPcache-reload rekommenderas efter applicerad uppdatering.

## Nytt i 1.0.71

- Rich text-editorn har fått en tydlig `Normal text`-knapp som bryter ut ur rubriker, citat, listor, kodblock och färgmarkeringar utan att användaren behöver rensa hela kommentaren.
- När text är markerad kan `Normal text` rensa bara den markerade formateringen och återgå till vanliga stycken.
- Vanliga tekniker kan inte längre skriva över ärendesammanfattningen från snabbformulären när de uppdaterar status eller lösning.
- Tekniker ser sammanfattningen som läsbar rich text, medan admin fortsatt kan redigera sammanfattningen i samma vy.
- Symfony- och Twig-beroenden är uppdaterade till patchade versioner efter Composer audit för nya advisories i `symfony/http-foundation`, `symfony/routing`, `symfony/security-http` och `twig/twig`.
- Testskyddet täcker kundens rich text-editor, teknikers skyddade sammanfattning, adminredigering och berörda status-/bilageflöden.
- Inga nya databasmigrationer krävs jämfört med 1.0.70.

## Nytt i 1.0.70

- Releasepaketen är ombyggda från den verifierade 1.0.69-kodbasen med ny versionsmetadata för `1.0.70`.
- Adminytan och paketens `release-metadata.json` pekar nu på samma aktuella versionsnummer.
- `symfony/polyfill-intl-idn` är uppdaterad till patchad version efter Composer audit för CVE-2026-46644.
- SLA-reglaget i adminytan kan nu stängas av korrekt igen; avstängt läge bevaras i både formulärtext och checkbox efter sparning.
- Uppgraderingspaketet är fortsatt kumulativt och kan användas direkt från äldre Driftpunkt 1.x-installationer.
- Inga nya databasmigrationer krävs jämfört med 1.0.69.
- Cache refresh och PHP/OPcache-reload rekommenderas fortfarande efter applicerad uppdatering.

## Nytt i 1.0.69

- Teknikerns ärendedetalj visar nu ett fokuserat huvudformulär direkt med ämne, status, lösning, sammanfattning och primärknappen “Spara ärende”.
- Den konkurrerande “Spara status”-ytan är borttagen från detaljvyn; mer sällan använda fält finns kvar bakom “Visa fler fält”.
- Koordinatorns ärendevy prioriterar tilldelning, företag och påminn tekniker i sidokolumnen, medan historik och riskläge är dolda tills de behövs.
- Kommentarer ligger kvar synliga i koordinatorvyn, men historik/audit konkurrerar inte längre med den aktuella dialogen.
- Rich text-editorn ligger inte längre i ett label-element, så klick i kommentars- eller sammanfattningsfältet triggar inte Ångra av misstag.
- Citatformat i editorn går nu att stänga av igen, så användaren kan fortsätta skriva vanlig text efter ett citat.

## Nytt i 1.0.68

- Ärendesammanfattningar använder nu samma säkra rich text-flöde som kommentarer i kund-, tekniker- och adminflöden.
- Rich text-editorn har fått rubriker, checklistor, inline-kod, kodblock, ångra/gör om, tangentbordsgenvägar, statusmeddelanden och säkrare inklistring av ren text.
- Ärendelistor och dashboards visar sammanfattningar som ren text, medan detaljvyer visar tillåten formatering utan att läcka farlig HTML.
- Formatteringen sanerar nu rubriker, checklistor, kodblock, osäkra länkar, script/style och farliga attribut innan lagring.
- Testskyddet täcker formaterade ärendesammanfattningar från både kund- och teknikerflöden samt rich text-konvertering till plain text.

## Nytt i 1.0.67

- Inventarielistor validerar nu dubbletter tydligare: datorer per hostname och skrivare per IP-adress vid manuell registrering, uppdatering och CSV-import.
- Tekniker- och kundkommentarer har en rikare kommentarseditor med fet/kursiv text, listor, citat, länkar och säkra färgmarkeringar.
- Kommentarer saneras innan lagring och återges säkert i portal och e-post, samtidigt som textversioner av mail får läsbar plain text.
- Teknikeröversikten är lugnare som standard genom att avancerade snabbfilter, bulkåtgärder och sök/sort-paneler kan hållas dolda tills teknikern väljer dem.
- Symfony- och Twig-beroenden är uppdaterade till patchade versioner efter Composer audit.
- Testskyddet täcker inventariedubbletter, kommentarsanering och notifieringar med formaterade kommentarer.

## Nytt i 1.0.66

- Lösenordsåterställning använder nu användarens tilldelade företagsunika utgående mailprofil när en sådan finns.
- Användare utan tilldelad företagsprofil går vidare till global primär utgående e-postserver.
- Säkerhetsmail markeras inte längre som `Skickat` i produktion om systemet bara skulle använda `null://`-fallback; notifieringsloggen visar i stället ett tydligt konfigurationsfel.
- Testskyddet verifierar att produktionsläget stoppar null-fallback för kravställda säkerhetsmail.

## Nytt i 1.0.65

- Glömt lösenord-flödet skriver nu notifieringsloggar för `password_reset`, så det syns om säkerhetsmailet skickades, hoppades över eller misslyckades.
- Inaktiva och okända e-postadresser loggas utan att formuläret läcker om kontot finns.
- SMTP-/OAuth-fel vid lösenordsåterställning fångas i notifieringsloggen, vilket gör livefelsökning möjlig när ticket-mail fungerar men reset-mail saknas.
- Testskyddet verifierar både skickad lösenordsåterställning och okänd adress i notifieringsloggen.

## Nytt i 1.0.64

- Ärendekoordinatorer kan skapa telefonärenden från en fokuserad vy med rubrik, felbeskrivning, prioritet, kundnamn och ansvarig tekniker.
- Okända telefonkunder skapas som inaktiva ghost-kunder med intern `@no-mail.invalid`-adress, så ärendet får en riktig requester utan att kundmail skickas.
- Teknikerportalens “Att ta tag i nu”-kort radbryter långa sammanfattningar, kund-/företagsrader, taggar och knappar så korten håller sig inom sin panel.
- Testskyddet täcker telefonärenden med befintliga kunder, ghost-kunder, valideringsfel och teknikerportalens dashboardrendering.

## Nytt i 1.0.63

- Import / Export / Skuggpersoner byter nu ärendenummer på befintligt importerat ärende när en requester-skuggperson kopplas eller skapas mot ett företag som använder egen ärendeserie.
- Ärendet dupliceras inte vid flytten: ticket-id, historik, importerad person och kundkoppling bevaras, medan auditloggen visar gammalt och nytt ärendenummer.
- Företag utan egen ärendeserie behåller befintligt `DP-*`-nummer och tekniker-/ansvarigkopplingar påverkas inte.
- Avdelnings- och funktionskonton fortsätter att kunna skapas utan e-postadress; systemet genererar intern `@no-mail.invalid`-adress och stänger av kundnotiser.
- Offentlig export hoppar från 1.0.53 till 1.0.63 och inkluderar de samlade förbättringarna för interna ärendelänkar, kundåtkomst, inventarielistor, skuggpersoner, tekniker-/koordinatorvyer, statusmail och releasepaket.

## Nytt i 1.0.62

- Teknikeröversiktens valbara sidomoduler toppjusteras så statistik och andra paneler inte sträcks ut konstigt när de aktiveras.
- Statusen `Löst` skickar fortsatt kundens lösningsmail, medan `Stängd` nu är administrativ och skickar inget kundmail.
- Teknikerns ärendeåtgärder har en utfällbar förklaring av vad statusvalen betyder.
- Kundsynlig kommentar är nu standard i teknikerkommentarer; tekniker väljer aktivt `Kundsvar` när kommentaren ska mejlas till kunden.

## Nytt i 1.0.61

- Teknikerstartsidan är minimalare som standard med klickbara nyckelrutor för aktiva ärenden, väntar på svar och totalt i teknikerns kö; rutan för försenade visas bara när SLA faktiskt används.
- Tekniker kan själva välja vilka extra moduler som visas på översikten, till exempel operativ cockpit, statistik, aktivitet, notifieringar, SLA-kö och uppföljningspanelen.
- Tekniker kan dölja **Teamets senaste** på startsidan och välja att menyns siffror vid **Översikt** och **Ärenden** bara räknar ärenden som är tilldelade dem.
- Tekniker och ärendekoordinatorer kan välja startsida efter inloggning, köns första urval, dölja nyckelrutorna, välja årstidsteman och slå på en personlig årstidsdekoration.
- Lösenordsåterställning är tydligt testskyddad som säkerhetsmail och skickas även om vanliga e-postnotiser är avstängda.
- Testskyddet för teknikerinställningar och teknikeröversikten har uppdaterats för de personliga dashboardvalen.

## Nytt i 1.0.60

- Löst/stängt-ärende-mail ber inte längre kunden att svara direkt, utan förklarar att svar inte krävs och att omdöme gärna får lämnas.
- Kundfeedback efter avslut har en konfigurerbar åldersgräns, standard 30 dagar, som döljer gamla omdömeslänkar och stoppar direkta formulärpostningar.
- Admin kan styra hur länge omdöme får lämnas efter avslut under ärendeinställningarna.
- Test- och driftflöden för loggcenter, lösenordsåterställning, skuggpersoner och teknikeröversikt ingår i samma releasepaket.

## Nytt i 1.0.59

- Kundmail för ärenden förklarar nu tydligare att kunden kan svara direkt på mailet och att svaret kopplas automatiskt till ärendet.
- Kundportalens öppna-knapp visar korrekt översatt knapptext i stället för rå översättningsnyckel.
- Import / Export / Skuggpersoner skiljer nu på avsändare och ansvarig: avsändare kopplas till kund/privatkund och ansvarig kopplas till tekniker.
- Skapa-flödet i Skuggpersoner skapar kund eller privatkund, med val för att stänga av e-postnotiser för avdelnings- eller funktionskonton.
- Skuggpersoner har tydligare kundfokuserade texter, radrankare och pagination som håller kvar rätt filtrerad sida efter sparning.
- Importerade ansvarig-namn auto-kopplas inte längre till tekniker och en reparationsmigration öppnar felaktigt länkade ansvarig-skuggpersoner igen utan att ändra ärendets tekniker.
- Ansvarig-skuggpersoner har ett separat fält för att välja ansvarig tekniker, där endast aktiva tekniker kan väljas.

## Nytt i 1.0.58

- Kundmail för ärenden förklarar nu tydligare att kunden kan svara direkt på mailet och att svaret kopplas automatiskt till ärendet.
- Kundportalens öppna-knapp visar korrekt översatt knapptext i stället för rå översättningsnyckel.
- Import / Export / Skuggpersoner är nu en ren kundkopplingskö: befintlig koppling söker bara kund/privatkund och ändrar aldrig tekniker/tilldelad ansvarig.
- Skapa-flödet i Skuggpersoner skapar kund eller privatkund, med val för att stänga av e-postnotiser för avdelnings- eller funktionskonton.
- Skuggpersoner har tydligare kundfokuserade texter, radrankare och pagination som håller kvar rätt filtrerad sida efter sparning.

## Nytt i 1.0.57

- Import / Export / Skuggpersoner kan nu hantera requester-skuggpersoner som egentligen är intern personal eller tekniker.
- För sådana fall finns valet "Koppla som intern skapare", som markerar skuggpersonen som hanterad utan att sätta teknikern som kund/requester på ärendet.
- Ärenden som skickats in av tekniker åt kund kan därmed behålla behovet av korrekt kund/företag separat, utan att tekniker felaktigt skapas eller kopplas som kund.
- Flödet har testskydd så intern skapare-koppling inte ändrar ärendets requester.

## Nytt i 1.0.56

- Kundportalen skiljer nu tydligare på "Mina ärenden" och "Företagets ärenden" för kundanvändare som har fått företagsvald ärendeåtkomst.
- "Mina ärenden" visar alltid bara kundens egna ärenden, medan den nya företagsvyn visar alla kundsynliga ärenden i samma företag för tillåtna användare.
- Sidomenyn visar separata antal för egna aktiva ärenden och företagets aktiva ärenden när företagsvyn är tillgänglig.
- Teknikerns snabbfilter kan nu begränsa ärendeöversikten till ett valt företag utan att behöva skriva företagsnamnet i fritextsökningen.
- Koppling av existerande användare i Import / Export / Skuggpersoner är mer robust: datalist-val sparar rätt användar-id och backend kan även tolka den synliga användaretiketten som fallback.
- Import-/exportflödet har regressionsskydd för skuggpersonkoppling där webbläsaren bara skickar den synliga komboboxtexten.

## Nytt i 1.0.55

- Företag kan nu ha en egen allowlist för vilka aktiva kundanvändare som får se alla kundsynliga ärenden i samma företag.
- Kundportalens ärendelistor, dashboard, sidomeny och detaljvy använder samma åtkomstregel: egna ärenden, företagsdelade ärenden och särskilt tilldelad företagsåtkomst, men aldrig interna ärenden.
- Inventarielistor för datorer och skrivare är nu alltid allowlist-styrda. Äldre "alla kundanvändare"-lägen ger inte längre kundåtkomst förrän användare bockas i.
- Adminvyn för inventarielistor visar sparade checkboxar och tydligare sammanfattning för valda användare.
- Ärendekoordinatorer får personliga inställningar för att själva slå på statkort, uppföljningspanel, avancerade filter och detaljerade ärendekort. Standardvyn är minimal.
- Koordinatorns risköversikt är renare som standard och kan visa mer detaljer när användaren själv väljer det.
- Ärendestatusen `On hold` hanteras i aktiv ärenderäkning, SLA-risk och koordinatoröversikt utan att dra onödiga åtgärdssignaler.

## Nytt i 1.0.54

- Ärendekoordinatorer och tekniker kan nu öppna interna ärendemejl via säkra engångsknappar som loggar in och skickar vidare till rätt ärende.
- Engångslänkarna lagras bara som hash, gäller i två timmar, kan användas en gång och behåller MFA-krav när kontot har MFA aktiverat. Tekniker och ärendekoordinatorer kan efter en godkänd MFA-kod välja att betro den aktuella enheten i sju dagar; lösenord krävs fortfarande vid ny inloggning och förtroendet upphör vid lösenords- eller MFA-byte.
- Textversioner av interna ärendemejl skriver inte längre ut engångstoken-länkar, utan hänvisar till HTML-knappen eller vanlig portalinloggning.
- Automatisk IMAP-hämtning markerar nu meddelanden som lästa direkt när de har hämtats in till Driftpunkt.
- Inkommande mail får försiktigare signaturrensning så tydliga signaturblock kapas utan att telefonnummer eller länkar i felbeskrivningen tas bort.
- Begärd av-fältet kan nu söka eller ta ett manuellt kundnamn som skuggperson, Företag kan sökas utan att nya företag skapas, och admin kan koppla inkommande mailadresser till kund/företag.
- Mailkonfigurationen har fått de senaste förbättringarna för tydligare OAuth/SMTP-hantering och tillhörande tester.

## Nytt i 1.0.53

- Lägger till en reparationsmigration som skapar `technician_team_memberships` om en liveinstallation redan fått 1.0.52-kod men saknar tabellen efter en avbruten migration.
- Reparationsmigrationen använder MariaDB-kompatibel SQL för främmande nycklar och backfillar medlemskap från `users.technician_team_id` med `NOT EXISTS`.
- Fixen tar sikte på 500-felet i adminvyer som identitet/företag där Doctrine försökte läsa teknikerteammedlemskap innan tabellen fanns.
- Releasepaketen för 1.0.53 ska kunna lyfta installationer som fastnat i mellanläget efter 1.0.52.

## Nytt i 1.0.52

- Intern personal kan nu ha ett primärt teknikerteam och valfritt antal extra teammedlemskap.
- `users.technician_team_id` finns kvar som primärt team för standardval, auto-routing, "koppla till mitt team" och delade teamköer.
- En ny medlemskapstabell `technician_team_memberships` backfillas från befintliga primära team vid migration.
- 1.0.52-paketen är ombyggda med MariaDB-kompatibel migrations-SQL för främmande nycklar i medlemskapstabellen.
- Admin-identitet har stöd för extra team på superadmin, admin, ärendekoordinator och tekniker, med validering mot saknat primärt team och inaktiva team.
- Teknikers läs- och samarbetsåtkomst, dashboard, stängda ärenden, "Mina team"-filter och koordinatorns teamvy räknar nu alla teammedlemskap.
- Tickets behåller fortsatt exakt ett ansvarigt team via `Ticket.assignedTeam`.
- Teamradering rensar både primär teamkoppling och extra medlemskap utan att ta bort andra team från användaren.
- Ärendekoordinatorn har en fast guide på `/portal/koordinator/guide` med arbetsflöde för inkommande kanal, triage, tilldelning, uppföljning, mailhantering, rapporter och eskalering.
- Koordinatorns meny visar `Guide` på översikt, ärendedetalj, rapporter och koordinatorläget i teknikerportalen.
- Guidesidan har visuella sektioner, flödeskartor, checklistor och sökfunktion för snabbare stöd i vardagsflödet.
- Guide, menytext, sökfält och hjälptexter är översatta på svenska, engelska och norska.
- Uppladdad webbplatslogga och favicon får versionsstyrda filnamn med innehållsfingeravtryck så gammal branding inte ligger kvar i webbläsarcache.
- 1.0.51-förbättringarna ingår fortsatt: tystare importflöden, enkel kundinloggning, dolbara startsidenyheter, minimal koordinatorvy och mer konsekventa teknikerärenderäknare.

## Översikt

Driftpunkt innehåller bland annat:

- publik webb med startsida, driftstatus, nyheter, sök, kontakt och policy-sidor
- kundkonto med självregistrering, lösenordsåterställning och kundportal för ticketdialog
- teknikerportal för ticketkö, prioritering, kommentarer, SLA och kunskapsbasarbete
- adminyta med sökbara och paginerade listor för användare, företag, e-postservrar, inkorgar och utgående profiler samt separata ytor för team, innehåll, driftstatus, databas, jobb och uppdateringar
- e-postflöden med spool-ingest, mailbox-polling och draftgranskning för osäkra fall
- kunskapsbas med publik/kundintern vy, fällbara guider, paginering per innehållstyp, nyhetsmodul och statuskommunikation i samma produkt
- underhållsläge, bilagearkivering, bakgrundsjobb och release-/uppgraderingspaket
- publikt ticket-formulär för att skapa nya tickets utan inloggning
- rapporter och BI-light-översikter för ärenden, SLA, backlog och företag
- tokenbaserat read-only API för enkel ticketexport till integrationer
- månadsrapporter för företag med automatisk e-postsändning
- systemaudit, applikationsloggning, loggcenter med export/rensning för superadmin och Debian-logrotate för enklare felsökning

## Vad man kan göra

### Publik webb

- visa startsida med statusöversikt och senaste nyheter
- läsa nyheter, publik kunskapsbas och publika policy-sidor
- använda sök och kontaktsida utan separat frontend
- visa driftstatus och underhållsinformation publikt
- skapa nya supporttickets via publikt formulär utan inloggning

### Kundflöden

- registrera privatkundskonto när funktionen är aktiverad
- logga in, återställa lösenord och följa egna eller företagsdelade tickets
- kommentera tickets kunden har access till
- lämna omdöme på lösta/stängda ärenden och få en valfri påminnelse om feedbackfunktionen är aktiverad
- läsa kundsynlig kunskapsbas och statusinformation
- se kundanpassade rapporter, datorer och skrivare under `Mina resurser` när företaget och användaren har fått åtkomst
- byta språk mellan svenska, engelska och norska i portalen

### Tekniker- och adminflöden

- skapa, ta över, uppdatera och kommentera tickets
- välja personligt standardspråk i tekniker-, koordinator- och adminytan så nästa inloggning öppnar med rätt språk
- tillhöra flera teknikerteam samtidigt via ett primärt team och extra teammedlemskap
- styra visibility, prioritet, påverkan, request type, routing och SLA
- söka, filtrera, sortera och paginera användare samt hantera endast vald användare i en responsiv sidopanel
- skapa och redigera användare med samma fältkomponenter, sökbart företagsval och bevarade listfilter
- hantera MFA-nödåtgärder och avancerad användarradering i separata riskavsnitt med befintliga behörighets- och historikskydd
- hantera primärt teknikerteam, extra teammedlemskap och identitet separat från den paginerade företagssidan
- skydda admin- och superadminbehörighet så bara superadmin kan skapa eller tilldela privilegierade roller
- låta superadmin styra globalt standardspråk och vilka språk som ska visas som valbara i gränssnittet
- hantera företag i en paginerad koncernvy där dotterbolag följer med sitt moderbolag
- skapa och publicera nyheter och kunskapsbasinnehåll med typflikar och bevarade filter i admin- och teknikerläge
- rensa testärenden per företag som superadmin med preview, säkerhetsfrågor och borttagning av tillhörande bilagor
- arbeta med telefonstödsdata i admin
- importera ärenden från SharePoint/CSV och behålla kund- och teknikernamn som skuggpersoner tills riktiga konton skapas eller kopplas
- ta bort felimporterade ärenden direkt från importgranskningen när de ännu inte har tilldelats tekniker eller team
- SupportDesk och dess fjärrsupportgenvägar tas bort inför 2.0.1; historiska inställningar bevaras men används inte
- söka, filtrera och paginera e-postservrar, supportinkorgar och utgående profiler samt skapa eller redigera vald post i en responsiv sidopanel
- testa serveranslutningar, följa användning och status samt öppna Google Workspace-, Microsoft 365- och OAuth-guider vid behov
- skydda lagrade e-postlösenord och OAuth-hemligheter från HTML samt blockera radering när status, historik eller beroenden gör åtgärden osäker
- konfigurera driftstatus, inställningar och underhåll
- följa BI-light-rapporter för inflöde, backlog, SLA-hälsa, risker, företag och intern arbetslast
- konfigurera och skicka månadsrapporter för företag
- låta ärendekoordinatorer läsa företagsdata och inventarielistor utan att ge full adminåtkomst
- koppla flera teknikeransvariga till ärenden när arbetsflödet kräver delat ansvar
- följa notifieringar, grupperade systemloggar, driftåtgärder och jobbfel i ett loggcenter med export och kontrollerad superadmin-rensning
- skapa egna informationspaneler och länkar via `addon.json`, exempelmall, validering och versionsstyrd aktivering under **Tillägg** (se [utvecklarguiden](docs/addon_build_and_release_guide.md))
- hantera utökad nyhetsredigering och telefonstöd som inbyggda funktioner med på/av under **Funktioner**; körbara addon-paket laddas inte längre och import/aktivering är spärrad inför 2.0.1 (se [övergångsguiden](docs/addon_build_and_release_guide.md))

### Drift och automation

- läsa in inkommande mail via spool eller polling av supportinkorgar
- lägga osäkra mail i draftgranskning innan de blir kundsynliga tickets
- köra mailpolling, SLA-kontroll, bilagearkivering och månadsrapporter via appens interna fallback eller externa schemaläggare
- köra engångspåminnelser för kundomdömen efter avslutade ärenden när funktionen är aktiverad
- köra databasjobb och post-update tasks via CLI eller adminens bakgrundsjobb
- använda `PHP_CLI_BINARY` för säkra bakgrundsstarter i Apache/mod_php- och webbhotellmiljöer
- bygga installations- och uppgraderingspaket
- stagea och applicera koduppdateringsflöden i admin/drift
- exportera en publik repo-kopia med privata moduler, driftkod och interna docs bortfiltrerade
- felsöka via `var/log/*.log`, systemd-loggar, release-metadata och checksummor för paket

## Begränsningar i nuläget

- API:t är read-only och avsett för kontrollerad ticketexport, inte som full integrationshub
- ingen full fristående BI-motor med sparade egna rapportmallar eller externa BI-integrationer
- produktion behöver fortfarande egen serverhardening, backup/restore och extern scheduler för förutsägbara bakgrundsjobb

## Installationskrav

Driftpunkt är en serverrenderad Symfony 8-applikation. Det finns ingen separat Node-, npm- eller frontend-build som krävs för att köra sidan i nuläget.

Minimikrav för lokal utveckling och serverdrift:

- PHP 8.4.27 eller senare inom 8.4-serien, alternativt PHP 8.5.12 eller senare inom 8.5-serien
- Composer 2
- MariaDB 10.11 eller senare, rekommenderat MariaDB 11 för lokal Docker-miljö
- `DATABASE_URL` måste peka på MariaDB utanför `APP_ENV=test`; `mysql://` ska ange `serverVersion` som innehåller `mariadb`
- PHP-tilläggen `ctype`, `curl`, `iconv`, `intl`, `mbstring`, `pdo`, `pdo_mysql`, `xml`, `zip` och gärna `opcache`
- en webbserver som kan köra PHP och peka dokumentroten mot `htdocs/`, till exempel Symfony CLI, PHP:s inbyggda server, Apache eller appcontainern i Docker
- skrivbar `var/`-katalog för cache, loggar, uppladdningar och delade driftfiler
- skrivbar `htdocs/assets/branding` om logotyp, flikikon och branding ska kunna ändras från adminytan; uppladdade `custom-site-*`-filer är runtime-data och ska bevaras vid koduppdateringar
- om adminytans webbaserade uppdateringsflöde ska användas måste den faktiska PHP/webbserver-användaren, normalt `www-data` men på Apache med `mpm-itk`/`AssignUserID` ofta vhost-användaren, även kunna skriva till kodfilerna som uppdateras: `bin/`, `config/`, `htdocs/`, `migrations/`, `public/`, `src/`, `templates/`, `composer.json`, `composer.lock` och `symfony.lock`

Rekommenderat för produktion:

- HTTPS/TLS framför applikationen
- ett unikt `APP_SECRET` i `.env.local` eller riktiga miljovariabler
- låt `DRIFTPUNKT_SESSION_IDLE_TIMEOUT=1800` eller ett kortare driftanpassat värde vara satt så inloggade sessioner stängs efter inaktivitet
- lämna `DRIFTPUNKT_ENABLE_DEMO_DATA=0` i produktion om du inte uttryckligen vill skapa demoärenden i en tom databas
- sätt `DRIFTPUNKT_API_TOKEN` bara om read-only API:t `/api/v1/tickets` ska aktiveras
- en riktig `DATABASE_URL` mot MariaDB
- SMTP-konfiguration via `MAILER_DSN` om appen ska skicka e-post
- konfigurera mottagare och svarsinkorg för interna rapporter i superadmins operativa cockpit; svarsadressen ska motsvara en aktiv IMAP-inkorg
- schemalagda jobb för mailpolling, SLA-kontroll, månadsrapporter och bilagearkivering via systemd, cron eller Docker-scheduler rekommenderas för förutsägbar produktion, men appen har en intern fallback som köar samma återkommande jobb från webbflödet om extern scheduler saknas
- regelbunden, återläsningstestad backup av MariaDB, `var/share`, `var/ticket_attachments`, `var/ticket_attachment_archives` och `.env.local`; installationens `APP_SECRET` måste bevaras krypterat eftersom den omsluter MFA-krypteringsnyckeln
- välj driftmodell för kodägarskap: webbaserad uppdatering kräver skrivbar applikationskod för samma användare som Apache/PHP kör webbplatsen med, medan en hårdare låst server kan låta `root` äga kodfilerna och i stället uppdateras via SSH/deploy-script

PHP-kravet omfattar säkerhetsrättningarna för CVE-2026-109618 och CVE-2026-109619 från den 21 oktober 2026; se [PHP:s säkerhetsmeddelande](https://www.php.net/archive/2026.php#2026-10-21-5). Composer och Driftpunkts uppgraderingspaket uppdaterar inte PHP-motorn. Uppdatera och verifiera både CLI och webbserverns PHP innan nya app-/vendor-paket appliceras, och starta om berörda processer. För Docker krävs ombyggnad med `--pull` och återskapande av både `app` och `scheduler`; det medför ett kort driftavbrott. Se [PHP-uppdatering och verifiering](docs/installation_and_deployment.md#säkerhetsuppdatera-php-motorn), även om basimagens publicering ännu inte är komplett.

Valfria verktyg:

- Symfony CLI för smidig lokal serverstart
- Docker och Docker Compose för lokal MariaDB eller komplett NAS-/serverdrift
- PHPUnit för testkörning via `php bin/phpunit`

### Central rapportering och e-postsvar

Fel och Önskemål sparas lokalt och notifieras till mottagaren som superadmin anger under **Interna rapporter** i den operativa cockpit-vyn. Saknad kund stannar i den lokala superadminvyn. Svarsinkorgen (Reply-To) måste vara exakt samma adress som en aktiv supportinkorg med fungerande IMAP-konfiguration i adminytan. Scheduler-processen måste köra `app:mail:poll` för att svar från mottagaren ska läggas tillbaka i rapporttråden.

Verifiera konfigurationen genom att skicka en testrapport och kontrollera att historiken visar **Skickad till Driftpunkts utvecklare**. Svara sedan på mejlet utan att ändra rapportreferensen i ämnet och kör vid behov:

```bash
php bin/console app:mail:poll --env=prod
```

Rapporten ska därefter ha status **Pågår**, visa svaret i rapporthistoriken och skicka en svarsnotis till rapportören. Inkommande mejl dedupliceras med RFC `Message-ID`; manuella importer utan Message-ID använder innehållshash som reserv. Svar begränsas till 20 000 tecken i rapporttråden medan originalmejlet behålls.

Rapportinskick begränsas till fem per användare och 15 minuter. Käll-URL:er tappar fragment och känsliga parametrar som token, session, autentisering, e-post och lösenord innan de lagras. Misslyckade centrala notifieringar försöks automatiskt upp till fem gånger via `app:internal-reports:retry-notifications`, med ökande väntetid. Superadmin kan se konfigurationsstatus och starta ett manuellt återförsök.

För publika GitHub Issues kan superadmin hämta en sanerad Markdown-mall från rapportkortet. Exporten utelämnar installation, rapportör och käll-URL samt filtrerar e-postadresser, länkar och IP-adresser. Filen måste fortfarande granskas manuellt innan publicering; ingen GitHub-token lagras i kundinstallationen.

Om notifieringen fortsätter misslyckas: kontrollera `var/log/prod.log`, SMTP-inställningen samt superadmins rapportinställningar och att svarsadressen motsvarar en aktiv IMAP-inkorg.

## Snabbstart

1. Installera PHP-beroenden

   ```bash
   composer install
   ```

2. Konfigurera miljö

   Standardvärdena i `.env` fungerar för lokal utveckling mot MariaDB från `compose.yaml`. Skapa `.env.local` om du vill ändra till exempel `DATABASE_URL`, `APP_SECRET`, `MAILER_DSN`, `DEFAULT_URI` eller `DRIFTPUNKT_SESSION_IDLE_TIMEOUT`.

   Supportkort kräver GD med JPEG/PNG-stöd i både webb-PHP och CLI samt en uttrycklig `DRIFTPUNKT_PUBLIC_BASE_URL` i `.env.local` eller miljön. Ingen adress gissas från inkommande Host-header. Kör levererade migrationer innan friskbekräftelse och mejlbehandling. Säkerhetskopiera även privata logotyper i `var/support_cards/logos` och bevara `APP_SECRET` säkert. Se [supportkortens installations- och driftanvisningar](docs/support_cards.md) för behörigheter, rotation och maskering av publika länkar i loggar.

3. Starta MariaDB om du använder lokal Docker-miljö

   ```bash
   docker compose up -d database
   ```

   Om du inte använder Docker, skapa en MariaDB-databas och uppdatera `DATABASE_URL`.

4. Initialisera databasen

   För en helt ny MariaDB-installation:

   ```bash
   php bin/console app:install:fresh --env=prod
   ```

   Kommandot skapar schema och basdata men inga användarkonton. Skapa därefter installationens första superadmin. Lösenordet efterfrågas dolt och bekräftas:

   ```bash
   php bin/console app:create-admin admin@example.com \
     --first-name=Förnamn \
     --last-name=Efternamn \
     --type=super_admin \
     --env=prod
   ```

   Kontrollera före MFA-konfiguration att `APP_SECRET` är ett långt, slumpmässigt installationsunikt värde. Projektets utvecklings- och platshållarvärden blockeras av nyckelhanteringen.

   Om du arbetar mot en befintlig databas med migrationshistorik:

   ```bash
   php bin/console doctrine:migrations:migrate -n
   ```

5. Skapa testkonton endast lokalt

   ```bash
   php bin/console app:create-test-accounts
   ```

   Kommandot vägrar köras i produktionsmiljö.

6. Starta sidan

   ```bash
   symfony server:start
   ```

   Om Symfony CLI saknas:

   ```bash
   php -S 127.0.0.1:8000 -t htdocs
   ```

7. Öppna `http://127.0.0.1:8000`

## Snabbstart med Docker Compose

Rootens `compose.yaml` startar MariaDB på port `33060` och mailtestning för lokal utveckling. NAS-/serverdrift med appcontainer finns i `deploy/nas/compose.yaml`.

1. Starta hjälptjänsterna

   ```bash
   docker compose up -d
   ```

2. Installera beroenden och initiera MariaDB

   ```bash
   composer install
   php bin/console app:install:fresh
   php bin/console app:create-admin admin@example.com --first-name=Förnamn --last-name=Efternamn --type=super_admin
   ```

3. (Valfritt) skapa testkonton

   ```bash
   php bin/console app:create-test-accounts
   ```

4. Öppna `http://127.0.0.1:8000`

## NAS med Docker Compose

För en NAS eller annan Docker-baserad server finns en komplett compose-setup med app, MariaDB, persistenta volymer och scheduler:

- [NAS-installation med Docker Compose](docs/nas_docker_setup.md)
- `deploy/nas/compose.yaml`
- `deploy/nas/.env.example`

Kort version:

```bash
cp deploy/nas/.env.example deploy/nas/.env
nano deploy/nas/.env
mkdir -p deploy/nas/data/var deploy/nas/data/mariadb
docker compose -f deploy/nas/compose.yaml --env-file deploy/nas/.env build --pull app &&
  docker compose -f deploy/nas/compose.yaml --env-file deploy/nas/.env up -d
docker compose -f deploy/nas/compose.yaml --env-file deploy/nas/.env exec app php bin/console app:install:fresh --env=prod
docker compose -f deploy/nas/compose.yaml --env-file deploy/nas/.env exec app php bin/console app:create-admin admin@example.com --first-name=Förnamn --last-name=Efternamn --type=super_admin --env=prod
```

## Debian-server

För en vanlig Debian-server utan Docker finns en konkret runbook och färdiga mallar:

- [Debian-server: krav och installation](docs/debian_server_setup.md)
- `deploy/debian/app.env.example` för `.env.local`
- `deploy/debian/apache-driftpunkt.conf` för Apache
- `deploy/debian/setup.sh` för basinstallation av paket, Composer, Apache-site och systemd-timers

Kort version:

```bash
sudo mkdir -p /var/www/driftpunkt
sudo chown "$USER":www-data /var/www/driftpunkt
git clone <repo-url> /var/www/driftpunkt
cd /var/www/driftpunkt
DOMAIN=driftpunkt.example.com sudo -E bash deploy/debian/setup.sh
sudo nano /var/www/driftpunkt/.env.local
sudo -u www-data php bin/console app:install:fresh --env=prod
sudo -u www-data php bin/console app:create-admin admin@example.com --first-name=Förnamn --last-name=Efternamn --type=super_admin --env=prod
```

När installation, databas, första konto och backup är verifierade aktiveras de externa bakgrundsjobben:

```bash
sudo systemctl enable --now driftpunkt-mail-poll.timer driftpunkt-attachment-archive.timer
systemctl list-timers 'driftpunkt-*' --all --no-pager
```

Bilagearkiveringen styrs under **Administration → Inställningar → Ärenden → Bilagor i ärenden**. Värdet `0` arkiverar lokala bilagor direkt när ett ärende är löst eller stängt; välj ett högre antal dagar om nyligen avslutade ärenden ska behålla separata originalfiler en tid. För en installation med annan Unix-användare eller annan sökväg än `www-data` och `/var/www/driftpunkt` måste `driftpunkt-attachment-archive.service` använda den faktiska kontoägaren, projektkatalogen och PHP-binären. Verifiera efter första körningen med:

```bash
systemctl status driftpunkt-attachment-archive.service --no-pager
tail -n 100 var/log/ticket-attachment-archive.log
systemctl --failed --no-pager
```

## Testkonton

Om du kör `app:create-test-accounts` skapas:

| Roll | E-post | Lösenord |
| --- | --- | --- |
| Super admin | `super@test.local` | `AdminPassword123` |
| Admin | `admin@test.local` | `AdminPassword123` |
| Tekniker | `tech@test.local` | `TechPassword123` |
| Kund | `customer@test.local` | `CustomerPassword123` |

`app:create-test-accounts` är endast avsett för lokal utveckling och test och blockeras i `prod`. `app:install:fresh` skapar aldrig konton.

Efter installationen ska superadmin:

1. logga in;
2. öppna **Inställningar → Åtkomst → MFA-policy**;
3. skapa eller importera MFA-krypteringsnyckeln;
4. välja vilka roller som får använda MFA;
5. frivilligt välja vilka roller som måste använda MFA;
6. välja period för betrodd enhet, med 14 dagar som standard.

MFA är frivillig för samtliga roller efter både installation och uppgradering. Inga roller får obligatoriskt MFA automatiskt. Ett senare rollkrav ger användare utan färdig MFA en individuell aktiveringsfrist på 14 dagar.

## Viktiga Kommandon

```bash
php bin/console app:create-test-accounts
php bin/console app:install:fresh
php bin/console app:create-admin <email> --first-name=<förnamn> --last-name=<efternamn> --type=<admin|super_admin>
php bin/console app:mail:ingest <spoolfil>
php bin/console app:mail:poll
php bin/console app:check-ticket-sla
php bin/console app:reports:send-monthly --dry-run
php bin/console app:archive-ticket-attachments
php bin/console app:send-ticket-feedback-reminders --dry-run
php bin/console app:operations:run-due
php bin/console app:database-maintenance:run <job-id>
php bin/console app:post-update:run <run-id>
php bin/console app:code-update:apply-run <run-id>
php bin/console app:maintenance status
php bin/console app:i18n:audit --strict
php bin/console app:release:build-packages
composer export:public-repo
php bin/phpunit
```

För att köra testsviten mot MariaDB i testmiljön, starta databasen och override:a `DATABASE_URL` för själva testkommandot:

```bash
docker compose up -d database
docker compose exec -T database mariadb -uroot -pdriftpunkt-root -e "CREATE DATABASE IF NOT EXISTS driftpunkt_test CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci; GRANT ALL PRIVILEGES ON driftpunkt_test.* TO 'driftpunkt'@'%'; FLUSH PRIVILEGES;"
DATABASE_URL='mysql://driftpunkt:driftpunkt@127.0.0.1:33060/driftpunkt?serverVersion=mariadb-11.8.6&charset=utf8mb4' APP_ENV=test php bin/phpunit
```

`phpunit.dist.xml` tvingar `APP_ENV=test` och Doctrine lägger på suffixet `_test`, så basdatabasen `driftpunkt` i URL:en används som `driftpunkt_test` under testkörningen.

## Språk och översättningar

Svenska är bas-språket i `translations/messages.sv.yaml`. Engelska och norska ska ha samma nycklar i `translations/messages.en.yaml` och `translations/messages.no.yaml`, även för äldre vyer som fortfarande skickar direkt svensk källtext till `t('...')`.

Kunder väljer språk i kundportalens toppmeny och valet sparas på kontot. Användare med admin-, superadmin-, tekniker- eller koordinatorroll kan spara ett personligt standardspråk. Superadmin kan dessutom välja globalt standardspråk och begränsa vilka installerade språk som visas som valbara; om ett sparat språk inte längre är aktivt används det globala standardspråket.

Kör språkgranskningen innan release eller när nya UI-texter läggs till:

```bash
php bin/console app:i18n:audit --strict
```

Kommandot kontrollerar alla språkfiler mot svenska, visar saknade översättningar och varnar om en översättning finns i engelska/norska men saknas i svenska basfilen. Adminytan under Språk & översättningar kan sedan användas för att hitta och fylla saknade texter per språk.

## Intern schemaläggningsfallback

Driftpunkt har en appstyrd fallback för återkommande driftjobb. När en webbförfrågan avslutas kontrollerar appen om mailpolling, SLA-kontroll, bilagearkivering eller månadsrapporter är förfallna och köar då:

```bash
php bin/console app:operations:run-due
```

Fallbacken använder låsning och state i `var/operational_tasks.lock` och `var/operational_tasks.json`, så den inte ska starta samma körning vid varje sidladdning. Extern schemaläggning via systemd, cron eller Docker-scheduler är fortfarande rekommenderad i produktion för mer förutsägbara körtider, men appen slutar inte fungera om det saknas.

## Releasepaket

Releaseversionen hämtas normalt från `version` i `composer.json`. Höj den inför varje släpp, till exempel från `1.0.0` till `1.0.1`, så får både adminytan och zip-filerna samma versionsnummer.

Aktuell release i detta arbetsläge är `1.0.132`. Motsvarande paket heter `driftpunkt-install-1.0.132.zip` och `driftpunkt-upgrade-1.0.132.zip`.

### Uppgradering från 1.0.131 till 1.0.132

Använd `driftpunkt-upgrade-1.0.132.zip` i superadmins uppdateringsvy. Ta backup av applikation och databas före uppgraderingen. Ingen databasmigration krävs.

Efter uppdateringen:

1. Kontrollera att adminöversikten visar version `1.0.132` och att uppdateringsjobbet är slutfört.
2. Logga in som kund, välj engelska i toppmenyn och kontrollera att valet markeras och att kundsidorna visas på engelska. Upprepa med norska.
3. Logga ut och in igen och kontrollera att språkvalet finns kvar.

### Uppgradering från 1.0.130 till 1.0.131

Använd `driftpunkt-upgrade-1.0.131.zip` i superadmins uppdateringsvy. Ta backup av applikation och databas före uppgraderingen. Releasen innehåller databasmigrationen `Version20261030120000`, som lägger till den frivilliga kolumnen `tickets.contact_phone`. Låt det ordinarie uppdateringsflödet slutföra efterstegen, köra migrationen, rensa cache och ladda om PHP/OPcache. PHP-kraven från 1.0.128 gäller oförändrade.

Efter uppdateringen:

1. Kontrollera att adminöversikten visar version `1.0.131` och att uppdateringsjobbet, inklusive migrationen, är slutfört.
2. Skapa ett kundärende med telefonnummer och kontrollera att numret är en klickbar länk för tekniker och koordinator och förifylls på kundens nästa ärende.
3. Öppna ett delat företagsärende som kollega och kontrollera att beställarens nummer inte visas.
4. Kontrollera att ett kritiskt ärende markeras i tekniker- och koordinatorlistorna och att markeringen försvinner när ärendet stängs.
5. Skriv en kommentar med understruken text, genomstruken text, överstrykning och skiljelinje och kontrollera resultatet i ärendet och i kundmejlet.
6. Exportera en CSV-lista med ett ärendeämne som börjar med `=` och kontrollera att värdet inleds med en apostrof.

### Uppgradering från 1.0.128 eller 1.0.129 till 1.0.130

Använd `driftpunkt-upgrade-1.0.130.zip` i superadmins uppdateringsvy. Paketet är kumulativt och kan även appliceras direkt från 1.0.128. Ta backup av applikation och databas före uppgraderingen. Ingen ny databasmigration tillkommer jämfört med 1.0.128 eller 1.0.129. Låt det ordinarie uppdateringsflödet slutföra efterstegen, rensa cache och ladda om PHP/OPcache. PHP-kraven från 1.0.128 gäller oförändrade.

Efter uppdateringen:

1. Kontrollera att adminöversikten visar version `1.0.130` och att uppdateringsjobbet är slutfört.
2. Öppna **Företagets ärenden** som kund med flera företag, välj ett företag och kontrollera att sammanfattningskorten följer valet och att CSV-exporten innehåller den filtrerade listan.
3. Skapa ett nytt ärende och kontrollera att senast använda företag är förvalt.
4. Skicka ett svar (SV:) utan ärendereferens från en känd kund och kontrollera att ett vanligt ärende skapas.
5. Skicka ett svar med ärendenumret från en känd kund och kontrollera att det läggs som kommentar på det befintliga ärendet.
6. Skriv en kommentar med flera rader och kontrollera att radbrotten finns kvar i ärendet och i kundmejlet.

### Uppgradering från 1.0.128 till 1.0.129

Använd `driftpunkt-upgrade-1.0.129.zip` i superadmins uppdateringsvy. Ta backup av applikation och databas före uppgraderingen. Ingen ny databasmigration tillkommer jämfört med 1.0.128. Låt det ordinarie uppdateringsflödet slutföra efterstegen, rensa cache och ladda om PHP/OPcache. PHP-kraven från 1.0.128 gäller oförändrade.

Efter uppdateringen:

1. Kontrollera att adminöversikten visar version `1.0.129` och att uppdateringsjobbet är slutfört.
2. Bifoga två eller flera filer i en kommentar som kund, tekniker och ärendekoordinator och kontrollera att alla visas i ärendet. Ta bort en fil i filväljaren före sändning och kontrollera att den inte bifogas.
3. Prova en ZIP-fil under 1 MB (godtas) och över 1 MB (nekas med meddelande).
4. Öppna ett mejlskapat ärende som ärendekoordinator och kontrollera att **Visa originalmejl** och nedladdningen av `.eml` fungerar.

### Uppgradering från 1.0.126 till 1.0.127

Använd `driftpunkt-upgrade-1.0.127.zip` i superadmins uppdateringsvy. Ta backup av applikation och databas före uppgraderingen. Ingen ny databasmigration tillkommer jämfört med 1.0.126. Låt det ordinarie uppdateringsflödet slutföra efterstegen, rensa cache och ladda om PHP/OPcache. Vid uppgradering från äldre versioner behövs även tidigare versioners migreringar.

Efter uppdateringen:

1. Kontrollera att adminöversikten visar version `1.0.127` och att uppdateringsjobbet är slutfört.
2. Öppna ett testärende som ärendekoordinator, ändra prioriteten och kontrollera att status, lösning och tilldelning är oförändrade. Kontrollera användare och före-/eftervärden i historiken.
3. Stäng ett aktivt testärende med en lösning. Kontrollera status **Stängd**, registrerad stängningstid, sparad lösning i läsvyn och att ärendet finns under **Avslutade ärenden**. Stängningen ska inte skicka något kundmejl.
4. Kontrollera att en tom lösning inte tillåter stängning och att ett redan stängt ärende behåller lösning och stängningstid vid upprepad stängning.
5. Öppna ett sammanslaget källärende och kontrollera att formulären för stängning och prioritet saknas. Huvudärendet ska fortfarande kunna ändras.
6. Kontrollera att återöppning fortfarande kräver en intern orsak och ger status **Öppen**.

### Uppgradering från 1.0.125 till 1.0.126

Använd det senast byggda `driftpunkt-upgrade-1.0.126.zip` i superadmins uppdateringsvy. Ta backup av applikation och databas före uppgraderingen. Migreringen `Version20261008120000` krävs från 1.0.125 och lägger till kolumnerna `incoming_mails.original_body`, `incoming_mails.raw_message_path` och `incoming_mails.automatic_kind`. Låt det ordinarie uppdateringsflödet köra migrationerna och slutföra efterstegen, rensa cache och ladda om PHP/OPcache. Råmejl sparas under `var/incoming_mail_attachments/<id>/original.eml` och ska ingå i filbackupen.

Efter uppdateringen:

1. Kontrollera att adminöversikten visar version `1.0.126`, att migreringen `Version20261008120000` är körd och att uppdateringsjobbet är slutfört.
2. Vidarebefordra ett mejl från en registrerad kund till en supportinkorg. Kontrollera att ärendet innehåller det vidarebefordrade innehållet men inte kundens signatur.
3. Öppna ärendet som tekniker, fäll ut **Visa originalmejl** och ladda ner `.eml`-filen.
4. Skicka ett frånvaromeddelande till en supportinkorg. Kontrollera att inget ärende skapas och att mejlloggen visar **Automatiskt mejl ignorerat**.
5. Kontrollera att ett vanligt nytt ärende fortfarande ger kunden en bekräftelse.
6. Befintliga ärenden får inget originalmejl i efterhand.

### Uppgradering från 1.0.124 till 1.0.125

Använd det senast byggda `driftpunkt-upgrade-1.0.125.zip` i superadmins uppdateringsvy. Ta backup av applikation och databas före uppgraderingen. Migreringen `Version20261001120000` krävs från 1.0.124 och lägger till kolumnen `companies.email_domains`. Låt det ordinarie uppdateringsflödet köra migrationerna och slutföra efterstegen, rensa cache och ladda om PHP/OPcache.

Efter uppdateringen:

1. Kontrollera att adminöversikten visar version `1.0.125`, att migreringen `Version20261001120000` är körd och att uppdateringsjobbet är slutfört.
2. Kontrollera att företagsbadges visar symbol och företagsnamn utan prefixet `Företag:`.
3. Kontrollera admins triagemottagare och deras personliga e-postinställningar. Utan vald mottagare eller allmän adress används aktiva ärendekoordinatorer.
4. Skicka ett provmejl från en okänd avsändare till en inkorg där avsändaren ska granskas. Bekräfta att ett internt utkast skapas och att granskningsnotisen når triagemottagaren via den riktiga utgående mejlservern.
5. Öppna länken i notisen med ett ärendekoordinatorkonto och kontrollera att rätt utkast visas under **Okända ärenden**.
6. Vid uteblivet mejl: kontrollera notifieringsloggen för `unknown_sender_review_created`, triageinställningarna och utgående e-postkonfiguration. Den okända avsändaren får ingen kundbekräftelse innan granskning.
7. Lägg in e-postdomäner under **Admin → Företag** och kontrollera att ett provmejl till moderbolagets inkorg skapar utkast eller ärende på rätt dotterbolag.
8. Kontrollera som kund att bilagor i kundsynliga kommentarer går att ladda ner och att interna bilagor inte är åtkomliga.

### Uppgradering till 1.0.124

Använd det kumulativa paketet `driftpunkt-upgrade-1.0.124.zip` i superadmins uppdateringsvy. Ta backup av applikation och databas före uppgraderingen. Uppdateringsflödet ska köra Doctrine-migreringen `Version20260922120000`, rensa cache och ladda om PHP/OPcache.

Efter uppdateringen:

1. Kontrollera att adminöversikten visar version `1.0.124`.
2. Kontrollera under **Systeminställningar → Ärenden & filer** att superadmin kan slå på och stänga av personliga e-postsignaturer.
3. Verifiera att avstängning bevarar sparade signaturer men hindrar redigering och utskick.
4. Skicka ett kundsvar med signatur och egen kopia och kontrollera att signaturen inte sparas i ärendehistoriken.
5. Kontrollera att företagsbadges visas i relevanta tekniker- och koordinatorvyer.

### Uppgradering till 1.0.115

Använd det kumulativa paketet `driftpunkt-upgrade-1.0.115.zip` i superadmins uppdateringsvy. Ta backup av både applikation och databas och verifiera återläsning innan paketet appliceras. Uppdateringsflödet ska köra migrationer, rensa cache och ladda om PHP/OPcache. Inga MFA-krav aktiveras automatiskt.

Efter uppdateringen:

1. Kontrollera att adminöversikten visar version `1.0.115` och att migrationer och eftersteg är slutförda.
2. Bekräfta att samtliga rollspecifika **Obligatoriskt**-val är av och att tidigare tillgänglighetsval är oförändrade.
3. Öppna **Inställningar → Åtkomst → MFA-policy**, skapa eller importera MFA-krypteringsnyckeln och kör `php bin/console app:mfa:encrypt-secrets --env=prod` tills migrationen rapporteras klar.
4. Verifiera frivillig MFA, vald period för betrodd enhet samt att befintliga sjudagarscookies inte förlängs.
5. Regressionstesta bilagor, CSV-export, inventariedatum, underhållsposter, notifieringar och de mobila portalvyerna.

### Rensa historiska utkastprefix

Version 1.0.109 innehåller ett skyddat underhållskommando för avslutade ärenden som fortfarande har rubrikprefixet `[Utkast]` eller `[Draft]`. Ta databasbackup före en skrivande körning och börja alltid med förhandsgranskning:

```bash
php bin/console app:tickets:normalize-legacy-draft-subjects --env=prod
```

Rensa i första hand uttryckligen kontrollerade referenser:

```bash
php bin/console app:tickets:normalize-legacy-draft-subjects \
  --env=prod \
  --ticket=REFERENS-1001 \
  --apply
```

`--all --apply` kan användas efter att hela förhandsvisningen har verifierats. Kommandot behandlar endast statusarna **Löst** och **Stängd**, hoppar alltid över ärenden med en väntande utkastgranskning och revisionsloggar varje ändrad rubrik.

En väntande granskning ska utredas och avslutas innan prefixet rensas. Kontrollera särskilt granskningsarten: `unknown_sender` hanteras i koordinatorns kö, medan exempelvis `unauthorized_reply` kan ligga i admins **E-post → Utkastgranskning**. Godkänn eller avvisa inte en gammal granskningspost slentrianmässigt om det kopplade ärendet redan har flyttats eller korrigerats, eftersom det ordinarie granskningsflödet kan uppdatera status, synlighet, kund, företag, sammanfattning och tilldelning. Verifiera aktuell ärendedata och använd en kontrollerad underhållsåtgärd med backup för redan behandlade historiska poster.

### Viktigt vid avbruten 1.0.45-uppdatering

Version `1.0.46` och senare innehåller hotfixen för migrationen `DoctrineMigrations\Version20260514100000`. Om en uppdatering till `1.0.45` stoppade med felet `Call to undefined method Doctrine\DBAL\Schema\Table::changeColumn()` ska du använda senaste `driftpunkt-upgrade-<version>.zip` och köra uppdateringsflödet igen.

Om koden redan är uppackad manuellt kan migrationen köras om från applikationskatalogen efter att `1.0.46` eller senare ligger på plats:

```bash
php bin/console doctrine:migrations:migrate --no-interaction --allow-no-migration --all-or-nothing --env=prod
```

Felet sker innan Doctrine markerar migrationen som slutförd, så samma migration kan normalt köras igen utan manuell databasändring. Kontrollera ändå alltid backup innan du fortsätter en avbruten driftuppdatering.

Bygg båda paketen:

```bash
composer build:packages
```

Om globalt `composer` saknas men projektets lokala Composer-PHAR finns i repo-roten kan samma kommando köras med:

```bash
php composer build:packages
```

Bygg bara uppgraderingspaketet:

```bash
composer build:upgrade-package
```

Om Composer-kommandot inte är tillgängligt i driftmiljön kan samma uppgraderingsbygge köras direkt via Symfony-kommandot:

```bash
php bin/console app:release:build-packages --type=upgrade
```

Bygg bara installationspaketet:

```bash
composer build:install-package
```

Både installations- och uppgraderingspaket innehåller `vendor/`, så en NAS eller Debian-server slipper hämta Composer-paket från internet under själva uppdateringen.

Uppgraderingspaket är kumulativa från Driftpunkt 1.x: senaste `driftpunkt-upgrade-<version>.zip` innehåller hela aktuella kodbasen och ska normalt kunna lyfta en installation som ligger flera versioner efter direkt till aktuell version. Själva adminuppdateraren jämför paketet mot installerad kod och skriver bara nya eller ändrade filer, tar bort gamla hanterade filer och bevarar runtime-data som `.env*`, `var/` och uppladdad branding.

Paketens webbrot är `htdocs/`. Apache, Docker eller NAS-webbserver ska därför peka mot `<appkatalog>/htdocs`. `public/` kan finnas kvar för kompatibilitet i äldre miljöer, men nya installationer ska inte kräva `/public`.

Om webbhotellet har en fast publik katalog som heter `/htdocs` kan hela installationspaketet packas upp direkt där. Paketets root-`.htaccess` och root-`index.php` gör då att appen startar från yttre `/htdocs`, samtidigt som känsliga mappar som `config/`, `src/`, `vendor/` och `var/` blockeras. Det kräver Apache med `mod_rewrite` och fungerande `.htaccess`.

Paketbygget tar bara med installations- och uppdateringsnära dokumentation från `docs/`. Interna produktplaner, systemspecar, skärmbilder, designunderlag och superpowers-planer följer inte med i zip-filerna.

Lägg releaseinformation i `release-notes/<version>.md` innan paketet byggs, till exempel `release-notes/1.0.9.md`. Paketbyggaren läser filen automatiskt, lägger den i zippen och bäddar in nyheter, driftkrav och efterkontroller i `release-metadata.json`. Ordinarie releasebyggen stoppas om filen saknas.

Ordinarie paketbyggen utan `--release-version` stoppar om `composer.json` saknar ett numeriskt `major.minor.patch`, om release notes för versionen saknas eller om versionsnumret hoppar över nästa patch-, minor- eller majorsteg. Det gör att exempelvis `1.0.90` följs av `1.0.91`, `1.1.0` eller `2.0.0`, men inte av ett oavsiktligt hopp till `1.0.92`.

Uppdateringar från adminytan kör förkontroll mot MariaDB, stoppar parallella uppdateringar, tar kodbackup, kör diff-medveten kodsynk, kör obligatoriska eftersteg och markerar inte versionen som klar förrän migrationer och cache-rensning har lyckats.

## Publik Export

Den publika repot ska inte längre få en rensad kodkopia. Exporten bygger i stället aktuella releasepaket och skriver en separat engelsk README för öppna repot.

Exporten innehåller:

- senaste installationspaketet: `packages/driftpunkt-install-<version>.zip`
- upp till tre kumulativa uppgraderingspaket totalt: det senaste samt högst två äldre paket som fallback och versionshistorik, under `packages/driftpunkt-upgrade-<version>.zip`
- en `.sha256`-fil bredvid varje paket
- `README.md` på engelska med produktbeskrivning, bilder, installationsflöde, uppgraderingsflöde och engelska release notes för aktuell publik release
- `LICENSE.md` och `SECURITY.md`, hämtade från utvecklingsrepot
- ärendemallar, säkerhetshänvisning och manuellt releaseflöde under `.github/`
- utvalda publika README-assets under `assets/`, hämtade från `docs/public-assets/`
- `PUBLIC_EXPORT_MANIFEST.md` med exporterade och överhoppade paket

Skärmbilder ska granskas för personuppgifter innan de inkluderas i exporten. Superadminbilden är undantagen eftersom den visar en personlig e-postadress.

Skapa eller uppdatera den publika arbetskopian från den privata repot:

```bash
composer export:public-repo
```

Kommandot kör paketbygget först, så aktuell version i `composer.json` får både install- och upgradepaket innan filerna kopieras. Peka exporten direkt mot en lokal klon av den publika GitHub-repot:

```bash
php bin/console app:repo:export-public --output-dir=/path/to/Driftpunkt
```

För den lokala publika arbetskopian som används här:

```bash
php bin/console app:repo:export-public --output-dir=/home/kenta/REPO/Driftpunkt-public
```

Rekommenderat arbetsflöde:

1. Utveckla i `Driftpunkt-privat`
2. Höj versionen och lägg releaseinformation i `release-notes/<version>.md`; skriv den på engelska om den ska synas i publika repots README
3. Kör publik export mot den lokala klonen av öppna repot
4. Granska att diffen bara innehåller README, licens, säkerhetspolicy, `.github/`, manifest, publika bilder och paketfiler
5. Commit:a och pusha när exporten ser ren ut

### GitHub Releases

Efter export, commit och push till det publika repot kan du öppna **Actions → Prepare GitHub Release → Run workflow** och ange den exporterade versionen, exempelvis `1.0.133`.

Flödet kontrollerar installations- och uppgraderingspaketens SHA-256 samt att releaseinformationen gäller rätt version. Det skapar sedan ett utkast i **Releases** med båda ZIP-filerna, kontrollsummor och releaseinformation. Granska utkastet och välj **Publish release**. Flödet publicerar inte automatiskt och ändrar inte en redan befintlig release.

## Dokumentation

Den planerade omdesignen för **Driftpunkt 2.0.0** finns i [Designplan för version 2.0.0](docs/portal_redesign_plan.md), med sparade konceptskisser. Hela gränssnittet omfattas: publika sidor, inloggningsflöden samt kund-, tekniker-, koordinator-, admin- och superadminportaler med undersidor. Utseende och användarupplevelse förbättras medan befintliga funktioner, behörigheter och verksamhetsregler bevaras. **Test och godkännande på NAS är obligatoriskt före driftsättning.** Planen beskriver framtida arbete och är inte implementerad funktionalitet.

Kompletterande prioriteringar, underlag och acceptanskriterier finns i [Förbättringsförslag för 2.0.0](docs/portal_redesign_review_2_0_0.md). Förslag som kräver ny funktionalitet är uttryckligen separerade från omdesignen.

Dokumentationen i `docs/` beskriver nuläget i koden, inte en framtida målbild. De drift- och publikt återanvändbara dokumenten är:

- `docs/driftpunkt_ticket_system_spec.md`
- `docs/installation_and_deployment.md`
- `docs/debian_server_setup.md`
- `docs/nas_docker_setup.md`
- `docs/mail_configuration_guide.md`
- `docs/mail_processing_rules.md`
- `docs/mail_polling_operations.md`
- `docs/ticket_attachment_archiving_operations.md`
- `docs/security_requirements.md`
- `docs/known_limitations.md`

Det privata repot kan dessutom innehålla interna produkt-, roll-, datamodell-, test- och planeringsdokument som inte behöver följa med i den publika exporten.

Bra startpunkter beroende på vad du vill göra:

- produktomfång och nuläge: `docs/driftpunkt_ticket_system_spec.md`
- installation och drift: `docs/installation_and_deployment.md`
- mailflöden: `docs/mail_processing_rules.md`
- Debian-server: `docs/debian_server_setup.md`
- NAS/Docker: `docs/nas_docker_setup.md`
- säkerhetskrav: `docs/security_requirements.md`

### Automatisk kundregistrering via företagsinkorg

Automatiken är avstängd som standard. För att aktivera den loggar superadmin in, öppnar inkorgens inställningar, väljer ett aktivt företag och markerar **Tillåt okända avsändare** och **Automatisk kundregistrering**. Ange tillåtna domäner på inkorgen eller **E-postdomäner** på företaget och dess dotterbolag under **Administration → Företag**, exempelvis `foretag.se`. Underdomäner anges separat; jokertecken och `@` används inte.

När en ny avsändares domän matchar ett aktivt företag inom inkorgens koncerngren skapas kundpersonen på det matchade företaget och ärendet får privat synlighet. Företagsdomäner har företräde framför inkorgens domänlista. Om bara inkorgens tillåtna domäner matchar används inkorgens företag. Befintliga kunder och avsändaralias inom samma koncerngren återanvänds utan att kunder flyttas mellan företag.

När automatiken är avstängd kan företagsdomäner fortfarande placera utkast på rätt dotterbolag. Okända avsändare som behöver granskas ger en notis enligt triageinställningarna och finns under **Okända ärenden**. Om inkorgen inte tillåter okända avsändare avvisas deras mejl även när de innehåller svar eller ärendenummer.

För en företagsgrupp som ska behålla tidigare flöde:

1. Logga in som superadmin och öppna **Administration → Företag**.
2. Öppna moderföretaget, markera **Behåll tidigare mejlhantering** och klicka på **Spara mejlhantering**.
3. Undantaget gäller moderföretaget och alla underföretag på samtliga nivåer. Det har företräde även om automatiken är påslagen på deras inkorgar.

Underföretag kan inte upphäva ett ärvt undantag. Vyerna visar vilket företag undantaget kommer från. När undantaget tas bort gäller inkorgarnas sparade inställningar igen, förutsatt att inget annat moderföretag fortfarande har undantag. Befintliga kunder, ärenden och granskningsutkast ändras inte.

Automatiskt skapade kunder får mejlhantering utan portalåtkomst eller inbjudan. Administratören kan aktivera **Portalåtkomst** separat i användarformuläret. Inloggning och lösenordsåterställning är blockerade tills dess. Domänmatchning är en kopplingsregel, inte verifierad identitet.

Registreringen använder transaktioner och gemensamt lås för att hantera samtidiga mejl och återkörning. Vid flera servrar måste `LOCK_DSN` peka på en gemensam låstjänst; med standardkonfiguration ska `var/lock` delas mellan webb och scheduler. Se [installation, inställningar och felsökning](docs/automatic-mail-customer-registration.md).

### Återhämtning efter cachefel i 1.0.120

Om appliceringsloggen visar att migreringen lyckats men **Refresh prod-cache** misslyckats med `Directory not empty`, kör följande som webbappens användare i PHP-containern. Kommandot rensar och bygger om produktionscachen:

```bash
cd /var/www/html
php bin/console cache:clear --env=prod --no-debug --no-interaction
```

På en vanlig server använder du installationens applikationskatalog i stället för `/var/www/html`. Kontrollera att kommandot ger `[OK]` och att inloggning, ärendevyer och mejlbevakning fungerar. Den historiska felposten ändras inte av manuell cacherensning.

Version 1.0.121 använder detta cachekommando i både obligatoriska och manuella eftersteg. Den första appliceringen kan fortfarande använda äldre uppdaterarkod som redan är laddad; om samma cachefel återkommer, kör kommandot ovan igen. Ingen ny migration tillkommer jämfört med 1.0.120 och en redan genomförd migration körs inte om.

## Licens

Driftpunkt distribueras under **Driftpunkt Free Use License 1.0**. Se [LICENSE.md](LICENSE.md) för fullständiga villkor och [SECURITY.md](SECURITY.md) för rapportering av säkerhetsbrister.
