<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

final class Version20261030120000 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Stores an optional contact phone number on tickets';
    }

    public function up(Schema $schema): void
    {
        $table = $schema->getTable('tickets');
        $table->addColumn('contact_phone', 'string', ['length' => 40, 'notnull' => false]);
    }

    public function down(Schema $schema): void
    {
        $table = $schema->getTable('tickets');
        $table->dropColumn('contact_phone');
    }
}
