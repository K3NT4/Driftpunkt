<?php

declare(strict_types=1);

namespace App\Module\Ticket\Service;

use App\Module\Ticket\Entity\Ticket;
use App\Module\Ticket\Entity\TicketComment;
use App\Module\Ticket\Entity\TicketCommentAttachment;
use Symfony\Component\HttpFoundation\File\UploadedFile;

final class TicketCommentAttachmentBuilder
{
    public const ZIP_MAX_UPLOAD_BYTES = 1048576;

    public function __construct(
        private readonly TicketAttachmentStorage $ticketAttachmentStorage,
        private readonly TicketAttachmentDeduplicator $ticketAttachmentDeduplicator,
    ) {
    }

    /**
     * @return list<UploadedFile>
     */
    public static function uploadedFilesFrom(mixed $value): array
    {
        $values = \is_array($value) ? $value : [$value];

        return array_values(array_filter($values, static fn (mixed $file): bool => $file instanceof UploadedFile));
    }

    /**
     * @param list<UploadedFile> $uploadedFiles
     * @param array{
     *     enabled: bool,
     *     maxUploadMb: int,
     *     storagePath: string,
     *     allowedExtensions: list<string>,
     *     externalUploadsEnabled: bool,
     *     externalProviderLabel: string,
     *     externalInstructions: string
     * } $attachmentSettings
     * @return AttachmentCopyResult
     */
    public function build(
        array $uploadedFiles,
        string $externalAttachmentUrl,
        string $externalAttachmentLabel,
        Ticket $ticket,
        TicketComment $comment,
        array $attachmentSettings,
    ): AttachmentCopyResult {
        if ([] === $uploadedFiles && '' === $externalAttachmentUrl) {
            return AttachmentCopyResult::empty();
        }

        if (!$attachmentSettings['enabled']) {
            throw new \InvalidArgumentException('Bilagor är inte aktiverade av admin just nu.');
        }

        $result = AttachmentCopyResult::empty();
        foreach ($uploadedFiles as $uploadedFile) {
            $attachment = $this->buildUploadedAttachment($uploadedFile, $ticket, $comment, $attachmentSettings, $result);
            if ($attachment instanceof TicketCommentAttachment) {
                $result->addCreatedAttachment($attachment);
            }
        }

        if ('' !== $externalAttachmentUrl) {
            $result->addCreatedAttachment($this->buildExternalAttachment($externalAttachmentUrl, $externalAttachmentLabel, $comment, $attachmentSettings));
        }

        return $result;
    }

    /**
     * @param array{maxUploadMb: int, storagePath: string, allowedExtensions: list<string>} $attachmentSettings
     */
    private function buildUploadedAttachment(UploadedFile $uploadedFile, Ticket $ticket, TicketComment $comment, array $attachmentSettings, AttachmentCopyResult $result): ?TicketCommentAttachment
    {
        if (!$uploadedFile->isValid()) {
            throw new \InvalidArgumentException('Filen kunde inte laddas upp.');
        }

        $maxFileSize = $attachmentSettings['maxUploadMb'] * 1024 * 1024;
        if ($uploadedFile->getSize() > $maxFileSize) {
            throw new \InvalidArgumentException(sprintf('Filen är för stor. Maxstorlek för direktuppladdning är %d MB.', $attachmentSettings['maxUploadMb']));
        }

        $originalName = trim($uploadedFile->getClientOriginalName());
        $extension = ltrim(mb_strtolower(pathinfo($originalName, \PATHINFO_EXTENSION)), '.');
        if ('' === $extension || !\in_array($extension, $attachmentSettings['allowedExtensions'], true)) {
            throw new \InvalidArgumentException(sprintf('Filtypen är inte tillåten. Tillåtna filtyper är: %s.', implode(', ', $attachmentSettings['allowedExtensions'])));
        }

        if ('zip' === $extension && $uploadedFile->getSize() > self::ZIP_MAX_UPLOAD_BYTES) {
            throw new \InvalidArgumentException('Zip-filer får vara högst 1 MB.');
        }

        $fileSize = (int) $uploadedFile->getSize();
        $contentHash = $this->ticketAttachmentDeduplicator->contentHashForFile($uploadedFile->getPathname());
        if (null !== $contentHash && null !== $this->ticketAttachmentDeduplicator->findDuplicateInTicket($ticket, $contentHash, $fileSize)) {
            $result->addSkippedDuplicate($originalName);

            return null;
        }

        $storedFile = $this->ticketAttachmentStorage->storeUploadedFile($uploadedFile, $ticket, $attachmentSettings['storagePath']);

        return TicketCommentAttachment::fromLocalFile(
            $comment,
            $storedFile['displayName'],
            $storedFile['filePath'],
            $storedFile['mimeType'],
            $storedFile['fileSize'],
            $storedFile['contentHash'],
        );
    }

    /**
     * @param array{externalUploadsEnabled: bool, externalProviderLabel: string} $attachmentSettings
     */
    private function buildExternalAttachment(string $externalAttachmentUrl, string $externalAttachmentLabel, TicketComment $comment, array $attachmentSettings): TicketCommentAttachment
    {
        if (!$attachmentSettings['externalUploadsEnabled']) {
            throw new \InvalidArgumentException('Extern delningslänk för stora filer är inte aktiverad av admin.');
        }

        $normalizedUrl = filter_var($externalAttachmentUrl, \FILTER_VALIDATE_URL);
        $scheme = false !== $normalizedUrl ? parse_url($normalizedUrl, \PHP_URL_SCHEME) : null;
        if (false === $normalizedUrl || !\in_array(mb_strtolower((string) $scheme), ['http', 'https'], true)) {
            throw new \InvalidArgumentException('Delningslänken måste vara en giltig http- eller https-adress.');
        }

        $displayName = '' !== $externalAttachmentLabel
            ? $externalAttachmentLabel
            : sprintf('Extern fil via %s', $attachmentSettings['externalProviderLabel']);

        return TicketCommentAttachment::fromExternalUrl($comment, mb_strimwidth(trim($displayName), 0, 255, ''), $normalizedUrl);
    }
}
