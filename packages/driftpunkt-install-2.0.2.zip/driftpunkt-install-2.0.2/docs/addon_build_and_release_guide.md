# Tillägg och inbyggda funktioner i 2.0.1

Status: funktionerna är verifierade i NAS- och Debian-testmiljö. Se [uppgraderingsguiden för 2.0.1](upgrade_to_2_0_1.md) och [författarguiden på engelska](addons.md).

## Inbyggda funktioner

Öppna **Funktioner** via administratörsmenyn (`/portal/admin/functions`). Administratörer kan slå på eller av:

- **Utökad nyhetsredigering**: tidigare News Editor Plus. Reglaget styr redigeringsverktygen; befintliga artiklar och deras rendering bevaras.
- **Telefonstöd**: administratörernas telefonöversikt. Direktåtkomst stoppas även om någon har kvar ett bokmärke när funktionen är avstängd.

Vanliga rollbehörigheter gäller även när en funktion är påslagen. Ändringar kräver CSRF-token och revisionsloggas. Avstängning raderar varken inställningar, innehåll eller historik.

Migration `Version20261116120000` kopierar tidigare på/av-val för `news-editor-plus` till `feature.news_extended_editor_enabled`. Om katalogposten saknas behålls tidigare standard: påslagen. Telefonstöd förblir påslaget som tidigare. Befintliga nya funktionsval skrivs inte över. Den gamla addonposten och releasehistoriken bevaras men styr inte längre nyhetsredigeraren.

## Äldre körbara paket

Den äldre modellen med PHP, controllers, tjänster och Twig från ZIP-paket är avvecklad. Sådana paket kan inte isoleras från kärnans behörigheter i samma PHP-process.

- Import och aktivering av paketversioner avvisas på servern.
- Paketen registrerar inte längre autoloading, tjänster, routes eller mallar vid uppstart.
- Paketfiler och kataloghistorik lämnas kvar för inventering. Gamla katalogfält visar tidigare registrering och är inte bevis för att ett paket körs.
- Äldre avregistrering och explicit paketstädning ska användas först efter kontroll av vad som behöver bevaras.

**SupportDesk är borttaget** enligt användarbeslut. Genvägar, inställningsyta och sparroute finns inte längre, och ingen ersättare planeras. Historiska AnyDesk-/TeamViewer-inställningar och katalogposter bevaras utan att läsas eller användas.

## Uppgradering och driftverifiering

Detta ändrar tilläggens körmodell. Inventera paket och beroenden på testkopian före driftsättning. Ta vanlig kod- och databasbackup. Uppgradering ska ske i underhållsläge; blanda inte den nya koden med en gammal kompilerad Symfony-container.

Kör ordinarie migrations- och cacheflöde för den faktiska installationen. Exempel efter att den nya koden lagts på plats:

```bash
php bin/console doctrine:migrations:migrate --no-interaction --allow-no-migration --all-or-nothing --env=prod
php bin/console cache:clear --env=prod --no-debug --no-interaction
```

Migrationen skriver funktionsinställningar i databasen. Cacherensningen bygger om appens container; hantera långlivade workers och OPcache enligt installationens vanliga deployrutin. Backa inte genom att bara kopiera tillbaka den gamla oskyddade addon-laddaren.

Verifiera på NAS/MariaDB före produktionsgodkännande:

1. Tidigare avstängd nyhetsredigering förblir avstängd efter migration.
2. Administratören kan ändra båda reglagen; kund och tekniker kan inte ändra dem.
3. Telefonstöd ger 404 när avstängt och fungerar efter återaktivering med oförändrade data.
4. Befintliga nyheter och telefonhistorik finns kvar.
5. Ett gammalt paket med `enabled: true` registrerar inga routes eller tjänster efter omstart/cacheombyggnad.
6. ZIP-import och direkt begäran om paketaktivering nekas utan nytt cachejobb.
7. SupportDesk-inställningar är bevarade och inga brutna startlänkar visas.

## Skapa ett eget tillägg – utan kodändringar

Första externa formatet är informationspaneler med text och länkar. PHP, Twig, JavaScript, SQL, CSS och egna resurser ingår inte. All rendering sker med Driftpunkts egna komponenter; ett tillägg får ingen databas-, fil-, API- eller nätverksåtkomst.

### Via adminytan

1. Logga in som superadmin och öppna **Tillägg → Egna tillägg**.
2. Välj **Ladda ner addon.json som exempel**.
3. Öppna filen i en textredigerare och ändra namn, beskrivning, länkar och placering.
4. Välj filen och klicka **Förhandsvisa** för att se panelen och målgruppen utan att spara eller aktivera. Samma komponent används på målsidan; tema och bredd kan variera. **Validera** kontrollerar filen utan att spara något.
5. Klicka **Importera** och granska den lagrade versionen via **Förhandsvisa** innan du väljer **Aktivera denna version**.
6. Kontrollera panelen på vald sida. **Stäng av** får omedelbar effekt utan cacherensning.

En panel visas för samtliga användare på den valda ytan; formatet har inga företagsspecifika datavyer. Lägg inte kundspecifik information i gemensamma paneler. Publika paneler är synliga utan inloggning.

### För utvecklare

Skapa en ny exempelfil (en befintlig fil skrivs inte över):

```bash
php bin/console app:addon:create mina-supportlankar --output=addon.json
php bin/console app:addon:validate addon.json
```

Den sista kommandoraden kontrollerar bara filen. Den varken importerar eller aktiverar ett tillägg. Formatet finns även som [exempelfil](examples/addon.json) och [JSON-schema](addon.schema.json). Schemat ger editorstöd; Driftpunkts validator kontrollerar även länkar, kontrolltecken och total filstorlek.

```json
{
  "schema_version": 1,
  "slug": "mina-supportlankar",
  "version": "1.0.0",
  "name": "Mina supportlänkar",
  "description": "Guider och kontaktvägar.",
  "placement": "homepage",
  "links": [{"label": "Kontakta supporten", "url": "/kontakt"}]
}
```

| Fält | Regel |
| --- | --- |
| `schema_version` | Heltalet `1`. Andra formatversioner avvisas. |
| `slug` | Stabil identitet, börjar med a–z, små bokstäver/siffror/bindestreck, högst 64 tecken. |
| `version` | Tre heltal, exempelvis `1.0.0`. Varje nummer är högst sex siffror. |
| `name` / `description` | Vanlig text, högst 80 respektive 1 000 tecken. HTML och Twig renderas som text. |
| `placement` | `homepage`, `customer_dashboard` eller `technician_dashboard`. |
| `links` | Högst åtta objekt med `label` (80 tecken) och `url` (2 048 tecken). |
| `links.url` | Intern sökväg som börjar med en ensam `/`, eller en `https://`-adress utan användarnamn/lösenord. Kontrolltecken, protokollrelativa länkar och bakstreck avvisas. |

Samtliga fält krävs; andra fält avvisas. Hela filen får vara högst 32 KiB. Ingen ZIP-fil eller byggprocess behövs. Säkert formaterad text interpoleras aldrig till kod eller mallar och externa länkar hämtas inte av servern.

### Uppdatering, återgång och borttagning

Behåll `slug`, höj `version` och importera den nya JSON-filen. Tidigare aktiv version fortsätter visas tills den nya uttryckligen aktiveras. Samma versionsnummer får inte skrivas över. Endast en version per slug kan vara aktiv. Välj en äldre bevarad version för att gå tillbaka.

Stäng av en aktiv version innan den tas bort. **Ta bort inaktiv version** raderar bara den valda deklarativa tilläggsfilen. Lagret rymmer högst 100 versioner; städa inaktiva versioner vid behov.

### Lagring och felsökning

Filer och aktiveringsval ligger i `var/declarative_addons/`, utanför webbrot och separat från PHP-/Twig-laddning. Ta med katalogen i normal backup. Webbprocessen behöver skrivbehörighet till den katalogen; kärnkoden behöver ingen extra skrivbehörighet. Import/aktivering sker under lås och filer byts atomiskt. Nya importer är inaktiva tills en superadmin aktiverar dem. Åtgärder revisionsloggas.

Om panelen inte visas: kontrollera aktiv version, placering och att rätt roll är inloggad. Adminytan visar **Kräver åtgärd** med filnamn, orsak och återhämtningssteg för skadade manifests, aktiveringsfiler och saknade aktiva versioner. Ogiltiga lagrade tillägg ignoreras och loggas. Hanteringen, förhandsvisningen och feltexterna följer svenska, engelska och norska. Författarens egen text översätts inte automatiskt. Om tilläggslagret inte går att läsa visas grundsidan utan paneler. Försök inte lösa det genom att aktivera gamla PHP-paket.

Mer avancerade integrationer och ett externt integrations-API ingår inte i format 1. Se [formatguiden](addons.md) och [uppgraderingsguiden](upgrade_to_2_0_1.md) för det stöd som finns.
