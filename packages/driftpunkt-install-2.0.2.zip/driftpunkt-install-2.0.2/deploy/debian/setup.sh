#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP_DIR="${APP_DIR:-$(cd "${SCRIPT_DIR}/../.." && pwd)}"
APP_USER="${APP_USER:-www-data}"
APP_GROUP="${APP_GROUP:-www-data}"
DOMAIN="${DOMAIN:-}"
PHP_BIN="${PHP_BIN:-php}"
PUBLIC_URL="${PUBLIC_URL:-}"

usage() {
  cat <<'HELP'
Driftpunkt på Debian 13 – förbered webbservern från installationspaketets rot.
  sudo env DOMAIN=support.example.com bash deploy/debian/setup.sh
  bash deploy/debian/setup.sh --check
  bash deploy/debian/setup.sh --help

Utan flagga installeras systempaket, Composer-beroenden, Apache-vhost och timerfiler.
En saknad .env.local skapas med slumpad APP_SECRET; befintliga hemligheter ändras inte.
Databas och första konto skapas separat. Inga tabeller raderas och timers startas inte.
--check gör en lokal PHP-/paketkontroll utan apt, nätverk, databas eller konfigurationsändring.
APP_DIR, APP_USER, APP_GROUP och PHP_BIN kan anges vid anpassad installation.
HELP
}
case "${1:-}" in
  --help|-h) usage; exit 0 ;;
  --check) [[ $# -eq 1 ]] || { usage >&2; exit 1; }; exec "$PHP_BIN" "$APP_DIR/deploy/check-runtime.php" ;;
  '') [[ $# -eq 0 ]] || { usage >&2; exit 1; } ;;
  *) usage >&2; exit 1 ;;
esac

[[ "$APP_DIR" =~ ^/[a-zA-Z0-9_./-]+$ && "$APP_DIR" != / ]] || { echo 'APP_DIR måste vara en absolut katalog utan blanksteg eller specialtecken.' >&2; exit 1; }
[[ "$APP_USER" =~ ^[a-z_][a-z0-9_-]*$ && "$APP_GROUP" =~ ^[a-z_][a-z0-9_-]*$ ]] || { echo 'Ogiltig tjänsteanvändare eller grupp.' >&2; exit 1; }
[[ "$DOMAIN" =~ ^[a-zA-Z0-9][a-zA-Z0-9.-]*$ && "$DOMAIN" != driftpunkt.example.com ]] || { echo 'Ange serverns riktiga domän eller IPv4-adress: sudo env DOMAIN=support.dindoman.se bash deploy/debian/setup.sh' >&2; exit 1; }
PUBLIC_URL="${PUBLIC_URL:-https://${DOMAIN}}"
[[ "$PUBLIC_URL" == "https://${DOMAIN}" || "$PUBLIC_URL" == "http://${DOMAIN}" ]] || { echo 'PUBLIC_URL ska vara http(s):// samma DOMAIN utan sökväg.' >&2; exit 1; }
trap 'printf "Installationen avbröts vid rad %s. Inga databastabeller har initierats av detta skript. Åtgärda felet innan du fortsätter.\n" "$LINENO" >&2' ERR

if [[ "${EUID}" -ne 0 ]]; then
  echo "Kor scriptet med sudo eller som root."
  exit 1
fi

if [[ ! -f "${APP_DIR}/composer.json" ]]; then
  echo "Hittar inte ${APP_DIR}/composer.json."
  echo "Packa upp installationspaketet och kör skriptet där composer.json finns."
  exit 1
fi

echo "Installerar Debian-paket..."
apt-get update
apt-get install -y \
  apache2 \
  git \
  unzip \
  curl \
  logrotate \
  mariadb-client \
  mariadb-server \
  php \
  php-cli \
  php-common \
  php-curl \
  php-intl \
  php-gd \
  php-mbstring \
  php-mysql \
  php-opcache \
  php-xml \
  php-zip \
  libapache2-mod-php

PHP_VERSION="$(${PHP_BIN} -r 'echo PHP_VERSION;' 2>/dev/null || true)"
if [[ -z "${PHP_VERSION}" ]]; then
  echo "PHP kunde inte koras."
  exit 1
fi

if ! "${PHP_BIN}" -r '
  $supported = (PHP_MAJOR_VERSION === 8 && PHP_MINOR_VERSION === 4 && version_compare(PHP_VERSION, "8.4.27", ">="))
    || (PHP_MAJOR_VERSION === 8 && PHP_MINOR_VERSION === 5 && version_compare(PHP_VERSION, "8.5.12", ">="));
  exit($supported ? 0 : 1);
'; then
  echo "Driftpunkt kraver PHP 8.4.27+ i 8.4-serien eller 8.5.12+ i 8.5-serien. Installerad version: ${PHP_VERSION}"
  echo "Uppdatera PHP-motorn for CVE-2026-109618 och CVE-2026-109619 och kor scriptet igen."
  exit 1
fi

PHP_BIN="$(command -v "$PHP_BIN")"
if [[ -f "$APP_DIR/composer" ]]; then
  COMPOSER=("$PHP_BIN" "$APP_DIR/composer")
else
  apt-get install -y composer
  COMPOSER=(composer)
fi
id "$APP_USER" >/dev/null
getent group "$APP_GROUP" >/dev/null

if [[ ! -f "${APP_DIR}/.env.local" ]]; then
  umask 077
  # Create only once; never rotate a production APP_SECRET on a repeated setup.
  DP_INSTALL_DIR="$APP_DIR" DP_INSTALL_DOMAIN="$DOMAIN" DP_INSTALL_URL="$PUBLIC_URL" "$PHP_BIN" <<'PHP'
<?php
$directory = getenv('DP_INSTALL_DIR');
$target = $directory.'/.env.local';
$content = file_get_contents($directory.'/deploy/debian/app.env.example');
$content = str_replace('byt-till-en-lang-slumpad-hemlighet', bin2hex(random_bytes(32)), $content);
$content = str_replace('https://driftpunkt.example.com', getenv('DP_INSTALL_URL'), $content);
$content = str_replace('driftpunkt.example.com', getenv('DP_INSTALL_DOMAIN'), $content);
$handle = fopen($target, 'x');
if (false === $handle) { exit(1); }
try { if (fwrite($handle, $content) !== strlen($content)) { exit(1); } } finally { fclose($handle); }
PHP
  chown "${APP_USER}:${APP_GROUP}" "${APP_DIR}/.env.local"
  chmod 600 "${APP_DIR}/.env.local"
fi
if grep -q 'byt-databaslosenord' "${APP_DIR}/.env.local"; then
  echo "Miljöfilen är förberedd med en slumpad APP_SECRET. Befintliga hemligheter har inte ändrats."
  echo "Nästa steg: konfigurera MariaDB och DATABASE_URL enligt docs/debian_server_setup.md."
  echo "Redigera ${APP_DIR}/.env.local och kör sedan samma setup-kommando igen."
  exit 0
fi

echo "Installerar Composer-beroenden..."
cd "${APP_DIR}"
mkdir -p "${APP_DIR}/var/cache" "${APP_DIR}/var/log" "${APP_DIR}/var/share" "${APP_DIR}/htdocs/assets/branding"
chown -R "${APP_USER}:${APP_GROUP}" "${APP_DIR}"
chmod 600 "${APP_DIR}/.env.local"
runuser -u "${APP_USER}" -- env APP_ENV=prod APP_DEBUG=0 COMPOSER_HOME="${APP_DIR}/var/composer" "${COMPOSER[@]}" install --no-dev --no-interaction --optimize-autoloader
runuser -u "${APP_USER}" -- "$PHP_BIN" "${APP_DIR}/deploy/check-runtime.php"

echo "Installerar logrotation..."
cp "${APP_DIR}/deploy/debian/driftpunkt-logrotate" /etc/logrotate.d/driftpunkt
sed -i "s#/var/www/driftpunkt#${APP_DIR}#g" /etc/logrotate.d/driftpunkt

echo "Installerar Apache-site..."
cp "${APP_DIR}/deploy/debian/apache-driftpunkt.conf" /etc/apache2/sites-available/driftpunkt.conf
sed -i "s#driftpunkt.example.com#${DOMAIN}#g" /etc/apache2/sites-available/driftpunkt.conf
sed -i "s#/var/www/driftpunkt#${APP_DIR}#g" /etc/apache2/sites-available/driftpunkt.conf
a2enmod rewrite
a2ensite driftpunkt.conf
apache2ctl configtest
systemctl reload apache2

echo "Installerar systemd-timers..."
cp "${APP_DIR}/deploy/debian/driftpunkt-"*.service /etc/systemd/system/
cp "${APP_DIR}/deploy/debian/driftpunkt-"*.timer /etc/systemd/system/
for service_name in driftpunkt-mail-poll driftpunkt-attachment-archive; do
  service_file="/etc/systemd/system/${service_name}.service"
  sed -i "s#/var/www/driftpunkt#${APP_DIR}#g" "${service_file}"
  sed -i "s#^User=www-data\$#User=${APP_USER}#" "${service_file}"
  sed -i "s#^Group=www-data\$#Group=${APP_GROUP}#" "${service_file}"
  sed -i "s#^ExecStart=/usr/bin/php #ExecStart=${PHP_BIN} #" "${service_file}"
done
systemctl daemon-reload

echo
echo "Serverförberedelser klara. Miljöfilens befintliga hemligheter har bevarats."
echo "Bara för en NY, TOM databas (aldrig för uppdatering):"
echo "  sudo -u ${APP_USER} ${PHP_BIN} ${APP_DIR}/bin/console app:install:fresh --env=prod"
echo "  sudo -u ${APP_USER} ${PHP_BIN} ${APP_DIR}/bin/console app:create-admin din-adress@example.com --type=super_admin --env=prod"
echo "Vid befintlig installation: följ uppgraderingsguiden och kör inte fresh-kommandot."
echo "Verifiera ${PUBLIC_URL}, första kontot och HTTPS innan verksamhetsjobben aktiveras."
echo "  systemctl enable --now driftpunkt-mail-poll.timer driftpunkt-attachment-archive.timer"
echo "Webbrot: ${APP_DIR}/htdocs. HTTPS/brandvägg konfigureras separat."
