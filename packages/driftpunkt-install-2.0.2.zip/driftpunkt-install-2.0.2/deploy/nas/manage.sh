#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "${SCRIPT_DIR}/../.." && pwd)"
ENV_FILE="${SCRIPT_DIR}/.env"
COMPOSE_FILE="${SCRIPT_DIR}/compose.yaml"
usage() {
  cat <<'HELP'
Driftpunkt NAS – kör från den uppackade installationskatalogen.
  bash deploy/nas/manage.sh init https://support.example.com
      Skapar privat miljöfil med slumpade hemligheter. Skriver aldrig över en befintlig fil.
  bash deploy/nas/manage.sh install [--resume]
      Bygger och initierar en NY installation. Startar ännu inga verksamhetsjobb.
      --resume återupptar en avbruten nyinstallation; databasinitiering nekar befintliga tabeller.
  bash deploy/nas/manage.sh admin admin@example.com
      Skapar första superadmin med dold lösenordsinmatning.
  bash deploy/nas/manage.sh start
      Startar schemaläggaren efter att första kontot och installationen verifierats.
  bash deploy/nas/manage.sh check
      Kontrollerar PHP, beroenden och bilder i app och schemaläggarens avbildning.
  bash deploy/nas/manage.sh status
  bash deploy/nas/manage.sh logs

Docker Compose v2 krävs. Använd sudo före bash om Docker kräver det.
Standardport på NAS: 8080. Ändra APP_PORT i den genererade miljöfilen vid behov.
Detta hjälpverktyg är för medföljande deploy/nas/compose.yaml, inte egna äldre stackar.
HELP
}
fail() { printf 'FEL: %s\n' "$*" >&2; exit 1; }
require_env() { [[ -f "$ENV_FILE" ]] || fail 'Kör init först. Befintliga installationer ska behålla sin ordinarie konfiguration.'; }
require_docker() {
  command -v docker >/dev/null || fail 'Docker saknas. Installera Container Manager/Docker och Compose v2 först.'
  docker compose version >/dev/null || fail 'Docker Compose v2 saknas eller kan inte köras.'
  docker info >/dev/null 2>&1 || fail 'Ingen åtkomst till Docker. Kontrollera tjänsten och dina rättigheter (eventuellt sudo).'
}
dc() { docker compose -f "$COMPOSE_FILE" --env-file "$ENV_FILE" "$@"; }
command_name="${1:-help}"
[[ $# -eq 0 ]] || shift
case "$command_name" in
  help|--help|-h) usage ;;
  init)
    [[ $# -eq 1 ]] || fail 'Ange publik basadress, exempelvis https://support.example.com eller http://nas-ip:8080.'
    url="${1%/}"
    [[ "$url" =~ ^https?://(\[[a-fA-F0-9:]+\]|[a-zA-Z0-9][a-zA-Z0-9.-]*)(:[0-9]{1,5})?$ ]] || fail 'Adressen ska vara http(s)://värd[:port], utan lösenord, sökväg eller frågesträng.'
    if [[ "$url" =~ :([0-9]+)$ ]]; then
      port="${BASH_REMATCH[1]}"; ((10#$port >= 1 && 10#$port <= 65535)) || fail 'Port måste vara 1–65535.'
    fi
    [[ ! -e "$ENV_FILE" ]] || fail 'Miljöfilen finns redan och har INTE ändrats.'
    secret() { od -An -N32 -tx1 /dev/urandom | tr -d ' \n'; }
    umask 077
    app_secret="$(secret)"; db_secret="$(secret)"; root_secret="$(secret)"
    [[ ${#app_secret} -eq 64 && ${#db_secret} -eq 64 && ${#root_secret} -eq 64 ]] || fail 'Kunde inte skapa säkra slumpvärden.'
    # Noclobber protects against a concurrent init after the existence check.
    (set -o noclobber; cat > "$ENV_FILE" <<ENV
APP_ENV=prod
APP_DEBUG=0
APP_SECRET=$app_secret
APP_SHARE_DIR=var/share
DEFAULT_URI=$url
DRIFTPUNKT_PUBLIC_BASE_URL=$url
PHP_CLI_BINARY=/usr/local/bin/php
APP_PORT=8080
MARIADB_DATABASE=driftpunkt
MARIADB_USER=driftpunkt
MARIADB_PASSWORD=$db_secret
MARIADB_ROOT_PASSWORD=$root_secret
DATABASE_URL="mysql://driftpunkt:$db_secret@database:3306/driftpunkt?serverVersion=mariadb-11.8.6&charset=utf8mb4"
MAILER_DSN=null://null
MAILER_FROM=notifications@example.invalid
DRIFTPUNKT_ENABLE_DEMO_DATA=0
ENV
    ) || fail 'Miljöfilen kunde inte skapas exklusivt. Ingen befintlig fil skrivs över.'
    printf 'Miljöfil skapad med rättighet 600. Hemligheterna visas inte. Säkerhetskopiera filen skyddat.\n'
    printf 'Granska DEFAULT_URI, APP_PORT och MAILER_FROM i deploy/nas/.env. SMTP är avstängt.\nNästa steg: bash deploy/nas/manage.sh install\n'
    ;;
  install)
    [[ $# -eq 0 || ( $# -eq 1 && "$1" == --resume ) ]] || fail 'Använd install eller install --resume.'
    require_env
    [[ ! -f "$SCRIPT_DIR/data/.installation-complete" ]] || fail 'Installationen är redan klar. Använd check/status eller uppgraderingsguiden.'
    if [[ $# -eq 0 && -d "$SCRIPT_DIR/data/mariadb" ]]; then
      if ! existing_data="$(find "$SCRIPT_DIR/data/mariadb" -mindepth 1 -maxdepth 1 -print -quit 2>/dev/null)"; then
        fail 'Databaskatalogen kan inte kontrolleras. Ingen ändring gjordes. Kontrollera rättigheter och använd uppgraderingsguiden för befintlig drift.'
      fi
      [[ -z "$existing_data" ]] || fail 'Databasfiler finns redan. Ingen ändring gjordes. Vid en avbruten NY installation: install --resume. För befintlig drift: följ uppgraderingsguiden.'
    fi
    require_docker
    dc config --quiet
    mkdir -p "$SCRIPT_DIR/data/var" "$SCRIPT_DIR/data/mariadb" "$SCRIPT_DIR/data/branding"
    dc build --pull app
    dc up -d database
    # app waits for MariaDB; scheduler must NOT wait for an uninitialised application's HTTP health.
    dc up -d app
    dc exec -T --user www-data app php deploy/check-runtime.php
    if [[ ! -f "$SCRIPT_DIR/data/.schema-initialized" ]]; then
      dc exec -T --user www-data app php bin/console app:install:fresh --env=prod --no-interaction
      (umask 077; printf 'Initialized by manage.sh after a successful fresh install.\n' > "$SCRIPT_DIR/data/.schema-initialized")
    elif [[ $# -eq 0 ]]; then
      fail 'Denna installation är redan initierad. Använd uppgraderingsguiden.'
    fi
    dc exec -T --user www-data app php -d memory_limit=512M bin/console cache:clear --env=prod --no-debug
    (umask 077; touch "$SCRIPT_DIR/data/.installation-complete")
    printf '\nDatabasen är initierad. Skapa nu första superadmin:\nbash deploy/nas/manage.sh admin din-adress@example.com\n'
    printf 'Verifiera inloggning och HTTPS innan: bash deploy/nas/manage.sh start\n'
    ;;
  admin)
    [[ $# -eq 1 && "$1" == *@* && "$1" != -* ]] || fail 'Ange administratörens e-postadress.'
    require_env; require_docker
    dc exec --user www-data app php bin/console app:create-admin "$1" --type=super_admin --env=prod
    ;;
  start)
    [[ $# -eq 0 ]] || fail 'start tar inga argument.'
    require_env; require_docker
    dc up -d --no-build scheduler
    printf 'Schemaläggaren startad. Kontrollera med status och logs.\n'
    ;;
  check)
    [[ $# -eq 0 ]] || fail 'check tar inga argument.'
    require_env; require_docker
    dc config --quiet
    dc exec -T --user www-data app php deploy/check-runtime.php
    # One-off command checks scheduler's image without starting its mail loop.
    dc run --rm --no-deps --user www-data --entrypoint php scheduler deploy/check-runtime.php
    ;;
  status|logs)
    [[ $# -eq 0 ]] || fail 'Kommandot tar inga argument.'
    require_env; require_docker
    if [[ "$command_name" == status ]]; then dc ps; else dc logs --tail=80 app scheduler; fi
    ;;
  *) usage >&2; fail 'Okänt kommando. Inga ändringar gjordes.' ;;
esac
