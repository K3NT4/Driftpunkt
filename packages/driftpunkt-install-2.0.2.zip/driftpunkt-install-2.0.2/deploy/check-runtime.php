<?php

declare(strict_types=1);

// Standalone preflight: no Symfony boot, database access or environment secrets.
$failed = false;
$check = static function (bool $ok, string $message) use (&$failed): void {
    echo ($ok ? '[OK] ' : '[FEL] ').$message.PHP_EOL;
    $failed = $failed || !$ok;
};
$check(PHP_INT_SIZE === 8, '64-bitars PHP');
$check((PHP_MAJOR_VERSION === 8 && PHP_MINOR_VERSION === 4 && version_compare(PHP_VERSION, '8.4.27', '>='))
    || (PHP_MAJOR_VERSION === 8 && PHP_MINOR_VERSION === 5 && version_compare(PHP_VERSION, '8.5.12', '>=')),
    'PHP '.PHP_VERSION.' (kräver 8.4.27+ inom 8.4 eller 8.5.12+ inom 8.5)');
foreach (['ctype', 'curl', 'fileinfo', 'gd', 'iconv', 'intl', 'mbstring', 'openssl', 'pdo_mysql', 'xml', 'zip'] as $extension) {
    $check(extension_loaded($extension), 'PHP-tillägg: '.$extension);
}
if (extension_loaded('gd')) {
    $gd = gd_info();
    $check(!empty($gd['JPEG Support']) && !empty($gd['PNG Support']) && !empty($gd['FreeType Support']), 'GD: JPEG, PNG och FreeType');
}
$root = dirname(__DIR__);
$check(is_file($root.'/vendor/autoload.php'), 'Produktionsberoenden finns');
$check(is_file($root.'/htdocs/index.php'), 'Webbrot: htdocs');
foreach (['technician', 'coordinator'] as $role) {
    foreach (['modern', 'classic'] as $layout) {
        foreach (['', '-mobile'] as $size) {
            $name = $role.'-'.$layout.$size.'.png';
            $check(is_file($root.'/htdocs/assets/layout-comparison/'.$name), 'Förhandsvisning: '.$name);
        }
    }
}
echo $failed ? "Förkontrollen har fel. Åtgärda dem innan installationen fortsätter.\n" : "Förkontrollen är klar. Databas, HTTPS och webbens PHP kontrolleras separat.\n";
exit($failed ? 1 : 0);
