<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

final class Version20261114190000 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Company support cards, explicit grants and source-separated public review context';
    }

    public function up(Schema $schema): void
    {
        $cards = $schema->createTable('support_cards');
        $cards->addColumn('id', 'string', ['length' => 32]);
        $cards->addColumn('company_id', 'integer');
        $cards->addColumn('token_hash', 'string', ['length' => 64, 'notnull' => false]);
        $cards->addColumn('encrypted_token', 'text', ['notnull' => false]);
        $cards->addColumn('active', 'boolean');
        $cards->addColumn('instruction', 'string', ['length' => 1000]);
        $cards->addColumn('urgent_contact', 'string', ['length' => 255]);
        $cards->addColumn('opening_hours', 'string', ['length' => 255]);
        $cards->addColumn('logo_key', 'string', ['length' => 80, 'notnull' => false]);
        $cards->setPrimaryKey(['id']);
        $cards->addUniqueIndex(['company_id']);
        $cards->addUniqueIndex(['token_hash']);
        $cards->addForeignKeyConstraint('companies', ['company_id'], ['id'], ['onDelete' => 'CASCADE']);

        $grants = $schema->createTable('support_card_grants');
        $grants->addColumn('id', 'integer', ['autoincrement' => true]);
        $grants->addColumn('user_id', 'integer');
        $grants->addColumn('company_id', 'integer');
        $grants->addColumn('revoked_at', 'datetime_immutable', ['notnull' => false]);
        $grants->setPrimaryKey(['id']);
        $grants->addUniqueIndex(['user_id', 'company_id'], 'uniq_support_card_grant');
        $grants->addIndex(['company_id']);
        $grants->addForeignKeyConstraint('users', ['user_id'], ['id'], ['onDelete' => 'CASCADE']);
        $grants->addForeignKeyConstraint('companies', ['company_id'], ['id'], ['onDelete' => 'CASCADE']);

        $incoming = $schema->getTable('incoming_mails');
        $incoming->addColumn('submission_source', 'string', ['length' => 30, 'default' => 'email']);
        $incoming->addColumn('requested_company_id', 'integer', ['notnull' => false]);
        $incoming->addIndex(['requested_company_id']);
        $incoming->addForeignKeyConstraint('companies', ['requested_company_id'], ['id'], ['onDelete' => 'SET NULL']);

        $submissions = $schema->createTable('support_card_submissions');
        $submissions->addColumn('id', 'string', ['length' => 64]);
        $submissions->addColumn('ticket_id', 'integer', ['notnull' => false]);
        $submissions->setPrimaryKey(['id']);
        $submissions->addIndex(['ticket_id']);
        $submissions->addForeignKeyConstraint('tickets', ['ticket_id'], ['id'], ['onDelete' => 'SET NULL']);
    }

    public function down(Schema $schema): void
    {
        $schema->dropTable('support_card_submissions');
        $incoming = $schema->getTable('incoming_mails');
        foreach ($incoming->getForeignKeys() as $fk) {
            if (['requested_company_id'] === $fk->getLocalColumns()) {
                $incoming->removeForeignKey($fk->getName());
            }
        }
        foreach ($incoming->getIndexes() as $index) {
            if (['requested_company_id'] === $index->getColumns()) {
                $incoming->dropIndex($index->getName());
            }
        }
        $incoming->dropColumn('requested_company_id');
        $incoming->dropColumn('submission_source');
        $schema->dropTable('support_card_grants');
        $schema->dropTable('support_cards');
    }
}
