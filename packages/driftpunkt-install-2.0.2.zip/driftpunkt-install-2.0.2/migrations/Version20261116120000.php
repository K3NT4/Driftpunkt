<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

final class Version20261116120000 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Preserves legacy news editor choice as a native feature setting; keeps addon history and data';
    }

    public function up(Schema $schema): void
    {
        $newsValue = $schema->hasTable('addon_modules')
            ? "COALESCE((SELECT CASE WHEN is_enabled = 1 THEN '1' ELSE '0' END FROM addon_modules WHERE slug = 'news-editor-plus'), '1')"
            : "'1'";

        foreach (['feature.news_extended_editor_enabled' => $newsValue, 'feature.telefonstod_enabled' => "'1'"] as $key => $value) {
            $this->addSql("INSERT INTO system_settings (setting_key, setting_value, created_at, updated_at)
                SELECT '$key', $value, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP
                WHERE NOT EXISTS (SELECT 1 FROM system_settings WHERE setting_key = '$key')");
        }
    }

    public function down(Schema $schema): void
    {
        $this->throwIrreversibleMigrationException('Feature preferences and retained addon history must not be reset automatically.');
    }
}
