<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

final class Version20261114120000 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Adds per-account snooze storage for the GitHub release version notice';
    }

    public function up(Schema $schema): void
    {
        $table = $schema->createTable('release_notice_snoozes');
        $table->addColumn('id', 'integer')->setAutoincrement(true);
        $table->addColumn('user_id', 'integer');
        $table->addColumn('release_version', 'string', ['length' => 40]);
        $table->addColumn('snoozed_until', 'bigint');
        $table->addColumn('created_at', 'datetime_immutable');
        $table->addColumn('updated_at', 'datetime_immutable');
        $table->setPrimaryKey(['id']);
        $table->addUniqueIndex(['user_id', 'release_version'], 'uniq_release_notice_user_version');
        $table->addIndex(['snoozed_until'], 'idx_release_notice_snoozed_until');
        $table->addForeignKeyConstraint('users', ['user_id'], ['id'], ['onDelete' => 'CASCADE']);
    }

    public function down(Schema $schema): void
    {
        $schema->dropTable('release_notice_snoozes');
    }
}
