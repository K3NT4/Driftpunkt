<?php

declare(strict_types=1);

namespace App\Twig;

use App\Module\Portal\Service\InternalPortalLayout;
use Twig\Extension\AbstractExtension;
use Twig\TwigFunction;

final class InternalPortalLayoutExtension extends AbstractExtension
{
    public function __construct(private readonly InternalPortalLayout $layout) {}
    public function getFunctions(): array { return [new TwigFunction('internal_portal_layout', [$this, 'view'])]; }
    public function view(mixed $user): array { return ['available' => $this->layout->available($user), 'choice' => $this->layout->choice($user), 'csrf_id' => $this->layout->available($user) ? $this->layout->csrfId($user) : null]; }
}
