<?php

declare(strict_types=1);

namespace App\Twig;

use App\Module\System\Service\ReleaseNoticeService;
use Twig\Extension\AbstractExtension;
use Twig\TwigFunction;

/**
 * Exposes release_notice() to Twig. The backing service performs the explicit
 * ROLE_SUPER_ADMIN check itself, reads the shared snapshot cache only and never
 * performs HTTP; it returns null (no banner) for every other account or when
 * there is no new, unsnoozed stable release.
 */
final class ReleaseNoticeExtension extends AbstractExtension
{
    public function __construct(
        private readonly ReleaseNoticeService $releaseNoticeService,
    ) {
    }

    public function getFunctions(): array
    {
        return [
            new TwigFunction('release_notice', [$this->releaseNoticeService, 'releaseNotice']),
        ];
    }
}
