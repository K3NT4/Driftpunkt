<?php

declare(strict_types=1);

namespace App\Twig;

use App\Module\System\Service\DeclarativeAddonManager;
use Symfony\Component\Security\Core\Authorization\AuthorizationCheckerInterface;
use Twig\Extension\AbstractExtension;
use Twig\TwigFunction;

final class DeclarativeAddonExtension extends AbstractExtension
{
    public function __construct(private readonly DeclarativeAddonManager $addons, private readonly AuthorizationCheckerInterface $authorization)
    {
    }

    public function getFunctions(): array
    {
        return [new TwigFunction('addon_panels', $this->panels(...))];
    }

    public function panels(string $placement): array
    {
        if ('homepage' !== $placement) {
            $role = match ($placement) {
                'customer_dashboard' => 'ROLE_CUSTOMER',
                'technician_dashboard' => 'ROLE_TECHNICIAN',
                default => null,
            };
            if (null === $role || !$this->authorization->isGranted($role)) {
                return [];
            }
        }

        return $this->addons->panels($placement);
    }
}
