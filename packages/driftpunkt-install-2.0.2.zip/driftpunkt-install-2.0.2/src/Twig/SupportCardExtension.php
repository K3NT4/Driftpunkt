<?php

declare(strict_types=1);

namespace App\Twig;

use App\Module\Identity\Entity\Company;
use App\Module\Identity\Entity\User;
use App\Module\PublicPortal\Service\SupportCardService;
use Twig\Extension\AbstractExtension;
use Twig\TwigFunction;

final class SupportCardExtension extends AbstractExtension
{
    public function __construct(private readonly SupportCardService $cards)
    {
    }

    public function getFunctions(): array
    {
        return [new TwigFunction('can_manage_support_card', $this->canManage(...))];
    }

    public function canManage(?User $user, ?Company $company): bool
    {
        return null !== $company && $this->cards->canManage($user, $company);
    }
}
