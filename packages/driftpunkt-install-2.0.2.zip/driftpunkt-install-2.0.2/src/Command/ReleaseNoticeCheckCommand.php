<?php

declare(strict_types=1);

namespace App\Command;

use App\Module\System\Service\GitHubReleaseChecker;
use Symfony\Component\Console\Attribute\AsCommand;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Style\SymfonyStyle;
use Symfony\Component\DependencyInjection\Attribute\Autowire;

/**
 * Background entry point for the server-wide automatic release check. The
 * shared snapshot state file in var/version_check governs the 24-hour
 * automatic cooldown; the task schedule only triggers this command.
 */
#[AsCommand(
    name: 'app:release-notice:check',
    description: 'Kontrollerar officiella GitHub-releaser och uppdaterar den gemensamma versionsaviseringen.',
)]
final class ReleaseNoticeCheckCommand extends Command
{
    public function __construct(
        private readonly GitHubReleaseChecker $releaseChecker,
        #[Autowire('%kernel.environment%')]
        private readonly string $environment,
    ) {
        parent::__construct();
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $io = new SymfonyStyle($input, $output);
        if ('test' === $this->environment) {
            $io->note('Bakgrundskontroll av versioner är avstängd i testmiljön.');

            return Command::SUCCESS;
        }
        $result = $this->releaseChecker->checkAutomatic();

        $io->text($result['message']);

        return 'failure' === $result['outcome'] ? Command::FAILURE : Command::SUCCESS;
    }
}
