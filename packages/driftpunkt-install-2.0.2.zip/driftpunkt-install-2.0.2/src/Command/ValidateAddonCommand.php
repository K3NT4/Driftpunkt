<?php

declare(strict_types=1);

namespace App\Command;

use App\Module\System\Service\DeclarativeAddonManager;
use App\Module\System\Exception\AddonProblem;
use Symfony\Contracts\Translation\TranslatorInterface;
use Symfony\Component\Console\Attribute\AsCommand;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Style\SymfonyStyle;

#[AsCommand(name: 'app:addon:validate', description: 'Validerar addon.json utan att importera eller aktivera tillägget.')]
final class ValidateAddonCommand extends Command
{
    public function __construct(private readonly DeclarativeAddonManager $addons, private readonly TranslatorInterface $translator)
    {
        parent::__construct();
    }

    protected function configure(): void
    {
        $this->setDescription($this->translator->trans('addons.cli.validate_description'));
        $this->addArgument('file', InputArgument::REQUIRED, $this->translator->trans('addons.cli.file_help'));
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $io = new SymfonyStyle($input, $output);
        try {
            $path = (string) $input->getArgument('file');
            if (!is_file($path) || false === ($json = file_get_contents($path, false, null, 0, DeclarativeAddonManager::MAX_BYTES + 1))) {
                throw new \RuntimeException('addons.error.upload_read');
            }
            $this->addons->validate($json);
            $io->success($this->translator->trans('addons.cli.validated'));

            return Command::SUCCESS;
        } catch (\InvalidArgumentException|\RuntimeException $exception) {
            $io->error($this->translator->trans($exception->getMessage(), $exception instanceof AddonProblem ? $exception->translationParameters() : []));

            return Command::FAILURE;
        }
    }
}
