<?php

declare(strict_types=1);

namespace App\Command;

use App\Module\System\Service\DeclarativeAddonManager;
use App\Module\System\Exception\AddonProblem;
use Symfony\Contracts\Translation\TranslatorInterface;
use Symfony\Component\Console\Attribute\AsCommand;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Style\SymfonyStyle;

#[AsCommand(name: 'app:addon:create', description: 'Skapar en addon.json för informationspaneler och länkar.')]
final class CreateAddonCommand extends Command
{
    public function __construct(private readonly DeclarativeAddonManager $addons, private readonly TranslatorInterface $translator)
    {
        parent::__construct();
    }

    protected function configure(): void
    {
        $this->setDescription($this->translator->trans('addons.cli.create_description'));
        $this->addArgument('slug', InputArgument::REQUIRED, $this->translator->trans('addons.cli.slug_help'))
            ->addOption('output', null, InputOption::VALUE_REQUIRED, $this->translator->trans('addons.cli.output_help'), 'addon.json');
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $io = new SymfonyStyle($input, $output);
        try {
            $json = json_encode($this->addons->example((string) $input->getArgument('slug')), \JSON_PRETTY_PRINT | \JSON_UNESCAPED_UNICODE | \JSON_UNESCAPED_SLASHES | \JSON_THROW_ON_ERROR)."\n";
            $path = (string) $input->getOption('output');
            $file = @fopen($path, 'x');
            if (false === $file) {
                throw new \RuntimeException('addons.error.create_exists');
            }
            try {
                if (\strlen($json) !== fwrite($file, $json)) {
                    throw new \RuntimeException('addons.error.create_write');
                }
            } finally {
                fclose($file);
            }
            $io->success($this->translator->trans('addons.cli.created'));

            return Command::SUCCESS;
        } catch (\InvalidArgumentException|\RuntimeException $exception) {
            $io->error($this->translator->trans($exception->getMessage(), $exception instanceof AddonProblem ? $exception->translationParameters() : []));

            return Command::FAILURE;
        }
    }
}
