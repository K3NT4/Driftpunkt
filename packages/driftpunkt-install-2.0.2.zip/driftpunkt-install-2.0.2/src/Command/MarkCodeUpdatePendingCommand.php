<?php

declare(strict_types=1);

namespace App\Command;

use App\Module\System\Service\SystemSettings;
use Symfony\Component\Console\Attribute\AsCommand;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

#[AsCommand(name: 'app:code-update:mark-pending', description: 'Registrerar en installerad uppdatering för friskbekräftelse efter cachebytet.')]
final class MarkCodeUpdatePendingCommand extends Command
{
    public function __construct(private readonly SystemSettings $systemSettings)
    {
        parent::__construct();
    }

    protected function configure(): void
    {
        $this->addArgument('package-name', InputArgument::REQUIRED);
        $this->addArgument('package-version', InputArgument::REQUIRED);
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $name = trim((string) $input->getArgument('package-name'));
        $version = trim((string) $input->getArgument('package-version'));
        if ('' === $name || '' === $version) {
            $output->writeln('<error>Paketnamn och version måste anges.</error>');

            return Command::INVALID;
        }

        $this->systemSettings->markUpdateReleasePendingConfirmation($name, $version);
        $output->writeln('Uppdateringen väntar på friskbekräftelse.');

        return Command::SUCCESS;
    }
}
