<?php

declare(strict_types=1);

namespace App\Module\Ticket\Entity;

use App\Module\Shared\Entity\TimestampableTrait;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity]
#[ORM\Table(name: 'ticket_comment_attachments')]
#[ORM\Index(columns: ['content_hash', 'file_size'], name: 'IDX_TICKET_COMMENT_ATTACHMENT_HASH_SIZE')]
#[ORM\HasLifecycleCallbacks]
class TicketCommentAttachment
{
    use TimestampableTrait;

    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\ManyToOne(inversedBy: 'attachments')]
    #[ORM\JoinColumn(nullable: false, onDelete: 'CASCADE')]
    private TicketComment $comment;

    #[ORM\Column(length: 255)]
    private string $displayName;

    #[ORM\Column(length: 191, nullable: true)]
    private ?string $mimeType = null;

    #[ORM\Column(nullable: true)]
    private ?int $fileSize = null;

    #[ORM\Column(length: 64, nullable: true)]
    private ?string $contentHash = null;

    #[ORM\Column(length: 1000, nullable: true)]
    private ?string $filePath = null;

    #[ORM\Column(length: 255, nullable: true)]
    private ?string $archiveEntryName = null;

    #[ORM\Column(length: 1000, nullable: true)]
    private ?string $externalUrl = null;

    #[ORM\Column(length: 64, nullable: true)]
    private ?string $inlineToken = null;

    public function getInlineToken(): ?string { return $this->inlineToken; }
    public function setInlineToken(?string $token): self
    {
        $this->inlineToken = null !== $token && preg_match('/^[a-f0-9]{64}$/D', $token) ? $token : null;
        return $this;
    }

    private function __construct(TicketComment $comment, string $displayName)
    {
        $this->comment = $comment;
        $this->displayName = trim($displayName);
    }

    public static function fromLocalFile(
        TicketComment $comment,
        string $displayName,
        string $filePath,
        ?string $mimeType,
        int $fileSize,
        ?string $contentHash = null,
    ): self {
        $attachment = new self($comment, $displayName);
        $attachment->filePath = $filePath;
        $attachment->mimeType = null !== $mimeType ? trim($mimeType) : null;
        $attachment->fileSize = max(0, $fileSize);
        $attachment->setContentHash($contentHash);

        return $attachment;
    }

    public static function fromExternalUrl(TicketComment $comment, string $displayName, string $externalUrl): self
    {
        $attachment = new self($comment, $displayName);
        $attachment->externalUrl = trim($externalUrl);

        return $attachment;
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getComment(): TicketComment
    {
        return $this->comment;
    }

    public function setComment(TicketComment $comment): self
    {
        $this->comment = $comment;

        return $this;
    }

    public function getDisplayName(): string
    {
        return $this->displayName;
    }

    public function getMimeType(): ?string
    {
        return $this->mimeType;
    }

    public function getFileSize(): ?int
    {
        return $this->fileSize;
    }

    public function getContentHash(): ?string
    {
        return $this->contentHash;
    }

    public function setContentHash(?string $contentHash): self
    {
        if (null === $contentHash) {
            $this->contentHash = null;

            return $this;
        }

        $normalized = mb_strtolower(trim($contentHash));
        $this->contentHash = 1 === preg_match('/^[a-f0-9]{64}$/', $normalized) ? $normalized : null;

        return $this;
    }

    public function getFilePath(): ?string
    {
        return $this->filePath;
    }

    public function getExternalUrl(): ?string
    {
        return $this->externalUrl;
    }

    public function getArchiveEntryName(): ?string
    {
        return $this->archiveEntryName;
    }

    public function markAsArchivedInZip(string $zipPath, string $entryName): self
    {
        $this->filePath = $zipPath;
        $this->archiveEntryName = trim($entryName);

        return $this;
    }

    public function isArchivedInZip(): bool
    {
        return null !== $this->archiveEntryName;
    }

    public function isExternal(): bool
    {
        return null !== $this->externalUrl;
    }

    public function isPreviewableImage(): bool
    {
        if ($this->isExternal()) {
            return false;
        }

        $mimeType = mb_strtolower((string) $this->mimeType);
        return \in_array($mimeType, ['image/png', 'image/jpeg', 'image/gif', 'image/webp'], true);
    }

    public function isPdf(): bool
    {
        return !$this->isExternal() && ('pdf' === mb_strtolower(pathinfo($this->displayName, PATHINFO_EXTENSION)) || 'application/pdf' === mb_strtolower((string) $this->mimeType));
    }

    public function isTnef(): bool
    {
        return !$this->isExternal() && ('winmail.dat' === mb_strtolower($this->displayName) || \in_array(mb_strtolower((string) $this->mimeType), ['application/ms-tnef', 'application/vnd.ms-tnef'], true));
    }

    public function isEmailMessage(): bool
    {
        if ($this->isExternal()) {
            return false;
        }

        return \in_array(mb_strtolower(pathinfo($this->displayName, PATHINFO_EXTENSION)), ['eml', 'msg'], true)
            || \in_array(mb_strtolower((string) $this->mimeType), ['message/rfc822', 'message/global', 'application/vnd.ms-outlook'], true);
    }

    public function isDocumentLike(): bool
    {
        if ($this->isExternal() || $this->isPreviewableImage()) {
            return false;
        }

        $mimeType = mb_strtolower((string) $this->mimeType);
        if (str_starts_with($mimeType, 'text/') || str_contains($mimeType, 'pdf') || str_contains($mimeType, 'word') || str_contains($mimeType, 'sheet') || str_contains($mimeType, 'excel') || str_contains($mimeType, 'csv')) {
            return true;
        }

        $extension = ltrim(mb_strtolower(pathinfo($this->displayName, \PATHINFO_EXTENSION)), '.');

        return \in_array($extension, ['pdf', 'txt', 'log', 'doc', 'docx', 'xls', 'xlsx', 'csv'], true);
    }

    public function getKindLabel(): string
    {
        if ($this->isExternal()) {
            return 'Extern länk';
        }

        if ($this->isPreviewableImage()) {
            return 'Bild';
        }

        if ($this->isEmailMessage()) {
            return 'Mejl';
        }

        if ($this->isDocumentLike()) {
            return 'Dokument';
        }

        return 'Fil';
    }
}
