<?php

declare(strict_types=1);

namespace App\Module\Portal\EventSubscriber;

use App\Module\Portal\Service\InternalPortalLayout;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpKernel\Event\RequestEvent;
use Symfony\Component\HttpKernel\KernelEvents;
use Symfony\Component\Routing\Generator\UrlGeneratorInterface;
use Symfony\Component\Security\Core\Authentication\Token\Storage\TokenStorageInterface;

/** Runs after portal/session/MFA/password gates, including on an already authenticated session. */
final class InternalPortalLayoutIntroductionSubscriber implements EventSubscriberInterface
{
    public function __construct(private readonly InternalPortalLayout $layout, private readonly TokenStorageInterface $tokens, private readonly UrlGeneratorInterface $urls) {}

    public static function getSubscribedEvents(): array { return [KernelEvents::REQUEST => ['onRequest', -30]]; }

    public function onRequest(RequestEvent $event): void
    {
        if (!$event->isMainRequest() || $event->hasResponse()) { return; }
        $request = $event->getRequest(); $user = $this->tokens->getToken()?->getUser();
        if (!$this->layout->needsIntroduction($user) || !$request->hasSession() || !$request->isMethod('GET')
            || $request->isXmlHttpRequest() || 'html' !== $request->getPreferredFormat('html')
            || !in_array($request->attributes->get('_route'), InternalPortalLayout::PAGE_ROUTES, true)) { return; }
        $export = $request->query->all()['export'] ?? null;
        if (null !== $export && '' !== $export) { return; }
        $response = new RedirectResponse($this->urls->generate('app_portal_layout_introduction', [
            'return_to' => $this->layout->returnPath($user, $request->getRequestUri()),
        ]));
        $response->headers->set('Cache-Control', 'private, no-store');
        $event->setResponse($response);
    }
}
