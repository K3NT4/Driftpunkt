<?php

declare(strict_types=1);

namespace App\Module\Portal\Controller;

use App\Module\Portal\Service\UiAssetVersion;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;

/**
 * Serves the shared 2.0.0 design foundation as cacheable files instead of inlining
 * them in every HTML response. Works the same under htdocs/ and public/, so no
 * packaging allowlist changes are needed. Contains no user data and needs no session.
 */
final class UiAssetController extends AbstractController
{
    public function __construct(
        private readonly UiAssetVersion $uiAssetVersion,
    ) {
    }

    #[Route('/ui/{asset}', name: 'app_ui_asset', requirements: ['asset' => 'foundation\.(css|js)'], methods: ['GET', 'HEAD'], stateless: true)]
    public function asset(Request $request, string $asset): Response
    {
        $version = $this->uiAssetVersion->versionFor($asset);
        $response = new Response(
            $this->renderView(UiAssetVersion::TEMPLATES[$asset]),
            Response::HTTP_OK,
            ['Content-Type' => str_ends_with($asset, '.css') ? 'text/css; charset=UTF-8' : 'text/javascript; charset=UTF-8'],
        );
        $response->headers->set('X-Content-Type-Options', 'nosniff');
        $response->setEtag($version);
        $response->setPublic();

        if ($request->query->get('v') === $version) {
            // The URL changes whenever the content changes, so the browser may keep it.
            $response->setMaxAge(31536000);
            $response->headers->addCacheControlDirective('immutable');
        } else {
            $response->setMaxAge(300);
        }

        $response->isNotModified($request);

        return $response;
    }
}
