<?php

declare(strict_types=1);

namespace App\Module\Portal\Controller;

use App\Module\Identity\Enum\UserType;
use App\Module\Portal\Service\{InternalPortalLayout, InternalPortalLayoutPreferenceStore};
use App\Twig\AppRuntime;
use Psr\Log\LoggerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\{Request, Response, RedirectResponse};
use Symfony\Component\Routing\Attribute\Route;
use Symfony\Component\Security\Http\Attribute\IsGranted;

#[IsGranted('ROLE_USER')]
final class InternalPortalLayoutController extends AbstractController
{
    public function __construct(private readonly InternalPortalLayout $layout, private readonly InternalPortalLayoutPreferenceStore $preferences,
        private readonly AppRuntime $i18n, private readonly LoggerInterface $logger) {}

    #[Route('/portal/layout', name: 'app_portal_layout_introduction', methods: ['GET'])]
    public function introduction(Request $request): Response
    {
        $user = $this->getUser();
        if (!$this->layout->isEnabled()) { throw $this->createNotFoundException(); }
        if (!$this->layout->available($user)) { return $this->privateResponse(new Response($this->i18n->translate('portal.layout.forbidden'), 403)); }
        return $this->privateResponse($this->render('portal/layout/introduction.html.twig', [
            'comparisonRole' => UserType::TECHNICIAN === $user->getType() ? 'technician' : 'coordinator',
            'layoutReturnPath' => $this->layout->returnPath($user, $request->query->all()['return_to'] ?? null),
            'layoutChoice' => $this->layout->choice($user),
            'layoutCsrfId' => $this->layout->csrfId($user),
        ]));
    }

    #[Route('/portal/layout/choice', name: 'app_portal_layout_choice', methods: ['POST'])]
    public function choose(Request $request): Response
    {
        $user = $this->getUser();
        if (!$this->layout->isEnabled()) { throw $this->createNotFoundException(); }
        if (!$this->layout->available($user)) { return $this->privateResponse(new Response($this->i18n->translate('portal.layout.forbidden'), 403)); }
        $expectedRole = $user->getType();
        $data = $request->request->all(); $token = $data['_token'] ?? null; $choice = $data['choice'] ?? null;
        if (!is_string($token) || !$this->isCsrfTokenValid($this->layout->csrfId($user), $token)) {
            return $this->privateResponse(new Response($this->i18n->translate('portal.layout.csrf_error'), 403));
        }
        if (!is_string($choice) || !in_array($choice, InternalPortalLayout::CHOICES, true)) {
            return $this->privateResponse(new Response($this->i18n->translate('portal.layout.invalid_choice'), 400));
        }
        try { $this->preferences->save($user, $choice, $expectedRole); }
        catch (\DomainException) { return $this->privateResponse(new Response($this->i18n->translate('portal.layout.forbidden'), 403)); }
        catch (\Throwable $error) {
            $this->logger->warning('Could not save internal portal layout choice.', ['exception' => $error, 'user_id' => $user->getId()]);
            return $this->privateResponse(new Response($this->i18n->translate('portal.layout.store_error'), 503));
        }
        $this->addFlash('success', $this->i18n->translate('portal.layout.saved'));
        return $this->privateResponse(new RedirectResponse($this->layout->returnPath($user, $data['return_to'] ?? null), Response::HTTP_SEE_OTHER));
    }

    private function privateResponse(Response $response): Response
    {
        $response->headers->set('Cache-Control', 'private, no-store'); $response->headers->set('X-Robots-Tag', 'noindex, nofollow'); return $response;
    }
}
