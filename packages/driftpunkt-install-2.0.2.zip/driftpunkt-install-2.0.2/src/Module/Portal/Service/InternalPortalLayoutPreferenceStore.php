<?php

declare(strict_types=1);

namespace App\Module\Portal\Service;

use App\Module\Identity\Entity\User;
use App\Module\Identity\Enum\UserType;
use Doctrine\DBAL\LockMode;
use Doctrine\ORM\EntityManagerInterface;

/** Serializes layout and acknowledgement together on the existing account row. */
final class InternalPortalLayoutPreferenceStore
{
    public function __construct(private readonly EntityManagerInterface $em, private readonly InternalPortalLayout $layout) {}

    public function save(User $user, string $choice, UserType $expectedRole): void
    {
        // Validate before opening a transaction; recheck the current account after locking.
        $this->layout->acknowledgedPreferences($user, $choice);
        $this->em->wrapInTransaction(function () use ($user, $choice, $expectedRole): void {
            $this->em->lock($user, LockMode::PESSIMISTIC_WRITE);
            $this->em->refresh($user);
            if ($expectedRole !== $user->getType()) { throw new \DomainException('Account role changed while choosing layout.'); }
            $user->setTechnicianPortalPreferences($this->layout->acknowledgedPreferences($user, $choice));
        });
    }
}
