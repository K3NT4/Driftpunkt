<?php

declare(strict_types=1);

namespace App\Module\Portal\Service;

use Symfony\Component\DependencyInjection\Attribute\Autowire;

/**
 * Content hash for the shared design foundation files, used as cache-busting query value.
 */
final class UiAssetVersion
{
    /**
     * @var array<string, string>
     */
    public const TEMPLATES = [
        'foundation.css' => 'shared/ui/foundation.css.twig',
        'foundation.js' => 'shared/ui/foundation.js.twig',
    ];

    /**
     * @var array<string, string>
     */
    private array $versions = [];

    public function __construct(
        #[Autowire('%kernel.project_dir%')]
        private readonly string $projectDir,
    ) {
    }

    public function versionFor(string $asset): string
    {
        if (!isset(self::TEMPLATES[$asset])) {
            throw new \InvalidArgumentException(sprintf('Unknown UI asset "%s".', $asset));
        }

        if (!isset($this->versions[$asset])) {
            $templates = [self::TEMPLATES[$asset]];
            if ('foundation.css' === $asset) {
                $templates[] = 'shared/ui/_ticket_comment_editor.css.twig';
            }
            $context = hash_init('sha256');
            foreach ($templates as $template) {
                $path = $this->projectDir.'/templates/'.$template;
                hash_update($context, $template);
                hash_update($context, is_file($path) ? (string) file_get_contents($path) : 'missing');
            }
            $hash = hash_final($context);
            $this->versions[$asset] = substr($hash, 0, 12);
        }

        return $this->versions[$asset];
    }
}
