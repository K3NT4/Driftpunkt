<?php

declare(strict_types=1);

namespace App\Module\Portal\Service;

use App\Module\Identity\Entity\User;
use App\Module\Identity\Enum\UserType;
use App\Module\System\Service\SystemSettings;
use Symfony\Component\DependencyInjection\Attribute\Autowire;

/** Account-bound presentation only. Controllers retain their existing access checks. */
final class InternalPortalLayout
{
    public const INTRODUCTION_VERSION = 1;
    public const CSRF_PREFIX = 'choose_internal_portal_layout';
    public const CHOICE_KEY = 'portalLayout';
    public const VERSION_KEY = 'portalLayoutIntroductionVersion';
    public const ROLE_KEY = 'portalLayoutIntroductionRole';
    public const CHOICES = ['classic', 'modern'];

    public const TEMPLATES = [
        'portal/technician.html.twig' => 'classic/portal/technician.html.twig',
        'portal/technician_ticket_overview.html.twig' => 'classic/portal/technician_ticket_overview.html.twig',
        'portal/technician_ticket_create.html.twig' => 'classic/portal/technician_ticket_create.html.twig',
        'portal/coordinator.html.twig' => 'classic/portal/coordinator.html.twig',
        'portal/coordinator_ticket_show.html.twig' => 'classic/portal/coordinator_ticket_show.html.twig',
        'portal/coordinator_phone_ticket_create.html.twig' => 'classic/portal/coordinator_phone_ticket_create.html.twig',
        'portal/coordinator_unknown_ticket_reviews.html.twig' => 'classic/portal/coordinator_unknown_ticket_reviews.html.twig',
        'portal/coordinator_reports.html.twig' => 'classic/portal/coordinator_reports.html.twig',
        'portal/coordinator_guide.html.twig' => 'classic/portal/coordinator_guide.html.twig',
        'portal/technician_settings.html.twig' => 'classic/portal/technician_settings.html.twig',
        'portal/security_technician.html.twig' => 'classic/portal/security_technician.html.twig',
        'portal/security.html.twig' => 'classic/portal/security_technician.html.twig',
        'portal/internal_reports.html.twig' => 'classic/portal/internal_reports.html.twig',
        'portal/technician_news.html.twig' => 'classic/portal/technician_news.html.twig',
        'portal/technician_knowledge_base.html.twig' => 'classic/portal/technician_knowledge_base.html.twig',
        'portal/attached_email.html.twig' => 'classic/portal/attached_email.html.twig',
        'portal/tnef_attachment.html.twig' => 'classic/portal/tnef_attachment.html.twig',
        'inventory/technician_index.html.twig' => 'classic/inventory/technician_index.html.twig',
        'inventory/technician_list.html.twig' => 'classic/inventory/technician_list.html.twig',
    ];

    public const PAGE_ROUTES = [
        'app_portal_technician', 'app_portal_technician_overview', 'app_portal_technician_closed_tickets',
        'app_portal_technician_ticket_show', 'app_portal_technician_tickets_new', 'app_portal_technician_settings',
        'app_portal_coordinator', 'app_portal_coordinator_closed_tickets', 'app_portal_coordinator_ticket_show',
        'app_portal_coordinator_phone_ticket_new', 'app_portal_coordinator_unknown_ticket_reviews',
        'app_portal_coordinator_reports', 'app_portal_coordinator_guide', 'app_portal_internal_reports',
        'app_portal_technician_news', 'app_portal_technician_knowledge_base',
        'app_inventory_technician_index', 'app_inventory_technician_list', 'app_ticket_attached_email', 'app_ticket_attachment_tnef',
    ];

    public function __construct(
        #[Autowire('%env(bool:DRIFTPUNKT_INTERNAL_LAYOUT_CHOICE_ENABLED)%')]
        private readonly bool $enabled = false,
        private readonly ?SystemSettings $settings = null,
    ) {
    }

    public function isEnabled(): bool
    {
        return $this->settings?->getBool(SystemSettings::INTERNAL_PORTAL_LAYOUT_CHOICE_ENABLED, $this->enabled) ?? $this->enabled;
    }

    public function available(mixed $user): bool
    {
        return $user instanceof User && $user->isActive() && $user->isPortalAccessEnabled()
            && in_array($user->getType(), [UserType::TECHNICIAN, UserType::TICKET_COORDINATOR], true) && $this->isEnabled();
    }

    public function needsIntroduction(mixed $user): bool
    {
        if (!$this->available($user)) { return false; }
        $preferences = $user->getTechnicianPortalPreferences();
        return !in_array($preferences[self::CHOICE_KEY] ?? null, self::CHOICES, true)
            || ($preferences[self::VERSION_KEY] ?? null) !== self::INTRODUCTION_VERSION
            || ($preferences[self::ROLE_KEY] ?? null) !== $user->getType()->value;
    }

    public function choice(mixed $user): string
    {
        if (!$this->available($user)) { return 'modern'; }
        $choice = $user->getTechnicianPortalPreferences()[self::CHOICE_KEY] ?? null;
        // Until a valid account/role acknowledgement exists, do not silently select the new UI.
        return !$this->needsIntroduction($user) && in_array($choice, self::CHOICES, true) ? $choice : 'classic';
    }

    public function resolve(string $template, mixed $user): string
    {
        return 'classic' === $this->choice($user) ? (self::TEMPLATES[$template] ?? $template) : $template;
    }

    /** Pure merge: preserves work state, language/theme/module choices and admin-owned keys. */
    public function acknowledgedPreferences(User $user, string $choice): array
    {
        if (!$this->available($user)) { throw new \DomainException('Layout choice is unavailable for this account.'); }
        if (!in_array($choice, self::CHOICES, true)) { throw new \InvalidArgumentException('Unsupported portal layout.'); }
        return array_replace($user->getTechnicianPortalPreferences(), [self::CHOICE_KEY => $choice,
            self::VERSION_KEY => self::INTRODUCTION_VERSION, self::ROLE_KEY => $user->getType()->value]);
    }

    /** An older role/version comparison must not acknowledge a different introduction. */
    public function csrfId(User $user): string
    {
        return self::CSRF_PREFIX.'.v'.self::INTRODUCTION_VERSION.'.'.$user->getType()->value;
    }

    public function returnPath(User $user, mixed $candidate): string
    {
        $fallback = UserType::TICKET_COORDINATOR === $user->getType() ? '/portal/koordinator' : '/portal/technician';
        if (!is_string($candidate) || strlen($candidate) > 4096 || !str_starts_with($candidate, '/portal/')
            || preg_match('/[\\x00-\\x20\\x7f\\\\\\\\]/', $candidate)) { return $fallback; }
        $parts = parse_url($candidate);
        if (false === $parts || array_intersect(['scheme', 'host', 'user', 'pass', 'port'], array_keys($parts))) { return $fallback; }
        $path = rawurldecode($parts['path'] ?? '');
        if (!str_starts_with($path, '/portal/') || preg_match('~[\\x00-\\x20\\x7f\\\\\\\\]|(?:^|/)\\.\\.?(?:/|$)~', $path)
            || preg_match('/%(?:0[0-9a-f]|1[0-9a-f]|7f|5c)/i', $candidate)
            || str_starts_with($path, '/portal/layout')) { return $fallback; }
        return $candidate;
    }
}
