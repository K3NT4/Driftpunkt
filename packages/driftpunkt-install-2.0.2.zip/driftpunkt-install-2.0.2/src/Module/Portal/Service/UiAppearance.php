<?php

declare(strict_types=1);

namespace App\Module\Portal\Service;

/**
 * Explicit mapping from stored 1.x appearance values to the 2.0.0 visual properties.
 *
 * Stored preference values are never rewritten here. The resolver only describes how an
 * existing value is presented: which colour palette, which colour scheme and which density.
 * Unknown or missing values fall back to the same defaults as the 1.x accessors.
 */
final class UiAppearance
{
    public const SURFACE_PUBLIC = 'public';
    public const SURFACE_CUSTOMER = 'customer';
    public const SURFACE_INTERNAL = 'internal';
    public const SURFACE_ADMIN = 'admin';

    public const SCHEME_LIGHT = 'light';
    public const SCHEME_DARK = 'dark';
    public const SCHEME_CONTRAST = 'contrast';
    public const SCHEME_SYSTEM = 'system';

    public const DENSITY_COMFORTABLE = 'comfortable';
    public const DENSITY_COMPACT = 'compact';

    /**
     * Internal portal themes (technician and coordinator views) as stored in
     * technicianPortalPreferences.theme. Order matches the 1.x settings form.
     *
     * @var array<string, array{palette: string, scheme: string, density: string}>
     */
    public const INTERNAL_THEMES = [
        'standard' => ['palette' => 'standard', 'scheme' => self::SCHEME_LIGHT, 'density' => self::DENSITY_COMFORTABLE],
        'hav' => ['palette' => 'hav', 'scheme' => self::SCHEME_LIGHT, 'density' => self::DENSITY_COMFORTABLE],
        'skog' => ['palette' => 'skog', 'scheme' => self::SCHEME_LIGHT, 'density' => self::DENSITY_COMFORTABLE],
        'kontrast' => ['palette' => 'kontrast', 'scheme' => self::SCHEME_CONTRAST, 'density' => self::DENSITY_COMFORTABLE],
        'solnedgang' => ['palette' => 'solnedgang', 'scheme' => self::SCHEME_LIGHT, 'density' => self::DENSITY_COMFORTABLE],
        'natt' => ['palette' => 'natt', 'scheme' => self::SCHEME_DARK, 'density' => self::DENSITY_COMFORTABLE],
        'fokus' => ['palette' => 'fokus', 'scheme' => self::SCHEME_LIGHT, 'density' => self::DENSITY_COMFORTABLE],
        'nord' => ['palette' => 'nord', 'scheme' => self::SCHEME_LIGHT, 'density' => self::DENSITY_COMFORTABLE],
        'grafit' => ['palette' => 'grafit', 'scheme' => self::SCHEME_DARK, 'density' => self::DENSITY_COMFORTABLE],
        'aurora' => ['palette' => 'aurora', 'scheme' => self::SCHEME_LIGHT, 'density' => self::DENSITY_COMFORTABLE],
        'koppar' => ['palette' => 'koppar', 'scheme' => self::SCHEME_LIGHT, 'density' => self::DENSITY_COMFORTABLE],
        'bordeaux' => ['palette' => 'bordeaux', 'scheme' => self::SCHEME_LIGHT, 'density' => self::DENSITY_COMFORTABLE],
        // Kompakt fokus is split into the Fokus palette plus the compact density so the
        // user's compact working mode is preserved as its own visual property.
        'kompakt_fokus' => ['palette' => 'fokus', 'scheme' => self::SCHEME_LIGHT, 'density' => self::DENSITY_COMPACT],
    ];

    /**
     * Customer appearance values as stored in customerPortalPreferences.theme.
     *
     * @var array<string, string>
     */
    public const CUSTOMER_SCHEMES = [
        'system' => self::SCHEME_SYSTEM,
        'light' => self::SCHEME_LIGHT,
        'dark' => self::SCHEME_DARK,
        'contrast' => self::SCHEME_CONTRAST,
    ];

    /**
     * @param array<string, mixed> $technicianPortalPreferences
     *
     * @return array{surface: string, theme: string, palette: string, scheme: string, density: string}
     */
    public static function resolve(
        string $surface,
        ?string $customerTheme = null,
        array $technicianPortalPreferences = [],
        bool $publicFollowsSystem = true,
    ): array {
        if (self::SURFACE_CUSTOMER === $surface) {
            $theme = \is_string($customerTheme) && isset(self::CUSTOMER_SCHEMES[$customerTheme]) ? $customerTheme : 'system';

            return [
                'surface' => self::SURFACE_CUSTOMER,
                'theme' => $theme,
                'palette' => 'brand',
                'scheme' => self::CUSTOMER_SCHEMES[$theme],
                'density' => self::DENSITY_COMFORTABLE,
            ];
        }

        if (self::SURFACE_INTERNAL === $surface) {
            $stored = $technicianPortalPreferences['theme'] ?? 'standard';
            $theme = \is_string($stored) && isset(self::INTERNAL_THEMES[$stored]) ? $stored : 'standard';
            $mapping = self::INTERNAL_THEMES[$theme];

            return [
                'surface' => self::SURFACE_INTERNAL,
                'theme' => $theme,
                'palette' => $mapping['palette'],
                'scheme' => $mapping['scheme'],
                'density' => $mapping['density'],
            ];
        }

        // Public pages can follow the device scheme; admin keeps its existing scheme.
        return [
            'surface' => self::SURFACE_ADMIN === $surface ? self::SURFACE_ADMIN : self::SURFACE_PUBLIC,
            'theme' => 'brand',
            'palette' => 'brand',
            'scheme' => self::SURFACE_ADMIN !== $surface && $publicFollowsSystem ? self::SCHEME_SYSTEM : self::SCHEME_LIGHT,
            'density' => self::DENSITY_COMFORTABLE,
        ];
    }
}
