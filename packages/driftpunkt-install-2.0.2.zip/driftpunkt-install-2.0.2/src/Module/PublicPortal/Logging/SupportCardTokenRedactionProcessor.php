<?php

declare(strict_types=1);

namespace App\Module\PublicPortal\Logging;

use Monolog\LogRecord;
use Monolog\Processor\ProcessorInterface;

final class SupportCardTokenRedactionProcessor implements ProcessorInterface
{
    private const REDACTED = '[support-card-token]';
    private const MAX_DEPTH = 20;
    private const MAX_NODES = 10000;

    public function __invoke(LogRecord $record): LogRecord
    {
        $seen = new \SplObjectStorage();
        $remaining = self::MAX_NODES;

        $context = $this->sanitize($record->context, $seen, $remaining);
        $remaining = self::MAX_NODES;
        $extra = $this->sanitize($record->extra, $seen, $remaining);

        return $record->with(
            message: $this->redact($record->message),
            context: $context,
            extra: $extra,
        );
    }

    private function redact(string $value, bool $tokenValue = false): string
    {
        if ($tokenValue && preg_match('/^[A-Za-z0-9_-]{43}$/D', $value)) {
            return self::REDACTED;
        }

        // Preserve the path prefix, including mixed raw/percent-encoded separators.
        return preg_replace('~((?:/|%2f)supportkort(?:/|%2f))[A-Za-z0-9_-]{43}(?![A-Za-z0-9_-])~i', '$1'.self::REDACTED, $value) ?? '[redaction-failed]';
    }

    /** @param \SplObjectStorage<object, null> $seen */
    private function sanitize(mixed $value, \SplObjectStorage $seen, int &$remaining, int $depth = 0, bool $tokenValue = false): mixed
    {
        if ($depth > self::MAX_DEPTH || --$remaining < 0) {
            return '[truncated]';
        }
        if (is_string($value)) {
            return $this->redact($value, $tokenValue);
        }
        if (is_array($value)) {
            $result = [];
            foreach ($value as $key => $item) {
                if ($remaining <= 0) {
                    $result['__truncated__'] = true;
                    break;
                }
                $safeKey = is_string($key) ? $this->redact($key) : $key;
                // Trace arguments may contain the raw route token without its URL prefix.
                $sensitive = $tokenValue || (is_string($key) && in_array(strtolower($key), ['token', 'args'], true));
                $result[$safeKey] = $this->sanitize($item, $seen, $remaining, $depth + 1, $sensitive);
            }

            return $result;
        }
        if (!is_object($value) || $value instanceof \DateTimeInterface) {
            return $value;
        }
        if ($seen->offsetExists($value)) {
            return '[recursive-object]';
        }
        $seen->offsetSet($value, null);
        try {
            if ($value instanceof \Throwable) {
                // Never pass the original Throwable to a formatter: it can stringify its trace again.
                return $this->sanitize([
                    'class' => get_class($value),
                    'message' => $value->getMessage(),
                    'code' => $value->getCode(),
                    'file' => $value->getFile(),
                    'line' => $value->getLine(),
                    'trace' => $value->getTrace(),
                    'previous' => $value->getPrevious(),
                ], $seen, $remaining, $depth + 1);
            }
            // Match Monolog's object normalization, then sanitize the resulting data exactly once.
            // Keeping the original object would allow JsonSerializable/__toString to leak later.
            $normalized = match (true) {
                $value instanceof \JsonSerializable => $value->jsonSerialize(),
                $value instanceof \Stringable => (string) $value,
                default => get_object_vars($value),
            };

            return [$this->redact(get_class($value)) => $this->sanitize($normalized, $seen, $remaining, $depth + 1, $tokenValue)];
        } catch (\Throwable) {
            return [$this->redact(get_class($value)) => '[unserializable]'];
        } finally {
            $seen->offsetUnset($value);
        }
    }
}
