<?php

declare(strict_types=1);

namespace App\Module\PublicPortal\Service;

use App\Module\Identity\Entity\Company;
use App\Module\Identity\Entity\User;
use App\Module\PublicPortal\Entity\SupportCard;
use App\Module\PublicPortal\Entity\SupportCardGrant;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\DependencyInjection\Attribute\Autowire;
use Symfony\Component\Security\Core\Authorization\AuthorizationCheckerInterface;
use Symfony\Component\Security\Core\Exception\AccessDeniedException;

final class SupportCardService
{
    public function __construct(
        private readonly EntityManagerInterface $entityManager,
        private readonly SupportCardTokenCipher $cipher,
        private readonly AuthorizationCheckerInterface $authorization,
        #[Autowire('%env(string:DRIFTPUNKT_PUBLIC_BASE_URL)%')] private readonly string $publicBaseUrl,
    ) {
    }

    public function isReady(): bool
    {
        try {
            $schema = $this->entityManager->getConnection()->createSchemaManager();
            if (!$schema->tablesExist(['support_cards', 'support_card_grants', 'support_card_submissions', 'incoming_mails'])) {
                return false;
            }
            $columns = $schema->listTableColumns('incoming_mails');

            return isset($columns['submission_source'], $columns['requested_company_id']);
        } catch (\Doctrine\DBAL\Exception) {
            return false;
        }
    }

    public function canManage(?User $user, Company $company): bool
    {
        if (!$user?->isActive() || !$company->isActive() || null === $company->getId() || $user->getCompany()?->getId() !== $company->getId()) {
            return false;
        }
        if (!$this->isReady()) {
            return false;
        }
        $grant = $this->entityManager->getRepository(SupportCardGrant::class)->findOneBy(['user' => $user, 'company' => $company]);

        return $grant instanceof SupportCardGrant && !$grant->isRevoked();
    }

    public function assertCanManage(?User $user, Company $company): void
    {
        if (!$this->canManage($user, $company)) {
            throw new AccessDeniedException();
        }
    }

    public function assignGrant(User $user, Company $company): void
    {
        if (!$this->authorization->isGranted('ROLE_ADMIN') || !$this->isReady() || !$user->isActive() || !$company->isActive() || null === $company->getId() || $user->getCompany()?->getId() !== $company->getId()) {
            throw new AccessDeniedException();
        }
        $grant = $this->entityManager->getRepository(SupportCardGrant::class)->findOneBy(['user' => $user, 'company' => $company]);
        if (!$grant instanceof SupportCardGrant) {
            $grant = new SupportCardGrant($user, $company);
            $this->entityManager->persist($grant);
        }
        $grant->renew();
        $this->entityManager->flush();
    }

    public function revokeGrant(User $user, Company $company): void
    {
        if (!$this->authorization->isGranted('ROLE_ADMIN') || !$this->isReady()) {
            throw new AccessDeniedException();
        }
        $grant = $this->entityManager->getRepository(SupportCardGrant::class)->findOneBy(['user' => $user, 'company' => $company]);
        $grant?->revoke();
        $this->entityManager->flush();
    }

    public function findForCompany(Company $company): ?SupportCard
    {
        if (!$this->isReady()) {
            return null;
        }
        return $this->entityManager->getRepository(SupportCard::class)->findOneBy(['company' => $company]);
    }

    public function save(User $user, Company $company, string $instruction, string $urgentContact, string $openingHours): SupportCard
    {
        $this->assertCanManage($user, $company);
        $card = $this->findForCompany($company);
        if (!$card instanceof SupportCard) {
            $card = new SupportCard($company);
            $this->replaceToken($card);
            $this->entityManager->persist($card);
        }
        $card->setInstruction($instruction);
        $card->setUrgentContact($urgentContact);
        $card->setOpeningHours($openingHours);
        $this->entityManager->flush();

        return $card;
    }

    public function revoke(User $user, SupportCard $card): void
    {
        $this->assertCanManage($user, $card->getCompany());
        $card->revoke();
        $this->entityManager->flush();
    }

    public function rotate(User $user, SupportCard $card): void
    {
        $this->assertCanManage($user, $card->getCompany());
        // Verify existing key before changing a working link; never silently repair key loss.
        if (null !== $card->getEncryptedToken()) {
            $this->cipher->decrypt($card->getEncryptedToken(), $card->getId());
        }
        $this->replaceToken($card);
        $this->entityManager->flush();
    }

    public function resolve(string $token): ?SupportCard
    {
        if (!preg_match('/^[A-Za-z0-9_-]{43}$/D', $token) || !$this->isReady()) {
            return null;
        }
        $card = $this->entityManager->getRepository(SupportCard::class)->findOneBy(['tokenHash' => $this->cipher->hash($token)]);

        return $card instanceof SupportCard && $card->isActive() ? $card : null;
    }

    public function publicUrl(User $user, SupportCard $card): string
    {
        $this->assertCanManage($user, $card->getCompany());
        $base = rtrim(trim($this->publicBaseUrl), '/');
        $parts = parse_url($base);
        if (false === filter_var($base, FILTER_VALIDATE_URL) || !is_array($parts) || !in_array($parts['scheme'] ?? '', ['https', 'http'], true) || isset($parts['user']) || isset($parts['pass']) || isset($parts['query']) || isset($parts['fragment'])) {
            throw new \RuntimeException('Konfigurera DRIFTPUNKT_PUBLIC_BASE_URL innan supportkort exporteras.');
        }
        if (!$card->isActive() || null === $card->getEncryptedToken()) {
            throw new \RuntimeException('Supportkortets länk är spärrad.');
        }

        return $base.'/supportkort/'.$this->cipher->decrypt($card->getEncryptedToken(), $card->getId());
    }

    private function replaceToken(SupportCard $card): void
    {
        $token = $this->cipher->generate();
        $encrypted = $this->cipher->encrypt($token, $card->getId());
        $card->replaceToken($this->cipher->hash($token), $encrypted);
    }
}
