<?php

declare(strict_types=1);

namespace App\Module\PublicPortal\Service;

use App\Module\Identity\Entity\User;
use App\Module\Identity\Enum\UserType;
use App\Module\System\Service\SystemSettings;
use App\Module\Ticket\Entity\Ticket;
use App\Module\Ticket\Entity\TicketCategory;
use App\Module\Ticket\Entity\TicketComment;
use App\Module\Ticket\Enum\TicketEscalationLevel;
use App\Module\Ticket\Enum\TicketImpactLevel;
use App\Module\Ticket\Enum\TicketPriority;
use App\Module\Ticket\Enum\TicketRequestType;
use App\Module\Ticket\Enum\TicketStatus;
use App\Module\Ticket\Enum\TicketVisibility;
use App\Module\Ticket\Service\TicketAuditLogger;
use App\Module\Ticket\Service\TicketCommentAttachmentBuilder;
use App\Module\Ticket\Service\TicketLifecycleService;
use App\Module\Ticket\Service\TicketReferenceGenerator;
use App\Module\Ticket\Service\TicketResponseNotifier;
use App\Module\Ticket\Service\TicketRoutingResolver;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\HttpFoundation\Request;

final class PublicTicketSubmissionService
{
    public function __construct(
        private readonly EntityManagerInterface $entityManager,
        private readonly SystemSettings $systemSettings,
        private readonly TicketReferenceGenerator $ticketReferenceGenerator,
        private readonly TicketRoutingResolver $ticketRoutingResolver,
        private readonly TicketAuditLogger $ticketAuditLogger,
        private readonly TicketResponseNotifier $ticketResponseNotifier,
        private readonly TicketCommentAttachmentBuilder $ticketCommentAttachmentBuilder,
        private readonly TicketLifecycleService $ticketLifecycleService,
        private readonly SupportCardReviewService $reviews,
        private readonly \Symfony\Component\Lock\LockFactory $lockFactory,
    ) {
    }

    public function submit(Request $request, ?\App\Module\PublicPortal\Entity\SupportCard $card = null, ?string $submissionId = null): ?Ticket
    {
        if (null === $card) {
            return $this->createTicket($request);
        }
        if (!$card->isActive() || null === $submissionId || !preg_match('/^[a-f0-9]{64}$/D', $submissionId)) {
            throw new \InvalidArgumentException('support_card.invalid');
        }
        $lock = $this->lockFactory->createLock('support-card-submission-'.$submissionId, 120);
        if (!$lock->acquire(true)) {
            throw new \RuntimeException('support_card.submission_busy');
        }
        $connection = $this->entityManager->getConnection();
        try {
            $existing = $this->entityManager->find(\App\Module\PublicPortal\Entity\SupportCardSubmission::class, $submissionId);
            if (null !== $existing) {
                return $existing->getTicket();
            }
            $connection->beginTransaction();
            try {
                // Reserve before touching attachments or the ORM. A duplicate cannot close the EntityManager.
                $connection->insert('support_card_submissions', ['id' => $submissionId]);
            } catch (\Doctrine\DBAL\Exception\UniqueConstraintViolationException $exception) {
                $connection->rollBack();
                if (false !== $connection->fetchOne('SELECT id FROM support_card_submissions WHERE id = ?', [$submissionId])) {
                    return null;
                }
                throw $exception;
            }

            return $this->createTicket($request, $card, $submissionId);
        } catch (\Throwable $exception) {
            if ($connection->isTransactionActive()) {
                $connection->rollBack();
            }
            throw $exception;
        } finally {
            $lock->release();
        }
    }

    private function createTicket(Request $request, ?\App\Module\PublicPortal\Entity\SupportCard $card = null, ?string $submissionId = null): Ticket
    {
        $name = $this->requestString($request, 'name');
        $email = mb_strtolower($this->requestString($request, 'email'));
        $phone = $this->requestString($request, 'phone');
        $subject = mb_substr($this->requestString($request, 'subject'), 0, 180);
        $summary = $this->requestString($request, 'summary');
        $category = $this->findCategory($request);
        $requestType = TicketRequestType::tryFrom($this->requestString($request, 'request_type')) ?? TicketRequestType::INCIDENT;
        $impactLevel = TicketImpactLevel::tryFrom($this->requestString($request, 'impact_level')) ?? TicketImpactLevel::SINGLE_USER;
        $customer = $this->findActiveCustomerByEmail($email);
        $needsReview = null !== $card && (null === $customer || $customer->getCompany()?->getId() !== $card->getCompany()->getId());
        if ($needsReview) {
            $customer = null;
        }
        $routingRule = $needsReview ? null : $this->ticketRoutingResolver->resolveRule($category, $customer, $requestType, $impactLevel);
        $slaPolicy = $routingRule?->getDefaultSlaPolicy();
        $priority = $routingRule?->getDefaultPriority() ?? $slaPolicy?->getEffectiveDefaultPriority() ?? TicketPriority::NORMAL;
        $escalationLevel = $routingRule?->getDefaultEscalationLevel() ?? $slaPolicy?->getEffectiveDefaultEscalationLevel() ?? TicketEscalationLevel::NONE;
        $assignee = $routingRule?->getDefaultAssignee() ?? $slaPolicy?->getEffectiveDefaultAssignee();
        $assignedTeam = $routingRule?->getTeam() ?? $slaPolicy?->getEffectiveDefaultTeam() ?? $assignee?->getTechnicianTeam();
        $company = $customer?->getCompany();

        $ticket = new Ticket(
            $this->ticketReferenceGenerator->nextReference($company),
            $subject,
            $this->buildPublicSummary($name, $email, $summary),
            TicketStatus::NEW,
            TicketVisibility::PRIVATE,
            $priority,
            $requestType,
            $impactLevel,
            $escalationLevel,
        );
        $ticket->setRequester($customer);
        $ticket->setContactPhone($phone);
        $ticket->setCompany($company);
        $ticket->setCategory($category);
        $ticket->setAssignee($assignee);
        $ticket->setAssignedTeam($assignedTeam);
        $ticket->setSlaPolicy($slaPolicy);
        $automaticStatusChange = $needsReview ? null : $this->markTicketOpenWhenRouted($ticket, 'intern routing satt');

        $initialComment = null;
        $attachments = [];
        $attachmentSettings = $this->systemSettings->getTicketAttachmentSettings();
        $uploadedFiles = TicketCommentAttachmentBuilder::uploadedFilesFrom($request->files->get('attachment'));
        $externalAttachmentUrl = $this->requestString($request, 'external_attachment_url');
        $externalAttachmentLabel = $this->requestString($request, 'external_attachment_label');
        if ([] !== $uploadedFiles || '' !== $externalAttachmentUrl) {
            if (mb_strlen($externalAttachmentUrl) > 1000) {
                throw new \InvalidArgumentException('Delningslänken får vara högst 1000 tecken.');
            }

            $initialComment = new TicketComment($ticket, $customer ?? (null === $card ? $this->findFirstAdminAuthor() : $this->findExistingInternalAuthor()), 'Bilagor bifogades när ärendet skapades.', false);

            try {
                $attachmentResult = $this->ticketCommentAttachmentBuilder->build(
                    $uploadedFiles,
                    $externalAttachmentUrl,
                    $externalAttachmentLabel,
                    $ticket,
                    $initialComment,
                    $attachmentSettings,
                );
                $attachments = $attachmentResult->getCreatedAttachments();
            } catch (\InvalidArgumentException $exception) {
                throw $exception;
            } catch (\RuntimeException) {
                throw new \InvalidArgumentException('Bilagan kunde inte sparas just nu.');
            }
        }

        if ($needsReview) {
            $this->reviews->create($ticket, $card, $name, $email, $summary);
        }
        if (null !== $submissionId) {
            $receipt = $this->entityManager->find(\App\Module\PublicPortal\Entity\SupportCardSubmission::class, $submissionId);
            $receipt->setTicket($ticket);
        }
        $this->entityManager->persist($ticket);
        if ($initialComment instanceof TicketComment) {
            $ticket->addComment($initialComment);
            $this->entityManager->persist($initialComment);
            foreach ($attachments as $attachment) {
                $initialComment->addAttachment($attachment);
                $this->entityManager->persist($attachment);
            }
        }
        $this->entityManager->flush();
        if (null !== $submissionId) {
            $this->entityManager->getConnection()->commit();
        }

        try {
        $this->ticketAuditLogger->log($ticket, 'public_ticket_created', 'Ärende skapat via publikt formulär.', $customer, [
            'requestIp' => $request->getClientIp(),
            'userAgent' => null === $card ? mb_substr((string) $request->headers->get('User-Agent'), 0, 255) : null,
            'source' => null === $card ? 'public_ticket_form' : 'support_card',
        ]);
        if (null !== $automaticStatusChange) {
            $this->ticketAuditLogger->log($ticket, 'ticket_updated', $automaticStatusChange.'.', $customer);
        }
        } catch (\Throwable) {
            // Persistence succeeded: an audit failure must not invite a duplicate submission.
        }
        if (!$needsReview && $ticket->getAssignee() instanceof User) {
            try {
                $this->ticketResponseNotifier->notifyAssignedTechnician($ticket, $ticket->getAssignee(), 'Ett nytt ärende har skapats via publikt formulär och tilldelats dig.');
            } catch (\Throwable) {
                // Ärendet är redan skapat; ett notifieringsfel ska inte ge publik besökare 500 eller uppmana till dubbelpostning.
            }
        }
        try {
            $this->ticketResponseNotifier->notifyTicketCreatedForTriage($ticket);
        } catch (\Throwable) {
            // Ärendet är redan skapat; triage-notisen får inte skapa en publik felrespons.
        }

        return $ticket;
    }

    private function findCategory(Request $request): ?TicketCategory
    {
        $categoryId = (int) $this->requestString($request, 'category_id');
        if ($categoryId <= 0) {
            return null;
        }

        $category = $this->entityManager->getRepository(TicketCategory::class)->find($categoryId);

        return $category instanceof TicketCategory ? $category : null;
    }

    private function findActiveCustomerByEmail(string $email): ?User
    {
        $user = $this->entityManager->getRepository(User::class)->findOneBy(['email' => mb_strtolower(trim($email))]);
        if (!$user instanceof User || !$user->isActive() || !\in_array($user->getType(), [UserType::CUSTOMER, UserType::PRIVATE_CUSTOMER], true)) {
            return null;
        }

        return $user;
    }

    private function findExistingInternalAuthor(): User
    {
        $author = $this->entityManager->getRepository(User::class)->findOneBy(['email' => 'public-ticket@driftpunkt.local']);
        if ($author instanceof User && UserType::TECHNICIAN === $author->getType()) {
            return $author;
        }
        $author = $this->entityManager->getRepository(User::class)->createQueryBuilder('author')
            ->where('author.type IN (:types)')
            ->setParameter('types', [UserType::SUPER_ADMIN, UserType::ADMIN, UserType::TECHNICIAN])
            ->orderBy('author.id', 'ASC')->setMaxResults(1)->getQuery()->getOneOrNullResult();
        if (!$author instanceof User) {
            throw new \InvalidArgumentException('support_card.attachment_author_missing');
        }

        return $author;
    }

    private function findFirstAdminAuthor(): User
    {
        $author = $this->entityManager->getRepository(User::class)->findOneBy(['email' => 'public-ticket@driftpunkt.local']);
        if (!$author instanceof User) {
            $author = new User('public-ticket@driftpunkt.local', 'Publikt', 'Formulär', UserType::TECHNICIAN);
            $author->setPassword(bin2hex(random_bytes(24)));
            $this->entityManager->persist($author);
        }

        $author
            ->setType(UserType::TECHNICIAN)
            ->disableEmailNotifications()
            ->deactivate();

        return $author;
    }

    private function requestString(Request $request, string $key, string $default = ''): string
    {
        $value = $request->request->all()[$key] ?? $default;
        if (null === $value || \is_array($value)) {
            return '';
        }

        if (!\is_scalar($value) && !$value instanceof \Stringable) {
            return '';
        }

        return trim((string) $value);
    }

    private function buildPublicSummary(string $name, string $email, string $summary): string
    {
        $lines = [
            'Publik kontakt:',
            sprintf('Namn: %s', $name),
            sprintf('E-post: %s', $email),
        ];
        $lines[] = '';
        $lines[] = 'Beskrivning:';
        $lines[] = $summary;

        return implode("\n", $lines);
    }

    private function markTicketOpenWhenRouted(Ticket $ticket, string $reason): ?string
    {
        $previousStatus = $this->ticketLifecycleService->markOpenWhenRouted($ticket);
        if (!$previousStatus instanceof TicketStatus) {
            return null;
        }

        return sprintf('status %s -> %s, %s', $previousStatus->label(), $ticket->getStatus()->label(), $reason);
    }
}
