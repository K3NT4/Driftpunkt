<?php

declare(strict_types=1);

namespace App\Module\PublicPortal\Service;

use Symfony\Component\DependencyInjection\Attribute\Autowire;
use Symfony\Component\HttpFoundation\File\UploadedFile;

final class SupportCardLogoStorage
{
    private readonly string $directory;

    public function __construct(#[Autowire('%kernel.project_dir%')] string $projectDir)
    {
        $this->directory = $projectDir.'/var/support_cards/logos';
    }

    public function store(UploadedFile $file): string
    {
        if (!$file->isValid() || $file->getSize() > 2 * 1024 * 1024) {
            throw new \InvalidArgumentException('Logotypen kunde inte laddas upp.');
        }
        $bytes = file_get_contents($file->getPathname());
        if ($bytes === false) {
            throw new \RuntimeException('Logotypen kunde inte läsas.');
        }
        $png = self::normalize($bytes);
        if (!is_dir($this->directory) && !mkdir($this->directory, 0700, true) && !is_dir($this->directory)) {
            throw new \RuntimeException('Logotyplagringen kunde inte skapas.');
        }
        $key = bin2hex(random_bytes(32)).'.png';
        $path = $this->directory.'/'.$key;
        $handle = fopen($path, 'xb');
        if ($handle === false) {
            throw new \RuntimeException('Logotypen kunde inte lagras.');
        }
        try {
            if (!chmod($path, 0600) || fwrite($handle, $png) !== strlen($png)) {
                throw new \RuntimeException('Logotypen kunde inte lagras.');
            }
        } catch (\Throwable $error) {
            unlink($path);
            throw $error;
        } finally {
            fclose($handle);
        }

        return $key;
    }

    public function dataUri(?string $key): ?string
    {
        if ($key === null || $key === '') {
            return null;
        }
        $path = $this->path($key);
        if (!is_file($path)) {
            return null;
        }
        if (filesize($path) > 2 * 1024 * 1024) {
            throw new \InvalidArgumentException('Logotypen är för stor.');
        }
        $bytes = file_get_contents($path);
        if ($bytes === false) {
            throw new \RuntimeException('Logotypen kunde inte läsas.');
        }

        return 'data:image/png;base64,'.base64_encode(self::normalize($bytes, true));
    }

    public function remove(?string $key): void
    {
        if ($key === null || $key === '') {
            return;
        }
        $path = $this->path($key);
        if (is_file($path) && !unlink($path)) {
            throw new \RuntimeException('Logotypen kunde inte tas bort.');
        }
    }

    private function path(string $key): string
    {
        if (!preg_match('/\A[a-f0-9]{64}\.png\z/D', $key)) {
            throw new \InvalidArgumentException('Ogiltig logotypnyckel.');
        }

        return $this->directory.'/'.$key;
    }

    /** Validate before allocating GD pixels; re-encoding discards metadata and appended content. */
    public static function normalize(string $bytes, bool $pngOnly = false): string
    {
        if ($bytes === '' || strlen($bytes) > 2 * 1024 * 1024) {
            throw new \InvalidArgumentException('Logotypen får vara högst 2 MiB.');
        }
        $mime = (new \finfo(FILEINFO_MIME_TYPE))->buffer($bytes);
        $bounds = @getimagesizefromstring($bytes);
        $allowed = $pngOnly ? ['image/png'] : ['image/png', 'image/jpeg'];
        if (!in_array($mime, $allowed, true) || $bounds === false || ($bounds['mime'] ?? null) !== $mime
            || $bounds[0] < 1 || $bounds[1] < 1 || $bounds[0] > 2048 || $bounds[1] > 2048
            || $bounds[0] * $bounds[1] > 4000000) {
            throw new \InvalidArgumentException('Logotypen måste vara JPEG/PNG, högst 2048 px per sida och fyra miljoner pixlar.');
        }
        $image = @imagecreatefromstring($bytes);
        if ($image === false) {
            throw new \InvalidArgumentException('Logotypens bilddata är ogiltiga.');
        }
        try {
            imagesavealpha($image, true);
            ob_start();
            try {
                if (!imagepng($image, null, 9)) {
                    throw new \RuntimeException('Logotypen kunde inte normaliseras.');
                }
                $png = ob_get_contents();
            } finally {
                ob_end_clean();
            }
        } finally {
            unset($image);
        }
        if (!is_string($png) || strlen($png) > 2 * 1024 * 1024) {
            throw new \InvalidArgumentException('Den normaliserade logotypen är för stor.');
        }

        return $png;
    }
}
