<?php

declare(strict_types=1);

namespace App\Module\PublicPortal\Service;

use Symfony\Component\DependencyInjection\Attribute\Autowire;

final class SupportCardTokenCipher
{
    private const DOMAIN = 'driftpunkt.support-card.v1';

    public function __construct(#[Autowire('%kernel.secret%')] private readonly string $secret)
    {
    }

    public function generate(): string
    {
        return rtrim(strtr(base64_encode(random_bytes(32)), '+/', '-_'), '=');
    }

    public function hash(string $token): string
    {
        return hash('sha256', self::DOMAIN."\0".$token);
    }

    public function encrypt(string $token, string $cardId): string
    {
        $nonce = random_bytes(12);
        $ciphertext = openssl_encrypt($token, 'aes-256-gcm', $this->key(), OPENSSL_RAW_DATA, $nonce, $tag, self::DOMAIN."\0".$cardId);
        if (false === $ciphertext) {
            throw new \RuntimeException('Supportkortets länkskydd kunde inte användas.');
        }

        return base64_encode($nonce.$tag.$ciphertext);
    }

    public function decrypt(string $value, string $cardId): string
    {
        $bytes = base64_decode($value, true);
        if (false === $bytes || strlen($bytes) < 29) {
            throw new \RuntimeException('Supportkortets länkskydd kunde inte läsas.');
        }
        $token = openssl_decrypt(substr($bytes, 28), 'aes-256-gcm', $this->key(), OPENSSL_RAW_DATA, substr($bytes, 0, 12), substr($bytes, 12, 16), self::DOMAIN."\0".$cardId);
        if (false === $token || !preg_match('/^[A-Za-z0-9_-]{43}$/D', $token)) {
            throw new \RuntimeException('Supportkortets länkskydd kunde inte läsas. Kontrollera APP_SECRET.');
        }

        return $token;
    }

    private function key(): string
    {
        if ('' === $this->secret) {
            throw new \RuntimeException('APP_SECRET måste konfigureras för supportkort.');
        }

        return hash_hkdf('sha256', $this->secret, 32, self::DOMAIN);
    }
}
