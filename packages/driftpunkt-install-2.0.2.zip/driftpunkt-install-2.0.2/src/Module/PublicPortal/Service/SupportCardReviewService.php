<?php

declare(strict_types=1);

namespace App\Module\PublicPortal\Service;

use App\Module\Identity\Entity\Company;
use App\Module\Identity\Entity\User;
use App\Module\Identity\Enum\UserType;
use App\Module\Mail\Entity\DraftTicketReview;
use App\Module\Mail\Entity\IncomingMail;
use App\Module\Mail\Enum\DraftTicketReviewKind;
use App\Module\Mail\Enum\IncomingMailProcessingResult;
use App\Module\PublicPortal\Entity\SupportCard;
use App\Module\Ticket\Entity\Ticket;
use App\Module\Ticket\Enum\TicketStatus;
use App\Module\Ticket\Enum\TicketVisibility;
use Doctrine\ORM\EntityManagerInterface;

final class SupportCardReviewService
{
    public function __construct(
        private readonly EntityManagerInterface $entityManager,
        private readonly \App\Module\Ticket\Service\TicketAuditLogger $audit,
        private readonly \App\Module\Ticket\Service\TicketRoutingResolver $routing,
    )
    {
    }

    /** Adapter contains contact information, never the card's bearer token or duplicate attachments. */
    public function create(Ticket $ticket, SupportCard $card, string $name, string $email, string $summary): void
    {
        $ticket->setRequester(null)->setCompany(null)->setVisibility(TicketVisibility::INTERNAL_ONLY);
        $mail = new IncomingMail($email, $ticket->getSubject(), $summary);
        $mail->setFromName(mb_substr($name, 0, 180));
        $mail->markSupportCardSubmission($card->getCompany());
        $mail->setMatchedTicket($ticket);
        $mail->markProcessed(IncomingMailProcessingResult::DRAFT_REVIEW_CREATED, 'support_card');
        $review = new DraftTicketReview($mail, 'support_card', DraftTicketReviewKind::UNKNOWN_SENDER);
        $review->setDraftTicket($ticket);
        $this->entityManager->persist($mail);
        $this->entityManager->persist($review);
    }

    public function approve(DraftTicketReview $review, ?User $requester, ?Company $company, bool $confirmed, User $actor): void
    {
        $mail = $review->getIncomingMail();
        $ticket = $review->getDraftTicket();
        if (!$mail->isSupportCardSubmission() || !$review->isPending() || !$ticket instanceof Ticket || !$confirmed
            || !$requester?->isActive() || !in_array($requester->getType(), [UserType::CUSTOMER, UserType::PRIVATE_CUSTOMER], true)
            || !$company?->isActive() || null === $company->getId() || $company->getId() !== $mail->getRequestedCompany()?->getId()
            || $requester->getCompany()?->getId() !== $company->getId()) {
            throw new \InvalidArgumentException('support_card.review_invalid');
        }

        $this->transition($review, 'approved', function () use ($review, $requester, $company, $actor): void {
            $ticket = $review->getDraftTicket();
            $mail = $review->getIncomingMail();
            $this->entityManager->refresh($ticket);
            $rule = $this->routing->resolveRule($ticket->getCategory(), $requester, $ticket->getRequestType(), $ticket->getImpactLevel());
            $policy = $rule?->getDefaultSlaPolicy();
            $assignee = $rule?->getDefaultAssignee() ?? $policy?->getEffectiveDefaultAssignee();
            $ticket->setRequester($requester)->setCompany($company)->setVisibility(TicketVisibility::PRIVATE)->setStatus(TicketStatus::OPEN);
            $ticket->setSlaPolicy($policy);
            $ticket->setPriority($rule?->getDefaultPriority() ?? $policy?->getEffectiveDefaultPriority() ?? \App\Module\Ticket\Enum\TicketPriority::NORMAL);
            $ticket->setEscalationLevel($rule?->getDefaultEscalationLevel() ?? $policy?->getEffectiveDefaultEscalationLevel() ?? \App\Module\Ticket\Enum\TicketEscalationLevel::NONE);
            $ticket->setAssignee($assignee);
            $ticket->setAssignedTeam($rule?->getTeam() ?? $policy?->getEffectiveDefaultTeam() ?? $assignee?->getTechnicianTeam());
            $mail->setMatchedUser($requester)->setMatchedCompany($company);
            $mail->markProcessed(IncomingMailProcessingResult::TICKET_CREATED, 'support_card');
            $review->markApproved($actor);
        });
        $this->auditTransition($review, $actor, 'support_card_review_approved');
    }

    public function reject(DraftTicketReview $review, User $actor): void
    {
        if (!$review->getIncomingMail()->isSupportCardSubmission() || !$review->isPending()) {
            throw new \InvalidArgumentException('support_card.review_invalid');
        }
        $this->transition($review, 'rejected', function () use ($review, $actor): void {
            if (null !== $ticket = $review->getDraftTicket()) {
                $this->entityManager->refresh($ticket);
                $ticket->setRequester(null)->setCompany(null)->setVisibility(TicketVisibility::INTERNAL_ONLY)->setStatus(TicketStatus::CLOSED);
            }
            $review->markRejected($actor);
            $review->getIncomingMail()->markProcessed(IncomingMailProcessingResult::REJECTED, 'support_card');
        });
        $this->auditTransition($review, $actor, 'support_card_review_rejected');
    }

    /** A conditional write serializes approval/rejection in the database, including SQLite. */
    private function transition(DraftTicketReview $review, string $status, callable $apply): void
    {
        $connection = $this->entityManager->getConnection();
        $connection->beginTransaction();
        try {
            $updated = $connection->executeStatement(
                'UPDATE draft_ticket_reviews SET status = ? WHERE id = ? AND status = ?',
                [$status, $review->getId(), 'pending'],
            );
            if (1 !== $updated) {
                throw new \InvalidArgumentException('support_card.review_invalid');
            }
            $this->entityManager->refresh($review);
            $apply();
            $this->entityManager->flush();
            $connection->commit();
        } catch (\Throwable $exception) {
            $connection->rollBack();
            throw $exception;
        }
    }

    private function auditTransition(DraftTicketReview $review, User $actor, string $action): void
    {
        if (null === $ticket = $review->getDraftTicket()) {
            return;
        }
        try {
            $this->audit->log($ticket, $action, 'support_card', $actor);
        } catch (\Throwable) {
            // The review transition is committed; audit failure cannot undo it.
        }
    }
}
