<?php

declare(strict_types=1);

namespace App\Module\PublicPortal\Service;

use BaconQrCode\Common\ErrorCorrectionLevel;
use BaconQrCode\Encoder\Encoder;
use Dompdf\Dompdf;
use Dompdf\Options;
use Symfony\Component\DependencyInjection\Attribute\Autowire;

final class SupportCardExportService
{
    public function __construct(#[Autowire('%kernel.project_dir%')] private readonly string $projectDir)
    {
    }

    /** @param array{companyName:string,instruction:string,urgentContact:string,openingHours:string,publicUrl:string,logoDataUri:?string,labels?:array{scan?:string,urgent?:string,hours?:string}} $data */
    public function exportPdf(array $data): string
    {
        $data = $this->validate($data);
        $directory = $this->projectDir.'/var/support_card_exports';
        if (!is_dir($directory) && !mkdir($directory, 0700, true) && !is_dir($directory)) {
            throw new \RuntimeException('Exportkatalogen kunde inte skapas.');
        }
        $fonts = dirname((new \ReflectionClass(Dompdf::class))->getFileName(), 2).'/lib/fonts';
        $options = new Options();
        $options->setIsRemoteEnabled(false);
        $options->setIsPhpEnabled(false);
        $options->setIsJavascriptEnabled(false);
        $options->setChroot([$directory, $fonts]);
        $options->setTempDir($directory);
        $options->setFontCache($directory);
        $options->setDefaultFont('DejaVu Sans');
        $options->setAllowedProtocols(['data://' => ['rules' => []], 'file://' => ['rules' => []]]);
        $dompdf = new Dompdf($options);
        $svg = $this->qrSvg($data['publicUrl']);
        $html = '<!doctype html><html><head><meta charset="UTF-8"><style>@page{margin:32pt}body{font-family:"DejaVu Sans";font-size:12pt;color:#111;overflow-wrap:break-word;word-wrap:break-word}h1{font-size:24pt}h2{font-size:18pt}p{overflow-wrap:break-word;word-wrap:break-word}.logo{max-width:180pt;max-height:90pt}.qr{width:210pt;height:210pt}</style></head><body>';
        if ($data['logoDataUri'] !== null) {
            $html .= '<img class="logo" src="'.$data['logoDataUri'].'" alt="Logotyp">';
        }
        $html .= '<h1>'.self::escape($data['companyName']).'</h1><h2>'.self::escape($data['labels']['scan']).'</h2>';
        foreach (['instruction' => '', 'urgentContact' => $data['labels']['urgent'], 'openingHours' => $data['labels']['hours']] as $key => $label) {
            $html .= ($label !== '' ? '<h3>'.self::escape($label).'</h3>' : '').'<p>'.nl2br(self::escape($data[$key])).'</p>';
        }
        $html .= '<img class="qr" alt="QR-kod" src="data:image/svg+xml;base64,'.base64_encode($svg).'"><p>'.self::escape($data['publicUrl']).'</p></body></html>';
        $dompdf->loadHtml($html, 'UTF-8');
        $dompdf->setPaper('A4');
        $dompdf->render();

        return $dompdf->output();
    }

    /** @param array{companyName:string,instruction:string,urgentContact:string,openingHours:string,publicUrl:string,logoDataUri:?string,labels?:array{scan?:string,urgent?:string,hours?:string}} $data */
    public function exportSvg(array $data): string
    {
        $data = $this->validate($data);
        $y = 40;
        $body = '';
        if ($data['logoDataUri'] !== null) {
            $body .= '<image x="40" y="30" width="200" height="100" href="'.$data['logoDataUri'].'"/>';
            $y = 165;
        }
        foreach (['companyName', 'heading', 'instruction', 'urgentContact', 'openingHours'] as $key) {
            $value = $key === 'heading' ? $data['labels']['scan'] : $data[$key];
            if ($key === 'urgentContact') {
                $value = $data['labels']['urgent'].': '.$value;
            } elseif ($key === 'openingHours') {
                $value = $data['labels']['hours'].': '.$value;
            }
            foreach ($this->lines($value, in_array($key, ['companyName', 'heading'], true) ? 32 : 42) as $line) {
                $body .= '<text x="40" y="'.$y.'" font-size="'.(in_array($key, ['companyName', 'heading'], true) ? 24 : 18).'">'.self::escape($line).'</text>';
                $y += 30;
            }
            $y += 15;
        }
        $body .= '<svg x="40" y="'.$y.'" width="300" height="300" viewBox="0 0 '.$this->qrSize($data['publicUrl']).' '.$this->qrSize($data['publicUrl']).'">'.$this->qrElements($data['publicUrl']).'</svg>';
        $y += 330;
        foreach ($this->lines($data['publicUrl'], 48, false) as $line) {
            $body .= '<text x="40" y="'.$y.'" font-size="16">'.self::escape($line).'</text>';
            $y += 25;
        }

        return '<?xml version="1.0" encoding="UTF-8"?><svg xmlns="http://www.w3.org/2000/svg" width="900" height="'.($y + 40).'" viewBox="0 0 900 '.($y + 40).'"><rect width="100%" height="100%" fill="white"/><g font-family="DejaVu Sans, sans-serif" fill="#111">'.$body.'</g></svg>';
    }

    private function validate(array $data): array
    {
        foreach (['companyName' => 300, 'instruction' => 4000, 'urgentContact' => 500, 'openingHours' => 500, 'publicUrl' => 2048] as $key => $limit) {
            if (!isset($data[$key]) || !is_string($data[$key]) || !mb_check_encoding($data[$key], 'UTF-8')
                || mb_strlen($data[$key]) > $limit || preg_match('/[\x00-\x08\x0B\x0C\x0E-\x1F\x{FFFE}\x{FFFF}]/u', $data[$key])) {
                throw new \InvalidArgumentException('Ogiltigt supportkortsfält: '.$key);
            }
        }
        $url = parse_url($data['publicUrl']);
        if (!is_array($url) || !in_array(strtolower($url['scheme'] ?? ''), ['http', 'https'], true)
            || empty($url['host']) || isset($url['user']) || isset($url['pass']) || preg_match('/\s/u', $data['publicUrl'])) {
            throw new \InvalidArgumentException('Supportkortets URL måste vara en absolut HTTP(S)-adress.');
        }
        $logo = $data['logoDataUri'] ?? null;
        if ($logo !== null) {
            $prefix = 'data:image/png;base64,';
            if (!is_string($logo) || strlen($logo) > 2800000 || !str_starts_with($logo, $prefix)) {
                throw new \InvalidArgumentException('Ogiltig logotypdata.');
            }
            $bytes = base64_decode(substr($logo, strlen($prefix)), true);
            if ($bytes === false) {
                throw new \InvalidArgumentException('Ogiltig logotypdata.');
            }
            $logo = $prefix.base64_encode(SupportCardLogoStorage::normalize($bytes, true));
        }
        $labels = $data['labels'] ?? [];
        if (!is_array($labels)) {
            throw new \InvalidArgumentException('Ogiltiga supportkortsetiketter.');
        }
        foreach (['scan' => 'Skanna och skapa ett ärende', 'urgent' => 'Akut kontakt', 'hours' => 'Öppettider'] as $key => $default) {
            $label = array_key_exists($key, $labels) ? $labels[$key] : $default;
            if (!is_string($label) || !mb_check_encoding($label, 'UTF-8')
                || preg_match('/[\x00-\x08\x0B\x0C\x0E-\x1F\x{FFFE}\x{FFFF}]/u', $label)) {
                throw new \InvalidArgumentException('Ogiltig supportkortsetikett: '.$key);
            }
            $label = trim(preg_replace('/\s+/u', ' ', $label));
            if ($label === '' || mb_strlen($label) > 160) {
                throw new \InvalidArgumentException('Supportkortsetiketten måste vara 1–160 tecken: '.$key);
            }
            $labels[$key] = $label;
        }
        $data['labels'] = $labels;
        $data['logoDataUri'] = $logo;

        return $data;
    }

    private static function escape(string $text): string
    {
        return htmlspecialchars($text, ENT_QUOTES | ENT_XML1, 'UTF-8');
    }

    /** @return list<string> */
    private function lines(string $text, int $width, bool $wrapWords = true): array
    {
        $lines = [];
        foreach (explode("\n", str_replace(["\r\n", "\r"], "\n", $text)) as $paragraph) {
            while (mb_strlen($paragraph) > $width) {
                $space = $wrapWords ? mb_strrpos(mb_substr($paragraph, 0, $width + 1), ' ') : false;
                $length = false !== $space && $space > 0 ? $space : $width;
                $lines[] = mb_substr($paragraph, 0, $length);
                $paragraph = mb_substr($paragraph, $length + ($length === $space ? 1 : 0));
            }
            $lines[] = $paragraph;
        }

        return $lines;
    }

    private function qrSize(string $url): int
    {
        return Encoder::encode($url, ErrorCorrectionLevel::M(), 'UTF-8')->getMatrix()->getWidth() + 8;
    }

    private function qrElements(string $url): string
    {
        $matrix = Encoder::encode($url, ErrorCorrectionLevel::M(), 'UTF-8')->getMatrix();
        $size = $matrix->getWidth() + 8;
        $result = '<rect width="'.$size.'" height="'.$size.'" fill="white"/>';
        for ($y = 0; $y < $matrix->getHeight(); ++$y) {
            for ($x = 0; $x < $matrix->getWidth(); ++$x) {
                if ($matrix->get($x, $y) === 1) {
                    $result .= '<rect x="'.($x + 4).'" y="'.($y + 4).'" width="1" height="1" fill="black"/>';
                }
            }
        }

        return $result;
    }

    private function qrSvg(string $url): string
    {
        $size = $this->qrSize($url);

        return '<svg xmlns="http://www.w3.org/2000/svg" width="'.$size.'" height="'.$size.'" viewBox="0 0 '.$size.' '.$size.'">'.$this->qrElements($url).'</svg>';
    }
}
