<?php

declare(strict_types=1);

namespace App\Module\PublicPortal\EventSubscriber;

use App\Module\Identity\Entity\Company;
use App\Module\Identity\Entity\User;
use App\Module\PublicPortal\Entity\SupportCardGrant;
use App\Module\PublicPortal\Entity\SupportCard;
use Doctrine\Bundle\DoctrineBundle\Attribute\AsDoctrineListener;
use Doctrine\ORM\Event\OnFlushEventArgs;
use Doctrine\ORM\Events;

#[AsDoctrineListener(event: Events::onFlush)]
final class SupportCardGrantLifecycleSubscriber
{
    public function onFlush(OnFlushEventArgs $event): void
    {
        $em = $event->getObjectManager();
        $uow = $em->getUnitOfWork();
        $targets = [];
        foreach ($uow->getScheduledEntityUpdates() as $entity) {
            $changes = $uow->getEntityChangeSet($entity);
            if ($entity instanceof User && (isset($changes['company']) || (isset($changes['isActive']) && !$entity->isActive()))) {
                $targets[] = ['user' => $entity];
            } elseif ($entity instanceof Company && isset($changes['isActive']) && !$entity->isActive()) {
                $targets[] = ['company' => $entity];
            }
        }
        if ([] === $targets) {
            return;
        }
        $schema = $em->getConnection()->createSchemaManager();
        $grantsReady = $schema->tablesExist(['support_card_grants']);
        $cardsReady = $schema->tablesExist(['support_cards']);
        foreach ($targets as $criteria) {
            if ($grantsReady) {
                foreach ($em->getRepository(SupportCardGrant::class)->findBy($criteria) as $grant) {
                    $grant->revoke();
                    $uow->recomputeSingleEntityChangeSet($em->getClassMetadata(SupportCardGrant::class), $grant);
                }
            }
            if ($cardsReady && isset($criteria['company'])) {
                foreach ($em->getRepository(SupportCard::class)->findBy($criteria) as $card) {
                    $card->revoke();
                    $uow->recomputeSingleEntityChangeSet($em->getClassMetadata(SupportCard::class), $card);
                }
            }
        }
    }
}
