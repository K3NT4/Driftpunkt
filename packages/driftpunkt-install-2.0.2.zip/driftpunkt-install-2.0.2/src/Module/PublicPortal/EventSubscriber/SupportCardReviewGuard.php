<?php

declare(strict_types=1);

namespace App\Module\PublicPortal\EventSubscriber;

use App\Module\Mail\Entity\DraftTicketReview;
use App\Module\Ticket\Entity\Ticket;
use App\Module\Ticket\Enum\TicketVisibility;
use Doctrine\Bundle\DoctrineBundle\Attribute\AsDoctrineListener;
use Doctrine\ORM\Event\OnFlushEventArgs;
use Doctrine\ORM\Events;
use Symfony\Component\Security\Core\Exception\AccessDeniedException;

#[AsDoctrineListener(event: Events::onFlush)]
final class SupportCardReviewGuard
{
    public function onFlush(OnFlushEventArgs $event): void
    {
        $em = $event->getObjectManager();
        foreach ($em->getUnitOfWork()->getScheduledEntityUpdates() as $ticket) {
            if (!$ticket instanceof Ticket || (null === $ticket->getRequester() && null === $ticket->getCompany() && TicketVisibility::INTERNAL_ONLY === $ticket->getVisibility())) {
                continue;
            }
            foreach ($em->getRepository(DraftTicketReview::class)->findBy(['draftTicket' => $ticket]) as $review) {
                if ($review->isPending() && $review->getIncomingMail()->isSupportCardSubmission()) {
                    throw new AccessDeniedException('support_card.review_required');
                }
            }
        }
    }
}
