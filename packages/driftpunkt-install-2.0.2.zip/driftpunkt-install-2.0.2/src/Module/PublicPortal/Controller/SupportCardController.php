<?php

declare(strict_types=1);

namespace App\Module\PublicPortal\Controller;

use App\Module\Identity\Entity\Company;
use App\Module\Identity\Entity\User;
use App\Module\PublicPortal\Entity\SupportCard;
use App\Module\System\Service\SystemAuditLogger;
use Psr\Log\LoggerInterface;
use App\Module\PublicPortal\Service\SupportCardService;
use App\Module\PublicPortal\Service\SupportCardExportService;
use App\Module\PublicPortal\Service\SupportCardLogoStorage;
use App\Twig\AppRuntime;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\File\UploadedFile;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;
use Symfony\Component\Security\Http\Attribute\IsGranted;

#[IsGranted('ROLE_USER')]
final class SupportCardController extends AbstractController
{
    public function __construct(
        private readonly SupportCardService $cards,
        private readonly SupportCardExportService $exporter,
        private readonly SupportCardLogoStorage $logos,
        private readonly EntityManagerInterface $entityManager,
        private readonly AppRuntime $runtime,
        private readonly SystemAuditLogger $auditLogger,
        private readonly LoggerInterface $logger,
    ) {
    }

    #[Route('/portal/supportkort/{id}', name: 'app_support_card_manage', methods: ['GET', 'POST'], requirements: ['id' => '\d+'])]
    public function manage(Request $request, Company $company): Response
    {
        if (!$this->cards->isReady()) {
            return $this->schemaUnavailable();
        }
        $user = $this->getUser();
        \assert($user instanceof User);
        $this->cards->assertCanManage($user, $company);
        $card = $this->cards->findForCompany($company);
        $error = null;
        if ($request->isMethod('POST')) {
            if (!$this->isCsrfTokenValid('support_card_'.$company->getId(), $request->request->getString('_token'))) {
                throw $this->createAccessDeniedException();
            }
            try {
                $action = $request->request->getString('action', 'save');
                if ('revoke' === $action && null !== $card) {
                    $this->cards->revoke($user, $card);
                } elseif ('rotate' === $action && null !== $card) {
                    $this->cards->rotate($user, $card);
                } elseif ('save' === $action) {
                    $logo = $request->files->get('logo');
                    $newKey = $logo instanceof UploadedFile ? $this->logos->store($logo) : null;
                    try {
                        $card = $this->cards->save($user, $company, $request->request->getString('instruction'), $request->request->getString('urgent_contact'), $request->request->getString('opening_hours'));
                        if (null !== $newKey || $request->request->getBoolean('remove_logo')) {
                            $oldKey = $card->getLogoKey();
                            $card->setLogoKey($newKey);
                            $this->entityManager->flush();
                            $newKey = null; // The stored key is now referenced by the committed card.
                            $this->logos->remove($oldKey);
                        }
                    } catch (\Throwable $exception) {
                        $this->logos->remove($newKey);
                        throw $exception;
                    }
                } else {
                    throw new \InvalidArgumentException();
                }

                $this->auditMutation($user, $company, match ($action) {
                    'save' => 'support_card_saved',
                    'rotate' => 'support_card_rotated',
                    'revoke' => 'support_card_revoked',
                });

                return $this->redirectToRoute('app_support_card_manage', ['id' => $company->getId()]);
            } catch (\InvalidArgumentException|\RuntimeException) {
                $error = $this->runtime->translate('support_card.save_error');
            }
        }

        $previewDataUri = null;
        $previewUrl = null;
        $previewError = null;
        if ($card?->isActive()) {
            try {
                $data = $this->exportData($user, $card);
                $previewDataUri = 'data:image/svg+xml;base64,'.base64_encode($this->exporter->exportSvg($data));
                $previewUrl = $data['publicUrl'];
            } catch (\InvalidArgumentException|\RuntimeException) {
                $previewError = $this->runtime->translate('support_card.export_error');
            }
        }

        return $this->secure($this->render('support_card/manage.html.twig', [
            'company' => $company,
            'card' => $card,
            'error' => $error,
            'previewDataUri' => $previewDataUri,
            'previewUrl' => $previewUrl,
            'previewError' => $previewError,
        ], new Response('', null === $error ? 200 : 422)));
    }

    #[Route('/portal/supportkort/{id}/export/{format}', name: 'app_support_card_export', methods: ['GET'], requirements: ['id' => '\d+', 'format' => 'pdf|svg'])]
    public function export(Company $company, string $format): Response
    {
        if (!$this->cards->isReady()) {
            return $this->schemaUnavailable();
        }
        $user = $this->getUser();
        \assert($user instanceof User);
        $this->cards->assertCanManage($user, $company);
        $card = $this->cards->findForCompany($company);
        if (null === $card) {
            throw $this->createNotFoundException();
        }
        try {
            $data = $this->exportData($user, $card);
            $body = 'pdf' === $format ? $this->exporter->exportPdf($data) : $this->exporter->exportSvg($data);
        } catch (\InvalidArgumentException|\RuntimeException) {
            return $this->secure(new Response($this->runtime->translate('support_card.export_error'), 422));
        }

        return $this->secure(new Response($body, 200, [
            'Content-Type' => 'pdf' === $format ? 'application/pdf' : 'image/svg+xml',
            'Content-Disposition' => 'attachment; filename="supportkort.'.$format.'"',
        ]));
    }

    #[Route('/portal/admin/supportkort/{id}/grant/{userId}', name: 'app_support_card_grant', methods: ['POST'], requirements: ['id' => '\d+', 'userId' => '\d+'])]
    #[IsGranted('ROLE_ADMIN')]
    public function grant(Request $request, Company $company, int $userId): Response
    {
        if (!$this->cards->isReady()) {
            return $this->schemaUnavailable();
        }
        if (!$this->isCsrfTokenValid('support_card_grant_'.$company->getId(), $request->request->getString('_token'))) {
            throw $this->createAccessDeniedException();
        }
        $user = $this->entityManager->find(User::class, $userId);
        if (!$user instanceof User) {
            throw $this->createNotFoundException();
        }
        $revoked = $request->request->getBoolean('revoke');
        if ($revoked) {
            $this->cards->revokeGrant($user, $company);
        } else {
            $this->cards->assignGrant($user, $company);
        }
        $actor = $this->getUser();
        \assert($actor instanceof User);
        $this->auditMutation($actor, $company, $revoked ? 'support_card_grant_revoked' : 'support_card_grant_assigned', $user);

        return $this->redirectToRoute('app_support_card_grants', ['id' => $company->getId()]);
    }

    #[Route('/portal/admin/supportkort/{id}/grants', name: 'app_support_card_grants', methods: ['GET'], requirements: ['id' => '\d+'])]
    #[IsGranted('ROLE_ADMIN')]
    public function grants(Company $company): Response
    {
        if (!$this->cards->isReady()) {
            return $this->schemaUnavailable();
        }
        $users = $this->entityManager->getRepository(User::class)->findBy(['company' => $company, 'isActive' => true]);
        $granted = [];
        foreach ($users as $user) {
            $granted[$user->getId()] = $this->cards->canManage($user, $company);
        }

        return $this->secure($this->render('support_card/grants.html.twig', ['company' => $company, 'users' => $users, 'granted' => $granted]));
    }

    /** @return array{companyName: string, instruction: string, urgentContact: string, openingHours: string, publicUrl: string, logoDataUri: ?string, labels: array{scan: string, urgent: string, hours: string}} */
    private function exportData(User $user, SupportCard $card): array
    {
        return [
            'companyName' => $card->getCompany()->getName(),
            'instruction' => $card->getInstruction(),
            'urgentContact' => $card->getUrgentContact(),
            'openingHours' => $card->getOpeningHours(),
            'publicUrl' => $this->cards->publicUrl($user, $card),
            'logoDataUri' => $this->logos->dataUri($card->getLogoKey()),
            'labels' => [
                'scan' => $this->runtime->translate('support_card.scan'),
                'urgent' => $this->runtime->translate('support_card.urgent_contact'),
                'hours' => $this->runtime->translate('support_card.opening_hours'),
            ],
        ];
    }

    private function schemaUnavailable(): Response
    {
        return $this->secure($this->render('support_card/not_ready.html.twig', [], new Response('', Response::HTTP_SERVICE_UNAVAILABLE)));
    }

    private function auditMutation(User $actor, Company $company, string $action, ?User $targetUser = null): void
    {
        $context = ['actorId' => $actor->getId(), 'companyId' => $company->getId(), 'targetUserId' => $targetUser?->getId()];
        try {
            $this->auditLogger->log($actor, $action, $this->runtime->translate('support_card.title'), json_encode($context, JSON_THROW_ON_ERROR));
        } catch (\Throwable) {
            // The mutation is already committed. Do not invite a second rotation when audit storage fails.
            $this->logger->error('Support card mutation audit could not be stored.', $context + ['action' => $action]);
        }
    }

    private function secure(Response $response): Response
    {
        $response->headers->set('Referrer-Policy', 'no-referrer');
        $response->headers->set('Cache-Control', 'private, no-store');
        $response->headers->set('X-Content-Type-Options', 'nosniff');

        return $response;
    }
}
