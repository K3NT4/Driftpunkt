<?php

declare(strict_types=1);

namespace App\Module\PublicPortal\Controller;

use App\Module\System\Service\FormRateLimiter;
use App\Module\System\Service\SystemSettings;
use App\Module\Ticket\Entity\Ticket;
use App\Module\Ticket\Entity\TicketCategory;
use App\Module\Ticket\Enum\TicketImpactLevel;
use App\Module\Ticket\Enum\TicketRequestType;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;

final class PublicTicketController extends AbstractController
{
    private ?\App\Module\PublicPortal\Entity\SupportCard $supportCard = null;
    private ?string $cardToken = null;
    private ?string $submissionNonce = null;

    public function __construct(
        private readonly EntityManagerInterface $entityManager,
        private readonly SystemSettings $systemSettings,
        private readonly FormRateLimiter $formRateLimiter,
        private readonly \App\Module\PublicPortal\Service\SupportCardService $supportCards,
        private readonly \App\Twig\AppRuntime $runtime,
        private readonly \App\Module\PublicPortal\Service\PublicTicketSubmissionService $submissionService,
    ) {
    }

    #[Route('/supportkort/{token}', name: 'app_public_support_card', methods: ['GET'])]
    #[Route('/skapa-arende', name: 'app_public_ticket_new', methods: ['GET'])]
    public function new(Request $request): Response
    {
        $this->denyWhenDisabled();
        if (null !== $unavailable = $this->initializeCard($request)) {
            return $unavailable;
        }

        return $this->renderFormPage($this->defaultsFromRequest($request));
    }

    #[Route('/supportkort/{token}', name: 'app_public_support_card_create', methods: ['POST'])]
    #[Route('/skapa-arende', name: 'app_public_ticket_create', methods: ['POST'])]
    public function create(Request $request): Response
    {
        $this->denyWhenDisabled();
        if (null !== $unavailable = $this->initializeCard($request)) {
            return $unavailable;
        }

        $defaults = $this->defaultsFromRequest($request);
        if (!$this->isCsrfTokenValid('public_create_ticket', $this->requestString($request, '_token'))) {
            return $this->renderFormPage($defaults, 'Kunde inte verifiera formuläret.', Response::HTTP_UNPROCESSABLE_ENTITY);
        }

        if ('' !== $this->requestString($request, 'website')) {
            return $this->renderFormPage($defaults, 'Kontrollera namn, e-post, ämne och beskrivning.', Response::HTTP_UNPROCESSABLE_ENTITY);
        }

        if (
            !$this->formRateLimiter->consume($request, 'public_ticket_form', 5, 900, $this->requestString($request, 'email'))
            || !$this->formRateLimiter->consume($request, 'public_ticket_form_ip', 15, 900)
        ) {
            return $this->renderFormPage($defaults, 'För många försök. Vänta en stund och försök igen.', Response::HTTP_TOO_MANY_REQUESTS);
        }

        $name = $this->requestString($request, 'name');
        $email = mb_strtolower($this->requestString($request, 'email'));
        $phone = $this->requestString($request, 'phone');
        $subject = mb_substr($this->requestString($request, 'subject'), 0, 180);
        $summary = $this->requestString($request, 'summary');

        if ('' === $name || '' === $subject || '' === $summary || false === filter_var($email, \FILTER_VALIDATE_EMAIL)) {
            return $this->renderFormPage($defaults, 'Kontrollera namn, e-post, ämne och beskrivning.', Response::HTTP_UNPROCESSABLE_ENTITY);
        }

        if ('' !== $phone && !Ticket::isValidContactPhone($phone)) {
            return $this->renderFormPage($defaults, 'Ange ett giltigt telefonnummer eller lämna fältet tomt.', Response::HTTP_UNPROCESSABLE_ENTITY);
        }

        try {
            $submissionId = null === $this->supportCard ? null : hash('sha256', $this->supportCard->getId().':'.$this->submissionNonce);
            $this->submissionService->submit($request, $this->supportCard, $submissionId);
        } catch (\InvalidArgumentException $exception) {
            return $this->renderFormPage($defaults, str_starts_with($exception->getMessage(), 'support_card.') ? $this->runtime->translate($exception->getMessage()) : $exception->getMessage(), Response::HTTP_UNPROCESSABLE_ENTITY);
        }

        return $this->renderFormPage([], null, Response::HTTP_OK, true);
    }

    private function initializeCard(Request $request): ?Response
    {
        $this->supportCard = null;
        $this->cardToken = null;
        $this->submissionNonce = null;
        $token = $request->attributes->get('token');
        if (!is_string($token)) {
            return null;
        }
        $card = $this->supportCards->resolve($token);
        if (null === $card) {
            return $this->render('support_card/unavailable.html.twig', [], new Response('', 404));
        }
        $this->supportCard = $card;
        $this->cardToken = $token;
        $sessionKey = 'support_card_nonces_'.$card->getId();
        $nonces = $request->getSession()->get($sessionKey, []);
        $nonces = is_array($nonces) ? array_values(array_filter($nonces, 'is_string')) : [];
        if ($request->isMethod('POST')) {
            $submittedNonce = $this->requestString($request, '_submission_nonce');
            foreach ($nonces as $nonce) {
                if (hash_equals($nonce, $submittedNonce)) {
                    $this->submissionNonce = $nonce;

                    return null;
                }
            }
        }

        // Each open form owns a receipt; keep retries and up to ten tabs valid.
        $this->submissionNonce = bin2hex(random_bytes(32));
        $nonces[] = $this->submissionNonce;
        $request->getSession()->set($sessionKey, array_slice($nonces, -10));
        if ($request->isMethod('POST')) {
            return $this->renderFormPage(
                $this->defaultsFromRequest($request),
                $this->runtime->translate('support_card.form_expired'),
                Response::HTTP_UNPROCESSABLE_ENTITY,
            );
        }

        return null;
    }

    private function denyWhenDisabled(): void
    {
        if (!$this->systemSettings->getPublicTicketFormSettings()['enabled']) {
            throw $this->createNotFoundException();
        }
    }

    /**
     * @param array<string, mixed> $defaults
     */
    private function renderFormPage(array $defaults, ?string $formError = null, int $status = Response::HTTP_OK, bool $ticketCreated = false): Response
    {
        $response = $this->render('public/ticket_create.html.twig', [
            'supportCard' => $this->supportCard,
            'cardToken' => $this->cardToken,
            'submissionNonce' => $this->submissionNonce,
            'defaults' => $defaults + $this->emptyDefaults(),
            'formError' => $formError,
            'ticketCreated' => $ticketCreated,
            'categories' => $this->entityManager->getRepository(TicketCategory::class)->findBy([], ['name' => 'ASC']),
            'ticketRequestTypes' => TicketRequestType::cases(),
            'ticketImpactLevels' => TicketImpactLevel::cases(),
            'ticketAttachmentSettings' => $this->systemSettings->getTicketAttachmentSettings(),
            'supportBranding' => $this->systemSettings->getSupportBrandingSettings(),
        ], new Response('', $status));
        if (null !== $this->supportCard) {
            $response->headers->set('Referrer-Policy', 'no-referrer');
            $response->headers->set('Cache-Control', 'private, no-store');
            $response->headers->set('X-Content-Type-Options', 'nosniff');
        }

        return $response;
    }

    /**
     * @return array<string, string>
     */
    private function defaultsFromRequest(Request $request): array
    {
        return [
            'name' => $this->requestString($request, 'name'),
            'email' => $this->requestString($request, 'email'),
            'phone' => $this->requestString($request, 'phone'),
            'subject' => $this->requestString($request, 'subject'),
            'summary' => $this->requestString($request, 'summary'),
            'category_id' => $this->requestString($request, 'category_id'),
            'request_type' => $this->requestString($request, 'request_type', TicketRequestType::INCIDENT->value),
            'impact_level' => $this->requestString($request, 'impact_level', TicketImpactLevel::SINGLE_USER->value),
            'external_attachment_url' => $this->requestString($request, 'external_attachment_url'),
            'external_attachment_label' => $this->requestString($request, 'external_attachment_label'),
        ];
    }

    /**
     * @return array<string, string>
     */
    private function emptyDefaults(): array
    {
        return [
            'name' => '',
            'email' => '',
            'phone' => '',
            'subject' => '',
            'summary' => '',
            'category_id' => '',
            'request_type' => TicketRequestType::INCIDENT->value,
            'impact_level' => TicketImpactLevel::SINGLE_USER->value,
            'external_attachment_url' => '',
            'external_attachment_label' => '',
        ];
    }

    private function requestString(Request $request, string $key, string $default = ''): string
    {
        $value = $request->request->all()[$key] ?? $default;
        if (null === $value || \is_array($value)) {
            return '';
        }

        if (!\is_scalar($value) && !$value instanceof \Stringable) {
            return '';
        }

        return trim((string) $value);
    }

}
