<?php

declare(strict_types=1);

namespace App\Module\PublicPortal\Entity;

use App\Module\Ticket\Entity\Ticket;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity]
#[ORM\Table(name: 'support_card_submissions')]
class SupportCardSubmission
{
    public function __construct(
        #[ORM\Id]
        #[ORM\Column(length: 64)]
        private string $id,
        #[ORM\ManyToOne]
        #[ORM\JoinColumn(nullable: true, onDelete: 'SET NULL')]
        private ?Ticket $ticket,
    ) {
    }

    public function setTicket(Ticket $ticket): void { $this->ticket = $ticket; }

    public function getTicket(): ?Ticket { return $this->ticket; }
}
