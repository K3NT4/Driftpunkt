<?php

declare(strict_types=1);

namespace App\Module\PublicPortal\Entity;

use App\Module\Identity\Entity\Company;
use App\Module\Identity\Entity\User;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity]
#[ORM\Table(name: 'support_cards')]
class SupportCard
{
    #[ORM\Id]
    #[ORM\Column(length: 32)]
    private string $id;

    #[ORM\OneToOne]
    #[ORM\JoinColumn(nullable: false, onDelete: 'CASCADE')]
    private Company $company;

    #[ORM\Column(length: 64, unique: true, nullable: true)]
    private ?string $tokenHash = null;

    #[ORM\Column(type: 'text', nullable: true)]
    private ?string $encryptedToken = null;

    #[ORM\Column]
    private bool $active = false;

    #[ORM\Column(length: 1000)]
    private string $instruction = '';

    #[ORM\Column(length: 255)]
    private string $urgentContact = '';

    #[ORM\Column(length: 255)]
    private string $openingHours = '';

    #[ORM\Column(length: 80, nullable: true)]
    private ?string $logoKey = null;

    public function __construct(Company $company)
    {
        $this->id = bin2hex(random_bytes(16));
        $this->company = $company;
    }

    public function getId(): string { return $this->id; }
    public function getCompany(): Company { return $this->company; }
    public function isActive(): bool { return $this->active && $this->company->isActive(); }
    public function getTokenHash(): ?string { return $this->tokenHash; }
    public function getEncryptedToken(): ?string { return $this->encryptedToken; }
    public function getLogoKey(): ?string { return $this->logoKey; }
    public function setLogoKey(?string $key): void { $this->logoKey = $key; }
    public function revoke(): void { $this->active = false; $this->tokenHash = null; $this->encryptedToken = null; }
    public function replaceToken(string $hash, string $ciphertext): void
    {
        $this->tokenHash = $hash;
        $this->encryptedToken = $ciphertext;
        $this->active = true;
    }

    public function getInstruction(): string { return $this->instruction; }
    public function setInstruction(string $value): void { $this->instruction = mb_substr(trim($value), 0, 1000); }
    public function getUrgentContact(): string { return $this->urgentContact; }
    public function setUrgentContact(string $value): void { $this->urgentContact = mb_substr(trim($value), 0, 255); }
    public function getOpeningHours(): string { return $this->openingHours; }
    public function setOpeningHours(string $value): void { $this->openingHours = mb_substr(trim($value), 0, 255); }
}
