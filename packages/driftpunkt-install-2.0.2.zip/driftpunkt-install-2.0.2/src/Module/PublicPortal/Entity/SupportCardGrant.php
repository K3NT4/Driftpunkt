<?php

declare(strict_types=1);

namespace App\Module\PublicPortal\Entity;

use App\Module\Identity\Entity\Company;
use App\Module\Identity\Entity\User;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity]
#[ORM\Table(name: 'support_card_grants')]
#[ORM\UniqueConstraint(name: 'uniq_support_card_grant', columns: ['user_id', 'company_id'])]
class SupportCardGrant
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\ManyToOne]
    #[ORM\JoinColumn(nullable: false, onDelete: 'CASCADE')]
    private User $user;

    #[ORM\ManyToOne]
    #[ORM\JoinColumn(nullable: false, onDelete: 'CASCADE')]
    private Company $company;

    #[ORM\Column(nullable: true)]
    private ?\DateTimeImmutable $revokedAt = null;

    public function __construct(User $user, Company $company)
    {
        $this->user = $user;
        $this->company = $company;
    }

    public function getUser(): User { return $this->user; }
    public function getCompany(): Company { return $this->company; }
    public function isRevoked(): bool { return null !== $this->revokedAt; }
    public function revoke(): void { $this->revokedAt ??= new \DateTimeImmutable(); }
    public function renew(): void { $this->revokedAt = null; }
}
