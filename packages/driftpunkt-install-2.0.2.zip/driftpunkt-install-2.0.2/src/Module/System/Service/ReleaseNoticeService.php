<?php

declare(strict_types=1);

namespace App\Module\System\Service;

use App\Module\Identity\Entity\User;
use Symfony\Component\Clock\ClockInterface;
use Symfony\Component\Security\Core\Authentication\Token\Storage\TokenStorageInterface;

/**
 * Read-only view-model for the release notice.
 *
 * Every method is cache-only and never performs HTTP: it reads the shared
 * snapshot file, the runtime-installed application version and per-account
 * snoozes. The banner data is produced only for accounts whose roles include
 * the update permission (ROLE_SUPER_ADMIN) and only while a newer stable
 * version exists and has not been snoozed for the account.
 */
final class ReleaseNoticeService
{
    public const DETAILS_ROUTE = 'app_portal_admin_release_notes';
    public const CHECK_ROUTE = 'app_portal_admin_release_check';
    public const CHECK_CSRF_ID = 'check_github_release';
    public const SNOOZE_ROUTE = 'app_portal_admin_release_notice_snooze';
    public const SNOOZE_CSRF_ID = 'snooze_github_release_notice';
    public const UNKNOWN_INSTALLED_VERSION_TEXT = 'Installerad version kunde inte fastställas';

    /** A 'checking' status older than this is stale (a process died mid-check). */
    private const STALE_CHECKING_SECONDS = 30;

    public function __construct(
        private readonly GitHubReleaseSnapshotStore $store,
        private readonly CodeUpdateManager $codeUpdateManager,
        private readonly ReleaseNoticeSnoozeManager $snoozeManager,
        private readonly TokenStorageInterface $tokenStorage,
        private readonly ClockInterface $clock,
    ) {
    }

    /**
     * Discreet banner data for the current user, or null. Reads snapshot cache
     * only; never performs HTTP. Explicitly checks the update permission.
     *
     * @return array<string, mixed>|null
     */
    public function releaseNotice(): ?array
    {
        $user = $this->currentUser();
        if (!$user instanceof User || !$this->hasUpdatePermission($user)) {
            return null;
        }

        $snapshot = $this->snapshot();
        if (!$snapshot['updateAvailable'] || !\is_array($snapshot['latest'])) {
            return null;
        }

        $latest = $snapshot['latest'];
        $snoozedUntil = $this->snoozeManager->activeSnoozedUntil($user, (string) $latest['releaseVersion']);
        if (null !== $snoozedUntil) {
            return null;
        }

        return [
            'latestVersion' => (string) $latest['releaseVersion'],
            'installedVersion' => (string) $snapshot['installedVersionDisplay'],
            'releaseUrl' => (string) $latest['releaseUrl'],
            'publishedAt' => (string) $latest['publishedAt'],
            'lastSuccessAt' => $snapshot['lastSuccessAt'],
            'detailsRoute' => self::DETAILS_ROUTE,
            'snoozeRoute' => self::SNOOZE_ROUTE,
            'snoozeCsrfId' => self::SNOOZE_CSRF_ID,
            'snoozeDaysLabel' => ReleaseNoticeSnoozeManager::SNOOZE_DAYS_LABEL,
        ];
    }

    /**
     * Full view-model for the release details page. Reads snapshot cache only;
     * never performs HTTP.
     *
     * @return array<string, mixed>
     */
    public function snapshot(): array
    {
        $state = $this->store->readState();
        $application = $this->codeUpdateManager->describeCurrentApplication();
        $installedRaw = trim((string) ($application['version'] ?? ''));
        $installedVersion = $this->normalizeVersionString($installedRaw);

        $latest = \is_array($state['latest'] ?? null)
            ? $this->normalizeLatest($state['latest'])
            : null;
        $latestVersion = null !== $latest && \is_string($latest['releaseVersion']) ? $latest['releaseVersion'] : null;

        $comparison = 'unknown';
        if (null !== $installedVersion && null !== $latestVersion) {
            $comparison = version_compare($latestVersion, $installedVersion) > 0
                ? 'newer'
                : (version_compare($latestVersion, $installedVersion) < 0 ? 'older' : 'same');
        }

        $now = $this->clock->now();
        $lastAttemptAt = $this->parseDateTime($state['lastAttemptAt'] ?? null);
        $checking = 'checking' === $state['status']
            && $lastAttemptAt instanceof \DateTimeImmutable
            && $now->getTimestamp() - $lastAttemptAt->getTimestamp() < self::STALE_CHECKING_SECONDS;
        $interrupted = 'checking' === $state['status'] && !$checking;

        $user = $this->currentUser();
        $snoozeUntil = $user instanceof User && null !== $latestVersion
            ? $this->snoozeManager->activeSnoozedUntil($user, $latestVersion)
            : null;

        return [
            'checking' => $checking,
            'interrupted' => $interrupted,
            'applicationName' => (string) ($application['name'] ?? 'driftpunkt'),
            'installedVersion' => $installedRaw,
            'installedVersionKnown' => null !== $installedVersion,
            'installedVersionDisplay' => null !== $installedVersion
                ? $installedRaw
                : self::UNKNOWN_INSTALLED_VERSION_TEXT,
            'latest' => $latest,
            'comparison' => $comparison,
            'updateAvailable' => 'newer' === $comparison,
            'historyIncomplete' => 'newer' === $comparison,
            'hasSuccessfulCheck' => null !== $this->parseDateTime($state['lastSuccessAt'] ?? null),
            'lastSuccessAt' => $this->nullableString($state['lastSuccessAt'] ?? null),
            'lastAttemptAt' => $this->nullableString($state['lastAttemptAt'] ?? null),
            'lastFailureAt' => $this->nullableString($state['lastFailureAt'] ?? null),
            'lastFailureMessage' => $this->nullableString($state['lastFailureMessage'] ?? null),
            'lastOutcomeMessage' => $this->nullableString($state['lastOutcomeMessage'] ?? null),
            'lastAttemptAgeSeconds' => $lastAttemptAt instanceof \DateTimeImmutable
                ? max(0, $now->getTimestamp() - $lastAttemptAt->getTimestamp())
                : null,
            'lastSuccessAgeSeconds' => ($lastSuccess = $this->parseDateTime($state['lastSuccessAt'] ?? null)) instanceof \DateTimeImmutable
                ? max(0, $now->getTimestamp() - $lastSuccess->getTimestamp())
                : null,
            'snoozedUntil' => $snoozeUntil?->format(DATE_ATOM),
            'snoozeAvailable' => $this->snoozeManager->isReady(),
            'snoozeActive' => null !== $snoozeUntil,
            'snoozeDaysLabel' => ReleaseNoticeSnoozeManager::SNOOZE_DAYS_LABEL,
            'detailsRoute' => self::DETAILS_ROUTE,
            'checkRoute' => self::CHECK_ROUTE,
            'checkCsrfId' => self::CHECK_CSRF_ID,
            'snoozeRoute' => self::SNOOZE_ROUTE,
            'snoozeCsrfId' => self::SNOOZE_CSRF_ID,
        ];
    }

    public function latestSnapshotReleaseVersion(): ?string
    {
        $latest = $this->store->readState()['latest'] ?? null;

        return \is_array($latest) ? ($this->normalizeLatest($latest)['releaseVersion'] ?? null) : null;
    }

    private function currentUser(): ?User
    {
        $user = $this->tokenStorage->getToken()?->getUser();

        return $user instanceof User ? $user : null;
    }

    private function hasUpdatePermission(User $user): bool
    {
        return \in_array('ROLE_SUPER_ADMIN', $user->getRoles(), true);
    }

    /**
     * @param array<string, mixed> $latest
     * @return array<string, mixed>|null
     */
    private function normalizeLatest(array $latest): ?array
    {
        $releaseVersion = isset($latest['releaseVersion']) && \is_string($latest['releaseVersion'])
            ? trim($latest['releaseVersion'])
            : '';
        $releaseUrl = isset($latest['releaseUrl']) && \is_string($latest['releaseUrl'])
            ? $latest['releaseUrl']
            : '';

        if (null === $this->normalizeVersionString($releaseVersion)
            || mb_strlen($releaseVersion) > ReleaseNoticeSnoozeManager::MAX_RELEASE_VERSION_LENGTH
            || !str_starts_with($releaseUrl, GitHubReleaseChecker::RELEASE_TAG_URL_PREFIX)
        ) {
            return null;
        }

        return [
            'releaseVersion' => $releaseVersion,
            'tagName' => \is_string($latest['tagName'] ?? null) ? (string) $latest['tagName'] : $releaseVersion,
            'releaseUrl' => $releaseUrl,
            'publishedAt' => \is_string($latest['publishedAt'] ?? null) ? (string) $latest['publishedAt'] : '',
            'notes' => \is_string($latest['notes'] ?? null) ? (string) $latest['notes'] : '',
            'notesTruncated' => (bool) ($latest['notesTruncated'] ?? false),
            'highlights' => \is_array($latest['highlights'] ?? null)
                ? array_values(array_filter($latest['highlights'], 'is_string'))
                : [],
        ];
    }

    private function normalizeVersionString(string $version): ?string
    {
        if (1 !== preg_match('/^v?(\d+(?:\.\d+)+)$/i', trim($version), $matches)) {
            return null;
        }

        return $matches[1];
    }

    private function nullableString(mixed $value): ?string
    {
        return \is_string($value) && '' !== $value ? $value : null;
    }

    private function parseDateTime(mixed $value): ?\DateTimeImmutable
    {
        if (!\is_string($value) || '' === trim($value)) {
            return null;
        }

        try {
            return new \DateTimeImmutable($value);
        } catch (\Throwable) {
            return null;
        }
    }
}
