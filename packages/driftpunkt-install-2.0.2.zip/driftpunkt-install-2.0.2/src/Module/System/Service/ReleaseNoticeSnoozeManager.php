<?php

declare(strict_types=1);

namespace App\Module\System\Service;

use App\Module\Identity\Entity\User;
use App\Module\System\Entity\ReleaseNoticeSnooze;
use Doctrine\ORM\EntityManagerInterface;
use Doctrine\DBAL\LockMode;
use Symfony\Component\Clock\ClockInterface;

final class ReleaseNoticeSnoozeManager
{
    public const SNOOZE_DAYS = 7;
    public const SNOOZE_DAYS_LABEL = '7 dagar';
    public const MAX_RELEASE_VERSION_LENGTH = 40;

    public function __construct(
        private readonly EntityManagerInterface $entityManager,
        private readonly ClockInterface $clock,
    ) {
    }

    public function snooze(User $user, string $releaseVersion): \DateTimeImmutable
    {
        $version = trim($releaseVersion);
        if ('' === $version || mb_strlen($version) > self::MAX_RELEASE_VERSION_LENGTH) {
            throw new \InvalidArgumentException('Ogiltig releaseversion.');
        }

        if (!$this->isReady()) {
            throw new \RuntimeException('Lagring för påminnelser kräver databasmigration.');
        }

        // Serialize first-time reminders on the existing account row: there is
        // no reminder row to lock until the first insert has completed.
        return $this->entityManager->wrapInTransaction(function () use ($user, $version): \DateTimeImmutable {
            $this->entityManager->lock($user, LockMode::PESSIMISTIC_WRITE);
            $snooze = $this->findSnooze($user, $version);
            $snoozedUntil = $this->clock->now()->modify(sprintf('+%d days', self::SNOOZE_DAYS));

            if ($snooze instanceof ReleaseNoticeSnooze) {
                $snooze->extendTo($snoozedUntil);
            } else {
                $this->entityManager->persist(new ReleaseNoticeSnooze($user, $version, $snoozedUntil));
            }

            return $snoozedUntil;
        });
    }

    public function isSnoozed(User $user, string $releaseVersion): bool
    {
        return null !== $this->activeSnoozedUntil($user, $releaseVersion);
    }

    public function activeSnoozedUntil(User $user, string $releaseVersion): ?\DateTimeImmutable
    {
        if (!$this->isReady()) {
            return null;
        }

        $snooze = $this->findSnooze($user, trim($releaseVersion));
        if (!$snooze instanceof ReleaseNoticeSnooze) {
            return null;
        }

        return $snooze->getSnoozedUntil() > $this->clock->now() ? $snooze->getSnoozedUntil() : null;
    }

    public function isReady(): bool
    {
        try {
            return $this->entityManager->getConnection()->createSchemaManager()
                ->tablesExist(['release_notice_snoozes']);
        } catch (\Throwable) {
            return false;
        }
    }

    private function findSnooze(User $user, string $releaseVersion): ?ReleaseNoticeSnooze
    {
        $repository = $this->entityManager->getRepository(ReleaseNoticeSnooze::class);
        $snooze = $repository->findOneBy([
            'user' => $user,
            'releaseVersion' => $releaseVersion,
        ]);

        return $snooze instanceof ReleaseNoticeSnooze ? $snooze : null;
    }
}
