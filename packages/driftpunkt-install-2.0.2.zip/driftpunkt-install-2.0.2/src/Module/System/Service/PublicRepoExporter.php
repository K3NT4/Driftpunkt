<?php

declare(strict_types=1);

namespace App\Module\System\Service;

use Symfony\Component\DependencyInjection\Attribute\Autowire;

final class PublicRepoExporter
{
    private const PACKAGE_DIRECTORY = 'packages';
    private const MANIFEST_FILENAME = 'PUBLIC_EXPORT_MANIFEST.md';
    private const UPGRADE_PACKAGE_LIMIT = 3;
    private const PUBLIC_DOCUMENTS = [
        'INSTALL.md',
        'docs/debian_server_setup.md',
        'docs/installation_and_deployment.md',
        'docs/nas_docker_setup.md',
        'LICENSE.md',
        'SECURITY.md',
        'docs/upgrade_to_2_0_0.md',
        'docs/support_cards.md',
        'docs/upgrade_to_2_0_1.md',
        'docs/addons.md',
        'docs/addon.schema.json',
        'docs/examples/addon.json',
        '.github/ISSUE_TEMPLATE/bug_report.md',
        '.github/ISSUE_TEMPLATE/feature-or-improvement.md',
        '.github/ISSUE_TEMPLATE/config.yml',
        '.github/workflows/release.yml',
    ];
    private const PACKAGE_FILENAME_PATTERN = '/^driftpunkt-(install|upgrade)-(.+)\.zip$/';

    /**
     * @var array<string, string>
     */
    private const PUBLIC_ASSETS = [
        'docs/public-assets/branding/logo-wide.png' => 'assets/branding/logo-wide.png',
        'docs/public-assets/branding/logo-icon.png' => 'assets/branding/logo-icon.png',
        'docs/public-assets/branding/logo-wide-v2.svg' => 'assets/branding/logo-wide-v2.svg',
        'docs/public-assets/branding/logo-wide-v2-dark.svg' => 'assets/branding/logo-wide-v2-dark.svg',
        'htdocs/assets/branding/driftpunkt-icon-v2.svg' => 'assets/branding/driftpunkt-icon-v2.svg',
        'docs/public-assets/screenshots/homepage.png' => 'assets/screenshots/homepage.png',
        'docs/public-assets/screenshots/public-status.png' => 'assets/screenshots/public-status.png',
        'docs/public-assets/screenshots/contact-page.png' => 'assets/screenshots/contact-page.png',
        'docs/public-assets/screenshots/maintenance-mode.png' => 'assets/screenshots/maintenance-mode.png',
        'docs/public-assets/screenshots/customer-portal.png' => 'assets/screenshots/customer-portal.png',
        'docs/public-assets/screenshots/customer-ticket.png' => 'assets/screenshots/customer-ticket.png',
        'docs/public-assets/screenshots/customer-mobile.png' => 'assets/screenshots/customer-mobile.png',
        'docs/public-assets/screenshots/technician-portal.png' => 'assets/screenshots/technician-portal.png',
        'docs/public-assets/screenshots/technician-overview.png' => 'assets/screenshots/technician-overview.png',
        'docs/public-assets/screenshots/technician-tickets.png' => 'assets/screenshots/technician-tickets.png',
        'docs/public-assets/screenshots/coordinator-portal.png' => 'assets/screenshots/coordinator-portal.png',
        'docs/public-assets/screenshots/admin-dashboard.png' => 'assets/screenshots/admin-dashboard.png',
        'docs/public-assets/screenshots/login-admin.png' => 'assets/screenshots/login-admin.png',
        'docs/public-assets/screenshots/login-technician.png' => 'assets/screenshots/login-technician.png',
        'docs/public-assets/screenshots/login-customer.png' => 'assets/screenshots/login-customer.png',
    ];

    public function __construct(
        #[Autowire('%kernel.project_dir%')]
        private readonly string $projectDir,
        private readonly ReleasePackageBuilder $releasePackageBuilder,
    ) {
    }

    /**
     * @return array{
     *     outputDirectory: string,
     *     copiedPaths: list<string>,
     *     skippedPaths: list<string>,
     *     fileCount: int,
     *     packages: list<array{
     *         type: string,
     *         version: string,
     *         filename: string,
     *         relativePath: string,
     *         checksumPath: string,
     *         checksumSha256: string
     *     }>
     * }
     */
    public function export(?string $outputDirectory = null): array
    {
        $distDirectory = $this->projectDir.\DIRECTORY_SEPARATOR.'dist';
        $this->releasePackageBuilder->buildPackages('both', null, $distDirectory);

        $availablePackages = $this->discoverReleasePackages($distDirectory);
        $selectedPackages = $this->selectPublicPackages($availablePackages);
        $skippedPaths = $this->skippedPackagePaths($availablePackages, $selectedPackages);
        // Historical packages are copied verbatim: reject unsafe archives before clearing an existing export.
        $this->assertPackagesExcludeRuntimeBranding($selectedPackages);

        $publicDocuments = [];
        foreach (self::PUBLIC_DOCUMENTS as $document) {
            $sourcePath = $this->projectDir.\DIRECTORY_SEPARATOR.$document;
            if (!is_file($sourcePath) || !is_readable($sourcePath)) {
                throw new \RuntimeException(sprintf('Kunde inte läsa %s för publik export.', $document));
            }
            $content = file_get_contents($sourcePath);
            if (false === $content) {
                throw new \RuntimeException(sprintf('Kunde inte läsa %s för publik export.', $document));
            }
            $publicDocuments[$document] = $content;
        }

        $targetDirectory = $outputDirectory ?? $this->projectDir.\DIRECTORY_SEPARATOR.'var'.\DIRECTORY_SEPARATOR.'public_repo_export';
        $this->prepareOutputDirectory($targetDirectory);

        $exportedPackages = $this->copyPackages($selectedPackages, $targetDirectory);
        $copiedAssets = $this->copyPublicAssets($targetDirectory);

        $copiedPaths = [];
        $this->writeFile($targetDirectory.\DIRECTORY_SEPARATOR.'README.md', $this->buildReadme($exportedPackages, $copiedAssets));
        $copiedPaths[] = 'README.md';
        foreach ($publicDocuments as $document => $content) {
            $this->writeFile($targetDirectory.\DIRECTORY_SEPARATOR.$document, $content);
            $copiedPaths[] = $document;
        }
        $copiedPaths = [...$copiedPaths, ...$copiedAssets];

        foreach ($exportedPackages as $package) {
            $copiedPaths[] = $package['relativePath'];
            $copiedPaths[] = $package['checksumPath'];
        }

        $this->writeFile(
            $targetDirectory.\DIRECTORY_SEPARATOR.self::MANIFEST_FILENAME,
            $this->buildManifest($exportedPackages, $copiedAssets, $skippedPaths),
        );
        $copiedPaths[] = self::MANIFEST_FILENAME;

        return [
            'outputDirectory' => $targetDirectory,
            'copiedPaths' => $copiedPaths,
            'skippedPaths' => $skippedPaths,
            'fileCount' => \count($copiedPaths),
            'packages' => $exportedPackages,
        ];
    }

    /** @param list<array{filename: string, path: string}> $packages */
    private function assertPackagesExcludeRuntimeBranding(array $packages): void
    {
        foreach ($packages as $package) {
            $archive = new \ZipArchive();
            if (true !== $archive->open($package['path'], \ZipArchive::RDONLY)) {
                throw new \RuntimeException(sprintf('Kunde inte kontrollera %s före publik export.', $package['filename']));
            }
            try {
                for ($index = 0; $index < $archive->numFiles; ++$index) {
                    $entry = $archive->getNameIndex($index);
                    if (false === $entry) {
                        throw new \RuntimeException(sprintf('Kunde inte läsa paketförteckningen i %s.', $package['filename']));
                    }
                    $path = str_replace('\\', '/', $entry);
                    $withoutArchiveRoot = (string) preg_replace('#^[^/]+/#', '', $path, 1);
                    if (SiteBrandingAssetStorage::isRuntimeBrandingPath($path)
                        || SiteBrandingAssetStorage::isRuntimeBrandingPath($withoutArchiveRoot)) {
                        throw new \RuntimeException(sprintf('Paketet %s innehåller uppladdad branding och får inte exporteras. Bygg om paketet från en ren källa.', $package['filename']));
                    }
                }
            } finally {
                $archive->close();
            }
        }
    }

    private function prepareOutputDirectory(string $directory): void
    {
        if (is_dir($directory)) {
            $this->removeDirectoryContents($directory);

            return;
        }

        if (!mkdir($directory, 0775, true) && !is_dir($directory)) {
            throw new \RuntimeException('Kunde inte skapa exportmappen för den publika repot.');
        }
    }

    /**
     * @return list<array{type: string, version: string, filename: string, path: string, modifiedAt: int}>
     */
    private function discoverReleasePackages(string $distDirectory): array
    {
        if (!is_dir($distDirectory)) {
            throw new \RuntimeException('Kunde inte hitta dist-mappen med versionspaket.');
        }

        $packages = [];
        foreach (array_values(array_filter(
            scandir($distDirectory) ?: [],
            static fn (string $entry): bool => !\in_array($entry, ['.', '..'], true),
        )) as $entry) {
            $path = $distDirectory.\DIRECTORY_SEPARATOR.$entry;
            if (!is_file($path) || 1 !== preg_match(self::PACKAGE_FILENAME_PATTERN, $entry, $matches)) {
                continue;
            }

            $packages[] = [
                'type' => $matches[1],
                'version' => $matches[2],
                'filename' => $entry,
                'path' => $path,
                'modifiedAt' => (int) (filemtime($path) ?: 0),
            ];
        }

        return $packages;
    }

    /**
     * @param list<array{type: string, version: string, filename: string, path: string, modifiedAt: int}> $packages
     * @return list<array{type: string, version: string, filename: string, path: string, modifiedAt: int}>
     */
    private function selectPublicPackages(array $packages): array
    {
        $installPackages = array_values(array_filter(
            $packages,
            static fn (array $package): bool => 'install' === $package['type'],
        ));
        $upgradePackages = array_values(array_filter(
            $packages,
            static fn (array $package): bool => 'upgrade' === $package['type'],
        ));

        $this->sortPackagesByRecency($installPackages);
        $this->sortPackagesByRecency($upgradePackages);

        if ([] === $installPackages) {
            throw new \RuntimeException('Inget installationspaket kunde hittas eller byggas.');
        }

        if ([] === $upgradePackages) {
            throw new \RuntimeException('Inget uppgraderingspaket kunde hittas eller byggas.');
        }

        return [
            $installPackages[0],
            ...array_slice($upgradePackages, 0, self::UPGRADE_PACKAGE_LIMIT),
        ];
    }

    /**
     * @param list<array{type: string, version: string, filename: string, path: string, modifiedAt: int}> $packages
     */
    private function sortPackagesByRecency(array &$packages): void
    {
        usort(
            $packages,
            static function (array $left, array $right): int {
                $modifiedComparison = $right['modifiedAt'] <=> $left['modifiedAt'];
                if (0 !== $modifiedComparison) {
                    return $modifiedComparison;
                }

                $versionComparison = version_compare($right['version'], $left['version']);
                if (0 !== $versionComparison) {
                    return $versionComparison;
                }

                return $right['filename'] <=> $left['filename'];
            },
        );
    }

    /**
     * @param list<array{type: string, version: string, filename: string, path: string, modifiedAt: int}> $availablePackages
     * @param list<array{type: string, version: string, filename: string, path: string, modifiedAt: int}> $selectedPackages
     * @return list<string>
     */
    private function skippedPackagePaths(array $availablePackages, array $selectedPackages): array
    {
        $selectedFilenames = array_flip(array_column($selectedPackages, 'filename'));
        $skippedPaths = [];

        foreach ($availablePackages as $package) {
            if (isset($selectedFilenames[$package['filename']])) {
                continue;
            }

            $skippedPaths[] = 'dist/'.$package['filename'];
        }

        sort($skippedPaths);

        return $skippedPaths;
    }

    /**
     * @param list<array{type: string, version: string, filename: string, path: string, modifiedAt: int}> $packages
     * @return list<array{
     *     type: string,
     *     version: string,
     *     filename: string,
     *     relativePath: string,
     *     checksumPath: string,
     *     checksumSha256: string
     * }>
     */
    private function copyPackages(array $packages, string $targetDirectory): array
    {
        $packageDirectory = $targetDirectory.\DIRECTORY_SEPARATOR.self::PACKAGE_DIRECTORY;
        if (!is_dir($packageDirectory) && !mkdir($packageDirectory, 0775, true) && !is_dir($packageDirectory)) {
            throw new \RuntimeException('Kunde inte skapa paketmappen i publik export.');
        }

        $exportedPackages = [];
        foreach ($packages as $package) {
            $targetPath = $packageDirectory.\DIRECTORY_SEPARATOR.$package['filename'];
            if (!copy($package['path'], $targetPath)) {
                throw new \RuntimeException(sprintf('Kunde inte kopiera %s till publik export.', $package['filename']));
            }

            $checksumSha256 = (string) hash_file('sha256', $targetPath);
            $checksumFilename = $package['filename'].'.sha256';
            $this->writeFile(
                $packageDirectory.\DIRECTORY_SEPARATOR.$checksumFilename,
                sprintf("%s  %s\n", $checksumSha256, $package['filename']),
            );

            $exportedPackages[] = [
                'type' => $package['type'],
                'version' => $package['version'],
                'filename' => $package['filename'],
                'relativePath' => self::PACKAGE_DIRECTORY.'/'.$package['filename'],
                'checksumPath' => self::PACKAGE_DIRECTORY.'/'.$checksumFilename,
                'checksumSha256' => $checksumSha256,
            ];
        }

        return $exportedPackages;
    }

    /**
     * @return list<string>
     */
    private function copyPublicAssets(string $targetDirectory): array
    {
        $copiedAssets = [];

        foreach (self::PUBLIC_ASSETS as $sourceRelativePath => $targetRelativePath) {
            $sourcePath = $this->projectDir.\DIRECTORY_SEPARATOR.$sourceRelativePath;
            if (!is_file($sourcePath)) {
                continue;
            }

            $targetPath = $targetDirectory.\DIRECTORY_SEPARATOR.str_replace('/', \DIRECTORY_SEPARATOR, $targetRelativePath);
            $targetAssetDirectory = dirname($targetPath);
            if (!is_dir($targetAssetDirectory) && !mkdir($targetAssetDirectory, 0775, true) && !is_dir($targetAssetDirectory)) {
                throw new \RuntimeException(sprintf('Kunde inte skapa asset-katalogen för %s.', $targetRelativePath));
            }

            if (!copy($sourcePath, $targetPath)) {
                throw new \RuntimeException(sprintf('Kunde inte kopiera publik README-asset %s.', $sourceRelativePath));
            }

            $copiedAssets[] = $targetRelativePath;
        }

        return $copiedAssets;
    }

    private function writeFile(string $path, string $contents): void
    {
        $directory = dirname($path);
        if (!is_dir($directory) && !mkdir($directory, 0775, true) && !is_dir($directory)) {
            throw new \RuntimeException(sprintf('Kunde inte skapa katalogen %s.', $directory));
        }

        if (false === file_put_contents($path, $contents)) {
            throw new \RuntimeException(sprintf('Kunde inte skriva filen %s.', basename($path)));
        }
    }

    /**
     * @param list<array{type: string, version: string, filename: string, relativePath: string, checksumPath: string, checksumSha256: string}> $packages
     * @param list<string> $assets
     */
    private function buildReadme(array $packages, array $assets): string
    {
        $installPackage = $this->firstPackageOfType($packages, 'install');
        $installArchiveRoot = preg_replace('/\.zip$/', '', $installPackage['filename']) ?? $installPackage['filename'];
        $upgradePackages = array_values(array_filter(
            $packages,
            static fn (array $package): bool => 'upgrade' === $package['type'],
        ));

        $lines = [
            '# Driftpunkt Release Packages',
            '',
            '<picture>',
            '  <source media="(prefers-color-scheme: dark)" srcset="assets/branding/logo-wide-v2-dark.svg">',
            '  <img src="assets/branding/logo-wide-v2.svg" alt="Driftpunkt" width="520">',
            '</picture>',
            '',
            'Driftpunkt is a support and operations platform for handling tickets, customer communication, technician work queues, operational status updates, knowledge base content, reports, company administration, and maintenance workflows.',
            '',
            'This public repository distributes release archives, documentation, and selected screenshots. The archives include application code and dependencies needed to run Driftpunkt; private Git history, internal planning documents, live environment files, and runtime customer data are not exported.',
            '',
            'The screenshots may show the Swedish interface. Language and branding can be changed after installation through the running application and its environment-specific configuration.',
            'The gallery shows Driftpunkt 2.0 with synthetic demonstration accounts and tickets; it contains no live customer data.',
            '',
            '**Stable release: '.$installPackage['version'].'** · [Download releases](https://github.com/K3NT4/Driftpunkt/releases/latest) · [Install](INSTALL.md) · [Upgrade](docs/upgrade_to_2_0_1.md)',
            '',
            'Before upgrading to 2.0, follow the [live-server upgrade checklist (English)](docs/upgrade_to_2_0_0.md), including backups, Docker prerequisites and enabling the personal classic/modern layout choice for technicians and ticket coordinators.',
            '',
            'For a new installation, start with [INSTALL.md (English)](INSTALL.md): Debian 13 and NAS instructions with explicit fresh-database protection and hidden administrator password input.',
            '',
            '## New in 2.0.2',
            '',
            '- Technicians can choose whether **Team latest** is shown below **My tickets** on their dashboard (shown by default).',
            '- Technicians can limit the menu counts next to **Overview** and **Tickets** to tickets assigned to them instead of the whole team (off by default).',
            '- Both choices are personal, work in the modern and classic technician layouts and do not affect ticket coordinators. No database migrations; follow [the 2.0.1 upgrade checklist](docs/upgrade_to_2_0_1.md).',
            '',
            '## New in 2.0.1',
            '',
            '- Create data-only JSON panels with an example, schema, validation and preview in Swedish, English or Norwegian. Import inactive, explicitly activate, switch versions, roll back, disable or delete inactive versions.',
            '- Place panels on the public homepage, customer overview or technician dashboard, including modern and classic technician layouts. Customer panels are shared across companies.',
            '- Executable PHP/Twig ZIP addons are retired. JSON panels run no code, fetch no URLs on the server and receive no database or API access.',
            '- Extended news editing and telephone support are native switches under Features. SupportDesk and its AnyDesk/TeamViewer shortcuts are removed; historical data is retained.',
            '- Update execution preloads console error and termination listeners before cache replacement. Follow the upgrade guide when starting from an older updater.',
            '- See [the addon guide](docs/addons.md) and [the 2.0.1 upgrade checklist](docs/upgrade_to_2_0_1.md).',
            '',
            '## Earlier 2.0 Improvements',
            '',
            '- Driftpunkt 2.0 redesigns the public website and all role portals with responsive navigation, clearer queues, visible company labels, accessible controls and working personal themes.',
            '- Customers get clearer search, status, conversation and attachment views; private customers can create tickets without belonging to a company.',
            '- Public pages retain installation branding and can follow the device theme. Administrators can disable system-theme following and subtle seasonal decorations.',
            '- Super administrators can enable a modern/classic presentation choice for technicians and ticket coordinators. Customer accounts use the modern portal with personal colour themes.',
            '- Basic text tools are visible, advanced tools are collapsed, and the toolbar can be hidden without losing a draft.',
            '- Company support cards add revocable QR links and PDF/SVG export. Read-only stable-release notices never install an update automatically.',
            '- Debian 13 and NAS installation helpers provide explicit fresh-database protection. Upgrade packages preserve installation data, mail configuration and private environment files; keep all encryption keys.',
            '- Update completion uses a fresh process after cache replacement. See the upgrade checklist before updating an installation using an older runner.',
            '',
            'Validation includes isolated SQL/file restoration and HTTP/CLI checks on a separate deployment. Real email delivery, production HTTPS, load and full visual acceptance remain environment-specific checks.',
            '',
            '<details>',
            '<summary>Earlier 1.x improvements</summary>',
            '',
            '- Release 1.0.133 adds customer inventory management, coordinator ownership, EML/MSG reading, PDF and inline image previews, winmail.dat extraction, attachment recovery forwarding, linked tickets from attached emails, clearer ticket intake and review screens, duplicate suggestions, and explicit group-wide read access to private subsidiary tickets. It also updates ten affected Symfony components to 8.1.11 for security fixes published on November 4, 2026. Three database migrations are required:',
            '  - Customer search from the portal overview also covers accessible company and subsidiary tickets. Selected customer users can manage the company computer list; customer removal archives the computer and keeps its history.',
            '  - A super admin can give a selected customer user on a parent company read access to all customer-visible tickets in the whole subsidiary tree, including private and closed tickets. Internal tickets, internal notes, and other company groups stay hidden, and the assignment does not grant any write access.',
            '  - Ticket coordinators can own tickets and take over when writing customer-visible comments; internal notes never change the assignment.',
            '  - Technicians and coordinators can read EML and Outlook MSG attachments including nested emails, preview PDFs, see pasted inline images without loading external tracking images, and download regular files extracted from `winmail.dat`.',
            '  - Attachment errors show file name and reason and forward the original email to the coordinator or selected triage recipients, with status, retry, and loop protection. An attached email can become a separate linked ticket, internal by default and without customer email.',
            '  - The internal ticket view shows an intake panel with sender, mailbox, and the saved reason a reply was linked, collected attachment warnings, up to three duplicate suggestions within existing read access (never merged automatically), compact file rows, and the planned email recipients for customer replies.',
            '  - Mail review shows a summary before approval and rejects a customer combined with a different company on the server. Cache warmup during Docker builds and updates gets a separate 512 MB memory budget.',
            '- Release 1.0.132 lets customers choose language at the top of the customer portal, remembers the choice on the account, and translates the customer pages into English and Norwegian.',
            '- Release 1.0.131 adds an optional contact phone number on tickets, clearer priority marking for technicians and ticket coordinators, more formatting options in the comment editor, and protection against spreadsheet formulas in portal CSV exports. It also updates `symfony/mime` to 8.1.10 for CVE-2026-45070 and includes a database migration.',
            '- Release 1.0.130 improves the customer portal company ticket view with per-company summaries, subsidiary totals, a searchable company filter, remembered filters, and CSV export. Replies from known customers that cannot be linked to a ticket now create regular tickets, ticket coordinators are notified for every pending mail review, and line breaks in comments are preserved.',
            '- Release 1.0.129 lets customers, technicians, and ticket coordinators attach several files at once with a clearer file picker, always allows ZIP attachments up to 1 MB, and shows the original email to ticket coordinators.',
            '- Release 1.0.128 updates 56 existing Composer packages, including core Symfony components to 8.1.9, while keeping Symfony in the 8.1 series. No packages were added or removed from the lockfile.',
            '- PHP must be updated separately to 8.4.27 or later within 8.4, or 8.5.12 or later within 8.5, before applying the new application archive. The Debian installer and Docker build check the required patch level for each PHP series.',
            '- Ticket coordinators can close active and resolved tickets, including unassigned tickets, with a required resolution. Administrative closing sets status Closed, records the closing time, and sends no customer email.',
            '- Saved resolutions remain visible in a separate read-only panel after closing. Repeating a close request preserves an already closed ticket\'s resolution and closing time.',
            '- Ticket coordinators can change priority without changing status, resolution, assignments, or the SLA policy.',
            '- Closing and priority changes require coordinator permissions and CSRF protection, record the acting user and before-and-after values in ticket history, and preserve read-only merged source tickets.',
            '- Forwarded messages and forwarded delivery failures keep their forwarded content in the ticket, while the customer\'s own signature is still removed.',
            '- Technicians can read the complete original email below the ticket description and download it as an `.eml` file.',
            '- Auto-replies and bounces no longer create tickets, machine-sent alerts never receive confirmations, and confirmations are rate-limited per sender to prevent mail loops.',
            '- Company badges show the company name and icon without a redundant label.',
            '- New review drafts from unknown mail senders notify the configured triage recipients and link to the matching draft in the coordinator queue. Delivery failures are logged.',
            '- Company email domains route unknown senders arriving at a parent inbox to the correct subsidiary. Automatic registration remains off by default; when enabled, it creates contacts on the matched company.',
            '- Customer access to internal comment attachments is blocked, and email replies follow the same access rules as the portal.',
            '- Login and MFA have account-based attempt limits, while public forms have additional IP-based limits.',
            '- Password reset and translation output escaping, attachment extensions, and database backup and restore error handling have been improved.',
            '- Technicians and coordinators can add personal signatures to customer emails and send a separate copy to their own account address.',
            '',
            '</details>',
            '',
            '## Screenshots',
            '',
            '| Public homepage | Public status |',
            '| --- | --- |',
            '| ![Driftpunkt public homepage](assets/screenshots/homepage.png) | ![Driftpunkt public status](assets/screenshots/public-status.png) |',
            '',
            '| Contact page | Maintenance mode |',
            '| --- | --- |',
            '| ![Driftpunkt contact page](assets/screenshots/contact-page.png) | ![Driftpunkt maintenance mode](assets/screenshots/maintenance-mode.png) |',
            '',
            '| Customer portal | Ticket conversation |',
            '| --- | --- |',
            '| ![Driftpunkt customer portal](assets/screenshots/customer-portal.png) | ![Driftpunkt customer ticket](assets/screenshots/customer-ticket.png) |',
            '',
            '| Technician overview | Technician ticket queue |',
            '| --- | --- |',
            '| ![Driftpunkt technician overview](assets/screenshots/technician-overview.png) | ![Driftpunkt technician ticket queue](assets/screenshots/technician-tickets.png) |',
            '',
            '| Ticket coordinator | Admin dashboard |',
            '| --- | --- |',
            '| ![Driftpunkt ticket coordinator](assets/screenshots/coordinator-portal.png) | ![Driftpunkt admin dashboard](assets/screenshots/admin-dashboard.png) |',
            '',
            '<details>',
            '<summary>Mobile view</summary>',
            '',
            '<img src="assets/screenshots/customer-mobile.png" alt="Driftpunkt customer portal on mobile" width="320">',
            '',
            '</details>',
            '',
            '## What Driftpunkt Includes',
            '',
            '- A public website for the homepage, operational status, news, search, contact details, public knowledge base content, and legal policy pages.',
            '- Public ticket intake for visitors when the feature is enabled, plus authenticated customer portals for ongoing support dialogue.',
            '- Customer accounts for both company customers and private customers, including password reset, language switching, personal light, dark, system, and high-contrast portal themes, ticket follow-up, comments, feedback, and customer-visible knowledge base content; super administrators can provision multiple company customers at once with secure temporary passwords.',
            '- Customer-facing resources such as allowlisted company reports, computer lists, and printer lists under a translated "My resources" menu when those resources are enabled.',
            '- Technician and ticket coordinator portals for queue work, triage, comments, assignment, conditional SLA follow-up, reports, activity, notifications, company inventory lookup, and internal issue or feature-request reporting, with a focused two-column technician ticket workbench and clearer personal ticket filtering.',
            '- Full ticket lifecycle support with statuses, priorities, impact levels, request types, routing rules, teams, multiple responsible technicians, internal notes, customer-visible replies, attachments, checklists, playbooks, and customer feedback reminders.',
            '- Admin tools for identity, companies, company hierarchies, teams, mail, ticket categories, intake templates, routing, SLA policies, public content, reports, logs, background jobs, settings, updates, and maintenance mode, with identity work split into focused user, customer, team, appearance, and triage sections.',
            '- Mail ingestion through spool or mailbox polling, incoming mail review, correction drafts, mailbox routing, outgoing profiles, ticket notification emails, and technician/customer links back to the related ticket.',
            '- Knowledge base and news management with public, customer, technician, and admin-facing workflows, optional technician contributions, smart tips, FAQ-style content, and status communication.',
            '- Operational tooling for read-only ticket API access, monthly company reports, database jobs, backups, restore/optimize tasks, migration runs, code update staging, package application, declarative addon management, log export, and controlled cleanup.',
            '- Localization and personalization for Swedish, English, and Norwegian UI text, personal default language in technician, coordinator, admin, and super admin workflows, global default/selectable language governance, customer portal themes, optional lightweight seasonal appearance, branding assets, MFA settings, declarative panels, and internal portal theme templates.',
            '- Release packages with bundled dependencies, metadata, release notes, post-update guidance, and SHA-256 checksums.',
            '',
            '## Profiles and What They Can Do',
            '',
            'Visible features depend on enabled settings, company access, and role permissions, but Driftpunkt currently supports these main profiles:',
            '',
            '### Public Visitor',
            '',
            '- Read the public homepage, operational status, news, public knowledge base articles, contact page, and legal pages.',
            '- Search public content from the server-rendered website.',
            '- Create a public support ticket without signing in when public ticket intake is enabled.',
            '- Follow general status and maintenance information published by the service team.',
            '',
            '### Company Customer',
            '',
            '- Sign in to the customer portal and follow tickets connected to the customer account or shared through the company.',
            '- Create tickets, add customer comments, see ticket status, and participate in the support dialogue for tickets they can access.',
            '- Read customer-visible knowledge base content and operational status information.',
            '- Leave feedback on resolved or closed tickets when customer feedback is enabled.',
            '- Open company resources such as reports, computer lists, and printer lists when the company has the feature enabled and the specific user has been granted access.',
            '- Manage the company computer list when explicitly granted by an admin: add, edit, comment on, and archive computers while keeping their change history.',
            '- Read all customer-visible tickets in the company and its whole subsidiary tree, including private and closed tickets, when a super admin has granted group-wide read access. This access is read-only.',
            '- Use customer reports only when explicitly allowlisted by an admin for that company user.',
            '- Switch portal language between Swedish, English, and Norwegian and choose a personal system, light, dark, or high-contrast portal theme.',
            '',
            '### Private Customer',
            '',
            '- Register a private customer account when self-registration is enabled.',
            '- Sign in, reset password, create personal support tickets, comment on accessible tickets, and follow personal case status.',
            '- Read customer-visible knowledge base and status information.',
            '- Provide feedback on completed tickets when the feedback workflow is enabled.',
            '- Private customers are separate from company report/resource access, which is controlled per company user.',
            '',
            '### Technician',
            '',
            '- Work from a technician overview built around assigned tickets, team tickets, queue health, recent activity, and notifications, with SLA cards and controls shown only when SLA is enabled and actively used.',
            '- Open separate personal queues for tickets owned as the primary technician and tickets assigned as a supporting technician, each with a direct sidebar link and count.',
            '- Hide the team\'s latest tickets on the dashboard and limit the Overview and Tickets menu counts to tickets assigned to them.',
            '- Create tickets, take over tickets, assign work, update status, priority, impact, request type, routing, optional SLA fields, checklist progress, and internal work notes.',
            '- Reply to customers, add internal comments, use ticket attachments when enabled, and follow links from technician notification emails back to the related ticket.',
            '- See an intake panel with sender, receiving mailbox, mail linking reason, and attachment warnings, get duplicate suggestions limited to tickets they can already read, and see the planned email recipients before replying.',
            '- Read EML and Outlook MSG attachments including nested emails, preview PDFs, view pasted inline images, download files extracted from `winmail.dat`, and create a separate linked ticket from an attached email.',
            '- See all tickets or only permitted tickets depending on the technician access setting.',
            '- Use knowledge base and news contribution workflows when enabled.',
            '- Report bugs, improvements or feature requests, and missing customers to super administrators from the technician menu.',
            '- Use technician inventory views, dashboard panels, secure login/MFA with configurable trusted devices (14 days by default), personal default language, and selectable portal theme templates, including the burgundy Bordeaux theme.',
            '',
            '### Ticket Coordinator',
            '',
            '- Use a coordinator overview for unassigned work, stale tickets, waiting customer cases, workload, and triage signals, with SLA signals shown only when SLA is in use.',
            '- Distribute tickets to technicians or teams, follow company and queue health, add comments, and keep cases moving without needing full admin access.',
            '- Be responsible for tickets and choose to take over when writing customer-visible comments; internal notes keep the current assignee.',
            '- Use the same intake panel, email reader, attachment recovery, and duplicate suggestions as technicians, and review a summary before approving incoming mail reviews.',
            '- Change ticket priority without changing status, resolution, assignments, or the SLA policy.',
            '- Close active and resolved tickets with a required resolution, including unassigned tickets. Administrative closing sends no customer email; the saved resolution remains visible, and merged source tickets stay read-only.',
            '- Open clearer coordinator and customer reports by company and period for inflow, backlog, status, priority, impact, request type, escalation, risk, ticket aging, and SLA only when applicable.',
            '- Follow an expanded coordinator guide for assignment, priority changes, tickets in progress, closing, comment visibility, reopening, and reporting, and submit internal reports from the same portal.',
            '- View company data plus computer and printer inventory when data exists and access is available.',
            '- Save a personal default language so the coordinator portal opens in the preferred language on the next login.',
            '',
            '### Admin',
            '',
            '- Manage regular operational administration: tickets, companies, users that are not privileged beyond their permission level, teams, categories, routing rules, intake templates, SLA policies, and support settings.',
            '- Configure customer portal features, company hierarchy visibility, ticket attachments, feedback, monthly company reports, MFA policy, public ticket intake, and customer self-registration.',
            '- Choose which customer users may read or manage each company computer list, and configure triage recipients for forwarded original emails when attachments fail.',
            '- Manage public content such as homepage settings, contact information, news, status messaging, knowledge base settings, translation languages, selectable language settings, UI translation overrides, privacy policy, terms, and cookie policy.',
            '- Manage mail servers, support inboxes, outgoing mail profiles, incoming mail review, correction drafts, and mailbox-based ticket creation.',
            '- Use admin reports for ticket inflow, backlog, SLA health, risk, companies, and internal workload.',
            '- Review application logs and notification logs, with super-admin-only controls hidden where appropriate.',
            '',
            '### Super Admin',
            '',
            '- Has full system and operational access, including all admin and technician capabilities.',
            '- Create or assign privileged profiles such as super admin, admin, and ticket coordinator.',
            '- Create multiple company customer accounts in one operation, with automatic secure temporary passwords and forced password changes at first sign-in.',
            '- Grant selected customer users on a parent company audit-logged, read-only access to all customer-visible tickets in the whole subsidiary tree.',
            '- Review internal reports from technicians and ticket coordinators, update their status, and leave reporter-visible feedback.',
            '- Reset or disable MFA for locked-out users without exposing their MFA secret or enrollment QR code; recovery actions are audit logged.',
            '- Manage destructive or infrastructure-sensitive actions such as database backup/download/restore/optimize, migration execution, code update staging/application, post-update tasks, job retry/purge, log export/cleanup, test ticket purge, branding, support branding, and declarative addon lifecycle.',
            '- Configure global maintenance mode, timezone, default language, selectable languages, optional seasonal appearance for the public homepage and customer portal, system status monitor settings, public ticket form controls, privileged mail tests, knowledge base controls, declarative addon panels, native feature switches, and secure update flows.',
            '',
            '### System and Automation',
            '',
            '- Poll support mailboxes or process mail spool input and create tickets or draft reviews from incoming messages.',
            '- Run due operational tasks for mail polling, SLA checks, monthly reports, customer feedback reminders, attachment archiving, database jobs, and post-update steps.',
            '- Provide a read-only token-based ticket API for controlled exports.',
            '- Build and apply cumulative install/upgrade packages with vendor dependencies included, release metadata, and checksum verification.',
            '',
            '## Packages',
            '',
            '- Current exported release: `'.$installPackage['version'].'`.',
            '- Fresh installation package: `'.$installPackage['relativePath'].'`',
            '- Newest cumulative upgrade package: `'.$upgradePackages[0]['relativePath'].'`',
            '- Older upgrade packages are kept as fallback and history, up to the latest '.self::UPGRADE_PACKAGE_LIMIT.' upgrade builds available during export.',
            '- SHA-256 checksum files are generated beside every package.',
            '- Public README assets exported here: '.\count($assets).'.',
            '',
            ...$this->buildLatestReleaseNotesSection($installPackage['version']),
            '## What This Repository Contains',
            '',
            '- `packages/`: install and upgrade zip files.',
            '- `packages/*.sha256`: checksum files for package verification.',
            '- `assets/`: logo and screenshots used by this README.',
            '- [Custom addons](docs/addons.md), [JSON schema](docs/addon.schema.json), [example](docs/examples/addon.json) and [2.0.1 upgrade](docs/upgrade_to_2_0_1.md).',
            '- `PUBLIC_EXPORT_MANIFEST.md`: export summary with package versions and checksums.',
            '',
            '## Current Runtime Requirements',
            '',
            '- PHP `~8.4.27 || ~8.5.12`: 8.4.27 or later within 8.4, or 8.5.12 or later within 8.5. PHP 8.5.11 does not meet these requirements.',
            '- PHP extensions: `ctype`, `curl`, `fileinfo`, `gd` (JPEG/PNG/FreeType), `iconv`, `intl`, `mbstring`, `openssl`, `pdo`, `pdo_mysql`, `xml`, and `zip`; `opcache` is recommended.',
            '- MariaDB 10.11 or later, Composer 2 for deployment and platform checks, and a web server with its document root set to `htdocs/`.',
            '- Production must use `APP_ENV=prod` and `APP_DEBUG=0`. The archives contain production `vendor/` dependencies without development bundles or PHPUnit.',
            '',
            'The PHP patch levels above fix CVE-2026-109618 and CVE-2026-109619; see the [official PHP security advisory](https://www.php.net/archive/2026.php#2026-10-21-5). Composer and application ZIP updates do not replace the PHP engine. Maintenance mode does not protect against PHP engine vulnerabilities that can be triggered before application code runs. Stop or isolate public web access while patching an unverified PHP runtime.',
            '',
            'Check the actual server and its installed PHP packages before changing them. The packaged `docs/installation_and_deployment.md` explains package inventory, candidate versions, simulated updates, and PHP verification. Update and verify the PHP engine before applying an application or vendor update.',
            '',
            'Run these checks in the application environment, using the PHP CLI binary selected for that installation:',
            '',
            '```bash',
            'php -v',
            'php --ini',
            'php -m',
            'composer check-platform-reqs --no-dev',
            '```',
            '',
            'Compare the reported version against the required PHP series even before applying the new ZIP: the existing installation may have weaker Composer requirements, and a successful autoload alone does not enforce the separate 8.5 minimum. Verify the actual web PHP version and SAPI through a protected request as well; CLI and PHP-FPM or Apache/mod_php may use different versions. Do not publish a `phpinfo()` page.',
            '',
            'Restart the PHP-FPM service used by the site, or restart Apache for mod_php, after updating the engine. Restart long-running PHP workers too, and check `PHP_CLI_BINARY` plus the PHP paths used by cron and systemd. Clear and warm the production cache and complete the restart requirements recorded in the release metadata after applying new application code.',
            '',
            '## Fresh installation',
            '',
            'Use the install package for a new server, NAS, or clean application directory.',
            '',
            '1. Download the latest `driftpunkt-install-*.zip` file and its matching `.sha256` file from `packages/`.',
            '2. Verify the package before unpacking it:',
            '',
            '```bash',
            'cd packages',
            'sha256sum -c '.$installPackage['filename'].'.sha256',
            '```',
            '',
            '3. Create a clean application directory on the target server or NAS.',
            '4. Unpack the zip file into that directory.',
            '5. Point the web server document root to the unpacked application directory\'s `htdocs/` folder. On shared hosting where the fixed public directory is already named `/htdocs`, unpack the whole package there and keep the package root `.htaccess` enabled.',
            '6. Configure the environment file for your deployment. Start from the example files included inside the package and set `APP_ENV=prod`, `APP_DEBUG=0`, real secrets, database credentials, mail settings, and domain-specific values.',
            '7. Start the database and web runtime for your deployment model.',
            '8. Run the installer from the unpacked application directory:',
            '',
            '```bash',
            'php bin/console app:install:fresh --env=prod',
            '```',
            '',
            '9. Create the first super administrator. The command prompts for and confirms the password without echoing it:',
            '',
            '```bash',
            'php bin/console app:create-admin admin@example.com --first-name=First --last-name=Last --type=super_admin --env=prod',
            '```',
            '',
            '10. Sign in and open **Settings → Access → MFA policy**. Create or import the MFA encryption key, choose MFA availability, optionally choose required roles, and select the trusted-device period. No role is forced to use MFA automatically.',
            '',
            '## Install on a new Debian server',
            '',
            'This flow installs Driftpunkt without Docker on a clean Debian server. Replace `driftpunkt.example.com`, passwords, and mail settings before production use.',
            '',
            '1. Install the tools needed to unpack the release package:',
            '',
            '```bash',
            'sudo apt-get update',
            'sudo apt-get install -y unzip',
            '```',
            '',
            '2. Download or copy `'.$installPackage['filename'].'` and `'.$installPackage['filename'].'.sha256` to the server, then verify the package:',
            '',
            '```bash',
            'sha256sum -c '.$installPackage['filename'].'.sha256',
            '```',
            '',
            '3. Unpack the release into `/var/www/driftpunkt`:',
            '',
            '```bash',
            'rm -rf /tmp/driftpunkt-install',
            'mkdir -p /tmp/driftpunkt-install',
            'unzip '.$installPackage['filename'].' -d /tmp/driftpunkt-install',
            'sudo mkdir -p /var/www/driftpunkt',
            'sudo cp -a /tmp/driftpunkt-install/'.$installArchiveRoot.'/. /var/www/driftpunkt/',
            'cd /var/www/driftpunkt',
            '```',
            '',
            '4. Run the Debian setup script. It installs Apache, PHP packages, MariaDB, Composer, logrotate, and Driftpunkt systemd timers:',
            '',
            '```bash',
            'DOMAIN=driftpunkt.example.com sudo -E bash deploy/debian/setup.sh',
            '```',
            '',
            '5. Edit `/var/www/driftpunkt/.env.local`, keep `APP_ENV=prod` and `APP_DEBUG=0`, and set real values for `APP_SECRET`, `DEFAULT_URI`, `DATABASE_URL`, `MAILER_DSN`, and `MAILER_FROM`:',
            '',
            '```bash',
            'sudo nano /var/www/driftpunkt/.env.local',
            '```',
            '',
            '6. Create the MariaDB database and user. Use the same password in `DATABASE_URL`:',
            '',
            '```bash',
            'sudo mariadb',
            '```',
            '',
            '```sql',
            'CREATE DATABASE driftpunkt CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;',
            "CREATE USER 'driftpunkt'@'localhost' IDENTIFIED BY 'change-this-database-password';",
            "GRANT ALL PRIVILEGES ON driftpunkt.* TO 'driftpunkt'@'localhost';",
            'FLUSH PRIVILEGES;',
            'EXIT;',
            '```',
            '',
            '7. Initialize Driftpunkt:',
            '',
            '```bash',
            'sudo -u www-data php /var/www/driftpunkt/bin/console app:install:fresh --env=prod',
            'sudo -u www-data php /var/www/driftpunkt/bin/console app:create-admin admin@example.com --first-name=First --last-name=Last --type=super_admin --env=prod',
            '```',
            '',
            '8. Confirm that Apache serves `/var/www/driftpunkt/htdocs`, then reload Apache and add HTTPS, for example with Certbot:',
            '',
            '```bash',
            'sudo apache2ctl configtest',
            'sudo systemctl reload apache2',
            'sudo apt-get install -y certbot python3-certbot-apache',
            'sudo certbot --apache -d driftpunkt.example.com',
            '```',
            '',
            '9. After the database, first account, backups, and application access have been verified, enable the external background timers:',
            '',
            '```bash',
            'sudo systemctl enable --now driftpunkt-mail-poll.timer driftpunkt-attachment-archive.timer',
            "systemctl list-timers 'driftpunkt-*' --all --no-pager",
            '```',
            '',
            'Attachment ZIP archiving is configured under **Administration → Settings → Tickets → Ticket attachments**. A retention value of `0` archives local attachments as soon as a ticket is resolved or closed. Choose a higher value when recently closed tickets should keep separate files for a grace period. If the installation uses a custom Unix account, application path, or PHP binary, update `driftpunkt-attachment-archive.service` accordingly before enabling it.',
            '',
            '## Install on a new NAS with Docker Compose',
            '',
            'This flow uses the Docker Compose stack included inside the install package. Adjust `/volume1/docker/driftpunkt` to the application path used by your NAS.',
            '',
            '1. Copy `'.$installPackage['filename'].'` and `'.$installPackage['filename'].'.sha256` to the NAS, then verify the package:',
            '',
            '```bash',
            'sha256sum -c '.$installPackage['filename'].'.sha256',
            '```',
            '',
            '2. Unpack the release into a persistent NAS folder:',
            '',
            '```bash',
            'rm -rf /tmp/driftpunkt-install',
            'mkdir -p /tmp/driftpunkt-install /volume1/docker/driftpunkt',
            'unzip '.$installPackage['filename'].' -d /tmp/driftpunkt-install',
            'cp -a /tmp/driftpunkt-install/'.$installArchiveRoot.'/. /volume1/docker/driftpunkt/',
            'cd /volume1/docker/driftpunkt',
            '```',
            '',
            '3. Create and edit the NAS environment file:',
            '',
            '```bash',
            'cp deploy/nas/.env.example deploy/nas/.env',
            'nano deploy/nas/.env',
            '```',
            '',
            'Keep `APP_ENV=prod` and `APP_DEBUG=0`, and set real values for `APP_SECRET`, `DEFAULT_URI`, `MARIADB_PASSWORD`, `MARIADB_ROOT_PASSWORD`, `DATABASE_URL`, `MAILER_DSN`, and `MAILER_FROM`. After signing in, configure the internal-report recipient and reply mailbox in the super-admin cockpit.',
            '',
            '4. Create persistent data folders and start the stack:',
            '',
            '```bash',
            'mkdir -p deploy/nas/data/var deploy/nas/data/mariadb',
            'docker compose -f deploy/nas/compose.yaml --env-file deploy/nas/.env build --pull app &&',
            '  docker compose -f deploy/nas/compose.yaml --env-file deploy/nas/.env up -d --force-recreate app scheduler',
            '```',
            '',
            'Stop if the build fails. If the official multiarchitecture base image manifest is unavailable, follow the explicit AMD64-only `PHP_BASE_IMAGE` option in `docs/installation_and_deployment.md` inside the package, after checking the Docker server architecture. Do not substitute an older PHP tag or an old cached application image.',
            '',
            '5. Initialize Driftpunkt inside the app container:',
            '',
            '```bash',
            'docker compose -f deploy/nas/compose.yaml --env-file deploy/nas/.env exec --user www-data app php bin/console app:install:fresh --env=prod',
            'docker compose -f deploy/nas/compose.yaml --env-file deploy/nas/.env exec --user www-data app php bin/console app:create-admin admin@example.com --first-name=First --last-name=Last --type=super_admin --env=prod',
            '```',
            '',
            '6. Open the URL from `DEFAULT_URI`, sign in, configure the MFA policy without enabling mandatory MFA unless explicitly wanted, and confirm that the app and scheduler containers are healthy:',
            '',
            '```bash',
            'docker compose -f deploy/nas/compose.yaml --env-file deploy/nas/.env ps',
            'docker compose -f deploy/nas/compose.yaml --env-file deploy/nas/.env logs -f app scheduler',
            '```',
            '',
            '## Automatic Customer Registration and Company Groups',
            '',
            'As super administrator, edit an inbox, link an active company, allow unknown senders, and enable automatic customer registration. Configure exact sender domains on the inbox or email domains on the company and its subsidiaries under Administration → Companies, for example `company.example`. Enter subdomains separately; do not use `@` or wildcards.',
            '',
            'A sender domain matching an active company in the inbox company branch creates the new contact on that company and a private ticket. Company domains take precedence over the inbox domain list. If only the inbox domain list matches, the inbox company is used. Existing contacts and aliases in the same branch are reused without moving contacts between companies.',
            '',
            'Company domains can also route review drafts to the correct subsidiary when automatic registration is disabled. Drafts requiring review notify the configured triage recipients and link to the Unknown tickets queue. If an inbox rejects unknown senders, their messages are rejected even when they contain a reply or ticket reference.',
            '',
            'To retain the previous workflow for a company group:',
            '',
            '1. Sign in as super administrator and open Administration → Companies.',
            '2. Open the parent company, enable **Behåll tidigare mejlhantering** (keep previous mail handling), and save the mail settings.',
            '3. The exception applies to the parent and all descendants at every level, even when their inbox automation is enabled.',
            '',
            'A child cannot override an inherited exception. The company and inbox views show its source. Removing an exception restores saved inbox settings unless another ancestor still has an exception. Existing contacts, tickets, and review drafts remain unchanged.',
            '',
            'Automatically registered contacts receive no portal invitation. Login, login links, existing portal sessions, and password reset are blocked until an administrator enables **Portalåtkomst** (portal access) in the user form. Domain matching is a company-routing rule, not identity verification.',
            '',
            'Enable this first on a test inbox. For multiple application servers, configure a shared `LOCK_DSN`; with default file locking, web and scheduler must share `var/lock`. The archives include `docs/automatic-mail-customer-registration.md` with setup, migration, and troubleshooting instructions.',
            '',
            '## Recovering from the 1.0.120 Cache Error',
            '',
            'If migrations succeeded but the apply log reports `Refresh prod-cache` and `Directory not empty`, run this inside the PHP container as the application user. It clears and warms the production cache:',
            '',
            '```bash',
            'cd /var/www/html',
            'php bin/console cache:clear --env=prod --no-debug --no-interaction',
            '```',
            '',
            'On a regular server, use the actual application directory. Expect an `[OK]` result, then check login, ticket views, and mail processing. Manual recovery does not rewrite a historical failed apply log.',
            '',
            'Version 1.0.121 uses this command in required and manual post-update tasks. An apply process started with older code may still run the old cache step once; if that happens, repeat the recovery command. There is no new migration beyond 1.0.120, and a completed migration is not repeated.',
            '',
            '## Upgrade an existing installation',
            '',
            '1. Use the newest cumulative `driftpunkt-upgrade-*.zip` package first. It contains the full current codebase and is the normal path even when the installed site is several releases behind.',
            '2. Back up the database and application files before applying the upgrade.',
            '   Preserve `.env.local` and its `APP_SECRET` in an encrypted, restore-tested backup. The secret is required to unwrap the stored MFA encryption key. Include `var/share`, `var/ticket_attachments`, `var/ticket_attachment_archives`, `var/incoming_mail_attachments`, and uploaded branding in `htdocs/assets/branding`, plus external storage paths if configured.',
            '3. Verify the checksum before using the package:',
            '',
            '```bash',
            'cd packages',
            'sha256sum -c driftpunkt-upgrade-<version>.zip.sha256',
            '```',
            '',
            '4. Update and verify the PHP engine for both web and background jobs before applying the ZIP. Keep `APP_ENV=prod` and `APP_DEBUG=0`, then apply the package through the Driftpunkt admin update flow when available, or unpack it according to your deployment procedure. Preserve the existing environment and `APP_SECRET`; do not run `composer update` on the server.',
            '5. Confirm that the web server document root points to `htdocs/`, or that the package root `.htaccess` is active when the whole package lives in a fixed `/htdocs` directory.',
            '6. Run database migrations, cache refresh, service reloads, and any other post-update steps listed in the package metadata and release notes.',
            '7. For version 1.0.21 or later, also verify Admin -> Identity links to the dedicated company page and Admin -> Companies paginates company groups correctly.',
            '8. Older upgrade packages are kept as fallback and history, not as required intermediate steps.',
            '9. Verify login, ticket creation, customer/technician portals, status page, and background jobs before leaving maintenance mode.',
            '10. Verify `systemctl --failed`, mail polling, and the attachment-archive service log after its first scheduled run.',
            '',
            '### Upgrading from 1.0.132 to 1.0.133',
            '',
            '- Back up the database, application files, private environment, runtime files, and uploaded branding. Keep the existing `APP_SECRET` and use a maintenance window.',
            '- Verify SHA-256 and apply `driftpunkt-upgrade-1.0.133.zip` through the normal update flow. Production dependencies are included. Do not run `composer update`.',
            '- Apply `Version20261105120000`, `Version20261105130000`, and `Version20261105140000`, refresh the production cache, and reload PHP/OPcache and workers. The supported PHP versions remain 8.4.27+ within 8.4 or 8.5.12+ within 8.5, on a 64-bit runtime.',
            '- Confirm version 1.0.133, a completed update job, all pending migrations applied, working customer and staff sign-in, subsidiary access boundaries, inventory permissions, attachment previews, and incoming and outgoing email. Verify real Outlook mail and SMTP in the target environment.',
            '',
            '### Upgrading from 1.0.131 to 1.0.132',
            '',
            '- Back up the database, application, private environment, runtime files, and uploaded branding before the maintenance window. Keep the existing `APP_SECRET`.',
            '- Verify the matching SHA-256 file and use the normal admin update flow with `driftpunkt-upgrade-1.0.132.zip`. The PHP requirements from 1.0.128 are unchanged. No database migration is required.',
            '- Confirm version 1.0.132 and a completed update job, then sign in as a customer, choose another language in the top bar, and confirm that the customer pages use it and that the choice remains after signing in again.',
            '',
            '### Upgrading from 1.0.130 to 1.0.131',
            '',
            '- Back up the database, application, private environment, runtime files, and uploaded branding before the maintenance window. Keep the existing `APP_SECRET`.',
            '- Verify the matching SHA-256 file and use the normal admin update flow with `driftpunkt-upgrade-1.0.131.zip`. The PHP requirements from 1.0.128 are unchanged; keep `APP_ENV=prod` and `APP_DEBUG=0` and do not run `composer update`.',
            '- This release includes the database migration `Version20261030120000`, which adds the nullable column `tickets.contact_phone`. Let the normal update flow complete all post-update steps, apply the migration, and refresh the production cache, then restart PHP/OPcache.',
            '- Confirm version 1.0.131 and a completed update job, then create a customer ticket with a phone number and confirm that it appears as a phone link for the technician. Confirm that a critical ticket is marked in the technician and coordinator lists.',
            '',
            '### Upgrading from 1.0.128 or 1.0.129 to 1.0.130',
            '',
            '- Back up the database, application, private environment, runtime files, and uploaded branding before the maintenance window. Keep the existing `APP_SECRET`.',
            '- Verify the matching SHA-256 file and use the normal admin update flow with `driftpunkt-upgrade-1.0.130.zip`. The package is cumulative and can be applied directly to 1.0.128. The PHP requirements from 1.0.128 are unchanged; keep `APP_ENV=prod` and `APP_DEBUG=0` and do not run `composer update`.',
            '- No new database migration is required from 1.0.128 or 1.0.129. Let the normal update flow complete all post-update steps and refresh the production cache, then restart PHP/OPcache. Upgrades from older versions must still apply their migrations.',
            '- Confirm version 1.0.130 and a completed update job, then open the company ticket view as a customer, select a company, and export the filtered list as CSV. Send a customer reply with the ticket reference and confirm that it is added to the existing ticket.',
            '',
            '### Upgrading from 1.0.128 to 1.0.129',
            '',
            '- Back up the database, application, private environment, runtime files, and uploaded branding before the maintenance window. Keep the existing `APP_SECRET`.',
            '- Verify the matching SHA-256 file and use the normal admin update flow with `driftpunkt-upgrade-1.0.129.zip`. The PHP requirements from 1.0.128 are unchanged; keep `APP_ENV=prod` and `APP_DEBUG=0` and do not run `composer update`.',
            '- No new database migration is required from 1.0.128. Let the normal update flow complete all post-update steps and refresh the production cache, then restart PHP/OPcache. Upgrades from older versions must still apply their migrations.',
            '- Confirm version 1.0.129 and a completed update job, then attach several files to a test comment and confirm that a ZIP file over 1 MB is rejected.',
            '',
            '### Upgrading from 1.0.127 to 1.0.128',
            '',
            '- Back up the database, application, private environment, runtime files, and uploaded branding before the maintenance window. Keep the existing `APP_SECRET`.',
            '- Update and verify PHP before applying `driftpunkt-upgrade-1.0.128.zip`: PHP 8.4 requires at least 8.4.27 and PHP 8.5 requires at least 8.5.12. Verify web PHP separately from CLI, restart FPM or Apache/mod_php and long-running workers, and check cron/systemd plus `PHP_CLI_BINARY`.',
            '- Verify the matching SHA-256 file and use the normal admin update flow. The ZIP includes production vendor dependencies; keep `APP_ENV=prod` and `APP_DEBUG=0`, preserve the existing environment, and do not run `composer update`.',
            '- No new database migration is required from 1.0.127. Let the normal update flow complete all post-update steps and refresh the production cache, then restart PHP/OPcache and long-running workers. Upgrades from older versions must still apply their existing migrations.',
            '- Confirm version 1.0.128 and a completed update job, then verify login/MFA, tickets, attachments, translated pages and icons, mail processing, and scheduled jobs. Review application and web-server logs before ending maintenance mode and restoring public access.',
            '- If application rollback is needed, retain the patched PHP engine. Do not restore a vulnerable PHP image or replace the installation secret.',
            '',
            'For Docker/NAS, rebuild from the 1.0.133 release source and recreate both services; applying an application ZIP does not update the container runtime. This causes a short interruption:',
            '',
            '```bash',
            'docker compose -f deploy/nas/compose.yaml --env-file deploy/nas/.env build --pull app &&',
            '  docker compose -f deploy/nas/compose.yaml --env-file deploy/nas/.env up -d --force-recreate app scheduler',
            'docker compose -f deploy/nas/compose.yaml --env-file deploy/nas/.env exec -T app php -v',
            'docker compose -f deploy/nas/compose.yaml --env-file deploy/nas/.env exec -T scheduler php -v',
            'docker compose -f deploy/nas/compose.yaml --env-file deploy/nas/.env exec -T app composer check-platform-reqs --no-dev',
            'docker compose -f deploy/nas/compose.yaml --env-file deploy/nas/.env ps',
            '```',
            '',
            'Abort if the build or PHP checks fail. Preserve database/runtime volumes and the environment file. Follow the packaged `docs/installation_and_deployment.md` for actual web-PHP verification and the explicit AMD64-only base-image option if the multiarchitecture manifest is unavailable; use a patched image for the actual server architecture.',
            '',
            '### Upgrading from 1.0.126 to 1.0.127',
            '',
            '- Use the latest `driftpunkt-upgrade-1.0.127.zip` and its matching checksum.',
            '- No new database migration is required from 1.0.126. Let the normal update flow complete its post-update steps, refresh the production cache, then reload PHP/OPcache.',
            '- Sign in as a ticket coordinator, change a ticket priority, and confirm that status and assignments remain unchanged.',
            '- Close an active or resolved ticket with a resolution. Confirm status Closed, the saved resolution, the closing time, and the audit entry. Administrative closing sends no customer email.',
            '- Confirm that merged source tickets remain read-only and that reopening a closed ticket still requires an internal reason.',
            '',
            '### Upgrading from 1.0.125 to 1.0.126',
            '',
            '- Use the latest `driftpunkt-upgrade-1.0.126.zip` and its matching checksum.',
            '- Migration `Version20261008120000` is required. It adds `original_body`, `raw_message_path` and `automatic_kind` to `incoming_mails`; let the update flow run migrations and refresh the production cache, then reload PHP/OPcache.',
            '- Raw messages are stored under `var/incoming_mail_attachments/<id>/original.eml`. Include that directory in file backups.',
            '- Verify the displayed version, a forwarded message keeping its forwarded content, the original email view and `.eml` download, and that an out-of-office reply is logged as ignored without creating a ticket.',
            '',
            '### Upgrading from 1.0.124 to 1.0.125',
            '',
            '- Use the latest `driftpunkt-upgrade-1.0.125.zip` and its matching checksum.',
            '- Migration `Version20261001120000` is required. It adds `companies.email_domains`; let the update flow run migrations and refresh the production cache, then reload PHP/OPcache.',
            '- Verify the displayed version, a completed update job, company-domain routing, and customer access to customer-visible attachments.',
            '- Send a test message from an unknown sender to an inbox requiring review. Confirm that the triage notification arrives through the production mail server and opens the correct draft after coordinator login.',
            '- Existing drafts are not notified retroactively, and failed notifications are not retried automatically. Check `unknown_sender_review_created` in the notification log when delivery is missing.',
            '',
            '### Interrupted 1.0.45 Migration',
            '',
            'Version `1.0.46` and later fix the 1.0.45 customer report migration error `Call to undefined method Doctrine\DBAL\Schema\Table::changeColumn()`. If an upgrade stopped on that error, apply the latest `driftpunkt-upgrade-<version>.zip` and rerun the migration step after the fixed files are in place:',
            '',
            '```bash',
            'php bin/console doctrine:migrations:migrate --no-interaction --allow-no-migration --all-or-nothing --env=prod',
            '```',
            '',
            'The failed 1.0.45 run stops before Doctrine records the migration as completed, so the patched 1.0.46 migration can normally run again without manual database edits. Always confirm that a fresh database backup exists before resuming an interrupted production upgrade.',
            '',
            '## Available upgrade packages',
            '',
        ];

        foreach ($upgradePackages as $package) {
            $lines[] = '- `'.$package['relativePath'].'`';
        }

        $lines[] = '';
        $lines[] = '## Notes';
        $lines[] = '';
        $lines[] = '- Keep private `.env`, backup, database dump, and customer files outside this repository.';
        $lines[] = '- Driftpunkt release packages prefer `htdocs/` as document root. If the full package must live directly in a fixed `/htdocs` web root, verify that `.htaccess` blocks `config/`, `src/`, `vendor/`, and `var/` before production use.';
        $lines[] = '- Review `PUBLIC_EXPORT_MANIFEST.md` after every export before committing to the public repository.';
        $lines[] = '- If checksum verification fails, do not install the package. Rebuild and export the release from the private repository.';
        $lines[] = '';
        $lines[] = '## GitHub Releases';
        $lines[] = '';
        $lines[] = 'Maintainers can run Actions → Prepare GitHub Release after exporting and pushing this repository. Enter the exported version, such as `1.0.133`.';
        $lines[] = 'The workflow verifies both package checksums and the release-note version, then creates a draft release with the installation package, upgrade package, checksums, and release notes. Review and publish the draft from GitHub Releases.';
        $lines[] = '';
        $lines[] = '## License';
        $lines[] = '';
        $lines[] = '- Driftpunkt is proprietary software distributed under the **Driftpunkt Free Use License 1.0**.';
        $lines[] = '- Driftpunkt is free to use for individuals, businesses, and organizations, including commercial internal operations.';
        $lines[] = '- Resale, redistribution, repackaging, and distribution of modified versions are not permitted without prior written authorization.';
        $lines[] = '- See [LICENSE.md](LICENSE.md) for the full license terms.';
        $lines[] = '';

        return implode("\n", $lines);
    }

    /**
     * @return list<string>
     */
    private function buildLatestReleaseNotesSection(string $version): array
    {
        $path = $this->projectDir.\DIRECTORY_SEPARATOR.'release-notes'.\DIRECTORY_SEPARATOR.$version.'.md';
        if (!is_file($path)) {
            return [];
        }

        $content = trim((string) file_get_contents($path));
        if ('' === $content) {
            return [];
        }

        $lines = [
            '## Latest Release Notes',
            '',
            'These notes are copied from the packaged release metadata for the current exported version.',
            '',
        ];

        foreach (preg_split('/\R/', $content) ?: [] as $line) {
            if (str_starts_with($line, '# ')) {
                $lines[] = '### '.substr($line, 2);

                continue;
            }

            if (str_starts_with($line, '## ')) {
                $lines[] = '### '.substr($line, 3);

                continue;
            }

            $lines[] = str_replace('](../docs/', '](docs/', $line);
        }

        $lines[] = '';

        return $lines;
    }

    /**
     * @param list<array{type: string, version: string, filename: string, relativePath: string, checksumPath: string, checksumSha256: string}> $packages
     * @return array{type: string, version: string, filename: string, relativePath: string, checksumPath: string, checksumSha256: string}
     */
    private function firstPackageOfType(array $packages, string $type): array
    {
        foreach ($packages as $package) {
            if ($type === $package['type']) {
                return $package;
            }
        }

        throw new \RuntimeException(sprintf('Kunde inte hitta %s-paket i publik export.', $type));
    }

    /**
     * @param list<array{type: string, version: string, filename: string, relativePath: string, checksumPath: string, checksumSha256: string}> $packages
     * @param list<string> $assets
     * @param list<string> $skippedPaths
     */
    private function buildManifest(array $packages, array $assets, array $skippedPaths): string
    {
        $lines = [
            '# Public Export Manifest',
            '',
            'Created: '.(new \DateTimeImmutable())->format(DATE_ATOM),
            '',
            '## Export Policy',
            '',
            '- Public exports contain release packages only.',
            '- The latest installation package is included.',
            '- The latest upgrade package is cumulative and should normally be used first.',
            '- Older upgrade packages are retained as fallback and release history.',
            '- Up to the latest '.self::UPGRADE_PACKAGE_LIMIT.' upgrade packages are included.',
            '- Selected logo and screenshot assets are included for README presentation.',
            '- License, security policy, issue templates, and the manual release workflow are copied from the development repository.',
            '- Application code and dependencies are included inside the release archives. Private Git history, live environment files, deployment secrets, runtime customer data, and internal planning documents are excluded.',
            '',
            '## Exported Packages',
            '',
            '| Type | Version | Package | SHA-256 |',
            '| --- | --- | --- | --- |',
        ];

        foreach ($packages as $package) {
            $lines[] = sprintf(
                '| %s | %s | `%s` | `%s` |',
                $package['type'],
                $package['version'],
                $package['relativePath'],
                $package['checksumSha256'],
            );
        }

        if ([] !== $assets) {
            $lines[] = '';
            $lines[] = '## Exported README Assets';
            $lines[] = '';

            foreach ($assets as $asset) {
                $lines[] = '- `'.$asset.'`';
            }
        }

        if ([] !== $skippedPaths) {
            $lines[] = '';
            $lines[] = '## Release Packages Not Exported';
            $lines[] = '';

            foreach ($skippedPaths as $skippedPath) {
                $lines[] = '- `'.$skippedPath.'`';
            }
        }

        $lines[] = '';

        return implode("\n", $lines);
    }

    private function removeDirectoryContents(string $directory): void
    {
        foreach (array_values(array_filter(
            scandir($directory) ?: [],
            static fn (string $entry): bool => !\in_array($entry, ['.', '..', '.git'], true),
        )) as $entry) {
            $path = $directory.\DIRECTORY_SEPARATOR.$entry;

            if (is_dir($path) && !is_link($path)) {
                $iterator = new \RecursiveIteratorIterator(
                    new \RecursiveDirectoryIterator($path, \FilesystemIterator::SKIP_DOTS),
                    \RecursiveIteratorIterator::CHILD_FIRST,
                );

                foreach ($iterator as $item) {
                    if ($item->isDir()) {
                        @rmdir($item->getPathname());

                        continue;
                    }

                    @unlink($item->getPathname());
                }

                @rmdir($path);

                continue;
            }

            @unlink($path);
        }
    }
}
