<?php

declare(strict_types=1);

namespace App\Module\System\Service;

use Symfony\Component\DependencyInjection\Attribute\Autowire;
use Symfony\Component\HttpFoundation\File\UploadedFile;

final class AddonPackageManager
{
    public function __construct(
        #[Autowire('%kernel.project_dir%')]
        private readonly string $projectDir,
    ) {
    }

    /**
     * @return list<array{
     *     id: string,
     *     slug: string,
     *     name: string,
     *     description: string,
     *     version: string,
     *     sourceLabel: string,
     *     installStatus: string,
     *     healthStatus: string,
     *     enabled: bool,
     *     importedAt: \DateTimeImmutable,
     *     fileCount: int,
     *     installPath: string,
     *     archivePath: string,
     *     filesRoot: string,
     *     dependencies: list<string>,
     *     environmentVariables: list<string>,
     *     setupChecklist: list<string>,
     *     impactAreas: list<string>,
     *     adminRoute: ?string,
     *     notes: ?string,
     *     verifiedAt: ?\DateTimeImmutable,
     *     isActiveVersion: bool
     * }>
     */
    public function listInstalledPackages(): array
    {
        $directory = $this->packagesDirectory();
        if (!is_dir($directory)) {
            return [];
        }

        $packages = [];
        foreach (glob($directory.\DIRECTORY_SEPARATOR.'*'.\DIRECTORY_SEPARATOR.'*'.\DIRECTORY_SEPARATOR.'package-manifest.json') ?: [] as $manifestPath) {
            $manifest = $this->readManifest($manifestPath);
            if (null === $manifest) {
                continue;
            }

            $packages[] = $manifest;
        }

        $activeVersionsBySlug = [];
        foreach ($packages as $package) {
            $slug = $package['slug'];
            if (!isset($activeVersionsBySlug[$slug])) {
                $activeVersionsBySlug[$slug] = $this->readActiveVersion($slug);
            }
        }

        $packages = array_map(function (array $package) use ($activeVersionsBySlug): array {
            $package['isActiveVersion'] = ($activeVersionsBySlug[$package['slug']] ?? null) === $package['version'];

            return $package;
        }, $packages);

        usort(
            $packages,
            static function (array $left, array $right): int {
                if ($left['slug'] === $right['slug']) {
                    return $right['importedAt']->getTimestamp() <=> $left['importedAt']->getTimestamp();
                }

                return strcmp($left['slug'], $right['slug']);
            },
        );

        return $packages;
    }

    /**
     * @return list<array{
     *     id: string,
     *     slug: string,
     *     name: string,
     *     description: string,
     *     version: string,
     *     sourceLabel: string,
     *     installStatus: string,
     *     healthStatus: string,
     *     enabled: bool,
     *     importedAt: \DateTimeImmutable,
     *     fileCount: int,
     *     installPath: string,
     *     archivePath: string,
     *     filesRoot: string,
     *     dependencies: list<string>,
     *     environmentVariables: list<string>,
     *     setupChecklist: list<string>,
     *     impactAreas: list<string>,
     *     adminRoute: ?string,
     *     notes: ?string,
     *     verifiedAt: ?\DateTimeImmutable,
     *     isActiveVersion: bool
     * }>
     */
    public function listInstalledPackagesForSlug(string $slug): array
    {
        $normalizedSlug = self::normalizeSlug($slug);

        return array_values(array_filter(
            $this->listInstalledPackages(),
            static fn (array $package): bool => $package['slug'] === $normalizedSlug,
        ));
    }

    /**
     * @return array{
     *     id: string,
     *     slug: string,
     *     name: string,
     *     description: string,
     *     version: string,
     *     sourceLabel: string,
     *     installStatus: string,
     *     healthStatus: string,
     *     enabled: bool,
     *     importedAt: \DateTimeImmutable,
     *     fileCount: int,
     *     installPath: string,
     *     archivePath: string,
     *     filesRoot: string,
     *     dependencies: list<string>,
     *     environmentVariables: list<string>,
     *     setupChecklist: list<string>,
     *     impactAreas: list<string>,
     *     adminRoute: ?string,
     *     notes: ?string,
     *     verifiedAt: ?\DateTimeImmutable,
     *     isActiveVersion: bool
     * }|null
     */
    public function findInstalledPackage(string $slug, string $version): ?array
    {
        foreach ($this->listInstalledPackagesForSlug($slug) as $package) {
            if ($package['version'] === trim($version)) {
                return $package;
            }
        }

        return null;
    }

    /**
     * @return array{
     *     id: string,
     *     slug: string,
     *     name: string,
     *     description: string,
     *     version: string,
     *     sourceLabel: string,
     *     installStatus: string,
     *     healthStatus: string,
     *     enabled: bool,
     *     importedAt: \DateTimeImmutable,
     *     fileCount: int,
     *     installPath: string,
     *     archivePath: string,
     *     filesRoot: string,
     *     dependencies: list<string>,
     *     environmentVariables: list<string>,
     *     setupChecklist: list<string>,
     *     impactAreas: list<string>,
     *     adminRoute: ?string,
     *     notes: ?string,
     *     verifiedAt: ?\DateTimeImmutable,
     *     isActiveVersion: bool
     * }
     */
    public function activateInstalledPackageVersion(string $slug, string $version): array
    {
        throw new \RuntimeException('Äldre tilläggspaket kan inte aktiveras. Inbyggda funktioner hanteras under Funktioner.');
    }

    public function deleteInstalledPackagesForSlug(string $slug): void
    {
        $normalizedSlug = self::normalizeSlug($slug);
        if ('' === $normalizedSlug) {
            throw new \RuntimeException('Tilläggets slug är ogiltig.');
        }

        $packagesDirectory = $this->packagesDirectory();
        if (!is_dir($packagesDirectory)) {
            return;
        }

        $realPackagesDirectory = realpath($packagesDirectory);
        if (false === $realPackagesDirectory) {
            throw new \RuntimeException('Kunde inte läsa tilläggslagrets sökväg.');
        }

        $slugDirectory = $packagesDirectory.\DIRECTORY_SEPARATOR.$normalizedSlug;
        if (!is_dir($slugDirectory)) {
            return;
        }

        $realSlugDirectory = realpath($slugDirectory);
        if (false === $realSlugDirectory || !str_starts_with($realSlugDirectory.\DIRECTORY_SEPARATOR, $realPackagesDirectory.\DIRECTORY_SEPARATOR)) {
            throw new \RuntimeException('Tilläggets paketkatalog ligger utanför tillåtet tilläggslager.');
        }

        $this->removeDirectory($realSlugDirectory);
    }

    public function deactivateInstalledPackagesForSlug(string $slug): void
    {
        $normalizedSlug = self::normalizeSlug($slug);
        if ('' === $normalizedSlug) {
            throw new \RuntimeException('Tilläggets slug är ogiltig.');
        }

        $packagesDirectory = $this->packagesDirectory();
        if (!is_dir($packagesDirectory)) {
            return;
        }

        $realPackagesDirectory = realpath($packagesDirectory);
        if (false === $realPackagesDirectory) {
            throw new \RuntimeException('Kunde inte läsa tilläggslagrets sökväg.');
        }

        $slugDirectory = $packagesDirectory.\DIRECTORY_SEPARATOR.$normalizedSlug;
        if (!is_dir($slugDirectory)) {
            return;
        }

        $realSlugDirectory = realpath($slugDirectory);
        if (false === $realSlugDirectory || !str_starts_with($realSlugDirectory.\DIRECTORY_SEPARATOR, $realPackagesDirectory.\DIRECTORY_SEPARATOR)) {
            throw new \RuntimeException('Tilläggets paketkatalog ligger utanför tillåtet tilläggslager.');
        }

        $deactivatedAt = (new \DateTimeImmutable())->format(DATE_ATOM);
        foreach (glob($realSlugDirectory.\DIRECTORY_SEPARATOR.'*'.\DIRECTORY_SEPARATOR.'package-manifest.json') ?: [] as $manifestPath) {
            $realManifestPath = realpath($manifestPath);
            if (false === $realManifestPath || !str_starts_with($realManifestPath, $realSlugDirectory.\DIRECTORY_SEPARATOR)) {
                continue;
            }

            try {
                /** @var array<string, mixed> $manifest */
                $manifest = json_decode((string) file_get_contents($realManifestPath), true, 512, \JSON_THROW_ON_ERROR);
            } catch (\Throwable) {
                continue;
            }
            if (!\is_array($manifest)) {
                continue;
            }

            $manifest['enabled'] = false;
            $manifest['deactivatedAt'] = $deactivatedAt;
            file_put_contents($realManifestPath, json_encode($manifest, \JSON_PRETTY_PRINT | \JSON_THROW_ON_ERROR));
        }

        @unlink($realSlugDirectory.\DIRECTORY_SEPARATOR.'active-version.json');
    }

    /**
     * @return array{
     *     id: string,
     *     slug: string,
     *     name: string,
     *     description: string,
     *     version: string,
     *     sourceLabel: string,
     *     installStatus: string,
     *     healthStatus: string,
     *     enabled: bool,
     *     importedAt: \DateTimeImmutable,
     *     fileCount: int,
     *     installPath: string,
     *     archivePath: string,
     *     filesRoot: string,
     *     dependencies: list<string>,
     *     environmentVariables: list<string>,
     *     setupChecklist: list<string>,
     *     impactAreas: list<string>,
     *     adminRoute: ?string,
     *     notes: ?string,
     *     verifiedAt: ?\DateTimeImmutable
     * }
     */
    public function installUploadedPackage(UploadedFile $uploadedFile): array
    {
        throw new \RuntimeException('Körbara tilläggspaket stöds inte. Inbyggda funktioner hanteras under Funktioner.');
    }

    private function packagesDirectory(): string
    {
        return $this->projectDir.\DIRECTORY_SEPARATOR.'var'.\DIRECTORY_SEPARATOR.'addon_packages';
    }

    private function activeVersionStatePath(string $slug): string
    {
        return $this->packagesDirectory().\DIRECTORY_SEPARATOR.self::normalizeSlug($slug).\DIRECTORY_SEPARATOR.'active-version.json';
    }

    private function readActiveVersion(string $slug): ?string
    {
        $path = $this->activeVersionStatePath($slug);
        if (!is_file($path)) {
            return null;
        }

        try {
            /** @var array<string, mixed> $data */
            $data = json_decode((string) file_get_contents($path), true, 512, \JSON_THROW_ON_ERROR);
        } catch (\Throwable) {
            return null;
        }

        $version = isset($data['version']) && is_string($data['version']) ? trim($data['version']) : '';

        return '' !== $version ? $version : null;
    }

    /**
     * @param mixed $value
     * @return list<string>
     */
    private function normalizeStringList(mixed $value): array
    {
        if (!is_array($value)) {
            return [];
        }

        return array_values(array_filter(array_map(
            static fn (mixed $item): string => is_scalar($item) ? trim((string) $item) : '',
            $value,
        ), static fn (string $item): bool => '' !== $item));
    }

    private function removeDirectory(string $directory): void
    {
        if (!is_dir($directory)) {
            return;
        }

        $iterator = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($directory, \FilesystemIterator::SKIP_DOTS),
            \RecursiveIteratorIterator::CHILD_FIRST,
        );

        foreach ($iterator as $item) {
            if ($item->isDir() && !$item->isLink()) {
                @rmdir($item->getPathname());

                continue;
            }

            @unlink($item->getPathname());
        }

        @rmdir($directory);
    }

    /**
     * @return array{
     *     id: string,
     *     slug: string,
     *     name: string,
     *     description: string,
     *     version: string,
     *     sourceLabel: string,
     *     installStatus: string,
     *     healthStatus: string,
     *     enabled: bool,
     *     importedAt: \DateTimeImmutable,
     *     fileCount: int,
     *     installPath: string,
     *     archivePath: string,
     *     filesRoot: string,
     *     dependencies: list<string>,
     *     environmentVariables: list<string>,
     *     setupChecklist: list<string>,
     *     impactAreas: list<string>,
     *     adminRoute: ?string,
     *     notes: ?string,
     *     verifiedAt: ?\DateTimeImmutable
     * }|null
     */
    private function readManifest(string $manifestPath): ?array
    {
        if (!is_file($manifestPath)) {
            return null;
        }

        try {
            /** @var array<string, mixed> $manifest */
            $manifest = json_decode((string) file_get_contents($manifestPath), true, 512, \JSON_THROW_ON_ERROR);
        } catch (\Throwable) {
            return null;
        }

        return $this->normalizeStoredManifest($manifest);
    }

    /**
     * @param array<string, mixed> $manifest
     * @return array{
     *     id: string,
     *     slug: string,
     *     name: string,
     *     description: string,
     *     version: string,
     *     sourceLabel: string,
     *     installStatus: string,
     *     healthStatus: string,
     *     enabled: bool,
     *     importedAt: \DateTimeImmutable,
     *     fileCount: int,
     *     installPath: string,
     *     archivePath: string,
     *     filesRoot: string,
     *     dependencies: list<string>,
     *     environmentVariables: list<string>,
     *     setupChecklist: list<string>,
     *     impactAreas: list<string>,
     *     adminRoute: ?string,
     *     notes: ?string,
     *     verifiedAt: ?\DateTimeImmutable
     * }
     */
    private function normalizeStoredManifest(array $manifest): array
    {
        $importedAt = isset($manifest['importedAt']) && is_string($manifest['importedAt'])
            ? new \DateTimeImmutable($manifest['importedAt'])
            : new \DateTimeImmutable();
        $verifiedAt = isset($manifest['verifiedAt']) && is_string($manifest['verifiedAt']) && '' !== $manifest['verifiedAt']
            ? new \DateTimeImmutable($manifest['verifiedAt'])
            : null;

        return [
            'id' => (string) ($manifest['id'] ?? ''),
            'slug' => (string) ($manifest['slug'] ?? ''),
            'name' => (string) ($manifest['name'] ?? 'Okänt addon'),
            'description' => (string) ($manifest['description'] ?? ''),
            'version' => (string) ($manifest['version'] ?? ''),
            'sourceLabel' => (string) ($manifest['sourceLabel'] ?? 'Zip-import'),
            'installStatus' => (string) ($manifest['installStatus'] ?? 'configuring'),
            'healthStatus' => (string) ($manifest['healthStatus'] ?? 'unknown'),
            'enabled' => (bool) ($manifest['enabled'] ?? false),
            'importedAt' => $importedAt,
            'fileCount' => (int) ($manifest['fileCount'] ?? 0),
            'installPath' => (string) ($manifest['installPath'] ?? ''),
            'archivePath' => (string) ($manifest['archivePath'] ?? ''),
            'filesRoot' => (string) ($manifest['filesRoot'] ?? ''),
            'dependencies' => $this->normalizeStringList($manifest['dependencies'] ?? []),
            'environmentVariables' => $this->normalizeStringList($manifest['environmentVariables'] ?? []),
            'setupChecklist' => $this->normalizeStringList($manifest['setupChecklist'] ?? []),
            'impactAreas' => $this->normalizeStringList($manifest['impactAreas'] ?? []),
            'adminRoute' => isset($manifest['adminRoute']) && is_string($manifest['adminRoute']) && '' !== $manifest['adminRoute']
                ? $manifest['adminRoute']
                : null,
            'notes' => isset($manifest['notes']) && is_string($manifest['notes']) && '' !== trim($manifest['notes'])
                ? trim($manifest['notes'])
                : null,
            'verifiedAt' => $verifiedAt,
            'isActiveVersion' => false,
        ];
    }

    private static function normalizeSlug(string $slug): string
    {
        $normalized = mb_strtolower(trim($slug));
        $normalized = preg_replace('/[^a-z0-9]+/', '-', $normalized) ?? '';

        return trim($normalized, '-');
    }
}
