<?php

declare(strict_types=1);

namespace App\Module\System\Service;

use Psr\Log\LoggerInterface;
use Psr\Log\NullLogger;
use Symfony\Component\Clock\ClockInterface;
use Symfony\Component\HttpClient\Exception\TransportException;
use Symfony\Component\Lock\LockFactory;
use Symfony\Contracts\HttpClient\HttpClientInterface;
use Symfony\Contracts\HttpClient\ResponseInterface;

/**
 * Fetches the latest published stable release from the official public GitHub repository
 * and maintains the server-wide snapshot used by the release notice.
 *
 * A single check holds one lock for its whole life cycle: cooldown evaluation,
 * pre-HTTP attempt persistence, the HTTP call and the result write. The last
 * successful snapshot is preserved whenever a later attempt fails.
 */
final class GitHubReleaseChecker
{
    public const RELEASES_API_URL = 'https://api.github.com/repos/K3NT4/Driftpunkt/releases/latest';
    public const RELEASE_TAG_URL_PREFIX = 'https://github.com/K3NT4/Driftpunkt/releases/tag/';
    public const AUTOMATIC_INTERVAL_SECONDS = 86400;
    public const MANUAL_COOLDOWN_SECONDS = 300;

    private const HTTP_TIMEOUT_SECONDS = 5.0;
    private const HTTP_MAX_DURATION_SECONDS = 8.0;
    private const HTTP_MAX_REDIRECTS = 0;
    private const MAX_BODY_BYTES = 2_000_000;
    private const NOTES_MAX_CHARS = 20_000;
    private const LOCK_RESOURCE = 'driftpunkt.release_notice.check';
    private const LOCK_TTL_SECONDS = 60.0;

    private const HIGHLIGHT_KEYWORDS = [
        'migration',
        'migrering',
        'databas',
        'php',
        'miljökrav',
        'säkerhet',
        'security',
        'mellansteg',
        'krävs',
        'kräver',
    ];

    private readonly LoggerInterface $logger;

    public function __construct(
        private readonly HttpClientInterface $httpClient,
        private readonly ClockInterface $clock,
        private readonly GitHubReleaseSnapshotStore $store,
        private readonly LockFactory $lockFactory,
        ?LoggerInterface $logger = null,
    ) {
        $this->logger = $logger ?? new NullLogger();
    }

    /**
     * @return array{outcome: string, message: string, releaseChanged: ?bool, retryAfterSeconds: ?int, state: array<string, mixed>}
     */
    public function checkAutomatic(): array
    {
        return $this->runCheck('automatic');
    }

    /**
     * @return array{outcome: string, message: string, releaseChanged: ?bool, retryAfterSeconds: ?int, state: array<string, mixed>}
     */
    public function checkManually(): array
    {
        return $this->runCheck('manual');
    }

    /**
     * @return array{outcome: string, message: string, releaseChanged: ?bool, retryAfterSeconds: ?int, state: array<string, mixed>}
     */
    private function runCheck(string $kind): array
    {
        $lock = $this->lockFactory->createLock(self::LOCK_RESOURCE, self::LOCK_TTL_SECONDS);
        if (!$lock->acquire(false)) {
            $state = $this->store->readState();

            return [
                'outcome' => 'busy',
                'message' => 'En versionskontroll körs redan. Ladda om sidan om en liten stund.',
                'releaseChanged' => null,
                'retryAfterSeconds' => null,
                'state' => $state,
            ];
        }

        try {
            $now = $this->clock->now();
            $state = $this->store->readState();

            $retryAfterSeconds = $this->cooldownRemaining($state, $now, $kind);
            if (null !== $retryAfterSeconds) {
                return [
                    'outcome' => 'cooldown',
                    'message' => 'Versionskontrollen har redan körts nyligen. Kontrollen kan upprepas om en stund.',
                    'releaseChanged' => null,
                    'retryAfterSeconds' => $retryAfterSeconds,
                    'state' => $state,
                ];
            }

            $previousState = $state;
            $state['status'] = 'checking';
            $state['lastAttemptAt'] = $now->format(DATE_ATOM);
            $state['lastAttemptKind'] = $kind;
            if ('manual' === $kind) {
                $state['lastManualAttemptAt'] = $now->format(DATE_ATOM);
            }
            $state['lastFailureMessage'] = null;
            $state['lastOutcomeMessage'] = null;
            $this->store->writeState($state);

            try {
                return $this->completeCheck($previousState, $state, $now);
            } catch (\Throwable $exception) {
                $this->logger->warning('Versionskontrollen mot GitHub misslyckades.', ['exception' => $exception]);

                return $this->recordFailure($state, $now, 'Versionskontrollen kunde inte slutföras just nu. Försök igen senare.');
            }
        } finally {
            $lock->release();
        }
    }

    /**
     * @param array<string, mixed> $previousState
     * @param array<string, mixed> $state
     * @return array{outcome: string, message: string, releaseChanged: ?bool, retryAfterSeconds: ?int, state: array<string, mixed>}
     */
    private function completeCheck(array $previousState, array $state, \DateTimeImmutable $now): array
    {
        $release = $this->validateStableRelease($this->fetchLatestRelease());

        $previousVersion = $this->latestVersionOf($previousState['latest'] ?? null);
        $newVersion = $this->latestVersionOf($release);
        $releaseChanged = null !== $newVersion && $newVersion !== $previousVersion;

        if (null === $release) {
            return $this->recordFailure($state, $now, 'Inga publicerade stabila releaser kunde verifieras. Tidigare information bevaras.');
        }

        $state['status'] = 'success';
        $state['lastSuccessAt'] = $now->format(DATE_ATOM);
        $state['lastFailureAt'] = null;
        $state['lastFailureMessage'] = null;
        $state['lastOutcomeMessage'] = null;
        $state['latest'] = $release;
        $this->store->writeState($state);

        return [
            'outcome' => 'success',
            'message' => 'Versionskontrollen slutfördes och den gemensamma informationen uppdaterades.',
            'releaseChanged' => $releaseChanged,
            'retryAfterSeconds' => null,
            'state' => $state,
        ];
    }

    /**
     * @param array<string, mixed> $state
     * @return array{outcome: string, message: string, releaseChanged: ?bool, retryAfterSeconds: ?int, state: array<string, mixed>}
     */
    private function recordFailure(array $state, \DateTimeImmutable $now, string $message): array
    {
        $state['status'] = 'failure';
        $state['lastFailureAt'] = $now->format(DATE_ATOM);
        $state['lastFailureMessage'] = $message;
        $state['lastOutcomeMessage'] = $message;
        $this->store->writeState($state);

        return [
            'outcome' => 'failure',
            'message' => $message,
            'releaseChanged' => null,
            'retryAfterSeconds' => null,
            'state' => $state,
        ];
    }

    /**
     * @param array<string, mixed> $state
     */
    private function cooldownRemaining(array $state, \DateTimeImmutable $now, string $kind): ?int
    {
        $lastAttempt = $this->parseDateTime($state['lastAttemptAt'] ?? null);
        $lastManual = $this->parseDateTime($state['lastManualAttemptAt'] ?? null);
        $nowTimestamp = $now->getTimestamp();

        if ('manual' === $kind) {
            $floor = $lastAttempt;
            if ($lastManual instanceof \DateTimeImmutable
                && (null === $floor || $lastManual->getTimestamp() > $floor->getTimestamp())) {
                $floor = $lastManual;
            }

            if (null === $floor) {
                return null;
            }

            $remaining = self::MANUAL_COOLDOWN_SECONDS - ($nowTimestamp - $floor->getTimestamp());

            return $remaining > 0 ? $remaining : null;
        }

        if (null === $lastAttempt) {
            return null;
        }

        $remaining = self::AUTOMATIC_INTERVAL_SECONDS - ($nowTimestamp - $lastAttempt->getTimestamp());

        return $remaining > 0 ? $remaining : null;
    }

    /**
     * @return array<string, mixed>
     */
    private function fetchLatestRelease(): array
    {
        $response = $this->httpClient->request('GET', self::RELEASES_API_URL, [
            'headers' => [
                'Accept' => 'application/vnd.github+json',
                'User-Agent' => 'Driftpunkt-ReleaseCheck',
            ],
            'timeout' => self::HTTP_TIMEOUT_SECONDS,
            'max_duration' => self::HTTP_MAX_DURATION_SECONDS,
            'max_redirects' => self::HTTP_MAX_REDIRECTS,
        ]);

        $body = $this->readBodyWithCap($response);

        if (200 !== $response->getStatusCode()) {
            throw new TransportException('GitHub svarade med oväntad status.');
        }

        /** @var mixed $release */
        $release = json_decode($body, true, 512, \JSON_THROW_ON_ERROR);
        if (!\is_array($release) || array_is_list($release)) {
            throw new TransportException('GitHub-svaret hade oväntat format.');
        }

        return $release;
    }

    private function readBodyWithCap(ResponseInterface $response): string
    {
        $body = '';
        foreach ($this->httpClient->stream($response) as $chunk) {
            if ($chunk->isTimeout()) {
                throw new TransportException('Hämtningen tog för lång tid.');
            }

            $content = $chunk->getContent();
            if (\strlen($body) + \strlen($content) > self::MAX_BODY_BYTES) {
                $response->cancel();

                throw new TransportException('Svaret från GitHub är större än den tillåtna storleken.');
            }
            $body .= $content;
        }

        return $body;
    }

    /**
     * GitHub selects the latest release; do not replace its selection with local
     * version sorting. Validate the publication and stable flags independently.
     *
     * @param array<string, mixed> $release
     * @return array<string, mixed>|null
     */
    private function validateStableRelease(array $release): ?array
    {
        if (false !== ($release['draft'] ?? null) || false !== ($release['prerelease'] ?? null)) {
            return null;
        }

        $publishedAt = $this->normalizePublishedAt($release['published_at'] ?? null);
        $tagName = $release['tag_name'] ?? null;
        if (null === $publishedAt || !\is_string($tagName)
            || 1 !== preg_match('/^[A-Za-z0-9._-]+$/', $tagName)) {
            return null;
        }

        $version = $this->normalizeVersionString($tagName);
        $body = $release['body'] ?? null;
        if (null === $version || (null !== $body && !\is_string($body))) {
            return null;
        }

        return $this->buildSnapshotRelease($tagName, $version, $publishedAt, $body);
    }

    private function normalizePublishedAt(mixed $publishedAt): ?\DateTimeImmutable
    {
        if (!\is_string($publishedAt) || '' === trim($publishedAt)) {
            return null;
        }

        try {
            return new \DateTimeImmutable(trim($publishedAt));
        } catch (\Throwable) {
            return null;
        }
    }

    private function normalizeVersionString(string $version): ?string
    {
        if (1 !== preg_match('/^v?(\d+(?:\.\d+)+)$/i', trim($version), $matches)) {
            return null;
        }

        return $matches[1];
    }

    /**
     * @param array<string, mixed> $release
     * @return array<string, mixed>
     */
    private function buildSnapshotRelease(string $tagName, string $version, \DateTimeImmutable $publishedAt, mixed $body): array
    {
        $notes = \is_string($body) ? trim($body) : '';
        $notesTruncated = mb_strlen($notes) > self::NOTES_MAX_CHARS;
        $notes = mb_substr($notes, 0, self::NOTES_MAX_CHARS);

        return [
            'releaseVersion' => $version,
            'tagName' => $tagName,
            'releaseUrl' => self::RELEASE_TAG_URL_PREFIX.rawurlencode($tagName),
            'publishedAt' => $publishedAt->format(DATE_ATOM),
            'notes' => $notes,
            'notesTruncated' => $notesTruncated,
            'highlights' => $this->extractHighlights($notes),
        ];
    }

    /**
     * @return list<string>
     */
    private function extractHighlights(string $notes): array
    {
        if ('' === $notes) {
            return [];
        }

        $highlights = [];
        foreach (preg_split('/\R/', $notes) ?: [] as $line) {
            foreach (self::HIGHLIGHT_KEYWORDS as $keyword) {
                if (false !== mb_stripos($line, $keyword)) {
                    $trimmed = trim($line);
                    if ('' !== $trimmed) {
                        $highlights[] = $trimmed;
                    }
                    break;
                }
            }

            if (\count($highlights) >= 10) {
                break;
            }
        }

        return $highlights;
    }

    private function latestVersionOf(mixed $latest): ?string
    {
        if (!\is_array($latest) || !isset($latest['releaseVersion']) || !\is_string($latest['releaseVersion'])) {
            return null;
        }

        return $latest['releaseVersion'];
    }

    private function parseDateTime(mixed $value): ?\DateTimeImmutable
    {
        if (!\is_string($value) || '' === trim($value)) {
            return null;
        }

        try {
            return new \DateTimeImmutable($value);
        } catch (\Throwable) {
            return null;
        }
    }
}
