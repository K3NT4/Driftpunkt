<?php

declare(strict_types=1);

namespace App\Module\System\Service;

use Symfony\Component\DependencyInjection\Attribute\Autowire;

/**
 * Persistent, server-wide release-check state outside the cleanable cache.
 *
 * The state file is the sole authority for release-notice cooldowns and keeps the
 * last successful snapshot even when a later check fails. Writes are atomic
 * (tmp + rename) and readers never need the check lock.
 */
final class GitHubReleaseSnapshotStore
{
    public const SCHEMA_VERSION = 1;
    private const STATE_FILENAME = 'state.json';

    public function __construct(
        #[Autowire('%kernel.project_dir%')]
        private readonly string $projectDir,
    ) {
    }

    public function statePath(): string
    {
        return $this->stateDirectory().\DIRECTORY_SEPARATOR.self::STATE_FILENAME;
    }

    /**
     * @return array<string, mixed>
     */
    public function readState(): array
    {
        $path = $this->statePath();
        if (!is_file($path)) {
            return $this->defaultState();
        }

        try {
            /** @var array<string, mixed> $state */
            $state = json_decode((string) file_get_contents($path), true, 512, \JSON_THROW_ON_ERROR);
            if (!\is_array($state)) {
                return $this->defaultState();
            }

            return array_replace($this->defaultState(), $state);
        } catch (\Throwable) {
            return $this->defaultState();
        }
    }

    /**
     * @param array<string, mixed> $state
     */
    public function writeState(array $state): void
    {
        $state['schemaVersion'] = self::SCHEMA_VERSION;
        $encodedState = json_encode($state, \JSON_PRETTY_PRINT | \JSON_THROW_ON_ERROR);
        $statePath = $this->statePath();
        $this->ensureDirectory();
        $temporaryPath = $statePath.'.tmp';

        if (false === file_put_contents($temporaryPath, $encodedState)) {
            throw new \RuntimeException('Kunde inte skriva statusfilen för versionsaviseringen.');
        }

        if (!rename($temporaryPath, $statePath)) {
            @unlink($temporaryPath);

            throw new \RuntimeException('Kunde inte aktivera den nya statusfilen för versionsaviseringen.');
        }
    }

    /**
     * @return array<string, mixed>
     */
    public function defaultState(): array
    {
        return [
            'schemaVersion' => self::SCHEMA_VERSION,
            'status' => 'idle',
            'lastAttemptAt' => null,
            'lastAttemptKind' => null,
            'lastManualAttemptAt' => null,
            'lastSuccessAt' => null,
            'lastFailureAt' => null,
            'lastFailureMessage' => null,
            'lastOutcomeMessage' => null,
            'latest' => null,
        ];
    }

    private function stateDirectory(): string
    {
        $directory = $this->projectDir.\DIRECTORY_SEPARATOR
            .'var'.\DIRECTORY_SEPARATOR.'version_check';
        return $directory;
    }

    private function ensureDirectory(): void
    {
        $directory = $this->stateDirectory();
        if (!is_dir($directory) && !mkdir($directory, 0775, true) && !is_dir($directory)) {
            throw new \RuntimeException('Kunde inte skapa mappen för versionsaviseringens status.');
        }
    }
}
