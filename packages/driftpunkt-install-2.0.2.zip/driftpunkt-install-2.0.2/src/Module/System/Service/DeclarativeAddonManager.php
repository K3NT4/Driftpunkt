<?php

declare(strict_types=1);

namespace App\Module\System\Service;

use App\Module\System\Exception\AddonProblem;
use App\Module\System\Exception\AddonStorageException;
use App\Module\System\Exception\AddonValidationException;
use Psr\Log\LoggerInterface;
use Symfony\Component\DependencyInjection\Attribute\Autowire;

/** Stores data-only addons. No uploaded file is executed, included or fetched. */
final class DeclarativeAddonManager
{
    public const MAX_BYTES = 32768;
    public const PLACEMENTS = ['homepage', 'customer_dashboard', 'technician_dashboard'];

    public function __construct(
        #[Autowire('%kernel.project_dir%')]
        private readonly string $projectDir,
        private readonly ?LoggerInterface $logger = null,
    ) {
    }

    public function validate(string $json): array
    {
        if (\strlen($json) > self::MAX_BYTES) {
            throw new AddonValidationException('addons.error.size');
        }
        try {
            $data = json_decode($json, true, 16, \JSON_THROW_ON_ERROR);
        } catch (\JsonException) {
            throw new AddonValidationException('addons.error.json');
        }
        $this->keys($data, ['schema_version', 'slug', 'version', 'name', 'description', 'placement', 'links'], 'addon.json');
        if (1 !== $data['schema_version']) {
            throw new AddonValidationException('addons.error.schema');
        }
        $this->identity($data['slug'], $data['version']);
        $this->text($data['name'], 'name', 80);
        $this->text($data['description'], 'description', 1000);
        if (!\in_array($data['placement'], self::PLACEMENTS, true)) {
            throw new AddonValidationException('addons.error.placement');
        }
        if (!\is_array($data['links']) || !array_is_list($data['links']) || \count($data['links']) > 8) {
            throw new AddonValidationException('addons.error.links');
        }
        foreach ($data['links'] as $link) {
            $this->keys($link, ['label', 'url'], 'links');
            $this->text($link['label'], 'links.label', 80);
            $this->text($link['url'], 'links.url', 2048);
            $url = $link['url'];
            if (preg_match('/[\x00-\x20\x7f\\\\]|%(?:0[0-9a-f]|1[0-9a-f]|7f|5c)/i', $url)) {
                throw new AddonValidationException('addons.error.url_characters');
            }
            if (str_starts_with($url, '/') && !str_starts_with($url, '//')) {
                continue;
            }
            $parts = parse_url($url);
            if (false === filter_var($url, \FILTER_VALIDATE_URL) || !\is_array($parts)
                || 'https' !== ($parts['scheme'] ?? '') || isset($parts['user']) || isset($parts['pass'])) {
                throw new AddonValidationException('addons.error.url');
            }
        }
        if (\strlen(json_encode($data, \JSON_PRETTY_PRINT | \JSON_UNESCAPED_UNICODE | \JSON_UNESCAPED_SLASHES | \JSON_THROW_ON_ERROR)) > self::MAX_BYTES) {
            throw new AddonValidationException('addons.error.normalized_size');
        }

        return $data;
    }

    public function example(string $slug = 'mina-supportlankar'): array
    {
        $this->identity($slug, '1.0.0');

        return [
            'schema_version' => 1, 'slug' => $slug, 'version' => '1.0.0',
            'name' => 'Mina supportlänkar', 'description' => 'Här hittar du guider och kontaktvägar.',
            'placement' => 'homepage',
            'links' => [['label' => 'Kontakta supporten', 'url' => '/kontakt']],
        ];
    }

    public function import(string $json): array
    {
        $manifest = $this->validate($json);
        $this->locked(function (string $root) use ($manifest): void {
            $path = $root.'/'.$this->filename($manifest);
            if (file_exists($path) || is_link($path)) {
                throw new AddonStorageException('addons.error.duplicate');
            }
            if (\count(glob($root.'/*.manifest.json') ?: []) >= 100) {
                throw new AddonStorageException('addons.error.capacity');
            }
            $this->write($path, $manifest);
        });

        return $manifest;
    }

    /** @return list<array{manifest: array, enabled: bool}> */
    public function all(): array
    {
        return $this->report()['addons'];
    }

    /** @return array{addons: list<array>, issues: list<array>} */
    public function report(): array
    {
        try {
            $root = $this->root();
        } catch (AddonStorageException $exception) {
            return ['addons' => [], 'issues' => [$this->issue('declarative_addons', $exception, 'addons.recovery.storage')]];
        }
        if (!is_dir($root)) {
            return ['addons' => [], 'issues' => []];
        }
        if (!is_readable($root)) {
            return ['addons' => [], 'issues' => [$this->issue('declarative_addons', new AddonStorageException('addons.error.storage_read'), 'addons.recovery.storage')]];
        }
        $addons = [];
        $issues = [];
        $states = [];
        foreach (array_slice(glob($root.'/*.manifest.json') ?: [], 0, 100) as $path) {
            try {
                $manifest = $this->validate($this->read($path, self::MAX_BYTES));
                if (basename($path) !== $this->filename($manifest)) {
                    throw new AddonStorageException('addons.error.identity');
                }
                $slug = $manifest['slug'];
                if (!isset($states[$slug])) {
                    $problem = null;
                    $states[$slug] = $this->state($root, $slug, $problem);
                    if (null !== $problem) {
                        $issues[$slug.'.state.json'] = $problem;
                    }
                }
                $state = $states[$slug];
                $addons[] = ['manifest' => $manifest, 'enabled' => true === ($state['enabled'] ?? false) && $manifest['version'] === ($state['version'] ?? null)];
            } catch (AddonValidationException|AddonStorageException $exception) {
                $issues[basename($path)] = $this->issue(basename($path), $exception, 'addons.recovery.manifest');
                $this->logger?->warning('Ogiltigt deklarativt tillägg ignorerades.', ['file' => basename($path)]);
            }
        }
        foreach (array_slice(glob($root.'/*.state.json') ?: [], 0, 100) as $path) {
            $slug = substr(basename($path), 0, -\strlen('.state.json'));
            try {
                $this->identity($slug, '1.0.0');
                if (!isset($states[$slug])) {
                    $problem = null;
                    $states[$slug] = $this->state($root, $slug, $problem);
                    if (null !== $problem) {
                        $issues[basename($path)] = $problem;
                    }
                }
                $state = $states[$slug];
                if (true === ($state['enabled'] ?? false) && [] === array_filter($addons, static fn (array $addon): bool => $addon['manifest']['slug'] === $slug && $addon['manifest']['version'] === $state['version'])) {
                    $issues[basename($path)] = $this->issue(basename($path), new AddonStorageException('addons.error.active_missing'), 'addons.recovery.state');
                }
            } catch (AddonValidationException $exception) {
                $issues[basename($path)] = $this->issue(basename($path), $exception, 'addons.recovery.state');
            }
        }
        foreach ($addons as &$addon) {
            $addon['problem'] = isset($issues[$addon['manifest']['slug'].'.state.json']);
        }
        unset($addon);
        usort($addons, static fn (array $left, array $right): int => strcmp($left['manifest']['slug'], $right['manifest']['slug'])
            ?: version_compare($right['manifest']['version'], $left['manifest']['version']));

        return ['addons' => $addons, 'issues' => array_values($issues)];
    }

    public function find(string $slug, string $version): array
    {
        $this->identity($slug, $version);
        $manifest = $this->validate($this->read($this->root().'/'.$this->filename(['slug' => $slug, 'version' => $version]), self::MAX_BYTES));
        if ($slug !== $manifest['slug'] || $version !== $manifest['version']) {
            throw new AddonStorageException('addons.error.identity');
        }

        return $manifest;
    }

    private function issue(string $file, AddonProblem $exception, string $action): array
    {
        return ['file' => $file, 'reason' => $exception->getMessage(), 'parameters' => $exception->translationParameters(), 'action' => $action];
    }

    public function setEnabled(string $slug, string $version, bool $enabled): void
    {
        $this->identity($slug, $version);
        $this->locked(function (string $root) use ($slug, $version, $enabled): void {
            $manifest = $this->validate($this->read($root.'/'.$this->filename(['slug' => $slug, 'version' => $version]), self::MAX_BYTES));
            if ($slug !== $manifest['slug'] || $version !== $manifest['version']) {
                throw new AddonStorageException('addons.error.identity');
            }
            $current = $this->state($root, $slug);
            if (!$enabled && ($current['version'] ?? null) !== $version) {
                throw new AddonStorageException('addons.error.inactive_version');
            }
            $this->write($root.'/'.$slug.'.state.json', ['version' => $version, 'enabled' => $enabled]);
        });
    }

    public function panels(string $placement): array
    {
        if (!\in_array($placement, self::PLACEMENTS, true)) {
            return [];
        }

        try {
            return array_values(array_map(static fn (array $addon): array => $addon['manifest'], array_filter(
                $this->all(), static fn (array $addon): bool => $addon['enabled'] && $placement === $addon['manifest']['placement'],
            )));
        } catch (\RuntimeException) {
            $this->logger?->error('Tilläggspaneler kunde inte läsas. Grundsidan visas utan tillägg.');

            return [];
        }
    }

    public function deleteVersion(string $slug, string $version): void
    {
        $this->identity($slug, $version);
        $this->locked(function (string $root) use ($slug, $version): void {
            $state = $this->state($root, $slug);
            if (true === ($state['enabled'] ?? false) && $version === ($state['version'] ?? null)) {
                throw new AddonStorageException('addons.error.active_delete');
            }
            $path = $root.'/'.$this->filename(['slug' => $slug, 'version' => $version]);
            $manifest = $this->validate($this->read($path, self::MAX_BYTES));
            if ($slug !== $manifest['slug'] || $version !== $manifest['version'] || !unlink($path)) {
                throw new AddonStorageException('addons.error.delete');
            }
        });
    }

    private function identity(mixed $slug, mixed $version): void
    {
        if (!\is_string($slug) || \strlen($slug) > 64 || 1 !== preg_match('/^[a-z][a-z0-9]*(?:-[a-z0-9]+)*$/D', $slug)) {
            throw new AddonValidationException('addons.error.slug');
        }
        if (!\is_string($version) || 1 !== preg_match('/^(?:0|[1-9][0-9]{0,5})\.(?:0|[1-9][0-9]{0,5})\.(?:0|[1-9][0-9]{0,5})$/D', $version)) {
            throw new AddonValidationException('addons.error.version');
        }
    }

    private function keys(mixed $value, array $keys, string $field): void
    {
        if (!\is_array($value) || array_is_list($value) || array_diff(array_keys($value), $keys) || array_diff($keys, array_keys($value))) {
            throw new AddonValidationException('addons.error.fields', ['%field%' => $field, '%fields%' => implode(', ', $keys)]);
        }
    }

    private function text(mixed $value, string $field, int $limit): void
    {
        if (!\is_string($value) || '' === trim($value) || mb_strlen($value) > $limit || preg_match('/[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]/', $value)) {
            throw new AddonValidationException('addons.error.text', ['%field%' => $field, '%limit%' => $limit]);
        }
    }

    private function filename(array $manifest): string
    {
        return $manifest['slug'].'--'.$manifest['version'].'.manifest.json';
    }

    private function root(bool $create = false): string
    {
        $path = $this->projectDir;
        foreach (['var', 'declarative_addons'] as $part) {
            $path .= '/'.$part;
            if (is_link($path) || (file_exists($path) && !is_dir($path))) {
                throw new AddonStorageException('addons.error.storage_directory');
            }
            if ($create && !is_dir($path) && !mkdir($path, 0750) && !is_dir($path)) {
                throw new AddonStorageException('addons.error.storage_create');
            }
        }

        return $path;
    }

    private function state(string $root, string $slug, ?array &$problem = null): array
    {
        $path = $root.'/'.$slug.'.state.json';
        if (!file_exists($path) && !is_link($path)) {
            return [];
        }
        try {
            $value = json_decode($this->read($path, 256), true, 4, \JSON_THROW_ON_ERROR);
            if (!\is_array($value) || array_diff(array_keys($value), ['enabled', 'version']) || !isset($value['version'], $value['enabled']) || !\is_bool($value['enabled'])) {
                throw new AddonStorageException('addons.error.state_invalid');
            }
            $this->identity($slug, $value['version']);

            return $value;
        } catch (AddonStorageException|AddonValidationException|\JsonException $exception) {
            $problem = $this->issue(basename($path), new AddonStorageException('addons.error.state_invalid'), 'addons.recovery.state');

            return [];
        }
    }

    private function read(string $path, int $limit): string
    {
        if (is_link($path) || !is_file($path)) {
            throw new AddonStorageException('addons.error.file_missing');
        }
        $value = file_get_contents($path, false, null, 0, $limit + 1);
        if (false === $value || \strlen($value) > $limit) {
            throw new AddonStorageException('addons.error.file_read');
        }

        return $value;
    }

    private function locked(callable $operation): void
    {
        $root = $this->root(true);
        $path = $root.'/.lock';
        if (is_link($path)) {
            throw new AddonStorageException('addons.error.lock_invalid');
        }
        $lock = fopen($path, 'c');
        if (false === $lock) {
            throw new AddonStorageException('addons.error.lock_open');
        }
        try {
            if (!flock($lock, \LOCK_EX)) {
                throw new AddonStorageException('addons.error.lock');
            }
            $operation($root);
        } finally {
            flock($lock, \LOCK_UN);
            fclose($lock);
        }
    }

    private function write(string $path, array $value): void
    {
        if (is_link($path)) {
            throw new AddonStorageException('addons.error.symlink');
        }
        $temporary = tempnam(\dirname($path), '.addon-');
        if (false === $temporary) {
            throw new AddonStorageException('addons.error.temporary');
        }
        try {
            $json = json_encode($value, \JSON_PRETTY_PRINT | \JSON_UNESCAPED_UNICODE | \JSON_UNESCAPED_SLASHES | \JSON_THROW_ON_ERROR);
            if (\strlen($json) !== file_put_contents($temporary, $json) || !rename($temporary, $path)) {
                throw new AddonStorageException('addons.error.write');
            }
        } finally {
            if (is_file($temporary)) {
                unlink($temporary);
            }
        }
    }
}
