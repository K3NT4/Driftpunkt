<?php

declare(strict_types=1);

namespace App\Module\System\Entity;

use App\Module\Identity\Entity\User;
use App\Module\Shared\Entity\TimestampableTrait;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity]
#[ORM\Table(name: 'release_notice_snoozes')]
#[ORM\UniqueConstraint(name: 'uniq_release_notice_user_version', columns: ['user_id', 'release_version'])]
#[ORM\Index(name: 'idx_release_notice_snoozed_until', columns: ['snoozed_until'])]
#[ORM\HasLifecycleCallbacks]
class ReleaseNoticeSnooze
{
    use TimestampableTrait;

    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\ManyToOne(targetEntity: User::class)]
    #[ORM\JoinColumn(nullable: false, onDelete: 'CASCADE')]
    private User $user;

    #[ORM\Column(name: 'release_version', type: Types::STRING, length: 40)]
    private string $releaseVersion;

    // Persist an absolute instant: Doctrine's timezone-less datetime type would
    // otherwise reinterpret the deadline when a portal user's timezone changes.
    #[ORM\Column(name: 'snoozed_until', type: Types::BIGINT)]
    private int $snoozedUntilTimestamp;

    public function __construct(User $user, string $releaseVersion, \DateTimeImmutable $snoozedUntil)
    {
        $this->user = $user;
        $this->releaseVersion = trim($releaseVersion);
        $this->snoozedUntilTimestamp = $snoozedUntil->getTimestamp();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getUser(): User
    {
        return $this->user;
    }

    public function getReleaseVersion(): string
    {
        return $this->releaseVersion;
    }

    public function getSnoozedUntil(): \DateTimeImmutable
    {
        return new \DateTimeImmutable('@'.$this->snoozedUntilTimestamp);
    }

    public function extendTo(\DateTimeImmutable $snoozedUntil): self
    {
        $this->snoozedUntilTimestamp = $snoozedUntil->getTimestamp();

        return $this;
    }
}
