<?php

declare(strict_types=1);

namespace App\Module\System\Controller;

use App\Module\Identity\Entity\User;
use App\Module\System\Exception\AddonProblem;
use App\Module\System\Exception\AddonValidationException;
use App\Module\System\Exception\AddonStorageException;
use Psr\Log\LoggerInterface;
use Symfony\Contracts\Translation\TranslatorInterface;
use App\Module\System\Service\DeclarativeAddonManager;
use App\Module\System\Service\SystemAuditLogger;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\File\UploadedFile;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;
use Symfony\Component\Security\Http\Attribute\IsGranted;

#[IsGranted('ROLE_SUPER_ADMIN')]
final class DeclarativeAddonsController extends AbstractController
{
    public function __construct(
        private readonly DeclarativeAddonManager $addons,
        private readonly SystemAuditLogger $audit,
        private readonly TranslatorInterface $translator,
        private readonly LoggerInterface $logger,
    )
    {
    }

    #[Route('/portal/addons/example.json', name: 'app_declarative_addon_example', methods: ['GET'])]
    public function example(): Response
    {
        return new Response(json_encode($this->addons->example(), \JSON_PRETTY_PRINT | \JSON_UNESCAPED_UNICODE | \JSON_UNESCAPED_SLASHES | \JSON_THROW_ON_ERROR), 200, [
            'Content-Type' => 'application/json', 'Content-Disposition' => 'attachment; filename="addon.json"',
        ]);
    }

    #[Route('/portal/addons/import-json', name: 'app_declarative_addon_import', methods: ['POST'])]
    public function import(Request $request): Response
    {
        $this->csrf($request, 'declarative_addon_import');
        try {
            $file = $request->files->get('manifest');
            if (!$file instanceof UploadedFile || !$file->isValid() || 'json' !== strtolower($file->getClientOriginalExtension())) {
                throw new AddonValidationException('addons.error.upload');
            }
            if ($file->getSize() > DeclarativeAddonManager::MAX_BYTES) {
                throw new AddonValidationException('addons.error.size');
            }
            $json = file_get_contents($file->getPathname(), false, null, 0, DeclarativeAddonManager::MAX_BYTES + 1);
            if (false === $json) {
                throw new AddonValidationException('addons.error.upload_read');
            }
            $action = $request->request->getString('action', 'validate');
            if (!\in_array($action, ['validate', 'preview', 'import'], true)) {
                throw new AddonValidationException('addons.error.action');
            }
            if ('preview' === $action) {
                return $this->renderPreview($this->addons->validate($json));
            }
            if ('validate' === $action) {
                $this->addons->validate($json);
                $this->addFlash('success', $this->translator->trans('addons.message.validated'));
            } else {
                $manifest = $this->addons->import($json);
                $user = $this->getUser();
                $this->audit->log($user instanceof User ? $user : null, 'admin.declarative_addon.imported', 'Importerade deklarativt tillägg', $manifest['slug'].' '.$manifest['version']);
                $this->addFlash('success', $this->translator->trans('addons.message.imported'));
            }
        } catch (AddonValidationException|AddonStorageException $exception) {
            $this->problem($exception);
        } catch (\Throwable $exception) {
            $this->logger->error('Deklarativ tilläggsåtgärd kunde inte bekräftas.', ['exception' => $exception]);
            $this->addFlash('error', $this->translator->trans('addons.error.operation'));
        }

        return $this->redirectToRoute('app_portal_admin', ['section' => 'addons']);
    }

    #[Route('/portal/addons/toggle-json', name: 'app_declarative_addon_toggle', methods: ['POST'])]
    public function toggle(Request $request): Response
    {
        $this->csrf($request, 'declarative_addon_toggle');
        try {
            $slug = $request->request->getString('slug');
            $version = $request->request->getString('version');
            $enabled = $request->request->getBoolean('enabled');
            $this->addons->setEnabled($slug, $version, $enabled);
            $user = $this->getUser();
            $this->audit->log($user instanceof User ? $user : null, 'admin.declarative_addon.toggled', 'Ändrade deklarativt tillägg', $slug.' '.$version.($enabled ? ' på' : ' av'));
            $this->addFlash('success', $this->translator->trans($enabled ? 'addons.message.enabled' : 'addons.message.disabled'));
        } catch (AddonValidationException|AddonStorageException $exception) {
            $this->problem($exception);
        } catch (\Throwable $exception) {
            $this->logger->error('Deklarativ tilläggsåtgärd kunde inte bekräftas.', ['exception' => $exception]);
            $this->addFlash('error', $this->translator->trans('addons.error.operation'));
        }

        return $this->redirectToRoute('app_portal_admin', ['section' => 'addons']);
    }

    #[Route('/portal/addons/preview-json', name: 'app_declarative_addon_preview', methods: ['GET'])]
    public function preview(Request $request): Response
    {
        try {
            return $this->renderPreview($this->addons->find($request->query->getString('slug'), $request->query->getString('version')));
        } catch (AddonValidationException|AddonStorageException $exception) {
            $this->problem($exception);

            return $this->redirectToRoute('app_portal_admin', ['section' => 'addons']);
        }
    }

    private function renderPreview(array $manifest): Response
    {
        $response = $this->render('portal/admin_addon_preview.html.twig', [
            'manifest' => $manifest,
            'title' => $this->translator->trans('addons.preview.title'),
            'summary' => $this->translator->trans('addons.preview.summary'),
        ]);
        $response->headers->set('Cache-Control', 'no-store, private');

        return $response;
    }

    private function problem(AddonProblem $exception): void
    {
        $this->addFlash('error', $this->translator->trans($exception->getMessage(), $exception->translationParameters()));
    }

    private function csrf(Request $request, string $id): void
    {
        if (!$this->isCsrfTokenValid($id, $request->request->getString('_token'))) {
            throw $this->createAccessDeniedException();
        }
    }

    #[Route('/portal/addons/delete-json', name: 'app_declarative_addon_delete', methods: ['POST'])]
    public function delete(Request $request): Response
    {
        $this->csrf($request, 'declarative_addon_delete');
        try {
            $slug = $request->request->getString('slug');
            $version = $request->request->getString('version');
            $this->addons->deleteVersion($slug, $version);
            $user = $this->getUser();
            $this->audit->log($user instanceof User ? $user : null, 'admin.declarative_addon.deleted', 'Tog bort inaktiv tilläggsversion', $slug.' '.$version);
            $this->addFlash('success', $this->translator->trans('addons.message.deleted'));
        } catch (AddonValidationException|AddonStorageException $exception) {
            $this->problem($exception);
        } catch (\Throwable $exception) {
            $this->logger->error('Deklarativ tilläggsåtgärd kunde inte bekräftas.', ['exception' => $exception]);
            $this->addFlash('error', $this->translator->trans('addons.error.operation'));
        }

        return $this->redirectToRoute('app_portal_admin', ['section' => 'addons']);
    }
}
