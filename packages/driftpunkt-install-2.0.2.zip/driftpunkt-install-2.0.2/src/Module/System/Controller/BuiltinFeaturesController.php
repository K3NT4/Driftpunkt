<?php

declare(strict_types=1);

namespace App\Module\System\Controller;

use App\Module\Identity\Entity\User;
use App\Module\System\Service\SystemAuditLogger;
use App\Module\System\Service\SystemSettings;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;
use Symfony\Component\Security\Http\Attribute\IsGranted;
use Symfony\Contracts\Translation\TranslatorInterface;

#[IsGranted('ROLE_ADMIN')]
final class BuiltinFeaturesController extends AbstractController
{
    public function __construct(
        private readonly SystemSettings $settings,
        private readonly EntityManagerInterface $entityManager,
        private readonly SystemAuditLogger $auditLogger,
        private readonly TranslatorInterface $translator,
    ) {
    }

    #[Route('/portal/admin/functions', name: 'app_portal_admin_builtin_features', methods: ['GET', 'POST'])]
    public function index(Request $request): Response
    {
        if ($request->isMethod('POST')) {
            if (!$this->isCsrfTokenValid('builtin_features', $request->request->getString('_token'))) {
                throw $this->createAccessDeniedException();
            }

            $this->entityManager->wrapInTransaction(function () use ($request): void {
                $this->settings->setBool(SystemSettings::FEATURE_NEWS_EXTENDED_EDITOR_ENABLED, $request->request->getBoolean('news_extended_editor'));
                $this->settings->setBool(SystemSettings::FEATURE_TELEFONSTOD_ENABLED, $request->request->getBoolean('telefonstod'));
                $user = $this->getUser();
                $this->auditLogger->log(
                    $user instanceof User ? $user : null,
                    'admin.features.updated',
                    'Uppdaterade inbyggda funktioner',
                    sprintf('Utökad nyhetsredigering: %s. Telefonstöd: %s.',
                        $request->request->getBoolean('news_extended_editor') ? 'på' : 'av',
                        $request->request->getBoolean('telefonstod') ? 'på' : 'av',
                    ),
                );
            });

            $this->addFlash('success', $this->translator->trans('features.saved'));

            return $this->redirectToRoute('app_portal_admin_builtin_features');
        }

        return $this->render('portal/admin_builtin_features.html.twig', [
            'title' => $this->translator->trans('features.title'),
            'summary' => $this->translator->trans('features.description'),
            'newsExtendedEditorEnabled' => $this->settings->getBool(SystemSettings::FEATURE_NEWS_EXTENDED_EDITOR_ENABLED, true),
            'telefonstodEnabled' => $this->settings->getBool(SystemSettings::FEATURE_TELEFONSTOD_ENABLED, true),
        ]);
    }
}
