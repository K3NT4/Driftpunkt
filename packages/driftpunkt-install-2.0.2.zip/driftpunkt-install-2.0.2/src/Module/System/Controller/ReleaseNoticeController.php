<?php

declare(strict_types=1);

namespace App\Module\System\Controller;

use App\Module\Identity\Entity\User;
use App\Module\System\Service\GitHubReleaseChecker;
use App\Module\System\Service\ReleaseNoticeService;
use App\Module\System\Service\ReleaseNoticeSnoozeManager;
use App\Twig\AppRuntime;
use Psr\Log\LoggerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;
use Symfony\Component\Security\Http\Attribute\IsGranted;

final class ReleaseNoticeController extends AbstractController
{
    public function __construct(
        private readonly ReleaseNoticeService $releaseNoticeService,
        private readonly GitHubReleaseChecker $releaseChecker,
        private readonly ReleaseNoticeSnoozeManager $snoozeManager,
        private readonly LoggerInterface $logger,
        private readonly AppRuntime $appRuntime,
    ) {
    }

    /**
     * Cache-only details page. Never performs HTTP: it renders the shared
     * snapshot produced by checkManually()/checkAutomatic(). The portal route
     * gate keeps out unauthenticated visitors; the explicit role check below
     * answers every request without update permission with a plain 403.
     */
    #[Route('/portal/admin/updates/release-notes', name: ReleaseNoticeService::DETAILS_ROUTE, methods: ['GET'])]
    public function notes(): Response
    {
        $denied = $this->forbiddenWithoutUpdatePermission();
        if (null !== $denied) {
            return $denied;
        }

        return $this->render('portal/admin/updates/release_notes.html.twig', [
            'release_notice_view' => $this->releaseNoticeService->snapshot(),
        ]);
    }

    #[Route('/portal/admin/updates/release-check', name: ReleaseNoticeService::CHECK_ROUTE, methods: ['POST'])]
    #[IsGranted('ROLE_SUPER_ADMIN')]
    public function check(Request $request): RedirectResponse
    {
        if (!$this->isCsrfTokenValid(ReleaseNoticeService::CHECK_CSRF_ID, (string) $request->request->get('_token'))) {
            $this->addFlash('error', $this->appRuntime->translate('portal.admin.release_notice.flash.check_csrf'));

            return $this->redirectToRoute(ReleaseNoticeService::DETAILS_ROUTE);
        }

        try {
            $result = $this->releaseChecker->checkManually();
        } catch (\Throwable $exception) {
            $this->logger->warning('Kunde inte starta versionskontrollen.', ['exception' => $exception]);
            $this->addFlash('error', $this->appRuntime->translate('portal.admin.release_notice.flash.store_failure'));

            return $this->redirectToRoute(ReleaseNoticeService::DETAILS_ROUTE);
        }
        $messageKey = match ($result['outcome']) {
            'success' => 'success',
            'no_release' => 'no_release',
            'cooldown' => 'cooldown',
            'busy' => 'busy',
            default => 'failure',
        };
        $this->addFlash('success' === $result['outcome'] ? 'success' : 'error', $this->appRuntime->translate(
            'portal.admin.release_notice.flash.'.$messageKey,
            ['%seconds%' => (string) (int) ($result['retryAfterSeconds'] ?? 0)],
        ));

        return $this->redirectToRoute(ReleaseNoticeService::DETAILS_ROUTE);
    }

    #[Route('/portal/admin/updates/release-notice/snooze', name: ReleaseNoticeService::SNOOZE_ROUTE, methods: ['POST'])]
    #[IsGranted('ROLE_SUPER_ADMIN')]
    public function snooze(Request $request): RedirectResponse
    {
        if (!$this->isCsrfTokenValid(ReleaseNoticeService::SNOOZE_CSRF_ID, (string) $request->request->get('_token'))) {
            $this->addFlash('error', $this->appRuntime->translate('portal.admin.release_notice.flash.snooze_csrf'));

            return $this->redirectToRoute(ReleaseNoticeService::DETAILS_ROUTE);
        }

        $latestVersion = $this->releaseNoticeService->latestSnapshotReleaseVersion();
        $requestedVersion = trim((string) $request->request->get('release_version'));
        if (null === $latestVersion || $requestedVersion !== $latestVersion) {
            $this->addFlash('error', $this->appRuntime->translate('portal.admin.release_notice.flash.snooze_invalid_version'));

            return $this->redirectToRoute(ReleaseNoticeService::DETAILS_ROUTE);
        }

        $user = $this->getUser();
        if (!$user instanceof User || null === $user->getId()) {
            $this->addFlash('error', $this->appRuntime->translate('portal.admin.release_notice.flash.snooze_no_account'));

            return $this->redirectToRoute(ReleaseNoticeService::DETAILS_ROUTE);
        }

        try {
            $snoozedUntil = $this->snoozeManager->snooze($user, $latestVersion);
            $this->addFlash('success', $this->appRuntime->translate('portal.admin.release_notice.flash.snooze_success', [
                '%version%' => $latestVersion,
                '%until%' => $snoozedUntil->format('Y-m-d H:i'),
            ]));
        } catch (\Throwable $exception) {
            $this->logger->warning('Kunde inte spara versionsaviseringens påminnelse.', ['exception' => $exception]);
            $this->addFlash('error', $this->appRuntime->translate('portal.admin.release_notice.flash.snooze_failure'));
        }

        return $this->redirectToRoute(ReleaseNoticeService::DETAILS_ROUTE);
    }

    private function forbiddenWithoutUpdatePermission(): ?Response
    {
        $user = $this->getUser();
        if ($user instanceof User && \in_array('ROLE_SUPER_ADMIN', $user->getRoles(), true)) {
            return null;
        }

        return new Response('Du saknar behörighet att se versionsaviseringen.', Response::HTTP_FORBIDDEN);
    }
}
