<?php

declare(strict_types=1);

namespace App\Module\System\Controller;

use App\Module\Identity\Entity\User;
use App\Module\System\Service\LocalePreferenceResolver;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Attribute\Route;

final class LocaleController extends AbstractController
{
    private const SESSION_KEY = 'app.locale';

    #[Route('/sprak/{locale}', name: 'app_locale_switch', methods: ['GET'])]
    public function switch(Request $request, string $locale, EntityManagerInterface $entityManager, LocalePreferenceResolver $localePreferenceResolver): RedirectResponse
    {
        $locale = $localePreferenceResolver->normalizeSelectable($locale);
        $request->getSession()->set(self::SESSION_KEY, $locale);
        $this->storePreferredLocale($locale, $entityManager);

        $returnTo = $this->localReturnPath(trim((string) $request->query->get('returnTo')));
        if (null !== $returnTo) {
            return $this->redirect($returnTo);
        }

        $referer = trim((string) $request->headers->get('referer'));
        if ('' !== $referer) {
            $refererParts = parse_url($referer);
            if (\is_array($refererParts)
                && isset($refererParts['host'])
                && strtolower($refererParts['host']) === strtolower($request->getHost())
                && (!isset($refererParts['port']) || (int) $refererParts['port'] === $request->getPort())
            ) {
                $refererPath = $this->localReturnPath(
                    ($refererParts['path'] ?? '/').(isset($refererParts['query']) ? '?'.$refererParts['query'] : ''),
                );
                if (null !== $refererPath) {
                    return $this->redirect($refererPath);
                }
            }
        }

        return $this->redirectToRoute('app_home');
    }

    /**
     * Accepts only a same-site absolute path. Protocol-relative ("//host"), backslash
     * variants ("/\\host") and control characters could otherwise send the visitor to
     * another site.
     */
    private function localReturnPath(string $path): ?string
    {
        if ('' === $path || '/' !== $path[0]) {
            return null;
        }

        if (isset($path[1]) && ('/' === $path[1] || '\\' === $path[1])) {
            return null;
        }

        if (1 === preg_match('/[\x00-\x1F\x7F\\\\]/', $path)) {
            return null;
        }

        return $path;
    }

    private function storePreferredLocale(string $locale, EntityManagerInterface $entityManager): void
    {
        $authenticatedUser = $this->getUser();
        if (!$authenticatedUser instanceof User || null === $authenticatedUser->getId()) {
            return;
        }

        $user = $entityManager->getRepository(User::class)->find($authenticatedUser->getId());
        if (!$user instanceof User) {
            return;
        }

        $authenticatedUser->setPreferredLocale($locale);
        $user->setPreferredLocale($locale);
        $entityManager->flush();
    }
}
