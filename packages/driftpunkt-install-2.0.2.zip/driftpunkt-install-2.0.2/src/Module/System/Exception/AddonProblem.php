<?php

declare(strict_types=1);

namespace App\Module\System\Exception;

interface AddonProblem extends \Throwable
{
    public function translationParameters(): array;
}
