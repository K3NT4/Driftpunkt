<?php

declare(strict_types=1);

namespace App\Module\System\Exception;

final class AddonValidationException extends \InvalidArgumentException implements AddonProblem
{
    public function __construct(string $key, private readonly array $parameters = [])
    {
        parent::__construct($key);
    }

    public function translationParameters(): array
    {
        return $this->parameters;
    }
}
