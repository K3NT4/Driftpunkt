<?php

declare(strict_types=1);

namespace App\EventSubscriber;

use App\Module\System\Service\AppDateTimeFormatter;
use Symfony\Component\Console\ConsoleEvents;
use Symfony\Component\Console\Event\ConsoleCommandEvent;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\HttpKernel\Event\RequestEvent;
use Symfony\Component\HttpKernel\KernelEvents;

final class TimeZoneSubscriber implements EventSubscriberInterface
{
    public function __construct(
        private readonly AppDateTimeFormatter $dateTimeFormatter,
    ) {
    }

    public static function getSubscribedEvents(): array
    {
        return [
            KernelEvents::REQUEST => ['applyConfiguredTimeZone', 128],
            ConsoleEvents::COMMAND => ['applyConfiguredTimeZoneForConsole', 128],
        ];
    }

    public function applyConfiguredTimeZone(RequestEvent $event): void
    {
        if (!$event->isMainRequest()) {
            return;
        }

        date_default_timezone_set($this->dateTimeFormatter->timeZoneIdentifier());
    }

    public function applyConfiguredTimeZoneForConsole(ConsoleCommandEvent $event): void
    {
        $commandName = $event->getCommand()?->getName();
        if (\is_string($commandName) && str_starts_with($commandName, 'cache:')) {
            date_default_timezone_set(AppDateTimeFormatter::DEFAULT_TIMEZONE);

            return;
        }

        date_default_timezone_set($this->dateTimeFormatter->timeZoneIdentifier());
    }
}
