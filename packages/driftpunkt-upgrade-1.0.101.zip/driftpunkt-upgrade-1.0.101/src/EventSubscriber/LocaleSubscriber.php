<?php

declare(strict_types=1);

namespace App\EventSubscriber;

use App\Module\Identity\Entity\User;
use App\Module\System\Service\LocalePreferenceResolver;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\HttpKernel\Event\RequestEvent;
use Symfony\Component\HttpKernel\KernelEvents;
use Symfony\Bundle\SecurityBundle\Security;
use Symfony\Contracts\Translation\LocaleAwareInterface;

final class LocaleSubscriber implements EventSubscriberInterface
{
    private const SESSION_KEY = 'app.locale';

    public function __construct(
        private readonly LocaleAwareInterface $translator,
        private readonly Security $security,
        private readonly LocalePreferenceResolver $localePreferenceResolver,
    ) {
    }

    public static function getSubscribedEvents(): array
    {
        return [
            KernelEvents::REQUEST => ['onKernelRequest', 0],
        ];
    }

    public function onKernelRequest(RequestEvent $event): void
    {
        $request = $event->getRequest();
        $session = $request->hasSession() ? $request->getSession() : null;
        $locale = $this->localePreferenceResolver->defaultLocale();

        $attributeLocale = $request->attributes->get('_locale');
        $switchLocale = $request->attributes->get('locale');
        $user = $this->security->getUser();

        if (\is_string($attributeLocale) && '' !== trim($attributeLocale)) {
            $locale = $this->localePreferenceResolver->normalizeSelectable($attributeLocale);
        } elseif ('app_locale_switch' === $request->attributes->get('_route') && \is_string($switchLocale) && '' !== trim($switchLocale)) {
            $locale = $this->localePreferenceResolver->normalizeSelectable($switchLocale);
        } elseif ($user instanceof User) {
            $locale = $this->localePreferenceResolver->forUser($user);
        } elseif (null !== $session && $session->has(self::SESSION_KEY)) {
            $locale = $this->localePreferenceResolver->normalizeSelectable((string) $session->get(self::SESSION_KEY, $locale));
        }

        $request->setLocale($locale);
        $this->translator->setLocale($locale);

        if (null !== $session) {
            $session->set(self::SESSION_KEY, $locale);
        }
    }
}
