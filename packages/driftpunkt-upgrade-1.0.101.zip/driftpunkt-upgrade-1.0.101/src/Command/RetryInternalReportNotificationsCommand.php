<?php

declare(strict_types=1);

namespace App\Command;

use App\Module\System\Entity\InternalReport;
use App\Module\System\Service\InternalReportNotifier;
use Doctrine\ORM\EntityManagerInterface;
use Psr\Log\LoggerInterface;
use Symfony\Component\Console\Attribute\AsCommand;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Style\SymfonyStyle;

#[AsCommand(
    name: 'app:internal-reports:retry-notifications',
    description: 'Försöker skicka om centrala rapportnotifieringar som tidigare misslyckats.',
)]
final class RetryInternalReportNotificationsCommand extends Command
{
    public function __construct(
        private readonly EntityManagerInterface $entityManager,
        private readonly InternalReportNotifier $notifier,
        private readonly LoggerInterface $logger,
    ) {
        parent::__construct();
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $io = new SymfonyStyle($input, $output);
        /** @var list<InternalReport> $reports */
        $reports = $this->entityManager->getRepository(InternalReport::class)->createQueryBuilder('report')
            ->andWhere('report.deliveryStatus = :failed')
            ->andWhere('report.notificationAttemptCount < :maxAttempts')
            ->andWhere('report.notificationNextAttemptAt IS NULL OR report.notificationNextAttemptAt <= :now')
            ->setParameter('failed', InternalReport::DELIVERY_FAILED)
            ->setParameter('maxAttempts', 5)
            ->setParameter('now', new \DateTimeImmutable())
            ->orderBy('report.createdAt', 'ASC')
            ->setMaxResults(25)
            ->getQuery()
            ->getResult();

        $sent = 0;
        foreach ($reports as $report) {
            try {
                if ($this->notifier->notify($report)) {
                    ++$sent;
                }
            } catch (\Throwable $exception) {
                $this->logger->error('Oväntat fel vid återförsök av intern rapportnotifiering.', [
                    'reportReference' => $report->getPublicReference(),
                    'exception' => $exception,
                ]);
            }
        }

        $io->success(sprintf('Återförsök klara. Behandlade: %d. Skickade: %d.', \count($reports), $sent));

        return Command::SUCCESS;
    }
}
