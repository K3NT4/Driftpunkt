<?php

declare(strict_types=1);

namespace App\Command;

use App\Module\Mail\Entity\IncomingMail;
use App\Module\Mail\Entity\SupportMailbox;
use App\Module\Mail\Service\IncomingMailProcessor;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\Console\Attribute\AsCommand;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Style\SymfonyStyle;

#[AsCommand(
    name: 'app:mail:ingest',
    description: 'Behandlar ett enskilt inkommande e-postmeddelande som ärende, svar, utkastgranskning eller avslag.',
)]
final class IngestIncomingMailCommand extends Command
{
    public function __construct(
        private readonly EntityManagerInterface $entityManager,
        private readonly IncomingMailProcessor $incomingMailProcessor,
    ) {
        parent::__construct();
    }

    protected function configure(): void
    {
        $this
            ->addArgument('mailbox', InputArgument::REQUIRED, 'Inkorgens e-postadress eller namn')
            ->addArgument('from', InputArgument::REQUIRED, 'Avsändarens e-postadress')
            ->addArgument('subject', InputArgument::REQUIRED, 'Ämne')
            ->addArgument('body', InputArgument::REQUIRED, 'Brödtext i ren text');
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $io = new SymfonyStyle($input, $output);
        $mailboxIdentifier = trim((string) $input->getArgument('mailbox'));

        $mailbox = $this->entityManager->getRepository(SupportMailbox::class)->findOneBy([
            'emailAddress' => mb_strtolower($mailboxIdentifier),
        ]);

        if (!$mailbox instanceof SupportMailbox) {
            $mailbox = $this->entityManager->getRepository(SupportMailbox::class)->findOneBy([
                'name' => $mailboxIdentifier,
            ]);
        }

        if (!$mailbox instanceof SupportMailbox) {
            $io->error('Kunde inte hitta angiven inkorg.');

            return Command::FAILURE;
        }

        $incomingMail = new IncomingMail(
            (string) $input->getArgument('from'),
            (string) $input->getArgument('subject'),
            (string) $input->getArgument('body'),
        );
        $incomingMail->setMailbox($mailbox);

        $this->entityManager->persist($incomingMail);
        $this->entityManager->flush();

        $this->incomingMailProcessor->process($incomingMail);

        $io->success(sprintf(
            'E-postmeddelande behandlat: %s. %s',
            $incomingMail->getProcessingResult()?->label() ?? 'okänt resultat',
            $incomingMail->getProcessingNote() ?? 'Ingen notering',
        ));

        return Command::SUCCESS;
    }
}
