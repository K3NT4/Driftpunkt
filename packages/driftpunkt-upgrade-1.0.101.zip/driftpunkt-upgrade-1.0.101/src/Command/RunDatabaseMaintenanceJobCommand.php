<?php

declare(strict_types=1);

namespace App\Command;

use App\Module\System\Service\DatabaseMaintenanceJobRunner;
use Psr\Log\LoggerInterface;
use Symfony\Component\Console\Attribute\AsCommand;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Style\SymfonyStyle;

#[AsCommand(
    name: 'app:database-maintenance:run',
    description: 'Behandlar ett köat databasunderhållsjobb i bakgrunden.',
)]
final class RunDatabaseMaintenanceJobCommand extends Command
{
    public function __construct(
        private readonly DatabaseMaintenanceJobRunner $databaseMaintenanceJobRunner,
        private readonly LoggerInterface $logger,
    ) {
        parent::__construct();
    }

    protected function configure(): void
    {
        $this->addArgument('job-id', InputArgument::REQUIRED, 'ID för köat databasjobb');
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $io = new SymfonyStyle($input, $output);

        try {
            $jobId = (string) $input->getArgument('job-id');
            $job = $this->databaseMaintenanceJobRunner->processQueuedJob($jobId);
        } catch (\Throwable $exception) {
            $this->logger->error('Databasjobb misslyckades oväntat.', [
                'job_id' => $jobId ?? (string) $input->getArgument('job-id'),
                'exception' => $exception,
            ]);
            $io->error($exception->getMessage());

            return Command::FAILURE;
        }

        $io->success(sprintf(
            'Databasjobb %s avslutat med status %s.',
            $job['id'],
            $job['status'],
        ));

        return 'completed' === $job['status'] ? Command::SUCCESS : Command::FAILURE;
    }
}
