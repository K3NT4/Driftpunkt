<?php

declare(strict_types=1);

namespace App\Command;

use App\Module\Maintenance\Service\MaintenanceMode;
use Symfony\Component\Console\Attribute\AsCommand;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Style\SymfonyStyle;

#[AsCommand(
    name: 'app:maintenance',
    description: 'Aktiverar, inaktiverar eller visar underhållsläget.',
)]
final class MaintenanceModeCommand extends Command
{
    public function __construct(
        private readonly MaintenanceMode $maintenanceMode,
    ) {
        parent::__construct();
    }

    protected function configure(): void
    {
        $this
            ->addArgument('action', InputArgument::OPTIONAL, 'on, off, schedule eller status', 'status')
            ->addOption('message', null, InputOption::VALUE_REQUIRED, 'Valfritt meddelande för underhållsläget')
            ->addOption('start', null, InputOption::VALUE_REQUIRED, 'Valfri schemalagd start i ett format som DateTimeImmutable accepterar')
            ->addOption('end', null, InputOption::VALUE_REQUIRED, 'Valfritt schemalagt slut i ett format som DateTimeImmutable accepterar');
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $io = new SymfonyStyle($input, $output);
        $action = mb_strtolower((string) $input->getArgument('action'));

        return match ($action) {
            'on' => $this->enable($io, $input->getOption('message'), $input->getOption('start'), $input->getOption('end')),
            'schedule' => $this->schedule($io, $input->getOption('message'), $input->getOption('start'), $input->getOption('end')),
            'off' => $this->disable($io),
            'status' => $this->status($io),
            default => Command::INVALID,
        };
    }

    private function enable(SymfonyStyle $io, mixed $message, mixed $start, mixed $end): int
    {
        $this->maintenanceMode->updateSettings(
            true,
            \is_string($message) ? $message : null,
            $this->parseOptionalDateTime($start),
            $this->parseOptionalDateTime($end),
        );
        $io->success('Underhållsläget är aktiverat.');

        return Command::SUCCESS;
    }

    private function schedule(SymfonyStyle $io, mixed $message, mixed $start, mixed $end): int
    {
        $startAt = $this->parseOptionalDateTime($start);
        $endAt = $this->parseOptionalDateTime($end);

        if (!$startAt instanceof \DateTimeImmutable) {
            $io->error('Ett giltigt --start-värde krävs när underhåll schemaläggs.');

            return Command::INVALID;
        }

        if ($endAt instanceof \DateTimeImmutable && $endAt < $startAt) {
            $io->error('--end kan inte vara tidigare än --start.');

            return Command::INVALID;
        }

        $state = $this->maintenanceMode->getState();
        $this->maintenanceMode->updateSettings(
            false,
            \is_string($message) ? $message : ($state['message'] ?? null),
            $startAt,
            $endAt,
        );
        $io->success('Underhållet har schemalagts.');

        return Command::SUCCESS;
    }

    private function disable(SymfonyStyle $io): int
    {
        $this->maintenanceMode->disable();
        $io->success('Underhållsläget är inaktiverat.');

        return Command::SUCCESS;
    }

    private function status(SymfonyStyle $io): int
    {
        $state = $this->maintenanceMode->getState();
        $io->definitionList(
            ['Manuellt aktiverat' => $state['enabled'] ? 'ja' : 'nej'],
            ['Aktivt just nu' => $state['effectiveEnabled'] ? 'ja' : 'nej'],
            ['Läge' => $state['mode']],
            ['Meddelande' => $state['message'] ?? 'inget'],
            ['Schemalagd start' => $state['scheduledStartAt'] ?? 'saknas'],
            ['Schemalagt slut' => $state['scheduledEndAt'] ?? 'saknas'],
            ['Uppdaterat' => $state['updatedAt'] ?? 'saknas'],
        );

        return Command::SUCCESS;
    }

    private function parseOptionalDateTime(mixed $value): ?\DateTimeImmutable
    {
        if (!\is_string($value) || '' === trim($value)) {
            return null;
        }

        try {
            return new \DateTimeImmutable($value);
        } catch (\Exception) {
            return null;
        }
    }
}
