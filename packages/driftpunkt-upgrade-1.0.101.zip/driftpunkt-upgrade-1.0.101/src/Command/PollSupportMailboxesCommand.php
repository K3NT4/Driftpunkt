<?php

declare(strict_types=1);

namespace App\Command;

use App\Module\Mail\Entity\ImapMessageReceipt;
use App\Module\Mail\Entity\IncomingMail;
use App\Module\Mail\Entity\SupportMailbox;
use App\Module\Mail\Enum\ImapMessageState;
use App\Module\Mail\Exception\GoogleAuthorizationRequiredException;
use App\Module\Mail\Service\EmailMimeParser;
use App\Module\Mail\Service\ImapMailboxFetcher;
use App\Module\Mail\Service\ImapMailboxSession;
use App\Module\Mail\Service\IncomingMailAttachmentStorage;
use App\Module\Mail\Service\IncomingMailProcessor;
use App\Module\Mail\Service\IncomingMailSpoolReader;
use Doctrine\ORM\EntityManagerInterface;
use Psr\Log\LoggerInterface;
use Symfony\Component\Console\Attribute\AsCommand;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Style\SymfonyStyle;

#[AsCommand(name: 'app:mail:poll', description: 'Hämtar aktiva supportinkorgar och behandlar köade e-postmeddelanden.')]
final class PollSupportMailboxesCommand extends Command
{
    private int $processedMessages = 0;
    private int $retryPendingMessages = 0;
    private int $quarantinedMessages = 0;
    private int $moveFailures = 0;

    public function __construct(
        private readonly EntityManagerInterface $entityManager,
        private readonly IncomingMailSpoolReader $incomingMailSpoolReader,
        private readonly ImapMailboxFetcher $imapMailboxFetcher,
        private readonly EmailMimeParser $emailMimeParser,
        private readonly IncomingMailAttachmentStorage $incomingMailAttachmentStorage,
        private readonly IncomingMailProcessor $incomingMailProcessor,
        private readonly LoggerInterface $logger,
    ) {
        parent::__construct();
    }

    protected function configure(): void
    {
        $this->addOption('mailbox', null, InputOption::VALUE_REQUIRED, 'Begränsa och tvinga hämtningen till en inkorg via e-postadress eller namn.');
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $this->processedMessages = 0;
        $this->retryPendingMessages = 0;
        $this->quarantinedMessages = 0;
        $this->moveFailures = 0;

        $io = new SymfonyStyle($input, $output);
        $mailboxFilter = trim((string) $input->getOption('mailbox'));
        /** @var list<SupportMailbox> $mailboxes */
        $mailboxes = $this->entityManager->getRepository(SupportMailbox::class)->findBy(['isActive' => true], ['id' => 'ASC']);
        if ('' !== $mailboxFilter) {
            $normalizedFilter = mb_strtolower($mailboxFilter);
            $mailboxes = array_values(array_filter($mailboxes, static fn (SupportMailbox $mailbox): bool => $mailbox->getEmailAddress() === $normalizedFilter || $mailbox->getName() === $mailboxFilter));
        }

        $polledMailboxes = 0;
        $skippedMailboxes = 0;
        $failedMailboxes = 0;
        foreach ($mailboxes as $mailbox) {
            if ('' === $mailboxFilter && !$mailbox->isDueForPolling()) {
                ++$skippedMailboxes;
                continue;
            }
            ++$polledMailboxes;
            $mailboxHadMessageError = false;
            try {
                $incomingServer = $mailbox->getIncomingServer();
                if ($incomingServer?->supportsIncoming() && 'imap' === $incomingServer->getTransportType()) {
                    if (!$this->imapMailboxFetcher->supports($mailbox)) {
                        throw new \RuntimeException($incomingServer->usesGoogleOAuth()
                            ? 'Google-kontot måste anslutas igen för den här inkorgen.'
                            : 'Inkorgens IMAP-autentisering är ofullständig.');
                    }
                    $mailboxHadMessageError = $this->pollImapMailbox($mailbox, $io);
                }

                foreach ($this->incomingMailSpoolReader->readPendingMessages($mailbox) as $message) {
                    $incomingMail = $this->createIncomingMailFromPayload($mailbox, $message);
                    $this->incomingMailProcessor->process($incomingMail);
                    $this->incomingMailSpoolReader->acknowledge($mailbox, $message['path']);
                    ++$this->processedMessages;
                }

                $mailbox->markPolledNow();
                if ($mailboxHadMessageError) {
                    $mailbox->markPollingFailed('Ett eller flera meddelanden väntar på återförsök eller kunde inte flyttas.');
                }
                $this->entityManager->flush();
            } catch (\Throwable $exception) {
                ++$failedMailboxes;
                if ($exception instanceof GoogleAuthorizationRequiredException) {
                    $mailbox->disconnectGoogle();
                }
                $mailbox->markPollingFailed($exception->getMessage());
                $this->entityManager->flush();
                $this->logger->error('E-posthämtning misslyckades för inkorg.', [
                    'mailbox_id' => $mailbox->getId(),
                    'mailbox_email' => $mailbox->getEmailAddress(),
                    'exception' => $exception,
                ]);
                $io->warning(sprintf('Hämtning misslyckades för "%s": %s', $mailbox->getEmailAddress(), $exception->getMessage()));
            }
        }

        $io->success(sprintf(
            'Hämtning klar: %d inkorgar pollades, %d hoppades över, %d meddelanden behandlades, %d väntar på retry, %d flyttades till Fel, %d flyttfel och %d inkorgar gav fel.',
            $polledMailboxes,
            $skippedMailboxes,
            $this->processedMessages,
            $this->retryPendingMessages,
            $this->quarantinedMessages,
            $this->moveFailures,
            $failedMailboxes,
        ));

        return $failedMailboxes > 0 || $this->quarantinedMessages > 0 || $this->moveFailures > 0 ? Command::FAILURE : Command::SUCCESS;
    }

    private function pollImapMailbox(SupportMailbox $mailbox, SymfonyStyle $io): bool
    {
        $session = $this->imapMailboxFetcher->openSession($mailbox);
        $hadError = false;
        try {
            $session->prepareDestinationFolders();
            $hadError = !$this->reconcilePendingMoves($mailbox, $session);
            foreach ($session->pendingUids() as $remoteUid) {
                $receipt = $this->receiptFor($mailbox, $session->getUidValidity(), $remoteUid);
                if (\in_array($receipt->getState(), [ImapMessageState::COMPLETED, ImapMessageState::QUARANTINED, ImapMessageState::REMOTE_MISSING], true)) {
                    continue;
                }
                if (\in_array($receipt->getState(), [ImapMessageState::PROCESSED_PENDING_MOVE, ImapMessageState::FAILED_PENDING_MOVE], true)) {
                    continue;
                }

                try {
                    $message = $session->fetchMessage($remoteUid);
                    $incomingMail = $this->createIncomingMailFromPayload($mailbox, $message);
                    $receipt->setIncomingMail($incomingMail);
                    $this->incomingMailProcessor->process($incomingMail);
                    if (null === $incomingMail->getProcessingResult()) {
                        throw new \RuntimeException('E-postbehandlingen avslutades utan ett beständigt resultat.');
                    }
                    $receipt->markProcessingSucceeded();
                    $this->entityManager->flush();
                    ++$this->processedMessages;
                    if (!$this->completePendingMove($receipt, $session)) {
                        $hadError = true;
                    }
                } catch (\Throwable $exception) {
                    $incomingMail = $receipt->getIncomingMail();
                    if ($incomingMail instanceof IncomingMail && null !== $incomingMail->getProcessingResult()) {
                        $receipt->markProcessingSucceeded();
                        $this->entityManager->flush();
                        ++$this->processedMessages;
                        $this->logger->warning('Sekundärt fel efter slutförd e-postbehandling.', [
                            'mailbox_id' => $mailbox->getId(),
                            'remote_uid' => $receipt->getRemoteUid(),
                            'exception' => $exception,
                        ]);
                        if (!$this->completePendingMove($receipt, $session)) {
                            $hadError = true;
                        }
                        continue;
                    }

                    $hadError = true;
                    $receipt->markProcessingFailed($exception->getMessage());
                    $this->entityManager->flush();
                    $this->logger->error('E-postmeddelande kunde inte behandlas.', [
                        'mailbox_id' => $mailbox->getId(),
                        'remote_uid' => $receipt->getRemoteUid(),
                        'attempt' => $receipt->getAttemptCount(),
                        'exception' => $exception,
                    ]);
                    if (ImapMessageState::FAILED_PENDING_MOVE === $receipt->getState()) {
                        if (!$this->completePendingMove($receipt, $session)) {
                            $hadError = true;
                        }
                    } else {
                        ++$this->retryPendingMessages;
                        $io->warning(sprintf('Mejl UID %s i %s väntar på försök %d av 3.', $receipt->getRemoteUid(), $mailbox->getEmailAddress(), $receipt->getAttemptCount() + 1));
                    }
                }
            }
        } finally {
            $session->close();
        }

        return $hadError;
    }

    private function reconcilePendingMoves(SupportMailbox $mailbox, ImapMailboxSession $session): bool
    {
        $allMovesCompleted = true;
        /** @var list<ImapMessageReceipt> $receipts */
        $receipts = $this->entityManager->getRepository(ImapMessageReceipt::class)->findBy([
            'mailbox' => $mailbox,
            'uidValidity' => $session->getUidValidity(),
            'state' => [ImapMessageState::PROCESSED_PENDING_MOVE, ImapMessageState::FAILED_PENDING_MOVE],
        ]);
        foreach ($receipts as $receipt) {
            if (!$session->messageExists($receipt->getRemoteUid())) {
                $receipt->markRemoteMissing();
                $this->logger->warning('IMAP-meddelandet saknas när en väntande flytt skulle slutföras.', [
                    'mailbox_id' => $mailbox->getId(),
                    'remote_uid' => $receipt->getRemoteUid(),
                ]);
                continue;
            }
            if (!$this->completePendingMove($receipt, $session)) {
                $allMovesCompleted = false;
            }
        }
        $this->entityManager->flush();

        return $allMovesCompleted;
    }

    private function completePendingMove(ImapMessageReceipt $receipt, ImapMailboxSession $session): bool
    {
        try {
            if (ImapMessageState::FAILED_PENDING_MOVE === $receipt->getState()) {
                $session->moveToError($receipt->getRemoteUid());
                $receipt->markQuarantined();
                ++$this->quarantinedMessages;
            } else {
                $session->moveToProcessed($receipt->getRemoteUid());
                $receipt->markCompleted();
            }
            $this->entityManager->flush();

            return true;
        } catch (\Throwable $exception) {
            ++$this->moveFailures;
            $this->logger->error('IMAP-meddelandet behandlades men kunde inte flyttas.', [
                'mailbox_id' => $receipt->getMailbox()->getId(),
                'remote_uid' => $receipt->getRemoteUid(),
                'destination_state' => $receipt->getState()->value,
                'exception' => $exception,
            ]);

            return false;
        }
    }

    private function receiptFor(SupportMailbox $mailbox, string $uidValidity, string $remoteUid): ImapMessageReceipt
    {
        $receipt = $this->entityManager->getRepository(ImapMessageReceipt::class)->findOneBy([
            'mailbox' => $mailbox,
            'uidValidity' => $uidValidity,
            'remoteUid' => $remoteUid,
        ]);
        if ($receipt instanceof ImapMessageReceipt) { return $receipt; }
        $receipt = new ImapMessageReceipt($mailbox, $uidValidity, $remoteUid);
        $this->entityManager->persist($receipt);
        $this->entityManager->flush();

        return $receipt;
    }

    /** @param array{from?: string, from_name?: ?string, message_id?: ?string, subject?: string, body?: string, raw_message?: ?string, attachments?: list<array{displayName: string, mimeType: ?string, content: string}>} $message */
    private function createIncomingMailFromPayload(SupportMailbox $mailbox, array $message): IncomingMail
    {
        $attachments = $message['attachments'] ?? [];
        $rawMessage = trim((string) ($message['raw_message'] ?? ''));
        if ('' !== $rawMessage) {
            $parsedMessage = $this->emailMimeParser->parse($rawMessage);
            $message = array_replace($message, $parsedMessage);
            $attachments = $parsedMessage['attachments'];
        }
        $messageId = \is_string($message['message_id'] ?? null) ? trim($message['message_id']) : '';
        if ('' !== $messageId) {
            $existingMail = $this->entityManager->getRepository(IncomingMail::class)->findOneBy([
                'mailbox' => $mailbox,
                'messageId' => mb_strtolower($messageId),
            ]);
            if ($existingMail instanceof IncomingMail) { return $existingMail; }
        }
        $incomingMail = new IncomingMail(trim((string) ($message['from'] ?? '')), trim((string) ($message['subject'] ?? '')), trim((string) ($message['body'] ?? '')));
        $incomingMail->setMailbox($mailbox)->setMessageId('' !== $messageId ? $messageId : null)->setFromName(\is_string($message['from_name'] ?? null) ? $message['from_name'] : null);
        $this->entityManager->persist($incomingMail);
        $this->entityManager->flush();
        if ($mailbox->allowsAttachments() && [] !== $attachments) {
            $incomingMail->setAttachmentMetadata($this->incomingMailAttachmentStorage->storeIncomingMailAttachments($incomingMail, $attachments));
            $this->entityManager->flush();
        }

        return $incomingMail;
    }
}
