<?php

declare(strict_types=1);

namespace App\Command;

use App\Module\Identity\Entity\User;
use App\Module\Identity\Enum\UserType;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\Console\Attribute\AsCommand;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Style\SymfonyStyle;
use Symfony\Component\PasswordHasher\Hasher\UserPasswordHasherInterface;

#[AsCommand(
    name: 'app:create-admin',
    description: 'Skapar det första administratörs- eller superadministratörskontot för en ny installation.',
)]
final class CreateInitialAdminCommand extends Command
{
    public function __construct(
        private readonly EntityManagerInterface $entityManager,
        private readonly UserPasswordHasherInterface $passwordHasher,
    ) {
        parent::__construct();
    }

    protected function configure(): void
    {
        $this
            ->addArgument('email', InputArgument::REQUIRED, 'E-postadress')
            ->addArgument('password', InputArgument::REQUIRED, 'Lösenord i klartext')
            ->addArgument('first-name', InputArgument::OPTIONAL, 'Förnamn', 'System')
            ->addArgument('last-name', InputArgument::OPTIONAL, 'Efternamn', 'Admin')
            ->addArgument('type', InputArgument::OPTIONAL, 'admin eller super_admin', UserType::SUPER_ADMIN->value);
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $io = new SymfonyStyle($input, $output);

        $email = mb_strtolower(trim((string) $input->getArgument('email')));
        $password = (string) $input->getArgument('password');
        $firstName = (string) $input->getArgument('first-name');
        $lastName = (string) $input->getArgument('last-name');
        $type = UserType::tryFrom((string) $input->getArgument('type'));

        if (!$type instanceof UserType || !\in_array($type, [UserType::ADMIN, UserType::SUPER_ADMIN], true)) {
            $io->error('Den första kontotypen måste vara admin eller super_admin.');

            return Command::INVALID;
        }

        $existingUser = $this->entityManager
            ->getRepository(User::class)
            ->findOneBy(['email' => $email]);

        if (null !== $existingUser) {
            $io->error(sprintf('En användare med e-postadressen "%s" finns redan.', $email));

            return Command::FAILURE;
        }

        $user = new User($email, $firstName, $lastName, $type);
        $user->setPassword($this->passwordHasher->hashPassword($user, $password));

        $this->entityManager->persist($user);
        $this->entityManager->flush();

        $io->success(sprintf(
            'Skapade %s-konto för %s. Logga in och aktivera MFA från säkerhetsvarningen i administratörsytan så snart som möjligt.',
            $type->label(),
            $user->getEmail(),
        ));

        return Command::SUCCESS;
    }
}
