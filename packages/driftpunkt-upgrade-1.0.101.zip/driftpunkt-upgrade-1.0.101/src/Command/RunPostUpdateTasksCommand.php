<?php

declare(strict_types=1);

namespace App\Command;

use App\Module\System\Service\PostUpdateTaskRunner;
use Psr\Log\LoggerInterface;
use Symfony\Component\Console\Attribute\AsCommand;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Style\SymfonyStyle;

#[AsCommand(
    name: 'app:post-update:run',
    description: 'Behandlar en köad efter-uppdateringskörning i bakgrunden.',
)]
final class RunPostUpdateTasksCommand extends Command
{
    public function __construct(
        private readonly PostUpdateTaskRunner $postUpdateTaskRunner,
        private readonly LoggerInterface $logger,
    ) {
        parent::__construct();
    }

    protected function configure(): void
    {
        $this->addArgument('run-id', InputArgument::REQUIRED, 'ID för köad efter-uppdateringskörning');
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $io = new SymfonyStyle($input, $output);

        try {
            $runId = (string) $input->getArgument('run-id');
            $run = $this->postUpdateTaskRunner->processQueuedRun($runId);
        } catch (\Throwable $exception) {
            $this->logger->error('Efter-uppdateringskörning misslyckades oväntat.', [
                'run_id' => $runId ?? (string) $input->getArgument('run-id'),
                'exception' => $exception,
            ]);
            $io->error($exception->getMessage());

            return Command::FAILURE;
        }

        $io->success(sprintf(
            'Efter-uppdateringskörning %s avslutad med status %s.',
            $run['id'],
            $run['status'],
        ));

        return 'completed' === $run['status'] ? Command::SUCCESS : Command::FAILURE;
    }
}
