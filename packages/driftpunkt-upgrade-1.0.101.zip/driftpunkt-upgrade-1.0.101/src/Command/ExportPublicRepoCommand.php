<?php

declare(strict_types=1);

namespace App\Command;

use App\Module\System\Service\PublicRepoExporter;
use Psr\Log\LoggerInterface;
use Symfony\Component\Console\Attribute\AsCommand;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Style\SymfonyStyle;

#[AsCommand(
    name: 'app:repo:export-public',
    description: 'Exporterar en publik och rensad arbetskopia från det privata Driftpunkt-repot.',
)]
final class ExportPublicRepoCommand extends Command
{
    public function __construct(
        private readonly PublicRepoExporter $publicRepoExporter,
        private readonly LoggerInterface $logger,
    ) {
        parent::__construct();
    }

    protected function configure(): void
    {
        $this->addOption('output-dir', null, InputOption::VALUE_REQUIRED, 'Mapp att exportera den publika arbetskopian till');
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $io = new SymfonyStyle($input, $output);

        try {
            $result = $this->publicRepoExporter->export(
                \is_string($input->getOption('output-dir')) ? $input->getOption('output-dir') : null,
            );
        } catch (\Throwable $exception) {
            $this->logger->error('Kunde inte exportera publik repo-kopia.', [
                'exception' => $exception,
            ]);
            $io->error($exception->getMessage());

            return Command::FAILURE;
        }

        $io->success(sprintf(
            'Publik export skapad i %s med %d filer.',
            $result['outputDirectory'],
            $result['fileCount'],
        ));
        $io->writeln('Kontrollera diffen i det publika repot innan du gör commit och push.');

        return Command::SUCCESS;
    }
}
