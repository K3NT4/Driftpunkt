<?php

declare(strict_types=1);

namespace App\Command;

use App\Module\System\Service\SystemSettings;
use App\Module\Ticket\Entity\Ticket;
use App\Module\Ticket\Enum\TicketStatus;
use App\Module\Ticket\Service\TicketResponseNotifier;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\Console\Attribute\AsCommand;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Style\SymfonyStyle;

#[AsCommand(
    name: 'app:send-ticket-feedback-reminders',
    description: 'Skickar en vänlig omdömespåminnelse för lösta eller stängda ärenden som saknar kundfeedback.',
)]
final class SendTicketFeedbackRemindersCommand extends Command
{
    public function __construct(
        private readonly EntityManagerInterface $entityManager,
        private readonly SystemSettings $systemSettings,
        private readonly TicketResponseNotifier $ticketResponseNotifier,
    ) {
        parent::__construct();
    }

    protected function configure(): void
    {
        $this->addOption('dry-run', null, InputOption::VALUE_NONE, 'Visa hur många påminnelser som skulle skickas utan att skicka e-post.');
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $io = new SymfonyStyle($input, $output);
        $settings = $this->systemSettings->getTicketCustomerFeedbackSettings();
        if (!$settings['enabled'] || !$settings['remindersEnabled']) {
            $io->success('Omdömespåminnelser är avstängda.');

            return Command::SUCCESS;
        }

        $dryRun = (bool) $input->getOption('dry-run');
        $cutoff = (new \DateTimeImmutable())->modify(sprintf('-%d days', $settings['reminderDelayDays']));
        $candidates = $this->feedbackReminderCandidates();
        $eligible = 0;
        $triggered = 0;

        foreach ($candidates as $ticket) {
            $completedAt = TicketStatus::CLOSED === $ticket->getStatus()
                ? ($ticket->getClosedAt() ?? $ticket->getUpdatedAt())
                : $ticket->getUpdatedAt();

            if ($completedAt > $cutoff) {
                continue;
            }

            ++$eligible;
            if ($this->ticketResponseNotifier->notifyCustomerFeedbackReminder($ticket, $dryRun)) {
                ++$triggered;
            }
        }

        $io->success(sprintf(
            '%s: %d kandidater kontrollerades, %d var redo och %d påminnelser %s.',
            $dryRun ? 'Dry-run' : 'Omdömespåminnelser',
            \count($candidates),
            $eligible,
            $triggered,
            $dryRun ? 'skulle skickas' : 'triggades',
        ));

        return Command::SUCCESS;
    }

    /**
     * @return list<Ticket>
     */
    private function feedbackReminderCandidates(): array
    {
        return $this->entityManager->getRepository(Ticket::class)
            ->createQueryBuilder('ticket')
            ->leftJoin('ticket.requester', 'requester')->addSelect('requester')
            ->leftJoin('ticket.feedbackEntries', 'feedback')->addSelect('feedback')
            ->andWhere('ticket.status IN (:statuses)')
            ->andWhere('ticket.requester IS NOT NULL')
            ->andWhere('feedback.id IS NULL')
            ->setParameter('statuses', [TicketStatus::RESOLVED, TicketStatus::CLOSED])
            ->orderBy('ticket.updatedAt', 'ASC')
            ->getQuery()
            ->getResult();
    }
}
