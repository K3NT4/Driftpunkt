<?php

declare(strict_types=1);

namespace App\Command;

use App\Module\System\Service\ReleasePackageBuilder;
use Psr\Log\LoggerInterface;
use Symfony\Component\Console\Attribute\AsCommand;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Style\SymfonyStyle;

#[AsCommand(
    name: 'app:release:build-packages',
    description: 'Bygger uppgraderings- och installationspaket som zip för en Driftpunkt-version.',
)]
final class BuildReleasePackagesCommand extends Command
{
    public function __construct(
        private readonly ReleasePackageBuilder $releasePackageBuilder,
        private readonly LoggerInterface $logger,
    ) {
        parent::__construct();
    }

    protected function configure(): void
    {
        $this
            ->addOption('type', null, InputOption::VALUE_REQUIRED, 'upgrade, install eller both', 'both')
            ->addOption('release-version', null, InputOption::VALUE_REQUIRED, 'Versionsnummer att paketera')
            ->addOption('output-dir', null, InputOption::VALUE_REQUIRED, 'Mapp som zip-filerna ska skrivas till');
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $io = new SymfonyStyle($input, $output);

        try {
            $packages = $this->releasePackageBuilder->buildPackages(
                (string) $input->getOption('type'),
                \is_string($input->getOption('release-version')) ? $input->getOption('release-version') : null,
                \is_string($input->getOption('output-dir')) ? $input->getOption('output-dir') : null,
            );
        } catch (\Throwable $exception) {
            $this->logger->error('Kunde inte bygga versionspaket.', [
                'exception' => $exception,
            ]);
            $io->error($exception->getMessage());

            return Command::FAILURE;
        }

        foreach ($packages as $package) {
            $io->writeln(sprintf(
                '%s-paket skapat: %s (%d filer, %.2f MB, sha256 %s)',
                ucfirst($package['type']),
                $package['path'],
                $package['entries'],
                $package['sizeBytes'] / 1048576,
                substr($package['checksumSha256'], 0, 12).'...',
            ));
        }

        $io->success(sprintf('%d versionspaket skapades.', \count($packages)));

        return Command::SUCCESS;
    }
}
