<?php

declare(strict_types=1);

namespace App\Command;

use Symfony\Component\Console\Attribute\AsCommand;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Style\SymfonyStyle;
use Symfony\Component\DependencyInjection\Attribute\Autowire;
use Symfony\Component\Yaml\Yaml;

#[AsCommand(
    name: 'app:i18n:audit',
    description: 'Kontrollerar att svenska översättningsnycklar har texter i övriga språk för CI.',
)]
final class I18nAuditCommand extends Command
{
    /**
     * @var list<string>
     */
    private const COMMON_SOURCE_TEXTS = [
        'Startsida',
        'Logga in',
        'Språk',
        'Väntar på kund',
        'Återställ lösenord',
        'Månadsrapport',
    ];

    public function __construct(
        #[Autowire('%kernel.project_dir%')]
        private readonly string $projectDir,
    ) {
        parent::__construct();
    }

    protected function configure(): void
    {
        $this
            ->addOption('locale', null, InputOption::VALUE_REQUIRED, 'Mål-locale som ska jämföras mot svenska, eller "all" för alla språkfiler.', 'all')
            ->addOption('strict', null, InputOption::VALUE_NONE, 'Returnera felkod om saknade översättningar hittas.');
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $io = new SymfonyStyle($input, $output);
        $localeOption = strtolower(str_replace('_', '-', trim((string) $input->getOption('locale'))));
        $localeOption = '' !== $localeOption ? $localeOption : 'all';
        $locales = $this->resolveTargetLocales($localeOption);

        if ([] === $locales) {
            $io->error('Inga mål-språk hittades att jämföra mot svenska.');

            return Command::FAILURE;
        }

        try {
            $swedishCatalogue = $this->loadCatalogue('sv');
        } catch (\RuntimeException $exception) {
            $io->error($exception->getMessage());

            return Command::FAILURE;
        }

        $hasProblems = false;
        $checkedLocales = [];

        foreach ($locales as $locale) {
            try {
                $targetCatalogue = $this->loadCatalogue($locale);
            } catch (\RuntimeException $exception) {
                $io->error($exception->getMessage());

                return Command::FAILURE;
            }

            $checkedLocales[] = $locale;
            $missingKeys = [];
            foreach ($swedishCatalogue as $key => $value) {
                if ('' === trim($value)) {
                    continue;
                }

                if (!isset($targetCatalogue[$key]) || '' === trim($targetCatalogue[$key])) {
                    $missingKeys[] = $key;
                }
            }

            $targetOnlyKeys = [];
            foreach (array_keys($targetCatalogue) as $key) {
                if (!array_key_exists($key, $swedishCatalogue)) {
                    $targetOnlyKeys[] = $key;
                }
            }

            $unresolvedSourceTexts = [];
            foreach (self::COMMON_SOURCE_TEXTS as $sourceText) {
                if (!$this->sourceTextResolves($sourceText, $swedishCatalogue, $targetCatalogue)) {
                    $unresolvedSourceTexts[] = $sourceText;
                }
            }

            if ([] === $missingKeys && [] === $targetOnlyKeys && [] === $unresolvedSourceTexts) {
                continue;
            }

            $hasProblems = true;

            if ([] !== $missingKeys) {
                $io->section(sprintf('Saknade %s-översättningar', $locale));
                $io->listing($missingKeys);
            }

            if ([] !== $targetOnlyKeys) {
                $io->section(sprintf('%s-nycklar som saknas i svenska basfilen', $locale));
                $io->listing($targetOnlyKeys);
            }

            if ([] !== $unresolvedSourceTexts) {
                $io->section(sprintf('Svenska källtexter som inte kan översättas till %s', $locale));
                $io->listing($unresolvedSourceTexts);
            }
        }

        if (!$hasProblems) {
            $io->success(sprintf('i18n-audit OK: %d Swedish keys checked against %s.', \count($swedishCatalogue), implode(', ', $checkedLocales)));

            return Command::SUCCESS;
        }

        if ((bool) $input->getOption('strict')) {
            $io->error('i18n-audit hittade saknade eller felplacerade översättningar.');

            return Command::FAILURE;
        }

        $io->warning('i18n-audit hittade saknade eller felplacerade översättningar, men strict-läge är avstängt.');

        return Command::SUCCESS;
    }

    /**
     * @return list<string>
     */
    private function resolveTargetLocales(string $localeOption): array
    {
        if ('all' !== $localeOption) {
            return [$localeOption];
        }

        $paths = glob($this->projectDir.'/translations/messages.*.yaml') ?: [];
        $locales = [];

        foreach ($paths as $path) {
            $filename = basename($path);
            if (!str_starts_with($filename, 'messages.') || !str_ends_with($filename, '.yaml')) {
                continue;
            }

            $locale = substr($filename, 9, -5);
            if ('sv' === $locale || '' === $locale) {
                continue;
            }

            $locales[] = $locale;
        }

        $locales = array_values(array_unique($locales));
        sort($locales);

        return $locales;
    }

    /**
     * @return array<string, string>
     */
    private function loadCatalogue(string $locale): array
    {
        $path = sprintf('%s/translations/messages.%s.yaml', $this->projectDir, $locale);
        if (!is_file($path)) {
            throw new \RuntimeException(sprintf('Översättningsfil saknas: %s', $path));
        }

        $parsed = Yaml::parseFile($path);
        if (!\is_array($parsed)) {
            return [];
        }

        return $this->flattenCatalogue($parsed);
    }

    /**
     * @param array<mixed> $catalogue
     *
     * @return array<string, string>
     */
    private function flattenCatalogue(array $catalogue, string $prefix = ''): array
    {
        $flattened = [];
        foreach ($catalogue as $key => $value) {
            if (!\is_string($key) && !\is_int($key)) {
                continue;
            }

            $fullKey = '' !== $prefix ? $prefix.'.'.$key : (string) $key;
            if (\is_array($value)) {
                $flattened += $this->flattenCatalogue($value, $fullKey);

                continue;
            }

            if (\is_scalar($value) || null === $value) {
                $flattened[$fullKey] = trim((string) $value);
            }
        }

        return $flattened;
    }

    /**
     * @param array<string, string> $swedishCatalogue
     * @param array<string, string> $targetCatalogue
     */
    private function sourceTextResolves(string $sourceText, array $swedishCatalogue, array $targetCatalogue): bool
    {
        if (isset($targetCatalogue[$sourceText]) && '' !== trim($targetCatalogue[$sourceText])) {
            return true;
        }

        foreach ($swedishCatalogue as $key => $value) {
            if ($value !== $sourceText) {
                continue;
            }

            $translation = $targetCatalogue[$key] ?? '';
            if ('' !== trim($translation) && $translation !== $sourceText) {
                return true;
            }
        }

        return false;
    }
}
