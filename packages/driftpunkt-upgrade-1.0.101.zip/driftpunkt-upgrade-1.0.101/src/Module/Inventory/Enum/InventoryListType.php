<?php

declare(strict_types=1);

namespace App\Module\Inventory\Enum;

enum InventoryListType: string
{
    case COMPUTER = 'computer';
    case PRINTER = 'printer';

    public function label(): string
    {
        return match ($this) {
            self::COMPUTER => 'Datorlista',
            self::PRINTER => 'Skrivarlista',
        };
    }

    public function pluralLabel(): string
    {
        return match ($this) {
            self::COMPUTER => 'Datorer',
            self::PRINTER => 'Skrivare',
        };
    }

    public function customerRoute(): string
    {
        return match ($this) {
            self::COMPUTER => 'app_inventory_customer_computers',
            self::PRINTER => 'app_inventory_customer_printers',
        };
    }
}
