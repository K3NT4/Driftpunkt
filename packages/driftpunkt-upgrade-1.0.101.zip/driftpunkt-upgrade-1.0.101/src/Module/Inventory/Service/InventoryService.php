<?php

declare(strict_types=1);

namespace App\Module\Inventory\Service;

use App\Module\Identity\Entity\Company;
use App\Module\Identity\Entity\User;
use App\Module\Identity\Enum\UserType;
use App\Module\Inventory\Entity\InventoryAuditLog;
use App\Module\Inventory\Entity\InventoryItem;
use App\Module\Inventory\Entity\InventoryListSetting;
use App\Module\Inventory\Enum\InventoryListType;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\HttpFoundation\File\UploadedFile;

final class InventoryService
{
    public function __construct(
        private readonly EntityManagerInterface $entityManager,
    ) {
    }

    public function setting(Company $company, InventoryListType $type, bool $create = false): ?InventoryListSetting
    {
        $setting = $this->entityManager->getRepository(InventoryListSetting::class)->findOneBy([
            'company' => $company,
            'type' => $type,
        ]);

        if (!$setting instanceof InventoryListSetting && $create) {
            $setting = new InventoryListSetting($company, $type);
            $this->entityManager->persist($setting);
        }

        return $setting instanceof InventoryListSetting ? $setting : null;
    }

    public function isEnabled(?Company $company, InventoryListType|string $type): bool
    {
        if (!$company instanceof Company) {
            return false;
        }

        $type = \is_string($type) ? InventoryListType::tryFrom($type) : $type;
        if (!$type instanceof InventoryListType) {
            return false;
        }

        return true === $this->setting($company, $type)?->isEnabled();
    }

    public function hasAnyEnabledList(): bool
    {
        return $this->entityManager->getRepository(InventoryListSetting::class)->count(['enabled' => true]) > 0;
    }

    /**
     * @return array{computer: array{enabled: bool, count: int, lastImportedAt: ?\DateTimeImmutable, lastImportFilename: ?string, accessRestricted: bool, allowedUserIds: list<int>, allowedUsers: list<User>}, printer: array{enabled: bool, count: int, lastImportedAt: ?\DateTimeImmutable, lastImportFilename: ?string, accessRestricted: bool, allowedUserIds: list<int>, allowedUsers: list<User>}}
     */
    public function companySummary(Company $company): array
    {
        $summary = [];
        foreach (InventoryListType::cases() as $type) {
            $setting = $this->setting($company, $type);
            $allowedUsers = $setting instanceof InventoryListSetting
                ? $this->sortUsers($setting->getAllowedUsers()->toArray())
                : [];
            $summary[$type->value] = [
                'enabled' => $setting?->isEnabled() ?? false,
                'count' => $this->countItems($company, $type),
                'lastImportedAt' => $setting?->getLastImportedAt(),
                'lastImportFilename' => $setting?->getLastImportFilename(),
                'accessRestricted' => $setting?->isAccessRestricted() ?? false,
                'allowedUserIds' => array_values(array_filter(array_map(static fn (User $user): ?int => $user->getId(), $allowedUsers))),
                'allowedUsers' => $allowedUsers,
            ];
        }

        return $summary;
    }

    public function canUserAccessList(?User $user, InventoryListType|string $type): bool
    {
        if (!$user instanceof User || !$user->isActive() || UserType::CUSTOMER !== $user->getType()) {
            return false;
        }

        $company = $user->getCompany();
        if (!$company instanceof Company) {
            return false;
        }

        $type = \is_string($type) ? InventoryListType::tryFrom($type) : $type;
        if (!$type instanceof InventoryListType) {
            return false;
        }

        $setting = $this->setting($company, $type);
        if (!$setting instanceof InventoryListSetting || !$setting->isEnabled()) {
            return false;
        }

        $userId = $user->getId();
        if (null === $userId) {
            return false;
        }

        foreach ($setting->getAllowedUsers() as $allowedUser) {
            if ($allowedUser->isActive() && $allowedUser->getId() === $userId && $this->isEligibleCustomerUser($company, $allowedUser)) {
                return true;
            }
        }

        return false;
    }

    /**
     * @return list<User>
     */
    public function customerUsers(Company $company): array
    {
        return $this->sortUsers(array_values(array_filter(
            $company->getUsers()->toArray(),
            fn (User $user): bool => $this->isEligibleCustomerUser($company, $user),
        )));
    }

    public function countItems(Company $company, InventoryListType $type): int
    {
        return $this->entityManager->getRepository(InventoryItem::class)->count([
            'company' => $company,
            'type' => $type,
        ]);
    }

    /**
     * @return list<InventoryItem>
     */
    public function items(Company $company, InventoryListType $type, string $query = '', ?string $sort = null, string $direction = 'asc'): array
    {
        $sort = $this->validSortColumn($type, $sort);
        $direction = 'desc' === mb_strtolower($direction) ? 'DESC' : 'ASC';

        $qb = $this->entityManager->getRepository(InventoryItem::class)->createQueryBuilder('item')
            ->andWhere('item.company = :company')
            ->andWhere('item.type = :type')
            ->setParameter('company', $company)
            ->setParameter('type', $type)
            ->orderBy('item.'.$sort, $direction)
            ->addOrderBy('item.updatedAt', 'DESC')
            ->addOrderBy('item.id', 'ASC');

        $query = mb_strtolower(trim($query));
        if ('' !== $query) {
            $qb
                ->andWhere('LOWER(CONCAT(COALESCE(item.hostname, \'\'), \' \', COALESCE(item.assignedTo, \'\'), \' \', COALESCE(item.manufacturer, \'\'), \' \', COALESCE(item.model, \'\'), \' \', COALESCE(item.serialNumber, \'\'), \' \', COALESCE(item.ipAddress, \'\'), \' \', COALESCE(item.printerName, \'\'), \' \', COALESCE(item.area, \'\'))) LIKE :query')
                ->setParameter('query', '%'.$query.'%');
        }

        return $qb->getQuery()->getResult();
    }

    /**
     * @return array{imported: int, removed: int}
     */
    public function importCsv(Company $company, InventoryListType $type, UploadedFile $file, User $actor): array
    {
        $rows = $this->parseCsv($file);
        $this->validateCsvHeaders($type, array_keys($rows[0] ?? []));
        $items = [];
        $seenUniqueValues = [];
        foreach ($rows as $row) {
            $item = new InventoryItem($company, $type);
            $data = $this->dataFromCsvRow($type, $row);
            $normalizedUniqueValue = $this->normalizedUniqueValue($data[$this->uniqueField($type)] ?? null);
            if ('' !== $normalizedUniqueValue) {
                if (isset($seenUniqueValues[$normalizedUniqueValue])) {
                    throw new \InvalidArgumentException($this->duplicateMessage($type));
                }
                $seenUniqueValues[$normalizedUniqueValue] = true;
            }

            $item->applyData($data);
            $items[] = $item;
        }

        $removed = $this->deleteItems($company, $type);
        foreach ($items as $item) {
            $this->entityManager->persist($item);
        }

        $setting = $this->setting($company, $type, true);
        \assert($setting instanceof InventoryListSetting);
        $setting->markImported($file->getClientOriginalName());
        $this->log($company, $type, $actor, 'import', [
            'filename' => $file->getClientOriginalName(),
            'imported' => \count($items),
            'removed' => $removed,
        ]);
        $this->entityManager->flush();

        return ['imported' => \count($items), 'removed' => $removed];
    }

    /**
     * @param array<string, mixed> $data
     */
    public function createItem(Company $company, InventoryListType $type, array $data, User $actor): InventoryItem
    {
        $item = new InventoryItem($company, $type);
        $normalizedData = $this->normalizeFormData($type, $data);
        $this->assertUniqueValueAvailable($company, $type, $normalizedData);
        $item->applyData($normalizedData);
        $this->entityManager->persist($item);
        $this->log($company, $type, $actor, 'item_created', ['item' => $item->snapshot()]);
        $this->entityManager->flush();

        return $item;
    }

    /**
     * @param array<string, mixed> $data
     */
    public function updateItem(InventoryItem $item, array $data, User $actor): void
    {
        $before = $item->snapshot();
        $normalizedData = $this->normalizeFormData($item->getType(), $data);
        $this->assertUniqueValueAvailable($item->getCompany(), $item->getType(), $normalizedData, $item);
        $item->applyData($normalizedData);
        $after = $item->snapshot();
        $this->log($item->getCompany(), $item->getType(), $actor, 'item_updated', [
            'itemId' => $item->getId(),
            'before' => $before,
            'after' => $after,
        ]);
        $this->entityManager->flush();
    }

    public function deleteItem(InventoryItem $item, User $actor): void
    {
        $this->log($item->getCompany(), $item->getType(), $actor, 'item_deleted', [
            'itemId' => $item->getId(),
            'item' => $item->snapshot(),
        ]);
        $this->entityManager->remove($item);
        $this->entityManager->flush();
    }

    public function setEnabled(Company $company, InventoryListType $type, bool $enabled, User $actor): void
    {
        $setting = $this->setting($company, $type, true);
        \assert($setting instanceof InventoryListSetting);
        $setting->setEnabled($enabled);
        $this->log($company, $type, $actor, $enabled ? 'enabled' : 'disabled', ['rowCount' => $this->countItems($company, $type)]);
        $this->entityManager->flush();
    }

    /**
     * @param list<int> $allowedUserIds
     */
    public function setAccess(Company $company, InventoryListType $type, bool $restricted, array $allowedUserIds, User $actor): void
    {
        $setting = $this->setting($company, $type, true);
        \assert($setting instanceof InventoryListSetting);

        $setting->setAccessRestricted(true);
        $setting->clearAllowedUsers();

        if ([] !== $allowedUserIds) {
            $users = $this->entityManager->getRepository(User::class)->findBy(['id' => array_values(array_unique($allowedUserIds))]);
            foreach ($users as $user) {
                if ($this->isEligibleCustomerUser($company, $user)) {
                    $setting->addAllowedUser($user);
                }
            }
        }

        $this->log($company, $type, $actor, 'access_updated', [
            'restricted' => $setting->isAccessRestricted(),
            'allowedUserIds' => array_values(array_filter(array_map(
                static fn (User $user): ?int => $user->getId(),
                $setting->getAllowedUsers()->toArray(),
            ))),
        ]);
        $this->entityManager->flush();
    }

    public function deleteList(Company $company, InventoryListType $type, User $actor): int
    {
        $rowCount = $this->countItems($company, $type);
        $this->deleteItems($company, $type);
        $setting = $this->setting($company, $type);
        if ($setting instanceof InventoryListSetting) {
            $this->entityManager->remove($setting);
        }

        $this->log($company, $type, $actor, 'list_deleted', ['rowCount' => $rowCount]);
        $this->entityManager->flush();

        return $rowCount;
    }

    /**
     * @return list<array{key: string, label: string}>
     */
    public function columns(InventoryListType $type): array
    {
        return match ($type) {
            InventoryListType::COMPUTER => [
                ['key' => 'hostname', 'label' => 'Hostname'],
                ['key' => 'assignedTo', 'label' => 'Användare / Avdelning'],
                ['key' => 'manufacturer', 'label' => 'Fabrikat'],
                ['key' => 'model', 'label' => 'Modell'],
                ['key' => 'serialNumber', 'label' => 'SN:'],
                ['key' => 'operatingSystem', 'label' => 'OS'],
                ['key' => 'processor', 'label' => 'Processor'],
                ['key' => 'memory', 'label' => 'Minne'],
                ['key' => 'storage', 'label' => 'HD'],
                ['key' => 'purchaseDate', 'label' => 'Inköpsdatum'],
                ['key' => 'warrantyEndsAt', 'label' => 'Sluttid för garantin'],
                ['key' => 'broken', 'label' => 'Trasig'],
                ['key' => 'comment', 'label' => 'Kommentar'],
            ],
            InventoryListType::PRINTER => [
                ['key' => 'ipAddress', 'label' => 'IP'],
                ['key' => 'printerKind', 'label' => 'Vad för skrivare'],
                ['key' => 'printerName', 'label' => 'Skrivarens Namn'],
                ['key' => 'area', 'label' => 'Område'],
                ['key' => 'serialNumber', 'label' => 'Serinummer'],
                ['key' => 'color', 'label' => 'Färg'],
                ['key' => 'model', 'label' => 'Modell'],
                ['key' => 'available', 'label' => 'Tillgänglig'],
                ['key' => 'installationDate', 'label' => 'Installation'],
                ['key' => 'pin', 'label' => 'PIN'],
            ],
        };
    }

    public function value(InventoryItem $item, string $key): string
    {
        $snapshot = $item->snapshot();
        $value = $snapshot[$key] ?? null;
        if (\is_bool($value)) {
            return $value ? 'Ja' : 'Nej';
        }

        return (string) $value;
    }

    private function validSortColumn(InventoryListType $type, ?string $sort): string
    {
        $columnKeys = array_column($this->columns($type), 'key');
        if (\is_string($sort) && \in_array($sort, $columnKeys, true)) {
            return $sort;
        }

        return InventoryListType::COMPUTER === $type ? 'hostname' : 'printerName';
    }

    /**
     * @param array<string, mixed> $data
     */
    private function assertUniqueValueAvailable(Company $company, InventoryListType $type, array $data, ?InventoryItem $currentItem = null): void
    {
        $field = $this->uniqueField($type);
        $value = $this->normalizedUniqueValue($data[$field] ?? null);
        if ('' === $value) {
            return;
        }

        $items = $this->entityManager->getRepository(InventoryItem::class)->findBy([
            'company' => $company,
            'type' => $type,
        ]);

        foreach ($items as $item) {
            if ($currentItem instanceof InventoryItem && $item->getId() === $currentItem->getId()) {
                continue;
            }

            $candidate = InventoryListType::COMPUTER === $type ? $item->getHostname() : $item->getIpAddress();
            if ($value === $this->normalizedUniqueValue($candidate)) {
                throw new \InvalidArgumentException($this->duplicateMessage($type));
            }
        }
    }

    private function uniqueField(InventoryListType $type): string
    {
        return InventoryListType::COMPUTER === $type ? 'hostname' : 'ipAddress';
    }

    private function duplicateMessage(InventoryListType $type): string
    {
        return InventoryListType::COMPUTER === $type
            ? 'Hostname finns redan i den här datorlistan.'
            : 'IP finns redan i den här skrivarlistan.';
    }

    private function normalizedUniqueValue(mixed $value): string
    {
        return mb_strtolower(trim((string) $value));
    }

    private function deleteItems(Company $company, InventoryListType $type): int
    {
        $items = $this->entityManager->getRepository(InventoryItem::class)->findBy([
            'company' => $company,
            'type' => $type,
        ]);
        foreach ($items as $item) {
            $this->entityManager->remove($item);
        }

        return \count($items);
    }

    /**
     * @return list<array<string, string>>
     */
    private function parseCsv(UploadedFile $file): array
    {
        if (!$file->isValid()) {
            throw new \InvalidArgumentException('CSV-filen kunde inte läsas.');
        }

        $sample = (string) file_get_contents($file->getPathname(), false, null, 0, 4096);
        $delimiter = $this->detectDelimiter($sample);
        $csv = new \SplFileObject($file->getPathname(), 'r');
        $csv->setCsvControl($delimiter, '"', '');
        $csv->setFlags(\SplFileObject::READ_CSV | \SplFileObject::SKIP_EMPTY);

        $headers = [];
        $rows = [];
        foreach ($csv as $cells) {
            if (!\is_array($cells) || [null] === $cells) {
                continue;
            }

            $values = array_map(static fn (mixed $value): string => trim((string) $value), $cells);
            if ([] === array_filter($values, static fn (string $value): bool => '' !== $value)) {
                continue;
            }

            if ([] === $headers) {
                $headers = array_map(fn (string $header): string => $this->cleanHeader($header), $values);
                continue;
            }

            $row = [];
            foreach ($headers as $index => $header) {
                $row[$header] = $values[$index] ?? '';
            }
            $rows[] = $row;
        }

        if ([] === $headers || [] === $rows) {
            throw new \InvalidArgumentException('CSV-filen behöver minst en rubrikrad och en datarad.');
        }

        return $rows;
    }

    /**
     * @param array<string, string> $row
     * @return array<string, mixed>
     */
    private function dataFromCsvRow(InventoryListType $type, array $row): array
    {
        $lookup = [];
        foreach ($row as $header => $value) {
            $lookup[$this->normalizeHeader($header)] = $value;
        }

        $get = fn (string ...$headers): string => $this->firstHeaderValue($lookup, $headers);

        if (InventoryListType::COMPUTER === $type) {
            return [
                'hostname' => $get('Hostname'),
                'assignedTo' => $get('Användare / Avdelning', 'Anvandare / Avdelning'),
                'manufacturer' => $get('Fabrikat'),
                'model' => $get('Modell'),
                'serialNumber' => $get('SN:', 'SN', 'Serienummer', 'Serinummer'),
                'operatingSystem' => $get('OS'),
                'processor' => $get('Processor'),
                'memory' => $get('Minne'),
                'storage' => $get('HD'),
                'purchaseDate' => $this->parseDate($get('Inköpsdatum', 'Inkopsdatum')),
                'warrantyEndsAt' => $this->parseDate($get('Sluttid för garantin', 'Sluttid for garantin')),
                'broken' => $this->parseBool($get('Trasig')),
                'comment' => $get('Kommentar'),
            ];
        }

        return [
            'ipAddress' => $get('IP'),
            'printerKind' => $get('Vad för skrivare', 'Vad for skrivare'),
            'printerName' => $get('Skrivarens Namn', 'Skrivarens namn'),
            'area' => $get('Område', 'Omrade'),
            'serialNumber' => $get('Serinummer', 'Serienummer'),
            'color' => $get('Färg', 'Farg'),
            'model' => $get('Modell'),
            'available' => $this->parseBool($get('Tillgänglig', 'Tillganglig')),
            'installationDate' => $this->parseDate($get('Installation')),
            'pin' => $get('PIN'),
        ];
    }

    /**
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    private function normalizeFormData(InventoryListType $type, array $data): array
    {
        $normalized = [];
        foreach ($this->columns($type) as $column) {
            $key = $column['key'];
            $value = $data[$key] ?? null;
            if (\in_array($key, ['purchaseDate', 'warrantyEndsAt', 'installationDate'], true)) {
                $value = $this->parseDate((string) $value);
            } elseif (\in_array($key, ['broken', 'available'], true)) {
                $value = filter_var($value, \FILTER_VALIDATE_BOOL);
            }
            $normalized[$key] = $value;
        }

        return $normalized;
    }

    private function cleanHeader(string $header): string
    {
        return trim(preg_replace('/^\xEF\xBB\xBF/', '', $header) ?? $header);
    }

    private function normalizeHeader(string $header): string
    {
        $ascii = iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $header);
        $normalized = strtolower((string) ($ascii ?: $header));

        return preg_replace('/[^a-z0-9]+/', '', $normalized) ?? '';
    }

    /**
     * @param array<string, string> $lookup
     * @param list<string> $headers
     */
    private function firstHeaderValue(array $lookup, array $headers): string
    {
        foreach ($headers as $header) {
            $key = $this->normalizeHeader($header);
            if (array_key_exists($key, $lookup)) {
                return trim($lookup[$key]);
            }
        }

        return '';
    }

    private function parseDate(string $value): ?\DateTimeImmutable
    {
        $value = trim($value);
        if ('' === $value) {
            return null;
        }

        foreach (['Y-m-d', 'Y/m/d', 'd/m/Y', 'd.m.Y'] as $format) {
            $date = \DateTimeImmutable::createFromFormat('!'.$format, $value);
            if ($date instanceof \DateTimeImmutable) {
                return $date;
            }
        }

        try {
            return new \DateTimeImmutable($value);
        } catch (\Throwable) {
            return null;
        }
    }

    private function parseBool(string $value): bool
    {
        return \in_array(mb_strtolower(trim($value)), ['1', 'ja', 'yes', 'true', 'på', 'pa', 'x'], true);
    }

    private function isEligibleCustomerUser(Company $company, User $user): bool
    {
        return $user->isActive()
            && UserType::CUSTOMER === $user->getType()
            && $user->getCompany()?->getId() === $company->getId();
    }

    /**
     * @param list<User> $users
     * @return list<User>
     */
    private function sortUsers(array $users): array
    {
        usort(
            $users,
            static fn (User $left, User $right): int => [$left->getDisplayName(), $left->getEmail(), $left->getId() ?? 0]
                <=> [$right->getDisplayName(), $right->getEmail(), $right->getId() ?? 0],
        );

        return $users;
    }

    /**
     * @param list<string> $headers
     */
    private function validateCsvHeaders(InventoryListType $type, array $headers): void
    {
        $present = array_fill_keys(array_map(fn (string $header): string => $this->normalizeHeader($header), $headers), true);
        $missing = [];
        foreach ($this->columns($type) as $column) {
            $normalized = $this->normalizeHeader($column['label']);
            if (!isset($present[$normalized])) {
                $missing[] = $column['label'];
            }
        }

        if ([] !== $missing) {
            throw new \InvalidArgumentException(sprintf('CSV-filen saknar kolumner: %s.', implode(', ', $missing)));
        }
    }

    private function detectDelimiter(string $sample): string
    {
        $line = strtok($sample, "\r\n") ?: '';
        $best = ',';
        $bestCount = -1;
        foreach ([',', ';', "\t"] as $delimiter) {
            $count = substr_count($line, $delimiter);
            if ($count > $bestCount) {
                $best = $delimiter;
                $bestCount = $count;
            }
        }

        return $best;
    }

    /**
     * @param array<string, mixed> $details
     */
    private function log(Company $company, InventoryListType $type, ?User $actor, string $action, array $details): void
    {
        $this->entityManager->persist(new InventoryAuditLog($company, $type, $actor, $action, $details));
    }
}
