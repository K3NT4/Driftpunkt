<?php

declare(strict_types=1);

namespace App\Module\Inventory\Entity;

use App\Module\Identity\Entity\Company;
use App\Module\Identity\Entity\User;
use App\Module\Inventory\Enum\InventoryListType;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity]
#[ORM\Table(name: 'inventory_audit_logs')]
#[ORM\Index(name: 'idx_inventory_audit_company_type', columns: ['company_id', 'type'])]
class InventoryAuditLog
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\ManyToOne(targetEntity: Company::class)]
    #[ORM\JoinColumn(nullable: false, onDelete: 'CASCADE')]
    private Company $company;

    #[ORM\Column(enumType: InventoryListType::class)]
    private InventoryListType $type;

    #[ORM\ManyToOne(targetEntity: User::class)]
    #[ORM\JoinColumn(onDelete: 'SET NULL', nullable: true)]
    private ?User $actor;

    #[ORM\Column(length: 80)]
    private string $action;

    #[ORM\Column(type: 'json')]
    private array $details;

    #[ORM\Column]
    private \DateTimeImmutable $createdAt;

    /**
     * @param array<string, mixed> $details
     */
    public function __construct(Company $company, InventoryListType $type, ?User $actor, string $action, array $details = [])
    {
        $this->company = $company;
        $this->type = $type;
        $this->actor = $actor;
        $this->action = mb_substr(trim($action), 0, 80);
        $this->details = $details;
        $this->createdAt = new \DateTimeImmutable();
    }

    public function getId(): ?int { return $this->id; }
    public function getCompany(): Company { return $this->company; }
    public function getType(): InventoryListType { return $this->type; }
    public function getActor(): ?User { return $this->actor; }
    public function getAction(): string { return $this->action; }
    public function getDetails(): array { return $this->details; }
    public function getCreatedAt(): \DateTimeImmutable { return $this->createdAt; }
}
