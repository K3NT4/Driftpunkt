<?php

declare(strict_types=1);

namespace App\Module\Inventory\Entity;

use App\Module\Identity\Entity\Company;
use App\Module\Identity\Entity\User;
use App\Module\Inventory\Enum\InventoryListType;
use App\Module\Shared\Entity\TimestampableTrait;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity]
#[ORM\Table(name: 'inventory_list_settings')]
#[ORM\UniqueConstraint(name: 'uniq_inventory_list_company_type', columns: ['company_id', 'type'])]
#[ORM\HasLifecycleCallbacks]
class InventoryListSetting
{
    use TimestampableTrait;

    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\ManyToOne(targetEntity: Company::class)]
    #[ORM\JoinColumn(nullable: false, onDelete: 'CASCADE')]
    private Company $company;

    #[ORM\Column(enumType: InventoryListType::class)]
    private InventoryListType $type;

    #[ORM\Column(options: ['default' => false])]
    private bool $enabled = false;

    #[ORM\Column(options: ['default' => false])]
    private bool $accessRestricted = false;

    /**
     * @var Collection<int, User>
     */
    #[ORM\ManyToMany(targetEntity: User::class)]
    #[ORM\JoinTable(name: 'inventory_list_allowed_users')]
    #[ORM\JoinColumn(name: 'list_setting_id', referencedColumnName: 'id', onDelete: 'CASCADE')]
    #[ORM\InverseJoinColumn(name: 'user_id', referencedColumnName: 'id', onDelete: 'CASCADE')]
    private Collection $allowedUsers;

    #[ORM\Column(nullable: true)]
    private ?\DateTimeImmutable $lastImportedAt = null;

    #[ORM\Column(length: 255, nullable: true)]
    private ?string $lastImportFilename = null;

    public function __construct(Company $company, InventoryListType $type)
    {
        $this->company = $company;
        $this->type = $type;
        $this->allowedUsers = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getCompany(): Company
    {
        return $this->company;
    }

    public function getType(): InventoryListType
    {
        return $this->type;
    }

    public function isEnabled(): bool
    {
        return $this->enabled;
    }

    public function setEnabled(bool $enabled): self
    {
        $this->enabled = $enabled;

        return $this;
    }

    public function isAccessRestricted(): bool
    {
        return $this->accessRestricted;
    }

    public function setAccessRestricted(bool $accessRestricted): self
    {
        $this->accessRestricted = $accessRestricted;

        return $this;
    }

    /**
     * @return Collection<int, User>
     */
    public function getAllowedUsers(): Collection
    {
        return $this->allowedUsers;
    }

    public function addAllowedUser(User $user): self
    {
        if (!$this->allowedUsers->contains($user)) {
            $this->allowedUsers->add($user);
        }

        return $this;
    }

    public function clearAllowedUsers(): self
    {
        $this->allowedUsers->clear();

        return $this;
    }

    public function getLastImportedAt(): ?\DateTimeImmutable
    {
        return $this->lastImportedAt;
    }

    public function markImported(string $filename): self
    {
        $this->lastImportedAt = new \DateTimeImmutable();
        $this->lastImportFilename = mb_substr(trim($filename), 0, 255) ?: null;

        return $this;
    }

    public function getLastImportFilename(): ?string
    {
        return $this->lastImportFilename;
    }
}
