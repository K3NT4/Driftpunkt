<?php

declare(strict_types=1);

namespace App\Module\System\Service;

use Symfony\Component\DependencyInjection\Attribute\Autowire;
use Symfony\Component\HttpFoundation\File\UploadedFile;

final class DatabaseMaintenanceService
{
    public function __construct(
        #[Autowire('%kernel.project_dir%')]
        private readonly string $projectDir,
    ) {
    }

    /**
     * @return array{
     *     driver: string,
     *     path: string,
     *     exists: bool,
     *     sizeBytes: int,
     *     modifiedAt: ?\DateTimeImmutable
     * }
     */
    public function describeSqliteDatabase(string $databasePath): array
    {
        $exists = is_file($databasePath);

        return [
            'driver' => 'sqlite',
            'path' => $databasePath,
            'exists' => $exists,
            'sizeBytes' => $exists ? (int) filesize($databasePath) : 0,
            'modifiedAt' => $exists ? $this->createDateTimeFromTimestamp((int) filemtime($databasePath)) : null,
        ];
    }

    /**
     * @return list<array{
     *     filename: string,
     *     path: string,
     *     sizeBytes: int,
     *     createdAt: \DateTimeImmutable,
     *     sourceLabel: string,
     *     format: string
     * }>
     */
    public function listBackups(): array
    {
        $directory = $this->backupDirectory();
        if (!is_dir($directory)) {
            return [];
        }

        $backups = [];
        foreach (glob($directory.\DIRECTORY_SEPARATOR.'*.zip') ?: [] as $path) {
            $metadata = $this->readBackupMetadata($path);
            if (null === $metadata) {
                continue;
            }

            $backups[] = $metadata;
        }

        usort(
            $backups,
            static fn (array $left, array $right): int => $right['createdAt']->getTimestamp() <=> $left['createdAt']->getTimestamp(),
        );

        return $backups;
    }

    /**
     * @return array{
     *     filename: string,
     *     path: string,
     *     sizeBytes: int,
     *     createdAt: \DateTimeImmutable,
     *     sourceLabel: string,
     *     format: string
     * }
     */
    public function createSqliteBackup(string $databasePath): array
    {
        $this->assertReadableSqliteDatabase($databasePath);

        $temporaryDatabasePath = $this->temporaryPath('sqlite-backup-');
        $source = new \SQLite3($databasePath, \SQLITE3_OPEN_READONLY);
        $destination = new \SQLite3($temporaryDatabasePath);
        $source->backup($destination);
        $destination->close();
        $source->close();

        $createdAt = new \DateTimeImmutable();
        $filename = sprintf('driftpunkt_db_backup_%s_%s.zip', $createdAt->format('Ymd_His_u'), bin2hex(random_bytes(3)));
        $backupPath = $this->backupDirectory().\DIRECTORY_SEPARATOR.$filename;

        $zip = new \ZipArchive();
        $result = $zip->open($backupPath, \ZipArchive::CREATE | \ZipArchive::OVERWRITE);
        if (true !== $result) {
            @unlink($temporaryDatabasePath);

            throw new \RuntimeException('Kunde inte skapa zip-säkerhetskopia för databasen.');
        }

        $zip->addFile($temporaryDatabasePath, 'database.sqlite');
        $zip->addFromString('manifest.json', json_encode([
            'createdAt' => $createdAt->format(DATE_ATOM),
            'sourceLabel' => basename($databasePath),
            'format' => 'sqlite_zip_backup',
        ], \JSON_PRETTY_PRINT | \JSON_THROW_ON_ERROR));
        $zip->close();

        @unlink($temporaryDatabasePath);

        $metadata = $this->readBackupMetadata($backupPath);
        if (null === $metadata) {
            throw new \RuntimeException('Backupen skapades men kunde inte läsas tillbaka.');
        }

        return $metadata;
    }

    /**
     * @return array{
     *     filename: string,
     *     path: string,
     *     sizeBytes: int,
     *     createdAt: \DateTimeImmutable,
     *     sourceLabel: string,
     *     format: string
     * }
     */
    public function createBackup(string $databaseReference): array
    {
        if ($this->isMariaDbReference($databaseReference)) {
            return $this->createMariaDbBackup($databaseReference);
        }

        return $this->createSqliteBackup($databaseReference);
    }

    /**
     * @return array{
     *     beforeSizeBytes: int,
     *     afterSizeBytes: int,
     *     optimizedAt: \DateTimeImmutable
     * }
     */
    public function optimizeSqliteDatabase(string $databasePath): array
    {
        $this->assertReadableSqliteDatabase($databasePath);

        $beforeSizeBytes = (int) filesize($databasePath);
        $database = new \SQLite3($databasePath);
        $database->exec('PRAGMA optimize');
        $database->exec('ANALYZE');
        $database->exec('VACUUM');
        $database->close();

        clearstatcache(true, $databasePath);

        return [
            'beforeSizeBytes' => $beforeSizeBytes,
            'afterSizeBytes' => (int) filesize($databasePath),
            'optimizedAt' => new \DateTimeImmutable(),
        ];
    }

    /**
     * @return array{
     *     beforeSizeBytes: int,
     *     afterSizeBytes: int,
     *     optimizedAt: \DateTimeImmutable,
     *     output?: string
     * }
     */
    public function optimizeDatabase(string $databaseReference): array
    {
        if ($this->isMariaDbReference($databaseReference)) {
            return $this->analyzeMariaDbDatabase($databaseReference);
        }

        return $this->optimizeSqliteDatabase($databaseReference);
    }

    /**
     * @return array{
     *     restoredFrom: string,
     *     previousBackup: array{
     *         filename: string,
     *         path: string,
     *         sizeBytes: int,
     *         createdAt: \DateTimeImmutable,
     *         sourceLabel: string,
     *         format: string
     *     }
     * }
     */
    public function restoreSqliteBackup(string $databasePath, UploadedFile $uploadedFile): array
    {
        $this->assertReadableSqliteDatabase($databasePath);
        if (!$uploadedFile->isValid()) {
            throw new \RuntimeException('Backupfilen kunde inte laddas upp korrekt.');
        }

        $temporaryDatabasePath = $this->extractUploadedBackupToTemporaryDatabase($uploadedFile);
        $this->assertReadableSqliteDatabase($temporaryDatabasePath);
        $this->assertSqliteBackupLooksValid($temporaryDatabasePath);

        $previousBackup = $this->createSqliteBackup($databasePath);

        $targetWalPath = $databasePath.'-wal';
        $targetShmPath = $databasePath.'-shm';
        @unlink($targetWalPath);
        @unlink($targetShmPath);

        if (!copy($temporaryDatabasePath, $databasePath)) {
            @unlink($temporaryDatabasePath);

            throw new \RuntimeException('Kunde inte skriva tillbaka backupen till databasen.');
        }

        @unlink($temporaryDatabasePath);
        clearstatcache(true, $databasePath);

        return [
            'restoredFrom' => $uploadedFile->getClientOriginalName() ?: basename($databasePath),
            'previousBackup' => $previousBackup,
        ];
    }

    /**
     * @return array{
     *     restoredFrom: string,
     *     previousBackup: array{
     *         filename: string,
     *         path: string,
     *         sizeBytes: int,
     *         createdAt: \DateTimeImmutable,
     *         sourceLabel: string,
     *         format: string
     *     }
     * }
     */
    public function restoreBackup(string $databaseReference, UploadedFile $uploadedFile): array
    {
        if ($this->isMariaDbReference($databaseReference)) {
            return $this->restoreMariaDbBackup($databaseReference, $uploadedFile);
        }

        return $this->restoreSqliteBackup($databaseReference, $uploadedFile);
    }

    public function resolveBackupPath(string $filename): string
    {
        $safeFilename = basename(trim($filename));
        if ('' === $safeFilename) {
            throw new \RuntimeException('Backupfilen saknar giltigt namn.');
        }

        $path = $this->backupDirectory().\DIRECTORY_SEPARATOR.$safeFilename;
        if (!is_file($path)) {
            throw new \RuntimeException('Backupfilen kunde inte hittas.');
        }

        return $path;
    }

    /**
     * @return array{filename: string, path: string, originalFilename: string}
     */
    public function stageRestoreUpload(UploadedFile $uploadedFile): array
    {
        if (!$uploadedFile->isValid()) {
            throw new \RuntimeException('Backupfilen kunde inte laddas upp korrekt.');
        }

        $originalFilename = trim((string) $uploadedFile->getClientOriginalName());
        $extension = mb_strtolower((string) pathinfo($originalFilename, \PATHINFO_EXTENSION));
        if (!\in_array($extension, ['zip', 'sql', 'sqlite', 'db'], true)) {
            throw new \RuntimeException('Backupen måste vara en .zip-, .sql-, .sqlite- eller .db-fil.');
        }

        $filename = sprintf(
            'database_restore_%s_%s.%s',
            (new \DateTimeImmutable())->format('Ymd_His_u'),
            bin2hex(random_bytes(3)),
            $extension,
        );
        $directory = $this->restoreStagingDirectory();
        $uploadedFile->move($directory, $filename);

        return [
            'filename' => $filename,
            'path' => $directory.\DIRECTORY_SEPARATOR.$filename,
            'originalFilename' => '' !== $originalFilename ? $originalFilename : $filename,
        ];
    }

    public function resolveRestoreUploadPath(string $filename): string
    {
        $safeFilename = basename(trim($filename));
        if ('' === $safeFilename) {
            throw new \RuntimeException('Restore-filen saknar giltigt namn.');
        }

        $path = $this->restoreStagingDirectory().\DIRECTORY_SEPARATOR.$safeFilename;
        if (!is_file($path)) {
            throw new \RuntimeException('Den stageade restore-filen kunde inte hittas.');
        }

        return $path;
    }

    private function backupDirectory(): string
    {
        $directory = $this->projectDir.\DIRECTORY_SEPARATOR.'var'.\DIRECTORY_SEPARATOR.'database_backups';
        if (!is_dir($directory) && !mkdir($directory, 0775, true) && !is_dir($directory)) {
            throw new \RuntimeException('Kunde inte skapa backupmappen för databasen.');
        }

        return $directory;
    }

    /**
     * @return array{
     *     filename: string,
     *     path: string,
     *     sizeBytes: int,
     *     createdAt: \DateTimeImmutable,
     *     sourceLabel: string,
     *     format: string
     * }
     */
    private function createMariaDbBackup(string $databaseReference): array
    {
        $connection = $this->parseMariaDbConnection($databaseReference);
        $dumpBinary = $this->firstAvailableCommand(['mariadb-dump', 'mysqldump']);
        $temporarySqlPath = $this->temporaryPath('mariadb-backup-');

        $this->runCommandWithSecret(
            [
                $dumpBinary,
                '--single-transaction',
                '--quick',
                '--routines',
                '--triggers',
                '--events',
                sprintf('--host=%s', $connection['host']),
                sprintf('--port=%d', $connection['port']),
                sprintf('--user=%s', $connection['user']),
                $connection['database'],
            ],
            $connection['password'],
            null,
            $temporarySqlPath,
        );

        $createdAt = new \DateTimeImmutable();
        $filename = sprintf('driftpunkt_mariadb_backup_%s_%s.zip', $createdAt->format('Ymd_His_u'), bin2hex(random_bytes(3)));
        $backupPath = $this->backupDirectory().\DIRECTORY_SEPARATOR.$filename;

        $zip = new \ZipArchive();
        $result = $zip->open($backupPath, \ZipArchive::CREATE | \ZipArchive::OVERWRITE);
        if (true !== $result) {
            @unlink($temporarySqlPath);

            throw new \RuntimeException('Kunde inte skapa zip-säkerhetskopia för MariaDB.');
        }

        $zip->addFile($temporarySqlPath, 'database.sql');
        $zip->addFromString('manifest.json', json_encode([
            'createdAt' => $createdAt->format(DATE_ATOM),
            'sourceLabel' => sprintf('%s/%s', $connection['host'], $connection['database']),
            'format' => 'mariadb_sql_zip_backup',
        ], \JSON_PRETTY_PRINT | \JSON_THROW_ON_ERROR));
        $zip->close();

        @unlink($temporarySqlPath);

        $metadata = $this->readBackupMetadata($backupPath);
        if (null === $metadata) {
            throw new \RuntimeException('MariaDB-backupen skapades men kunde inte läsas tillbaka.');
        }

        return $metadata;
    }

    /**
     * @return array{
     *     beforeSizeBytes: int,
     *     afterSizeBytes: int,
     *     optimizedAt: \DateTimeImmutable,
     *     output: string
     * }
     */
    private function analyzeMariaDbDatabase(string $databaseReference): array
    {
        $connection = $this->parseMariaDbConnection($databaseReference);
        $checkBinary = $this->firstAvailableCommand(['mariadb-check', 'mysqlcheck']);
        $output = $this->runCommandWithSecret(
            [
                $checkBinary,
                '--analyze',
                sprintf('--host=%s', $connection['host']),
                sprintf('--port=%d', $connection['port']),
                sprintf('--user=%s', $connection['user']),
                '--databases',
                $connection['database'],
            ],
            $connection['password'],
        );

        return [
            'beforeSizeBytes' => 0,
            'afterSizeBytes' => 0,
            'optimizedAt' => new \DateTimeImmutable(),
            'output' => $output,
        ];
    }

    /**
     * @return array{
     *     restoredFrom: string,
     *     previousBackup: array{
     *         filename: string,
     *         path: string,
     *         sizeBytes: int,
     *         createdAt: \DateTimeImmutable,
     *         sourceLabel: string,
     *         format: string
     *     }
     * }
     */
    private function restoreMariaDbBackup(string $databaseReference, UploadedFile $uploadedFile): array
    {
        if (!$uploadedFile->isValid()) {
            throw new \RuntimeException('Backupfilen kunde inte laddas upp korrekt.');
        }

        $connection = $this->parseMariaDbConnection($databaseReference);
        $temporarySqlPath = $this->extractUploadedSqlBackup($uploadedFile);
        $this->assertSqlBackupLooksValid($temporarySqlPath);
        $previousBackup = $this->createMariaDbBackup($databaseReference);

        $clientBinary = $this->firstAvailableCommand(['mariadb', 'mysql']);
        $this->runCommandWithSecret(
            [
                $clientBinary,
                sprintf('--host=%s', $connection['host']),
                sprintf('--port=%d', $connection['port']),
                sprintf('--user=%s', $connection['user']),
                $connection['database'],
            ],
            $connection['password'],
            $temporarySqlPath,
        );

        @unlink($temporarySqlPath);

        return [
            'restoredFrom' => $uploadedFile->getClientOriginalName() ?: 'database.sql',
            'previousBackup' => $previousBackup,
        ];
    }

    private function restoreStagingDirectory(): string
    {
        $directory = $this->projectDir.\DIRECTORY_SEPARATOR.'var'.\DIRECTORY_SEPARATOR.'database_restore_staging';
        if (!is_dir($directory) && !mkdir($directory, 0775, true) && !is_dir($directory)) {
            throw new \RuntimeException('Kunde inte skapa stagingmappen för database-restore.');
        }

        return $directory;
    }

    /**
     * @return array{
     *     filename: string,
     *     path: string,
     *     sizeBytes: int,
     *     createdAt: \DateTimeImmutable,
     *     sourceLabel: string,
     *     format: string
     * }|null
     */
    private function readBackupMetadata(string $path): ?array
    {
        if (!is_file($path)) {
            return null;
        }

        $zip = new \ZipArchive();
        if (true !== $zip->open($path)) {
            return null;
        }

        $manifestRaw = $zip->getFromName('manifest.json');
        $zip->close();

        $createdAt = $this->createDateTimeFromTimestamp((int) filemtime($path));
        $sourceLabel = basename($path);
        $format = 'sqlite_zip_backup';

        if (false !== $manifestRaw) {
            try {
                /** @var array<string, mixed> $manifest */
                $manifest = json_decode($manifestRaw, true, 512, \JSON_THROW_ON_ERROR);
                if (isset($manifest['createdAt']) && is_string($manifest['createdAt'])) {
                    $createdAt = new \DateTimeImmutable($manifest['createdAt']);
                }
                if (isset($manifest['sourceLabel']) && is_string($manifest['sourceLabel']) && '' !== trim($manifest['sourceLabel'])) {
                    $sourceLabel = trim($manifest['sourceLabel']);
                }
                if (isset($manifest['format']) && is_string($manifest['format']) && '' !== trim($manifest['format'])) {
                    $format = trim($manifest['format']);
                }
            } catch (\JsonException|\Exception) {
            }
        }

        return [
            'filename' => basename($path),
            'path' => $path,
            'sizeBytes' => (int) filesize($path),
            'createdAt' => $createdAt,
            'sourceLabel' => $sourceLabel,
            'format' => $format,
        ];
    }

    private function isMariaDbReference(string $databaseReference): bool
    {
        $reference = $this->resolveDatabaseReference($databaseReference);

        return str_starts_with($reference, 'mysql://') || str_starts_with($reference, 'mariadb://');
    }

    /**
     * @return array{host: string, port: int, user: string, password: string, database: string}
     */
    private function parseMariaDbConnection(string $databaseReference): array
    {
        $databaseUrl = $this->resolveDatabaseReference($databaseReference);

        $parts = parse_url($databaseUrl);
        if (!\is_array($parts)) {
            throw new \RuntimeException('MariaDB-anslutningen kunde inte läsas från DATABASE_URL.');
        }

        $scheme = strtolower((string) ($parts['scheme'] ?? ''));
        if (!\in_array($scheme, ['mysql', 'mariadb'], true)) {
            throw new \RuntimeException('Databasrutinen kräver en MariaDB DATABASE_URL.');
        }

        $database = trim(rawurldecode((string) ($parts['path'] ?? '')), '/');
        if ('' === $database) {
            throw new \RuntimeException('DATABASE_URL saknar databasnamn.');
        }

        $user = rawurldecode((string) ($parts['user'] ?? ''));
        if ('' === $user) {
            throw new \RuntimeException('DATABASE_URL saknar MariaDB-användare.');
        }

        return [
            'host' => rawurldecode((string) ($parts['host'] ?? '127.0.0.1')),
            'port' => (int) ($parts['port'] ?? 3306),
            'user' => $user,
            'password' => rawurldecode((string) ($parts['pass'] ?? '')),
            'database' => $database,
        ];
    }

    private function resolveDatabaseReference(string $databaseReference): string
    {
        $reference = trim($databaseReference);
        if ('env:DATABASE_URL' !== $reference) {
            return $reference;
        }

        $serverValue = $_SERVER['DATABASE_URL'] ?? null;
        if (\is_string($serverValue) && '' !== trim($serverValue)) {
            return trim($serverValue);
        }

        $envValue = $_ENV['DATABASE_URL'] ?? null;
        if (\is_string($envValue) && '' !== trim($envValue)) {
            return trim($envValue);
        }

        $getenvValue = getenv('DATABASE_URL');

        return \is_string($getenvValue) ? trim($getenvValue) : '';
    }

    private function firstAvailableCommand(array $commands): string
    {
        foreach ($commands as $command) {
            $path = trim((string) shell_exec(sprintf('command -v %s 2>/dev/null', escapeshellarg((string) $command))));
            if ('' !== $path) {
                return $path;
            }
        }

        throw new \RuntimeException(sprintf(
            'Saknar MariaDB-klientverktyg (%s). Installera mariadb-client i containern/servern.',
            implode(', ', array_map('strval', $commands)),
        ));
    }

    /**
     * @param list<string> $command
     */
    private function runCommandWithSecret(array $command, string $password, ?string $stdinPath = null, ?string $stdoutPath = null): string
    {
        if (null !== $stdinPath && !is_file($stdinPath)) {
            throw new \RuntimeException('Kunde inte läsa SQL-filen.');
        }

        $stdout = null !== $stdoutPath ? ['file', $stdoutPath, 'w'] : ['pipe', 'w'];
        $descriptorSpec = [
            0 => null !== $stdinPath ? ['file', $stdinPath, 'r'] : ['pipe', 'r'],
            1 => $stdout,
            2 => ['pipe', 'w'],
        ];
        $baseEnvironment = getenv();
        if (!\is_array($baseEnvironment)) {
            $baseEnvironment = [];
        }
        $environment = array_merge($baseEnvironment, [
            'MYSQL_PWD' => $password,
            'MARIADB_PWD' => $password,
        ]);

        $process = proc_open($command, $descriptorSpec, $pipes, $this->projectDir, $environment);
        if (!\is_resource($process)) {
            throw new \RuntimeException('Kunde inte starta MariaDB-kommandot.');
        }

        if (null === $stdinPath) {
            fwrite($pipes[0], '');
            fclose($pipes[0]);
        }

        $output = '';
        if (null === $stdoutPath) {
            $output = (string) stream_get_contents($pipes[1]);
            fclose($pipes[1]);
        }

        $errorOutput = (string) stream_get_contents($pipes[2]);
        fclose($pipes[2]);

        $exitCode = proc_close($process);
        if (0 !== $exitCode) {
            throw new \RuntimeException(trim(sprintf(
                "MariaDB-kommandot misslyckades med exitkod %d.\n%s",
                $exitCode,
                $errorOutput,
            )));
        }

        return trim($output."\n".$errorOutput);
    }

    private function extractUploadedSqlBackup(UploadedFile $uploadedFile): string
    {
        $originalName = mb_strtolower((string) $uploadedFile->getClientOriginalName());
        $extension = pathinfo($originalName, \PATHINFO_EXTENSION);

        if ('sql' === $extension) {
            $temporaryPath = $this->temporaryPath('mariadb-restore-');
            if (!copy($uploadedFile->getPathname(), $temporaryPath)) {
                throw new \RuntimeException('Kunde inte läsa den uppladdade SQL-backupen.');
            }

            return $temporaryPath;
        }

        if ('zip' !== $extension) {
            throw new \RuntimeException('MariaDB-restore kräver en .zip- eller .sql-fil.');
        }

        $zip = new \ZipArchive();
        if (true !== $zip->open($uploadedFile->getPathname())) {
            throw new \RuntimeException('Kunde inte öppna zip-säkerhetskopian.');
        }

        $sqlEntryName = null;
        for ($index = 0; $index < $zip->numFiles; ++$index) {
            $entryName = (string) $zip->getNameIndex($index);
            if (str_ends_with(mb_strtolower($entryName), '.sql')) {
                $sqlEntryName = $entryName;
                break;
            }
        }

        if (null === $sqlEntryName) {
            $zip->close();

            throw new \RuntimeException('Zip-backupen innehåller ingen SQL-dump.');
        }

        $content = $zip->getFromName($sqlEntryName);
        $zip->close();
        if (false === $content) {
            throw new \RuntimeException('Kunde inte läsa SQL-dumpen ur zip-säkerhetskopian.');
        }

        $temporaryPath = $this->temporaryPath('mariadb-restore-');
        file_put_contents($temporaryPath, $content);

        return $temporaryPath;
    }

    private function assertSqlBackupLooksValid(string $sqlPath): void
    {
        if (!is_file($sqlPath) || filesize($sqlPath) < 1) {
            throw new \RuntimeException('SQL-backupen är tom eller kunde inte läsas.');
        }

        $handle = fopen($sqlPath, 'rb');
        if (false === $handle) {
            throw new \RuntimeException('SQL-backupen kunde inte öppnas.');
        }

        $sample = (string) fread($handle, 1048576);
        fclose($handle);

        if (!str_contains($sample, 'CREATE TABLE') && !str_contains($sample, 'MariaDB') && !str_contains($sample, 'MySQL')) {
            throw new \RuntimeException('SQL-backupen ser inte ut som en MariaDB-dump.');
        }
    }

    private function extractUploadedBackupToTemporaryDatabase(UploadedFile $uploadedFile): string
    {
        $originalName = mb_strtolower((string) $uploadedFile->getClientOriginalName());
        $extension = pathinfo($originalName, \PATHINFO_EXTENSION);

        if (\in_array($extension, ['sqlite', 'db'], true)) {
            $temporaryPath = $this->temporaryPath('sqlite-restore-');
            if (!copy($uploadedFile->getPathname(), $temporaryPath)) {
                throw new \RuntimeException('Kunde inte läsa den uppladdade backupfilen.');
            }

            return $temporaryPath;
        }

        if ('zip' !== $extension) {
            throw new \RuntimeException('Backupen måste vara en .zip-, .sqlite- eller .db-fil.');
        }

        $zip = new \ZipArchive();
        if (true !== $zip->open($uploadedFile->getPathname())) {
            throw new \RuntimeException('Kunde inte öppna zip-säkerhetskopian.');
        }

        $databaseEntryName = null;
        for ($index = 0; $index < $zip->numFiles; ++$index) {
            $entryName = (string) $zip->getNameIndex($index);
            $normalizedEntryName = mb_strtolower($entryName);
            if (str_ends_with($normalizedEntryName, '.sqlite') || str_ends_with($normalizedEntryName, '.db')) {
                $databaseEntryName = $entryName;
                break;
            }
        }

        if (null === $databaseEntryName) {
            $zip->close();

            throw new \RuntimeException('Zip-backupen innehåller ingen SQLite-databas.');
        }

        $content = $zip->getFromName($databaseEntryName);
        $zip->close();
        if (false === $content) {
            throw new \RuntimeException('Kunde inte läsa databasinnehållet ur zip-säkerhetskopian.');
        }

        $temporaryPath = $this->temporaryPath('sqlite-restore-');
        file_put_contents($temporaryPath, $content);

        return $temporaryPath;
    }

    private function assertReadableSqliteDatabase(string $databasePath): void
    {
        if (!is_file($databasePath)) {
            throw new \RuntimeException('Databasfilen kunde inte hittas.');
        }

        if (!is_readable($databasePath) || !is_writable($databasePath)) {
            throw new \RuntimeException('Databasfilen måste vara läsbar och skrivbar.');
        }
    }

    private function assertSqliteBackupLooksValid(string $databasePath): void
    {
        $database = new \SQLite3($databasePath, \SQLITE3_OPEN_READONLY);
        $result = $database->querySingle("SELECT COUNT(*) FROM sqlite_master WHERE type = 'table' AND name IN ('doctrine_migration_versions', 'users', 'tickets')");
        $database->close();

        if ((int) $result < 1) {
            throw new \RuntimeException('Backupen ser inte ut att vara en giltig Driftpunkt-databas.');
        }
    }

    private function temporaryPath(string $prefix): string
    {
        $path = tempnam(sys_get_temp_dir(), $prefix);
        if (false === $path) {
            throw new \RuntimeException('Kunde inte skapa en tillfällig fil för databasrutinen.');
        }

        return $path;
    }

    private function createDateTimeFromTimestamp(int $timestamp): \DateTimeImmutable
    {
        return (new \DateTimeImmutable())->setTimestamp($timestamp);
    }
}
