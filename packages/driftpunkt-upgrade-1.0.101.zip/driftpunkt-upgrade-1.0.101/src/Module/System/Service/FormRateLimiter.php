<?php

declare(strict_types=1);

namespace App\Module\System\Service;

use Psr\Cache\CacheItemPoolInterface;
use Symfony\Component\DependencyInjection\Attribute\Autowire;
use Symfony\Component\HttpFoundation\Request;

final class FormRateLimiter
{
    public function __construct(
        #[Autowire(service: 'cache.app')]
        private readonly CacheItemPoolInterface $cache,
    ) {
    }

    public function isBlocked(Request $request, string $scope, int $limit, int $windowSeconds, ?string $identity = null): bool
    {
        try {
            [, $state] = $this->loadState($request, $scope, $windowSeconds, $identity);

            return $state['count'] >= $limit;
        } catch (\Throwable) {
            return false;
        }
    }

    public function hasAttempts(Request $request, string $scope, int $windowSeconds, ?string $identity = null): bool
    {
        try {
            [, $state] = $this->loadState($request, $scope, $windowSeconds, $identity);

            return $state['count'] > 0;
        } catch (\Throwable) {
            return false;
        }
    }

    public function retryAfter(Request $request, string $scope, int $windowSeconds, ?string $identity = null): int
    {
        try {
            [, $state] = $this->loadState($request, $scope, $windowSeconds, $identity);

            return max(0, $state['resetAt'] - time());
        } catch (\Throwable) {
            return 0;
        }
    }

    public function consume(Request $request, string $scope, int $limit, int $windowSeconds, ?string $identity = null): bool
    {
        try {
            [$item, $state] = $this->loadState($request, $scope, $windowSeconds, $identity);
            if ($state['count'] >= $limit) {
                return false;
            }

            ++$state['count'];
            $item->set($state);
            $item->expiresAfter(max(1, $state['resetAt'] - time()));
            $this->cache->save($item);

            return true;
        } catch (\Throwable) {
            return true;
        }
    }

    public function reset(Request $request, string $scope, ?string $identity = null): void
    {
        try {
            $this->cache->deleteItem($this->cacheKey($request, $scope, $identity));
        } catch (\Throwable) {
        }
    }

    public function forceBlock(Request $request, string $scope, int $limit, int $windowSeconds, ?string $identity = null): void
    {
        try {
            $item = $this->cache->getItem($this->cacheKey($request, $scope, $identity));
            $item->set([
                'count' => max(1, $limit),
                'resetAt' => time() + max(1, $windowSeconds),
            ]);
            $item->expiresAfter(max(1, $windowSeconds));
            $this->cache->save($item);
        } catch (\Throwable) {
        }
    }

    /**
     * @return array{0: \Psr\Cache\CacheItemInterface, 1: array{count: int, resetAt: int}}
     */
    private function loadState(Request $request, string $scope, int $windowSeconds, ?string $identity): array
    {
        $item = $this->cache->getItem($this->cacheKey($request, $scope, $identity));
        $now = time();
        $value = $item->isHit() ? $item->get() : null;

        if (!\is_array($value) || !isset($value['count'], $value['resetAt']) || (int) $value['resetAt'] <= $now) {
            return [$item, [
                'count' => 0,
                'resetAt' => $now + max(1, $windowSeconds),
            ]];
        }

        return [$item, [
            'count' => max(0, (int) $value['count']),
            'resetAt' => (int) $value['resetAt'],
        ]];
    }

    private function cacheKey(Request $request, string $scope, ?string $identity): string
    {
        $clientIp = $request->getClientIp() ?? 'unknown-ip';
        $normalizedIdentity = mb_strtolower(trim((string) $identity));

        return 'form_rate_limit.'.sha1($scope.'|'.$clientIp.'|'.$normalizedIdentity);
    }
}
