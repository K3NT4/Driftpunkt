<?php

declare(strict_types=1);

namespace App\Module\System\Service;

final class AppDateTimeFormatter
{
    public const DEFAULT_TIMEZONE = 'Europe/Stockholm';
    public const DEFAULT_DATETIME_FORMAT = 'Y-m-d H:i';
    public const DEFAULT_DATE_FORMAT = 'Y-m-d';
    public const DEFAULT_TIME_FORMAT = 'H:i';
    public const DATETIME_INPUT_FORMAT = 'Y-m-d\TH:i';

    private const COMMON_TIMEZONES = [
        'Europe/Stockholm',
        'Europe/Oslo',
        'Europe/Copenhagen',
        'UTC',
    ];

    public function __construct(
        private readonly SystemSettings $systemSettings,
    ) {
    }

    public function timeZoneIdentifier(): string
    {
        try {
            return self::normalizeTimeZoneIdentifier(
                $this->systemSettings->getString(SystemSettings::SYSTEM_TIMEZONE, self::DEFAULT_TIMEZONE),
            );
        } catch (\Throwable) {
            return self::DEFAULT_TIMEZONE;
        }
    }

    public function timeZone(): \DateTimeZone
    {
        return new \DateTimeZone($this->timeZoneIdentifier());
    }

    public function now(): \DateTimeImmutable
    {
        return new \DateTimeImmutable('now', $this->timeZone());
    }

    public function today(): \DateTimeImmutable
    {
        return new \DateTimeImmutable('today', $this->timeZone());
    }

    public function toConfiguredTimeZone(\DateTimeInterface $dateTime): \DateTimeImmutable
    {
        return \DateTimeImmutable::createFromInterface($dateTime)->setTimezone($this->timeZone());
    }

    public function format(mixed $dateTime, string $format = self::DEFAULT_DATETIME_FORMAT, string $empty = ''): string
    {
        $dateTime = $this->normalizeDateTime($dateTime);
        if (!$dateTime instanceof \DateTimeImmutable) {
            return $empty;
        }

        return $this->toConfiguredTimeZone($dateTime)->format($format);
    }

    public function formatDate(mixed $dateTime, string $format = self::DEFAULT_DATE_FORMAT, string $empty = ''): string
    {
        return $this->format($dateTime, $format, $empty);
    }

    public function formatTime(mixed $dateTime, string $format = self::DEFAULT_TIME_FORMAT, string $empty = ''): string
    {
        return $this->format($dateTime, $format, $empty);
    }

    public function formatDateTimeInput(mixed $dateTime): string
    {
        return $this->format($dateTime, self::DATETIME_INPUT_FORMAT);
    }

    public function normalizeDateTime(mixed $dateTime): ?\DateTimeImmutable
    {
        if ($dateTime instanceof \DateTimeInterface) {
            return \DateTimeImmutable::createFromInterface($dateTime);
        }

        if (null === $dateTime) {
            return null;
        }

        if (\is_int($dateTime) || \is_float($dateTime)) {
            return (new \DateTimeImmutable('@'.(string) (int) $dateTime))->setTimezone($this->timeZone());
        }

        if (!\is_string($dateTime)) {
            return null;
        }

        $value = trim($dateTime);
        if ('' === $value) {
            return null;
        }

        if (ctype_digit($value)) {
            return (new \DateTimeImmutable('@'.$value))->setTimezone($this->timeZone());
        }

        try {
            return new \DateTimeImmutable($value, $this->timeZone());
        } catch (\Throwable) {
            return null;
        }
    }

    public function parseLocalDateTime(string $value): ?\DateTimeImmutable
    {
        $normalized = trim(str_replace('T', ' ', $value));
        if ('' === $normalized) {
            return null;
        }

        foreach (['!Y-m-d H:i:s', '!Y-m-d H:i'] as $format) {
            $dateTime = \DateTimeImmutable::createFromFormat($format, $normalized, $this->timeZone());
            $errors = \DateTimeImmutable::getLastErrors();
            if (
                $dateTime instanceof \DateTimeImmutable
                && (false === $errors || (0 === $errors['warning_count'] && 0 === $errors['error_count']))
            ) {
                return $dateTime;
            }
        }

        try {
            return new \DateTimeImmutable($normalized, $this->timeZone());
        } catch (\Throwable) {
            return null;
        }
    }

    public function parseLocalDateStart(string $value): ?\DateTimeImmutable
    {
        $value = trim($value);
        if ('' === $value) {
            return null;
        }

        $date = \DateTimeImmutable::createFromFormat('!Y-m-d H:i:s', $value.' 00:00:00', $this->timeZone());
        $errors = \DateTimeImmutable::getLastErrors();

        return $date instanceof \DateTimeImmutable
            && (false === $errors || (0 === $errors['warning_count'] && 0 === $errors['error_count']))
            ? $date
            : null;
    }

    public function parseLocalDateEnd(string $value): ?\DateTimeImmutable
    {
        $start = $this->parseLocalDateStart($value);

        return $start instanceof \DateTimeImmutable ? $start->setTime(23, 59, 59) : null;
    }

    /**
     * @return array{
     *     identifier: string,
     *     label: string,
     *     offset: string,
     *     abbreviation: string,
     *     isDst: bool,
     *     currentTime: string,
     *     options: list<array{identifier: string, label: string, common: bool}>
     * }
     */
    public function settingsSummary(): array
    {
        $now = $this->now();

        return [
            'identifier' => $this->timeZoneIdentifier(),
            'label' => $this->timeZoneLabel(),
            'offset' => 'UTC'.$now->format('P'),
            'abbreviation' => $now->format('T'),
            'isDst' => '1' === $now->format('I'),
            'currentTime' => $now->format(self::DEFAULT_DATETIME_FORMAT),
            'options' => $this->timeZoneOptions(),
        ];
    }

    public function timeZoneLabel(): string
    {
        $now = $this->now();

        return sprintf('%s %s UTC%s', $this->timeZoneIdentifier(), $now->format('T'), $now->format('P'));
    }

    /**
     * @return list<array{identifier: string, label: string, common: bool}>
     */
    public function timeZoneOptions(): array
    {
        $identifiers = timezone_identifiers_list();
        $common = array_values(array_filter(
            self::COMMON_TIMEZONES,
            static fn (string $identifier): bool => \in_array($identifier, $identifiers, true),
        ));
        $ordered = array_values(array_unique([...$common, ...$identifiers]));
        $now = new \DateTimeImmutable();

        return array_map(
            static function (string $identifier) use ($common, $now): array {
                $timeZone = new \DateTimeZone($identifier);
                $offsetSeconds = $timeZone->getOffset($now);
                $offset = sprintf(
                    'UTC%s%02d:%02d',
                    $offsetSeconds >= 0 ? '+' : '-',
                    (int) floor(abs($offsetSeconds) / 3600),
                    (int) floor((abs($offsetSeconds) % 3600) / 60),
                );

                return [
                    'identifier' => $identifier,
                    'label' => sprintf('%s (%s)', $identifier, $offset),
                    'common' => \in_array($identifier, $common, true),
                ];
            },
            $ordered,
        );
    }

    public static function normalizeTimeZoneIdentifier(string $identifier): string
    {
        $normalized = trim($identifier);
        if ('' === $normalized) {
            return self::DEFAULT_TIMEZONE;
        }

        if (!\in_array($normalized, timezone_identifiers_list(), true)) {
            throw new \InvalidArgumentException('Ogiltig tidszon. Välj en giltig IANA-tidszon.');
        }

        return $normalized;
    }
}
