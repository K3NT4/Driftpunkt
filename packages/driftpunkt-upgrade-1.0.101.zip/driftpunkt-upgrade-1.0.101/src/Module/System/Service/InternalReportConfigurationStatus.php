<?php

declare(strict_types=1);

namespace App\Module\System\Service;

use App\Module\Mail\Entity\SupportMailbox;
use App\Module\Mail\Service\ConfiguredMailer;
use App\Module\Mail\Service\ImapMailboxFetcher;
use Doctrine\ORM\EntityManagerInterface;

final class InternalReportConfigurationStatus
{
    public function __construct(
        private readonly EntityManagerInterface $entityManager,
        private readonly ConfiguredMailer $mailer,
        private readonly ImapMailboxFetcher $imapMailboxFetcher,
        private readonly SystemSettings $systemSettings,
    ) {
    }

    /**
     * @return array{ready: bool, settings: array{recipient: string, replyTo: string}, checks: list<array{label: string, ready: bool, detail: string}>}
     */
    public function describe(): array
    {
        $settings = $this->systemSettings->getInternalReportSettings();
        $recipient = $settings['recipient'];
        $replyTo = $settings['replyTo'];
        $mailbox = false !== filter_var($replyTo, \FILTER_VALIDATE_EMAIL)
            ? $this->entityManager->getRepository(SupportMailbox::class)->findOneBy(['emailAddress' => $replyTo, 'isActive' => true])
            : null;
        $imapReady = $mailbox instanceof SupportMailbox && $this->imapMailboxFetcher->supports($mailbox);
        $lastPolledAt = $mailbox instanceof SupportMailbox ? $mailbox->getLastPolledAt() : null;
        $schedulerReady = $lastPolledAt instanceof \DateTimeImmutable && $lastPolledAt >= new \DateTimeImmutable('-15 minutes');

        $checks = [
            [
                'label' => 'Central mottagare',
                'ready' => false !== filter_var($recipient, \FILTER_VALIDATE_EMAIL),
                'detail' => false !== filter_var($recipient, \FILTER_VALIDATE_EMAIL) ? $recipient : 'Ogiltig eller saknad adress',
            ],
            [
                'label' => 'Utgående e-post',
                'ready' => $this->mailer->hasConfiguredOutbound(),
                'detail' => $this->mailer->hasConfiguredOutbound() ? 'SMTP eller annan utgående transport är aktiv' : 'Ingen verklig utgående transport är konfigurerad',
            ],
            [
                'label' => 'Svarsinkorg',
                'ready' => $imapReady,
                'detail' => $imapReady ? $replyTo : 'Reply-To matchar inte en komplett aktiv IMAP-inkorg',
            ],
            [
                'label' => 'Mailpolling',
                'ready' => $schedulerReady,
                'detail' => $lastPolledAt instanceof \DateTimeImmutable
                    ? sprintf('Senast körd %s', $lastPolledAt->format('Y-m-d H:i:s'))
                    : 'Ingen lyckad polling har registrerats',
            ],
        ];

        return [
            'ready' => [] === array_filter($checks, static fn (array $check): bool => !$check['ready']),
            'settings' => $settings,
            'checks' => $checks,
        ];
    }
}
