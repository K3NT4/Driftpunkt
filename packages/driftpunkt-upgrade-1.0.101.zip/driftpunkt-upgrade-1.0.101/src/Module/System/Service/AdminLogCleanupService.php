<?php

declare(strict_types=1);

namespace App\Module\System\Service;

use App\Module\Identity\Entity\User;
use App\Module\Notification\Entity\NotificationLog;
use App\Module\System\Entity\SystemAuditLog;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\DependencyInjection\Attribute\Autowire;
use Symfony\Component\HttpFoundation\Request;

final class AdminLogCleanupService
{
    public function __construct(
        private readonly EntityManagerInterface $entityManager,
        private readonly AdminLogCenterBuilder $logCenterBuilder,
        private readonly SystemAuditLogger $systemAuditLogger,
        #[Autowire('%kernel.project_dir%')]
        private readonly string $projectDir,
    ) {
    }

    /**
     * @return array{deletedRows: int, clearedFiles: int, failedFiles: int, skippedActiveJobs: int, auditTrailCreated: bool, label: string}
     */
    public function clear(Request $request, User $actor, string $reason): array
    {
        $type = trim((string) $request->request->get('log_type'));

        $result = match ($type) {
            'system' => $this->clearSystemLogs($request),
            'notifications' => $this->clearNotifications($request),
            'audit' => $this->clearAuditLogs($request),
            'jobs' => $this->clearJobLogs($request),
            default => throw new \InvalidArgumentException('Okänd loggtyp.'),
        };

        $this->systemAuditLogger->log(
            $actor,
            'admin.logs.clear',
            sprintf('Rensade %s', $result['label']),
            sprintf(
                '%d databasposter, %d filer rensade, %d filfel, %d aktiva jobb lämnades kvar. Filter: %s. Orsak: %s',
                $result['deletedRows'],
                $result['clearedFiles'],
                $result['failedFiles'],
                $result['skippedActiveJobs'],
                json_encode($this->filterSummary($request, $type), \JSON_UNESCAPED_UNICODE | \JSON_UNESCAPED_SLASHES) ?: '{}',
                $reason,
            ),
        );

        return $result;
    }

    /**
     * @return array{deletedRows: int, clearedFiles: int, failedFiles: int, skippedActiveJobs: int, auditTrailCreated: bool, label: string}
     */
    private function clearSystemLogs(Request $request): array
    {
        $selectedFile = trim((string) $request->request->get('system_log_file'));
        $scope = trim((string) $request->request->get('system_log_scope', 'selected'));
        $files = $this->logCenterBuilder->listSystemLogFiles();
        $targets = [];

        foreach ($files as $file) {
            if ('all' === $scope || $file['name'] === $selectedFile) {
                $targets[] = $file;
            }
        }

        $cleared = 0;
        $failed = 0;
        foreach ($targets as $file) {
            if (@file_put_contents($file['path'], '') === false) {
                ++$failed;
                continue;
            }

            ++$cleared;
        }

        return [
            'deletedRows' => 0,
            'clearedFiles' => $cleared,
            'failedFiles' => $failed,
            'skippedActiveJobs' => 0,
            'auditTrailCreated' => false,
            'label' => 'systemloggar',
        ];
    }

    /**
     * @return array{deletedRows: int, clearedFiles: int, failedFiles: int, skippedActiveJobs: int, auditTrailCreated: bool, label: string}
     */
    private function clearNotifications(Request $request): array
    {
        $ids = array_map(
            static fn (NotificationLog $log): int => (int) $log->getId(),
            $this->logCenterBuilder->notificationQuery($this->logCenterBuilder->notificationFilters($request))
                ->getQuery()
                ->getResult(),
        );

        $deleted = 0;
        if ([] !== $ids) {
            $deleted = (int) $this->entityManager->createQueryBuilder()
                ->delete(NotificationLog::class, 'log')
                ->andWhere('log.id IN (:ids)')
                ->setParameter('ids', $ids)
                ->getQuery()
                ->execute();
        }

        return [
            'deletedRows' => $deleted,
            'clearedFiles' => 0,
            'failedFiles' => 0,
            'skippedActiveJobs' => 0,
            'auditTrailCreated' => false,
            'label' => 'notifieringsloggar',
        ];
    }

    /**
     * @return array{deletedRows: int, clearedFiles: int, failedFiles: int, skippedActiveJobs: int, auditTrailCreated: bool, label: string}
     */
    private function clearAuditLogs(Request $request): array
    {
        $ids = array_map(
            static fn (SystemAuditLog $log): int => (int) $log->getId(),
            $this->logCenterBuilder->auditQuery($this->logCenterBuilder->auditFilters($request))
                ->getQuery()
                ->getResult(),
        );

        $deleted = 0;
        if ([] !== $ids) {
            $deleted = (int) $this->entityManager->createQueryBuilder()
                ->delete(SystemAuditLog::class, 'log')
                ->andWhere('log.id IN (:ids)')
                ->setParameter('ids', $ids)
                ->getQuery()
                ->execute();
        }

        return [
            'deletedRows' => $deleted,
            'clearedFiles' => 0,
            'failedFiles' => 0,
            'skippedActiveJobs' => 0,
            'auditTrailCreated' => true,
            'label' => 'driftåtgärder',
        ];
    }

    /**
     * @return array{deletedRows: int, clearedFiles: int, failedFiles: int, skippedActiveJobs: int, auditTrailCreated: bool, label: string}
     */
    private function clearJobLogs(Request $request): array
    {
        $jobs = $this->logCenterBuilder->filteredJobs($request);
        $cleared = 0;
        $failed = 0;
        $skipped = 0;

        foreach ($jobs as $job) {
            if (!\in_array($job['status'], ['completed', 'failed'], true)) {
                ++$skipped;
                continue;
            }

            $path = $this->jobPath((string) $job['source'], (string) $job['id']);
            if (null === $path || !is_file($path)) {
                continue;
            }

            foreach ($this->jobLogPaths($path) as $targetPath) {
                if (!is_file($targetPath)) {
                    continue;
                }

                if (@unlink($targetPath)) {
                    ++$cleared;
                } else {
                    ++$failed;
                }
            }
        }

        return [
            'deletedRows' => 0,
            'clearedFiles' => $cleared,
            'failedFiles' => $failed,
            'skippedActiveJobs' => $skipped,
            'auditTrailCreated' => false,
            'label' => 'jobbloggar',
        ];
    }

    private function jobPath(string $source, string $id): ?string
    {
        $filename = basename($id).'.json';

        return match ($source) {
            'database' => $this->projectDir.'/var/database_jobs/'.$filename,
            'code_updates' => $this->projectDir.'/var/code_update_runs/'.$filename,
            'updates' => $this->postUpdatePath($filename),
            default => null,
        };
    }

    private function postUpdatePath(string $filename): string
    {
        $path = $this->projectDir.'/var/post_update_runs/'.$filename;
        if (is_file($path)) {
            return $path;
        }

        return $this->projectDir.'/var/code_update_runs/'.$filename;
    }

    /**
     * @return array<string, string>
     */
    private function filterSummary(Request $request, string $type): array
    {
        return match ($type) {
            'system' => [
                'file' => trim((string) $request->request->get('system_log_file')),
                'scope' => trim((string) $request->request->get('system_log_scope', 'selected')),
            ],
            'notifications' => $this->logCenterBuilder->notificationFilters($request),
            'audit' => $this->logCenterBuilder->auditFilters($request),
            'jobs' => $this->logCenterBuilder->jobFilters($request),
            default => [],
        };
    }

    /**
     * @return list<string>
     */
    private function jobLogPaths(string $jsonPath): array
    {
        $paths = [$jsonPath];
        if (str_ends_with($jsonPath, '.json')) {
            $paths[] = substr($jsonPath, 0, -5).'.log';
        }
        $paths[] = $jsonPath.'.log';

        return array_values(array_unique($paths));
    }
}
