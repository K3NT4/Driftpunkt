<?php

declare(strict_types=1);

namespace App\Module\System\Service;

use App\Module\Identity\Entity\Company;
use App\Module\Identity\Entity\User;

final class LocalePreferenceResolver
{
    public function __construct(
        private readonly SystemSettings $systemSettings,
    ) {
    }

    public function defaultLocale(): string
    {
        return $this->systemSettings->getDefaultLocale();
    }

    public function normalizeSelectable(?string $locale): string
    {
        return $this->systemSettings->normalizeSelectableLocale($locale);
    }

    public function forUser(?User $user): string
    {
        if (!$user instanceof User) {
            return $this->defaultLocale();
        }

        $locale = $user->getPreferredLocale();
        if (null === $locale && $user->getCompany() instanceof Company) {
            $locale = $user->getCompany()->getPreferredLocale();
        }

        return $this->normalizeSelectable($locale);
    }

    public function forCompany(?Company $company): string
    {
        if (!$company instanceof Company) {
            return $this->defaultLocale();
        }

        return $this->normalizeSelectable($company->getPreferredLocale());
    }

    public function forRecipient(?User $recipient = null, ?Company $company = null): string
    {
        if ($recipient instanceof User) {
            return $this->forUser($recipient);
        }

        return $this->forCompany($company);
    }
}
