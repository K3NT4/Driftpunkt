<?php

declare(strict_types=1);

namespace App\Module\System\Service;

class ProjectCommandExecutor
{
    /**
     * @param list<string> $command
     *
     * @return array{exitCode: int, output: string}
     */
    public function execute(array $command, string $workingDirectory): array
    {
        $descriptorSpec = [
            0 => ['pipe', 'r'],
            1 => ['pipe', 'w'],
            2 => ['pipe', 'w'],
        ];

        $process = proc_open($command, $descriptorSpec, $pipes, $workingDirectory, $this->processEnvironment($workingDirectory));
        if (!\is_resource($process)) {
            throw new \RuntimeException('Kunde inte starta kommandot för efteruppdatering.');
        }

        fwrite($pipes[0], '');
        fclose($pipes[0]);

        $stdout = stream_get_contents($pipes[1]);
        fclose($pipes[1]);

        $stderr = stream_get_contents($pipes[2]);
        fclose($pipes[2]);

        $exitCode = proc_close($process);

        return [
            'exitCode' => $exitCode,
            'output' => trim((string) $stdout."\n".(string) $stderr),
        ];
    }

    /**
     * @return array<string, string>
     */
    private function processEnvironment(string $workingDirectory): array
    {
        $environment = getenv();
        if (!\is_array($environment)) {
            $environment = [];
        }

        $composerHome = $workingDirectory.'/var/composer-home';
        if (!is_dir($composerHome) && !mkdir($composerHome, 0775, true) && !is_dir($composerHome)) {
            throw new \RuntimeException('Kunde inte skapa Composer HOME för efteruppdatering.');
        }

        if (!isset($environment['HOME']) || '' === trim((string) $environment['HOME'])) {
            $environment['HOME'] = $composerHome;
        }

        if (!isset($environment['COMPOSER_HOME']) || '' === trim((string) $environment['COMPOSER_HOME'])) {
            $environment['COMPOSER_HOME'] = $composerHome;
        }

        /** @var array<string, string> $environment */
        return $environment;
    }
}
