<?php

declare(strict_types=1);

namespace App\Module\System\Service;

use App\Module\Notification\Entity\NotificationLog;
use App\Module\System\Entity\SystemAuditLog;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\DependencyInjection\Attribute\Autowire;
use Symfony\Component\HttpFoundation\Request;

final class AdminLogCenterBuilder
{
    private const SYSTEM_PER_PAGE = 30;
    private const NOTIFICATION_PER_PAGE = 25;
    private const AUDIT_PER_PAGE = 25;
    private const JOB_PER_PAGE = 25;

    public function __construct(
        private readonly EntityManagerInterface $entityManager,
        #[Autowire('%kernel.project_dir%')]
        private readonly string $projectDir,
    ) {
    }

    /**
     * @return array<string, mixed>
     */
    public function build(Request $request, bool $includeSensitive): array
    {
        $activeTab = trim((string) $request->query->get('tab', 'overview'));
        if (!$request->query->has('tab') && $this->hasNotificationFilters($request)) {
            $activeTab = 'notifications';
        }
        $allowedTabs = ['overview', 'notifications'];
        if ($includeSensitive) {
            $allowedTabs = array_merge($allowedTabs, ['system', 'audit', 'jobs']);
        }
        if (!\in_array($activeTab, $allowedTabs, true)) {
            $activeTab = 'notifications';
        }

        $notifications = $this->buildNotificationView($request);
        $system = $includeSensitive ? $this->buildSystemLogView($request) : $this->emptySystemLogView();
        $audit = $includeSensitive ? $this->buildAuditView($request) : $this->emptyPagedView();
        $jobs = $includeSensitive ? $this->buildJobView($request) : $this->emptyPagedView();

        return [
            'activeTab' => $activeTab,
            'tabs' => array_values(array_filter([
                ['id' => 'overview', 'label' => 'Överblick', 'sensitive' => false],
                ['id' => 'notifications', 'label' => 'Notifieringar', 'sensitive' => false],
                $includeSensitive ? ['id' => 'system', 'label' => 'Systemloggar', 'sensitive' => true] : null,
                $includeSensitive ? ['id' => 'audit', 'label' => 'Driftåtgärder', 'sensitive' => true] : null,
                $includeSensitive ? ['id' => 'jobs', 'label' => 'Jobbfel', 'sensitive' => true] : null,
            ])),
            'overview' => [
                'systemErrors' => $system['summary']['error'] ?? 0,
                'systemWarnings' => $system['summary']['warning'] ?? 0,
                'skippedNotifications' => $notifications['summary']['skipped'] ?? 0,
                'failedJobs' => $jobs['summary']['failed'] ?? 0,
                'latestImportant' => $this->latestImportant($system, $notifications, $jobs, $includeSensitive),
            ],
            'notifications' => $notifications,
            'system' => $system,
            'audit' => $audit,
            'jobs' => $jobs,
            'clearPreviews' => [
                'system' => [
                    'count' => $system['pagination']['total'] ?? 0,
                    'label' => ($system['selectedFile']['name'] ?? '') !== '' ? $system['selectedFile']['name'] : 'Ingen fil vald',
                ],
                'notifications' => [
                    'count' => $notifications['pagination']['total'] ?? 0,
                    'label' => 'matchande notifieringar',
                ],
                'audit' => [
                    'count' => $audit['pagination']['total'] ?? 0,
                    'label' => 'matchande driftåtgärder',
                ],
                'jobs' => [
                    'count' => $jobs['summary']['clearable'] ?? 0,
                    'label' => 'avslutade eller misslyckade jobbloggar',
                ],
            ],
        ];
    }

    private function hasNotificationFilters(Request $request): bool
    {
        return '' !== trim((string) $request->query->get('q', ''))
            || 'all' !== trim((string) $request->query->get('delivery', 'all'))
            || 'all' !== trim((string) $request->query->get('event', 'all'))
            || 'all' !== trim((string) $request->query->get('date', 'all'));
    }

    /**
     * @return list<array<string, string|int|null>>
     */
    public function notificationExportRows(Request $request): array
    {
        return array_map(
            static fn (NotificationLog $log): array => [
                'created_at' => $log->getCreatedAt()->format('Y-m-d H:i:s'),
                'delivery' => $log->isSent() ? 'Skickat' : 'Hoppat över',
                'recipient' => $log->getRecipientEmail(),
                'event' => $log->getEventType(),
                'subject' => $log->getSubject(),
                'status' => $log->getStatusMessage(),
                'ticket' => $log->getTicket()?->getReference(),
            ],
            $this->notificationQuery($this->notificationFilters($request))
                ->setMaxResults(5000)
                ->getQuery()
                ->getResult(),
        );
    }

    /**
     * @return list<array<string, string|int|null>>
     */
    public function systemExportRows(Request $request): array
    {
        $view = $this->buildSystemLogView($request, 5000);

        return array_map(
            static fn (array $entry): array => [
                'latest_at' => $entry['latestAt'],
                'first_at' => $entry['firstAt'],
                'level' => $entry['level'],
                'channel' => $entry['channel'],
                'count' => $entry['count'],
                'message' => $entry['message'],
            ],
            $view['allEntries'],
        );
    }

    /**
     * @return list<array<string, string|null>>
     */
    public function auditExportRows(Request $request): array
    {
        return array_map(
            static fn (SystemAuditLog $log): array => [
                'created_at' => $log->getCreatedAt()->format('Y-m-d H:i:s'),
                'actor' => $log->getActorEmail(),
                'action' => $log->getAction(),
                'title' => $log->getTitle(),
                'message' => $log->getMessage(),
            ],
            $this->auditQuery($this->auditFilters($request))
                ->setMaxResults(5000)
                ->getQuery()
                ->getResult(),
        );
    }

    /**
     * @return list<array<string, string|null>>
     */
    public function jobExportRows(Request $request): array
    {
        return array_map(
            static fn (array $job): array => [
                'queued_at' => $job['queuedAt']->format('Y-m-d H:i:s'),
                'source' => $job['source'],
                'status' => $job['status'],
                'id' => $job['id'],
                'title' => $job['title'],
                'detail' => $job['detail'],
                'output' => $job['output'],
            ],
            array_slice($this->filteredJobs($request), 0, 5000),
        );
    }

    /**
     * @return array<string, mixed>
     */
    private function buildNotificationView(Request $request): array
    {
        $filters = $this->notificationFilters($request);
        $page = max(1, $request->query->getInt('notification_page', 1));
        $query = $this->notificationQuery($filters);
        $total = $this->countQuery($query, 'log.id');
        $items = $query
            ->setFirstResult(($page - 1) * self::NOTIFICATION_PER_PAGE)
            ->setMaxResults(self::NOTIFICATION_PER_PAGE)
            ->getQuery()
            ->getResult();

        return [
            'items' => $items,
            'groups' => $this->groupItemsByDate($items, static fn (NotificationLog $log): ?\DateTimeInterface => $log->getCreatedAt()),
            'filters' => $filters,
            'eventTypes' => $this->notificationEventTypes(),
            'pagination' => $this->pagination($total, $page, self::NOTIFICATION_PER_PAGE),
            'summary' => [
                'total' => $total,
                'sent' => $this->countNotificationDelivery(true),
                'skipped' => $this->countNotificationDelivery(false),
            ],
        ];
    }

    /**
     * @return array{q: string, delivery: string, event: string, date: string}
     */
    public function notificationFilters(Request $request): array
    {
        return [
            'q' => trim((string) $request->query->get('q', $request->request->get('q', ''))),
            'delivery' => trim((string) $request->query->get('delivery', $request->request->get('delivery', 'all'))),
            'event' => trim((string) $request->query->get('event', $request->request->get('event', 'all'))),
            'date' => trim((string) $request->query->get('date', $request->request->get('date', 'all'))),
        ];
    }

    /**
     * @param array{q: string, delivery: string, event: string, date: string} $filters
     */
    public function notificationQuery(array $filters): \Doctrine\ORM\QueryBuilder
    {
        $qb = $this->entityManager->getRepository(NotificationLog::class)
            ->createQueryBuilder('log')
            ->leftJoin('log.ticket', 'ticket')
            ->orderBy('log.createdAt', 'DESC');

        if ('' !== $filters['q']) {
            $qb
                ->andWhere('LOWER(log.recipientEmail) LIKE :query OR LOWER(log.subject) LIKE :query OR LOWER(log.statusMessage) LIKE :query OR LOWER(ticket.reference) LIKE :query')
                ->setParameter('query', '%'.mb_strtolower($filters['q']).'%');
        }

        if ('sent' === $filters['delivery']) {
            $qb->andWhere('log.sent = true');
        } elseif ('skipped' === $filters['delivery']) {
            $qb->andWhere('log.sent = false');
        }

        if ('all' !== $filters['event'] && '' !== $filters['event']) {
            $qb->andWhere('log.eventType = :eventType')->setParameter('eventType', $filters['event']);
        }

        $this->applyDateFilter($qb, 'log.createdAt', $filters['date']);

        return $qb;
    }

    /**
     * @return list<string>
     */
    private function notificationEventTypes(): array
    {
        $rows = $this->entityManager->getRepository(NotificationLog::class)
            ->createQueryBuilder('log')
            ->select('DISTINCT log.eventType AS eventType')
            ->orderBy('log.eventType', 'ASC')
            ->getQuery()
            ->getScalarResult();

        return array_values(array_filter(array_map(
            static fn (array $row): string => (string) ($row['eventType'] ?? ''),
            $rows,
        )));
    }

    private function countNotificationDelivery(bool $sent): int
    {
        return (int) $this->entityManager->getRepository(NotificationLog::class)
            ->createQueryBuilder('log')
            ->select('COUNT(log.id)')
            ->andWhere('log.sent = :sent')
            ->setParameter('sent', $sent)
            ->getQuery()
            ->getSingleScalarResult();
    }

    /**
     * @return array<string, mixed>
     */
    private function buildSystemLogView(Request $request, int $maxEntries = self::SYSTEM_PER_PAGE): array
    {
        $files = $this->listSystemLogFiles();
        $selectedFile = $this->selectSystemLogFile($files, trim((string) $request->query->get('system_log_file', $request->request->get('system_log_file', ''))));
        $filters = [
            'file' => $selectedFile['name'] ?? '',
            'level' => trim((string) $request->query->get('system_log_level', $request->request->get('system_log_level', 'all'))),
            'q' => trim((string) $request->query->get('system_log_q', $request->request->get('system_log_q', ''))),
        ];
        $page = max(1, $request->query->getInt('system_page', 1));
        $entries = null !== $selectedFile ? $this->parseSystemLogEntries($selectedFile['path']) : [];
        $filtered = array_values(array_filter($entries, fn (array $entry): bool => $this->matchesSystemEntry($entry, $filters)));
        $grouped = $this->groupSystemLogEntries($filtered);
        $total = \count($grouped);

        return [
            'files' => $files,
            'selectedFile' => $selectedFile,
            'entries' => array_slice($grouped, ($page - 1) * self::SYSTEM_PER_PAGE, $maxEntries),
            'groups' => $this->groupItemsByDate(
                array_slice($grouped, ($page - 1) * self::SYSTEM_PER_PAGE, $maxEntries),
                fn (array $entry): ?\DateTimeInterface => $this->dateFromSystemTimestamp($entry['latestAt'] ?? null),
            ),
            'allEntries' => $grouped,
            'filters' => $filters,
            'pagination' => $this->pagination($total, $page, self::SYSTEM_PER_PAGE),
            'summary' => $this->systemSummary($filtered),
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function emptySystemLogView(): array
    {
        return [
            'files' => [],
            'selectedFile' => null,
            'entries' => [],
            'groups' => [],
            'allEntries' => [],
            'filters' => ['file' => '', 'level' => 'all', 'q' => ''],
            'pagination' => $this->pagination(0, 1, self::SYSTEM_PER_PAGE),
            'summary' => ['total' => 0, 'error' => 0, 'warning' => 0, 'info' => 0, 'debug' => 0],
        ];
    }

    /**
     * @return list<array{name: string, path: string, size: int, modifiedAt: ?\DateTimeImmutable}>
     */
    public function listSystemLogFiles(): array
    {
        $logDirectory = $this->projectDir.'/var/log';
        if (!is_dir($logDirectory)) {
            return [];
        }

        $files = [];
        foreach (scandir($logDirectory) ?: [] as $filename) {
            if ('.' === $filename || '..' === $filename || !str_ends_with($filename, '.log')) {
                continue;
            }

            $path = $logDirectory.'/'.$filename;
            if (!is_file($path) || !is_readable($path)) {
                continue;
            }

            $modifiedAt = filemtime($path);
            $files[] = [
                'name' => $filename,
                'path' => $path,
                'size' => (int) (filesize($path) ?: 0),
                'modifiedAt' => false !== $modifiedAt ? new \DateTimeImmutable('@'.$modifiedAt) : null,
            ];
        }

        usort($files, static fn (array $left, array $right): int => ($right['modifiedAt']?->getTimestamp() ?? 0) <=> ($left['modifiedAt']?->getTimestamp() ?? 0));

        return $files;
    }

    /**
     * @param list<array{name: string, path: string, size: int, modifiedAt: ?\DateTimeImmutable}> $files
     * @return array{name: string, path: string, size: int, modifiedAt: ?\DateTimeImmutable}|null
     */
    private function selectSystemLogFile(array $files, string $selectedFileName): ?array
    {
        foreach ($files as $file) {
            if ($file['name'] === $selectedFileName) {
                return $file;
            }
        }

        return $files[0] ?? null;
    }

    /**
     * @return list<array{at: ?string, channel: ?string, level: string, message: string}>
     */
    public function parseSystemLogEntries(string $path): array
    {
        $content = $this->readTailFromFile($path, 350000);
        if ('' === $content) {
            return [];
        }

        $entries = [];
        $currentEntry = null;

        foreach (preg_split("/\r\n|\n|\r/", $content) ?: [] as $line) {
            if (preg_match('/^\[(?<at>[^\]]+)\]\s+(?:(?<channel>[A-Za-z0-9_.-]+)\.)?(?<level>DEBUG|INFO|NOTICE|WARNING|ERROR|CRITICAL|ALERT|EMERGENCY):\s*(?<message>.*)$/', $line, $matches) === 1) {
                if (null !== $currentEntry) {
                    $entries[] = $currentEntry;
                }

                $currentEntry = [
                    'at' => trim((string) $matches['at']),
                    'channel' => '' !== trim((string) ($matches['channel'] ?? '')) ? trim((string) $matches['channel']) : null,
                    'level' => strtoupper(trim((string) $matches['level'])),
                    'message' => trim((string) $matches['message']),
                ];

                continue;
            }

            if (null !== $currentEntry) {
                $currentEntry['message'] .= "\n".$line;
                continue;
            }

            if ('' === trim($line)) {
                continue;
            }

            $entries[] = [
                'at' => null,
                'channel' => null,
                'level' => $this->inferSystemLogLevel($line),
                'message' => trim($line),
            ];
        }

        if (null !== $currentEntry) {
            $entries[] = $currentEntry;
        }

        return $entries;
    }

    /**
     * @param array{level: string, q: string} $filters
     */
    private function matchesSystemEntry(array $entry, array $filters): bool
    {
        if ('all' !== $filters['level'] && '' !== $filters['level'] && mb_strtolower((string) $entry['level']) !== mb_strtolower($filters['level'])) {
            return false;
        }

        if ('' === $filters['q']) {
            return true;
        }

        $needle = mb_strtolower($filters['q']);
        $haystack = mb_strtolower(implode(' ', array_filter([
            $entry['at'],
            $entry['channel'],
            $entry['level'],
            $entry['message'],
        ], static fn (mixed $value): bool => \is_string($value) && '' !== $value)));

        return str_contains($haystack, $needle);
    }

    /**
     * @param list<array{at: ?string, channel: ?string, level: string, message: string}> $entries
     * @return list<array{firstAt: ?string, latestAt: ?string, channel: ?string, level: string, message: string, count: int}>
     */
    private function groupSystemLogEntries(array $entries): array
    {
        $groups = [];

        foreach ($entries as $entry) {
            $key = implode("\0", [
                $entry['level'],
                $entry['channel'] ?? '',
                $entry['message'],
            ]);

            if (!isset($groups[$key])) {
                $groups[$key] = [
                    'firstAt' => $entry['at'],
                    'latestAt' => $entry['at'],
                    'channel' => $entry['channel'],
                    'level' => $entry['level'],
                    'message' => $entry['message'],
                    'count' => 0,
                ];
            }

            ++$groups[$key]['count'];
            $groups[$key]['latestAt'] = $entry['at'] ?? $groups[$key]['latestAt'];
        }

        $grouped = array_values($groups);
        usort($grouped, static fn (array $left, array $right): int => strcmp((string) ($right['latestAt'] ?? ''), (string) ($left['latestAt'] ?? '')));

        return $grouped;
    }

    /**
     * @param list<array{level: string}> $entries
     * @return array{total: int, error: int, warning: int, info: int, debug: int}
     */
    private function systemSummary(array $entries): array
    {
        return [
            'total' => \count($entries),
            'error' => \count(array_filter($entries, static fn (array $entry): bool => \in_array($entry['level'], ['ERROR', 'CRITICAL', 'ALERT', 'EMERGENCY'], true))),
            'warning' => \count(array_filter($entries, static fn (array $entry): bool => 'WARNING' === $entry['level'])),
            'info' => \count(array_filter($entries, static fn (array $entry): bool => \in_array($entry['level'], ['INFO', 'NOTICE'], true))),
            'debug' => \count(array_filter($entries, static fn (array $entry): bool => 'DEBUG' === $entry['level'])),
        ];
    }

    private function readTailFromFile(string $path, int $maxBytes): string
    {
        $size = filesize($path);
        if (false === $size || 0 === $size) {
            return '';
        }

        $handle = @fopen($path, 'rb');
        if (false === $handle) {
            return '';
        }

        $offset = max(0, $size - $maxBytes);
        fseek($handle, $offset);
        $content = (string) stream_get_contents($handle);
        fclose($handle);

        if ($offset > 0) {
            $firstNewline = strpos($content, "\n");
            if (false !== $firstNewline) {
                $content = substr($content, $firstNewline + 1);
            }
        }

        return trim($content);
    }

    private function inferSystemLogLevel(string $line): string
    {
        $normalized = mb_strtolower($line);
        foreach ([
            'CRITICAL' => ['critical', 'fatal', 'panic', 'emergency'],
            'ERROR' => ['error', 'exception', 'failed', 'failure'],
            'WARNING' => ['warning', 'deprecated', 'slow'],
            'INFO' => ['info', 'notice'],
            'DEBUG' => ['debug', 'trace'],
        ] as $level => $keywords) {
            foreach ($keywords as $keyword) {
                if (str_contains($normalized, $keyword)) {
                    return $level;
                }
            }
        }

        return 'INFO';
    }

    /**
     * @return array<string, mixed>
     */
    private function buildAuditView(Request $request): array
    {
        $filters = $this->auditFilters($request);
        $page = max(1, $request->query->getInt('audit_page', 1));
        $query = $this->auditQuery($filters);
        $total = $this->countQuery($query, 'log.id');
        $items = $query
            ->setFirstResult(($page - 1) * self::AUDIT_PER_PAGE)
            ->setMaxResults(self::AUDIT_PER_PAGE)
            ->getQuery()
            ->getResult();

        return [
            'items' => $items,
            'groups' => $this->groupItemsByDate($items, static fn (SystemAuditLog $log): ?\DateTimeInterface => $log->getCreatedAt()),
            'filters' => $filters,
            'pagination' => $this->pagination($total, $page, self::AUDIT_PER_PAGE),
            'summary' => ['total' => $total],
        ];
    }

    /**
     * @return array{audit_q: string, audit_date: string}
     */
    public function auditFilters(Request $request): array
    {
        return [
            'audit_q' => trim((string) $request->query->get('audit_q', $request->request->get('audit_q', ''))),
            'audit_date' => trim((string) $request->query->get('audit_date', $request->request->get('audit_date', 'all'))),
        ];
    }

    /**
     * @param array{audit_q: string, audit_date: string} $filters
     */
    public function auditQuery(array $filters): \Doctrine\ORM\QueryBuilder
    {
        $qb = $this->entityManager->getRepository(SystemAuditLog::class)
            ->createQueryBuilder('log')
            ->orderBy('log.createdAt', 'DESC');

        if ('' !== $filters['audit_q']) {
            $qb
                ->andWhere('LOWER(log.actorEmail) LIKE :auditQuery OR LOWER(log.action) LIKE :auditQuery OR LOWER(log.title) LIKE :auditQuery OR LOWER(log.message) LIKE :auditQuery')
                ->setParameter('auditQuery', '%'.mb_strtolower($filters['audit_q']).'%');
        }

        $this->applyDateFilter($qb, 'log.createdAt', $filters['audit_date']);

        return $qb;
    }

    /**
     * @return array<string, mixed>
     */
    private function buildJobView(Request $request): array
    {
        $filters = $this->jobFilters($request);
        $page = max(1, $request->query->getInt('job_page', 1));
        $filtered = $this->filteredJobs($request);
        $total = \count($filtered);
        $items = array_slice($filtered, ($page - 1) * self::JOB_PER_PAGE, self::JOB_PER_PAGE);

        return [
            'items' => $items,
            'groups' => $this->groupItemsByDate($items, static fn (array $job): ?\DateTimeInterface => $job['queuedAt'] ?? null),
            'filters' => $filters,
            'pagination' => $this->pagination($total, $page, self::JOB_PER_PAGE),
            'summary' => [
                'total' => $total,
                'failed' => \count(array_filter($filtered, static fn (array $job): bool => 'failed' === $job['status'])),
                'clearable' => \count(array_filter($filtered, static fn (array $job): bool => \in_array($job['status'], ['completed', 'failed'], true))),
            ],
        ];
    }

    /**
     * @return list<array<string, mixed>>
     */
    public function filteredJobs(Request $request): array
    {
        $filters = $this->jobFilters($request);
        $jobs = $this->allJobs();

        return array_values(array_filter(
            $jobs,
            function (array $job) use ($filters): bool {
                if ('all' !== $filters['job_source'] && '' !== $filters['job_source'] && $job['source'] !== $filters['job_source']) {
                    return false;
                }

                if ('all' !== $filters['job_status'] && '' !== $filters['job_status']) {
                    if ('active' === $filters['job_status']) {
                        if (!\in_array($job['status'], ['queued', 'running'], true)) {
                            return false;
                        }
                    } elseif ($job['status'] !== $filters['job_status']) {
                        return false;
                    }
                }

                if (!$this->matchesDatePreset($job['queuedAt'], $filters['job_date'])) {
                    return false;
                }

                if ('' !== $filters['job_query']) {
                    $query = mb_strtolower($filters['job_query']);
                    $haystack = mb_strtolower(implode(' ', [
                        $job['id'],
                        $job['source'],
                        $job['title'],
                        $job['detail'],
                        $job['output'],
                    ]));

                    if (!str_contains($haystack, $query)) {
                        return false;
                    }
                }

                return true;
            },
        ));
    }

    /**
     * @return array{job_source: string, job_status: string, job_query: string, job_date: string}
     */
    public function jobFilters(Request $request): array
    {
        return [
            'job_source' => trim((string) $request->query->get('job_source', $request->request->get('job_source', 'all'))),
            'job_status' => trim((string) $request->query->get('job_status', $request->request->get('job_status', 'all'))),
            'job_query' => trim((string) $request->query->get('job_query', $request->request->get('job_query', ''))),
            'job_date' => trim((string) $request->query->get('job_date', $request->request->get('job_date', 'all'))),
        ];
    }

    /**
     * @return list<array<string, mixed>>
     */
    private function allJobs(): array
    {
        $jobs = array_merge(
            $this->databaseJobRecords(),
            $this->codeUpdateRunRecords(),
            $this->postUpdateRunRecords(),
        );

        usort($jobs, static fn (array $left, array $right): int => $right['queuedAt']->getTimestamp() <=> $left['queuedAt']->getTimestamp());

        return $jobs;
    }

    /**
     * @return list<array<string, mixed>>
     */
    private function databaseJobRecords(): array
    {
        $jobs = [];
        foreach ($this->jsonRecords($this->projectDir.'/var/database_jobs') as $record) {
            if (!isset($record['id'], $record['queuedAt'], $record['status'], $record['label'])) {
                continue;
            }

            try {
                $queuedAt = new \DateTimeImmutable((string) $record['queuedAt']);
            } catch (\Throwable) {
                continue;
            }

            $jobs[] = [
                'id' => (string) $record['id'],
                'source' => 'database',
                'title' => (string) $record['label'],
                'status' => (string) $record['status'],
                'queuedAt' => $queuedAt,
                'startedAt' => $this->nullableDate($record['startedAt'] ?? null),
                'finishedAt' => $this->nullableDate($record['finishedAt'] ?? null),
                'detail' => \is_string($record['resultSummary'] ?? null) && '' !== trim((string) $record['resultSummary'])
                    ? (string) $record['resultSummary']
                    : 'Databasjobb i kö eller pågående.',
                'output' => \is_string($record['output'] ?? null) ? (string) $record['output'] : '',
            ];
        }

        return $jobs;
    }

    /**
     * @return list<array<string, mixed>>
     */
    private function codeUpdateRunRecords(): array
    {
        $jobs = [];
        foreach ($this->jsonRecords($this->projectDir.'/var/code_update_runs') as $record) {
            if (!isset($record['id'], $record['packageId'], $record['queuedAt'], $record['status'])) {
                continue;
            }

            try {
                $queuedAt = new \DateTimeImmutable((string) $record['queuedAt']);
            } catch (\Throwable) {
                continue;
            }

            $jobs[] = [
                'id' => (string) $record['id'],
                'source' => 'code_updates',
                'title' => 'Koduppdatering',
                'status' => (string) $record['status'],
                'queuedAt' => $queuedAt,
                'startedAt' => $this->nullableDate($record['startedAt'] ?? null),
                'finishedAt' => $this->nullableDate($record['finishedAt'] ?? null),
                'detail' => trim(sprintf('%s %s', (string) ($record['packageName'] ?? 'Okänt paket'), (string) ($record['packageVersion'] ?? 'okänd'))),
                'output' => \is_string($record['output'] ?? null) ? (string) $record['output'] : '',
            ];
        }

        return $jobs;
    }

    /**
     * @return list<array<string, mixed>>
     */
    private function postUpdateRunRecords(): array
    {
        $jobs = [];
        $records = array_merge(
            $this->jsonRecords($this->projectDir.'/var/post_update_runs'),
            $this->jsonRecords($this->projectDir.'/var/code_update_runs'),
        );

        foreach ($records as $record) {
            if (!isset($record['id'], $record['queuedAt'], $record['selectedTasks'], $record['taskResults'], $record['status'])) {
                continue;
            }

            try {
                $queuedAt = new \DateTimeImmutable((string) $record['queuedAt']);
            } catch (\Throwable) {
                continue;
            }

            $taskResults = \is_array($record['taskResults']) ? $record['taskResults'] : [];
            $selectedTasks = \is_array($record['selectedTasks']) ? $record['selectedTasks'] : [];
            $outputs = [];
            foreach ($taskResults as $taskResult) {
                if (!\is_array($taskResult)) {
                    continue;
                }

                $outputs[] = sprintf(
                    '[%s] %s%s%s',
                    ($taskResult['succeeded'] ?? false) ? 'OK' : 'FAIL',
                    (string) ($taskResult['label'] ?? ''),
                    "\n",
                    (string) ($taskResult['output'] ?? ''),
                );
            }

            $jobs[] = [
                'id' => (string) $record['id'],
                'source' => 'updates',
                'title' => 'Efter uppdatering',
                'status' => (string) $record['status'],
                'queuedAt' => $queuedAt,
                'startedAt' => $this->nullableDate($record['startedAt'] ?? null),
                'finishedAt' => $this->nullableDate($record['finishedAt'] ?? null),
                'detail' => [] !== $taskResults ? sprintf('%d steg loggade.', \count($taskResults)) : sprintf('%d steg valda.', \count($selectedTasks)),
                'output' => implode("\n\n", $outputs),
            ];
        }

        return $jobs;
    }

    /**
     * @return list<array<string, mixed>>
     */
    private function jsonRecords(string $directory): array
    {
        if (!is_dir($directory)) {
            return [];
        }

        $records = [];
        foreach (glob($directory.\DIRECTORY_SEPARATOR.'*.json') ?: [] as $path) {
            try {
                $record = json_decode((string) file_get_contents($path), true, 512, \JSON_THROW_ON_ERROR);
            } catch (\JsonException) {
                continue;
            }

            if (\is_array($record)) {
                $records[] = $record;
            }
        }

        return $records;
    }

    private function nullableDate(mixed $value): ?\DateTimeImmutable
    {
        if (!\is_string($value) || '' === trim($value)) {
            return null;
        }

        try {
            return new \DateTimeImmutable($value);
        } catch (\Throwable) {
            return null;
        }
    }

    /**
     * @return array{items: list<mixed>, filters: array<string, string>, pagination: array<string, int>, summary: array<string, int>}
     */
    private function emptyPagedView(): array
    {
        return [
            'items' => [],
            'groups' => [],
            'filters' => [],
            'pagination' => $this->pagination(0, 1, 25),
            'summary' => ['total' => 0, 'failed' => 0, 'clearable' => 0],
        ];
    }

    /**
     * @template T
     * @param list<T> $items
     * @param callable(T): ?\DateTimeInterface $dateResolver
     * @return list<array{key: string, label: string, count: int, items: list<T>}>
     */
    private function groupItemsByDate(array $items, callable $dateResolver): array
    {
        $groups = [];

        foreach ($items as $item) {
            $date = $dateResolver($item);
            $key = $date instanceof \DateTimeInterface ? $date->format('Y-m-d') : 'no-date';
            if (!isset($groups[$key])) {
                $groups[$key] = [
                    'key' => $key,
                    'label' => $this->dateGroupLabel($date),
                    'count' => 0,
                    'items' => [],
                ];
            }

            ++$groups[$key]['count'];
            $groups[$key]['items'][] = $item;
        }

        return array_values($groups);
    }

    private function dateGroupLabel(?\DateTimeInterface $date): string
    {
        if (!$date instanceof \DateTimeInterface) {
            return 'Utan datum';
        }

        $dateKey = $date->format('Y-m-d');
        $today = (new \DateTimeImmutable('today'))->format('Y-m-d');
        $yesterday = (new \DateTimeImmutable('yesterday'))->format('Y-m-d');

        return match ($dateKey) {
            $today => 'Idag',
            $yesterday => 'Igår',
            default => $dateKey,
        };
    }

    private function dateFromSystemTimestamp(mixed $value): ?\DateTimeInterface
    {
        if (!\is_string($value) || '' === trim($value)) {
            return null;
        }

        try {
            return new \DateTimeImmutable($value);
        } catch (\Throwable) {
            return null;
        }
    }

    /**
     * @return list<array{label: string, detail: string, tab: string, tone: string}>
     */
    private function latestImportant(array $system, array $notifications, array $jobs, bool $includeSensitive): array
    {
        $items = [];
        if ($includeSensitive) {
            foreach (array_slice($system['entries'] ?? [], 0, 3) as $entry) {
                if (!\in_array($entry['level'], ['ERROR', 'CRITICAL', 'ALERT', 'EMERGENCY', 'WARNING'], true)) {
                    continue;
                }
                $items[] = [
                    'label' => $entry['level'].' · '.($entry['channel'] ?? 'system'),
                    'detail' => mb_substr($entry['message'], 0, 180),
                    'tab' => 'system',
                    'tone' => 'ERROR' === $entry['level'] ? 'red' : 'orange',
                ];
            }

            foreach (array_slice($jobs['items'] ?? [], 0, 3) as $job) {
                if ('failed' !== $job['status']) {
                    continue;
                }
                $items[] = [
                    'label' => 'Jobbfel · '.$job['title'],
                    'detail' => $job['detail'],
                    'tab' => 'jobs',
                    'tone' => 'red',
                ];
            }
        }

        foreach (array_slice($notifications['items'] ?? [], 0, 3) as $log) {
            if (!$log instanceof NotificationLog || $log->isSent()) {
                continue;
            }
            $items[] = [
                'label' => 'Notifiering hoppades över',
                'detail' => $log->getRecipientEmail().' · '.$log->getStatusMessage(),
                'tab' => 'notifications',
                'tone' => 'blue',
            ];
        }

        return array_slice($items, 0, 6);
    }

    private function countQuery(\Doctrine\ORM\QueryBuilder $queryBuilder, string $field): int
    {
        $countQuery = clone $queryBuilder;
        $countQuery
            ->resetDQLPart('orderBy')
            ->setFirstResult(0)
            ->setMaxResults(null)
            ->select(sprintf('COUNT(%s)', $field));

        return (int) $countQuery->getQuery()->getSingleScalarResult();
    }

    private function applyDateFilter(\Doctrine\ORM\QueryBuilder $qb, string $field, string $dateFilter): void
    {
        $now = new \DateTimeImmutable();
        if ('today' === $dateFilter) {
            $qb
                ->andWhere(sprintf('%s >= :dateFrom', $field))
                ->setParameter('dateFrom', $now->setTime(0, 0));
        } elseif ('last_7_days' === $dateFilter) {
            $qb
                ->andWhere(sprintf('%s >= :dateFrom', $field))
                ->setParameter('dateFrom', $now->modify('-7 days'));
        } elseif ('older' === $dateFilter) {
            $qb
                ->andWhere(sprintf('%s < :dateBefore', $field))
                ->setParameter('dateBefore', $now->modify('-7 days'));
        }
    }

    private function matchesDatePreset(\DateTimeImmutable $date, string $dateFilter): bool
    {
        $now = new \DateTimeImmutable();

        return match ($dateFilter) {
            'today' => $date >= $now->setTime(0, 0),
            'last_7_days' => $date >= $now->modify('-7 days'),
            'older' => $date < $now->modify('-7 days'),
            default => true,
        };
    }

    /**
     * @return array{total: int, page: int, perPage: int, pages: int, from: int, to: int}
     */
    private function pagination(int $total, int $page, int $perPage): array
    {
        $pages = max(1, (int) ceil($total / max(1, $perPage)));
        $page = min(max(1, $page), $pages);

        return [
            'total' => $total,
            'page' => $page,
            'perPage' => $perPage,
            'pages' => $pages,
            'from' => 0 === $total ? 0 : (($page - 1) * $perPage) + 1,
            'to' => min($total, $page * $perPage),
        ];
    }
}
