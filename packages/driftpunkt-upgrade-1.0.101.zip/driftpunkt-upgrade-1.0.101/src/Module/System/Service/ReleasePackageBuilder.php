<?php

declare(strict_types=1);

namespace App\Module\System\Service;

use Symfony\Component\DependencyInjection\Attribute\Autowire;

final class ReleasePackageBuilder
{
    private const MINIMUM_SUPPORTED_CUMULATIVE_UPGRADE_VERSION = '1.0.0';

    /**
     * @var list<string>
     */
    private const UPGRADE_PACKAGE_PATHS = [
        '.htaccess',
        'Dockerfile',
        'README.md',
        'bin',
        'composer.json',
        'composer.lock',
        'config',
        'deploy',
        'docs/addon_build_and_release_guide.md',
        'docs/api_integration.md',
        'docs/debian_server_setup.md',
        'docs/installation_and_deployment.md',
        'docs/known_limitations.md',
        'docs/mail_configuration_guide.md',
        'docs/mail_polling_operations.md',
        'docs/nas_docker_setup.md',
        'docs/security_requirements.md',
        'docs/ticket_attachment_archiving_operations.md',
        'htdocs',
        'index.php',
        'migrations',
        'public',
        'src',
        'symfony.lock',
        'templates',
        'translations',
        'vendor',
    ];

    /**
     * @var list<string>
     */
    private const INSTALL_PACKAGE_PATHS = [
        '.htaccess',
        'Dockerfile',
        'README.md',
        'bin',
        'composer',
        'composer.json',
        'composer.lock',
        'compose.override.yaml',
        'compose.yaml',
        'config',
        'deploy',
        'docs/addon_build_and_release_guide.md',
        'docs/api_integration.md',
        'docs/debian_server_setup.md',
        'docs/installation_and_deployment.md',
        'docs/known_limitations.md',
        'docs/mail_configuration_guide.md',
        'docs/mail_polling_operations.md',
        'docs/nas_docker_setup.md',
        'docs/security_requirements.md',
        'docs/ticket_attachment_archiving_operations.md',
        'htdocs',
        'index.php',
        'migrations',
        'public',
        'src',
        'symfony.lock',
        'templates',
        'translations',
        'vendor',
    ];

    public function __construct(
        #[Autowire('%kernel.project_dir%')]
        private readonly string $projectDir,
    ) {
    }

    /**
     * @param 'upgrade'|'install'|'both' $packageType
     *
     * @return list<array{
     *     type: string,
     *     version: string,
     *     filename: string,
     *     path: string,
     *     checksumSha256: string,
     *     checksumPath: string,
     *     sizeBytes: int,
     *     entries: int
     * }>
     */
    public function buildPackages(string $packageType = 'both', ?string $version = null, ?string $outputDirectory = null): array
    {
        $normalizedType = strtolower(trim($packageType));
        if (!\in_array($normalizedType, ['upgrade', 'install', 'both'], true)) {
            throw new \RuntimeException('Pakettypen måste vara upgrade, install eller both.');
        }

        $application = $this->describeApplication();
        $resolvedVersion = $this->resolveVersion($application, $version);
        if (null === $version) {
            $this->assertSequentialReleaseVersion($resolvedVersion);
        }
        $distDirectory = $this->ensureOutputDirectory($outputDirectory ?? $this->projectDir.\DIRECTORY_SEPARATOR.'dist');

        $packages = [];
        if (\in_array($normalizedType, ['upgrade', 'both'], true)) {
            $packages[] = $this->buildPackageArchive(
                'upgrade',
                $resolvedVersion,
                $application['name'],
                self::UPGRADE_PACKAGE_PATHS,
                $distDirectory,
            );
        }

        if (\in_array($normalizedType, ['install', 'both'], true)) {
            $packages[] = $this->buildPackageArchive(
                'install',
                $resolvedVersion,
                $application['name'],
                self::INSTALL_PACKAGE_PATHS,
                $distDirectory,
            );
        }

        return $packages;
    }

    /**
     * @return array{name: string, version: string}
     */
    private function describeApplication(): array
    {
        $composerPath = $this->projectDir.\DIRECTORY_SEPARATOR.'composer.json';
        if (!is_file($composerPath)) {
            throw new \RuntimeException('composer.json kunde inte hittas för releasebygget.');
        }

        try {
            /** @var array<string, mixed> $composer */
            $composer = json_decode((string) file_get_contents($composerPath), true, 512, \JSON_THROW_ON_ERROR);
        } catch (\JsonException $exception) {
            throw new \RuntimeException('composer.json kunde inte läsas för releasebygget.', 0, $exception);
        }

        return [
            'name' => isset($composer['name']) && \is_string($composer['name']) ? $composer['name'] : 'driftpunkt',
            'version' => isset($composer['version']) && \is_string($composer['version']) ? $composer['version'] : 'dev',
        ];
    }

    /**
     * @param array{name: string, version: string} $application
     */
    private function resolveVersion(array $application, ?string $version): string
    {
        $candidate = null !== $version ? trim($version) : trim($application['version']);
        if ('' === $candidate) {
            throw new \RuntimeException('Ange en version via --version eller sätt version i composer.json.');
        }

        return preg_replace('/[^A-Za-z0-9._-]+/', '-', $candidate) ?? 'dev';
    }

    private function assertSequentialReleaseVersion(string $version): void
    {
        if (1 !== preg_match('/^\d+\.\d+\.\d+$/D', $version)) {
            throw new \RuntimeException('Releaseversionen i composer.json måste följa formatet major.minor.patch, exempelvis 1.0.91.');
        }

        if (!is_file($this->projectDir.\DIRECTORY_SEPARATOR.$this->releaseNotesPath($version))) {
            throw new \RuntimeException(sprintf('Release notes saknas. Skapa release-notes/%s.md före paketbygget.', $version));
        }

        $documentedVersions = [];
        foreach (glob($this->projectDir.\DIRECTORY_SEPARATOR.'release-notes'.\DIRECTORY_SEPARATOR.'*.md') ?: [] as $path) {
            $documentedVersion = pathinfo($path, \PATHINFO_FILENAME);
            if ($documentedVersion === $version || 1 !== preg_match('/^\d+\.\d+\.\d+$/D', $documentedVersion)) {
                continue;
            }

            $documentedVersions[] = $documentedVersion;
        }

        if ([] === $documentedVersions) {
            return;
        }

        usort($documentedVersions, static fn (string $left, string $right): int => version_compare($right, $left));
        $previousVersion = $documentedVersions[0];
        $previousParts = array_map('intval', explode('.', $previousVersion));
        $allowedVersions = [
            sprintf('%d.%d.%d', $previousParts[0], $previousParts[1], $previousParts[2] + 1),
            sprintf('%d.%d.0', $previousParts[0], $previousParts[1] + 1),
            sprintf('%d.0.0', $previousParts[0] + 1),
        ];

        if (!\in_array($version, $allowedVersions, true)) {
            throw new \RuntimeException(sprintf(
                'Releaseversionen %s följer inte versionstegen efter %s. Nästa tillåtna version är %s, %s eller %s.',
                $version,
                $previousVersion,
                ...$allowedVersions,
            ));
        }
    }

    private function ensureOutputDirectory(string $directory): string
    {
        if (!is_dir($directory) && !mkdir($directory, 0775, true) && !is_dir($directory)) {
            throw new \RuntimeException('Kunde inte skapa katalogen för versionspaketen.');
        }

        return $directory;
    }

    /**
     * @param list<string> $includedPaths
     *
     * @return array{
     *     type: string,
     *     version: string,
     *     filename: string,
     *     path: string,
     *     checksumSha256: string,
     *     checksumPath: string,
     *     sizeBytes: int,
     *     entries: int
     * }
     */
    private function buildPackageArchive(
        string $type,
        string $version,
        string $applicationName,
        array $includedPaths,
        string $outputDirectory,
    ): array {
        $filename = sprintf('driftpunkt-%s-%s.zip', $type, $version);
        $archivePath = $outputDirectory.\DIRECTORY_SEPARATOR.$filename;
        $archiveRoot = sprintf('driftpunkt-%s-%s', $type, $version);

        $zip = new \ZipArchive();
        $result = $zip->open($archivePath, \ZipArchive::CREATE | \ZipArchive::OVERWRITE);
        if (true !== $result) {
            throw new \RuntimeException(sprintf('Kunde inte skapa %s-paketet.', $type));
        }

        $entryCount = 0;
        $manifestFiles = [];
        foreach ($includedPaths as $relativePath) {
            $sourcePath = $this->projectDir.\DIRECTORY_SEPARATOR.$relativePath;
            if (!file_exists($sourcePath)) {
                if ('vendor' === $relativePath && \in_array($type, ['install', 'upgrade'], true)) {
                    $zip->close();

                    throw new \RuntimeException('Releasepaketet kräver vendor/. Kör composer install först.');
                }

                continue;
            }

            $entryCount += $this->addPathToArchive($zip, $sourcePath, $archiveRoot, $relativePath, $manifestFiles);
        }

        $releaseNotesPath = $this->releaseNotesPath($version);
        $releaseNotesSourcePath = $this->projectDir.\DIRECTORY_SEPARATOR.$releaseNotesPath;
        if (is_file($releaseNotesSourcePath)) {
            $zip->addFile($releaseNotesSourcePath, $archiveRoot.'/'.$releaseNotesPath);
            $manifestFiles[] = $this->manifestFileEntry($releaseNotesSourcePath, $releaseNotesPath);
            ++$entryCount;
        }

        usort($manifestFiles, static fn (array $left, array $right): int => $left['path'] <=> $right['path']);
        $releaseNotesMetadata = $this->releaseNotesMetadata($version, $type, $manifestFiles);
        $contentManifestSha256 = $this->hashManifestFiles($manifestFiles);
        $metadataPath = $archiveRoot.'/release-metadata.json';
        $zip->addFromString($metadataPath, json_encode(array_merge([
            'applicationName' => $applicationName,
            'packageType' => $type,
            'version' => $version,
            'builtAt' => (new \DateTimeImmutable())->format(DATE_ATOM),
            'installationMode' => 'install' === $type ? 'fresh_install' : 'upgrade',
            'cumulativeUpgrade' => 'upgrade' === $type,
            'minimumSupportedVersion' => 'upgrade' === $type ? self::MINIMUM_SUPPORTED_CUMULATIVE_UPGRADE_VERSION : null,
            'requiresVendor' => true,
            'managedPaths' => $includedPaths,
            'preflightChecklist' => $this->preflightChecklist($type),
            'fileCount' => \count($manifestFiles),
            'archiveEntryCount' => $entryCount + 1,
            'contentManifestSha256' => $contentManifestSha256,
            'files' => $manifestFiles,
        ], $releaseNotesMetadata), \JSON_PRETTY_PRINT | \JSON_UNESCAPED_SLASHES | \JSON_THROW_ON_ERROR));
        ++$entryCount;

        $zip->close();
        $checksumSha256 = hash_file('sha256', $archivePath);
        $checksumPath = $archivePath.'.sha256';
        file_put_contents($checksumPath, sprintf("%s  %s\n", $checksumSha256, $filename));

        return [
            'type' => $type,
            'version' => $version,
            'filename' => $filename,
            'path' => $archivePath,
            'checksumSha256' => $checksumSha256,
            'checksumPath' => $checksumPath,
            'sizeBytes' => (int) filesize($archivePath),
            'entries' => $entryCount,
        ];
    }

    /**
     * @param list<array{path: string, sizeBytes: int, sha256: string}> $manifestFiles
     */
    private function addPathToArchive(\ZipArchive $zip, string $sourcePath, string $archiveRoot, string $relativePath, array &$manifestFiles): int
    {
        $normalizedRelativePath = str_replace('\\', '/', $relativePath);

        if (is_dir($sourcePath)) {
            $entryCount = 0;
            $iterator = new \RecursiveIteratorIterator(
                new \RecursiveDirectoryIterator($sourcePath, \FilesystemIterator::SKIP_DOTS),
                \RecursiveIteratorIterator::SELF_FIRST,
            );

            foreach ($iterator as $item) {
                $itemRelativePath = $normalizedRelativePath.'/'.str_replace('\\', '/', ltrim(substr($item->getPathname(), \strlen($sourcePath)), \DIRECTORY_SEPARATOR));
                if ($this->shouldSkipPackagedPath($itemRelativePath)) {
                    continue;
                }

                $archivePath = $archiveRoot.'/'.$itemRelativePath;
                if ($item->isDir()) {
                    $zip->addEmptyDir($archivePath);
                    ++$entryCount;

                    continue;
                }

                $zip->addFile($item->getPathname(), $archivePath);
                $manifestFiles[] = $this->manifestFileEntry($item->getPathname(), $itemRelativePath);
                ++$entryCount;
            }

            return $entryCount;
        }

        if ($this->shouldSkipPackagedPath($normalizedRelativePath)) {
            return 0;
        }

        $zip->addFile($sourcePath, $archiveRoot.'/'.$normalizedRelativePath);
        $manifestFiles[] = $this->manifestFileEntry($sourcePath, $normalizedRelativePath);

        return 1;
    }

    /**
     * @return array{path: string, sizeBytes: int, sha256: string}
     */
    private function manifestFileEntry(string $sourcePath, string $relativePath): array
    {
        return [
            'path' => str_replace('\\', '/', $relativePath),
            'sizeBytes' => (int) filesize($sourcePath),
            'sha256' => hash_file('sha256', $sourcePath),
        ];
    }

    /**
     * @param list<array{path: string, sizeBytes: int, sha256: string}> $manifestFiles
     */
    private function hashManifestFiles(array $manifestFiles): string
    {
        return hash('sha256', json_encode($manifestFiles, \JSON_UNESCAPED_SLASHES | \JSON_THROW_ON_ERROR));
    }

    private function releaseNotesPath(string $version): string
    {
        return sprintf('release-notes/%s.md', $version);
    }

    /**
     * @param list<array{path: string, sizeBytes: int, sha256: string}> $manifestFiles
     * @return array{
     *     releaseNotesPresent: bool,
     *     releaseNotesPath: string,
     *     releaseNotesMarkdown: string,
     *     releaseHighlights: list<array{section: string, text: string}>,
     *     operationalNotes: list<string>,
     *     postUpdateChecklist: list<string>,
     *     requiresMigrations: bool,
     *     requiresCacheRefresh: bool,
     *     requiresServiceReload: bool
     * }
     */
    private function releaseNotesMetadata(string $version, string $type, array $manifestFiles): array
    {
        $relativePath = $this->releaseNotesPath($version);
        $path = $this->projectDir.\DIRECTORY_SEPARATOR.$relativePath;
        $hasMigrations = $this->manifestContainsPathPrefix($manifestFiles, 'migrations/');
        $requiresCacheRefresh = 'upgrade' === $type;

        if (!is_file($path)) {
            return [
                'releaseNotesPresent' => false,
                'releaseNotesPath' => $relativePath,
                'releaseNotesMarkdown' => '',
                'releaseHighlights' => [],
                'operationalNotes' => [],
                'postUpdateChecklist' => [],
                'requiresMigrations' => $hasMigrations,
                'requiresCacheRefresh' => $requiresCacheRefresh,
                'requiresServiceReload' => false,
            ];
        }

        $markdown = (string) file_get_contents($path);
        $sections = $this->parseReleaseNoteSections($markdown);
        $operationalNotes = $sections['databas och drift'] ?? $sections['operations'] ?? $sections['database and operations'] ?? [];
        $postUpdateChecklist = $sections['kontroll efter uppdatering'] ?? $sections['verification'] ?? $sections['post-update verification'] ?? [];
        $explicitMigrationRequirement = $this->detectRequirementFromNotes($operationalNotes, ['migration']);
        $explicitCacheRequirement = $this->detectRequirementFromNotes($operationalNotes, ['cache']);
        $explicitReloadRequirement = $this->detectRequirementFromNotes($operationalNotes, ['omstart', 'reload', 'restart']);

        return [
            'releaseNotesPresent' => true,
            'releaseNotesPath' => $relativePath,
            'releaseNotesMarkdown' => $markdown,
            'releaseHighlights' => $this->releaseHighlightsFromSections($sections),
            'operationalNotes' => $operationalNotes,
            'postUpdateChecklist' => $postUpdateChecklist,
            'requiresMigrations' => $explicitMigrationRequirement ?? $hasMigrations,
            'requiresCacheRefresh' => $explicitCacheRequirement ?? $requiresCacheRefresh,
            'requiresServiceReload' => $explicitReloadRequirement ?? false,
        ];
    }

    /**
     * @param list<array{path: string, sizeBytes: int, sha256: string}> $manifestFiles
     */
    private function manifestContainsPathPrefix(array $manifestFiles, string $prefix): bool
    {
        foreach ($manifestFiles as $file) {
            if (str_starts_with($file['path'], $prefix)) {
                return true;
            }
        }

        return false;
    }

    /**
     * @return array<string, list<string>>
     */
    private function parseReleaseNoteSections(string $markdown): array
    {
        $sections = [];
        $currentSection = null;

        foreach (preg_split('/\R/u', $markdown) ?: [] as $line) {
            if (preg_match('/^##\s+(.+)$/u', trim($line), $headingMatch)) {
                $currentSection = mb_strtolower(trim($headingMatch[1]));
                $sections[$currentSection] ??= [];

                continue;
            }

            if (null === $currentSection) {
                continue;
            }

            if (preg_match('/^\s*(?:[-*]|\d+\.)\s+(.+)$/u', $line, $itemMatch)) {
                $item = trim($itemMatch[1]);
                if ('' !== $item) {
                    $sections[$currentSection][] = $item;
                }
            }
        }

        return $sections;
    }

    /**
     * @param array<string, list<string>> $sections
     * @return list<array{section: string, text: string}>
     */
    private function releaseHighlightsFromSections(array $sections): array
    {
        $highlights = [];
        foreach ([
            'nytt' => 'Nytt',
            'highlights' => 'Highlights',
            'förbättrat' => 'Förbättrat',
            'improved' => 'Improved',
            'fixat' => 'Fixat',
            'fixed' => 'Fixed',
            'fixed and improved' => 'Fixed and Improved',
        ] as $normalizedSection => $label) {
            foreach ($sections[$normalizedSection] ?? [] as $item) {
                $highlights[] = [
                    'section' => $label,
                    'text' => $item,
                ];
            }
        }

        return $highlights;
    }

    /**
     * @param list<string> $notes
     * @param list<string> $keywords
     */
    private function detectRequirementFromNotes(array $notes, array $keywords): ?bool
    {
        foreach ($notes as $note) {
            $normalizedNote = mb_strtolower($note);
            $matchesKeyword = false;
            foreach ($keywords as $keyword) {
                if (str_contains($normalizedNote, $keyword)) {
                    $matchesKeyword = true;
                    break;
                }
            }

            if (!$matchesKeyword) {
                continue;
            }

            if (preg_match('/\b(nej|no|false)\b/u', $normalizedNote)) {
                return false;
            }

            if (preg_match('/\b(ja|yes|true|kräver|requires|vid behov|required|recommended|rekommenderas)\b/u', $normalizedNote)) {
                return true;
            }
        }

        return null;
    }

    /**
     * @return list<string>
     */
    private function preflightChecklist(string $type): array
    {
        if ('install' === $type) {
            return [
                'Packa upp på ny server eller ren applikationsmapp.',
                'Peka webbserverns dokumentrot mot htdocs/, eller packa upp hela paketet direkt i fast /htdocs där root-.htaccess är aktiv.',
                'Kopiera deploy/nas/.env.example till en riktig miljöfil och sätt hemligheter.',
                'Starta databasen och kör app:install:fresh efter att beroenden är på plats.',
            ];
        }

        return [
            'Aktivera underhållsläge innan paketet appliceras.',
            'Kontrollera att inga databas- eller uppdateringsjobb körs.',
            'Verifiera att webbcontainern kan skriva till applikationsfilerna.',
            'Kontrollera att webbservern pekar på htdocs/ eller att root-.htaccess skyddar fast /htdocs-läge efter uppdateringen.',
            'Behåll den automatiska kodbackupen tills releasen är verifierad.',
        ];
    }

    private function shouldSkipPackagedPath(string $relativePath): bool
    {
        $normalizedPath = str_replace('\\', '/', $relativePath);
        $basename = basename($normalizedPath);

        return str_starts_with($normalizedPath, 'var/')
            || str_starts_with($normalizedPath, '.git/')
            || str_starts_with($normalizedPath, 'dist/')
            || '.env' === $basename
            || str_starts_with($basename, '.env.local')
            || (str_starts_with($basename, '.env.') && '.env.example' !== $basename);
    }
}
