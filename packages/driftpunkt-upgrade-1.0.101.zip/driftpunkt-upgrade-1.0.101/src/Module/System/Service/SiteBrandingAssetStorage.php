<?php

declare(strict_types=1);

namespace App\Module\System\Service;

use Symfony\Component\DependencyInjection\Attribute\Autowire;
use Symfony\Component\HttpFoundation\File\UploadedFile;

final class SiteBrandingAssetStorage
{
    public const DEFAULT_LOGO_PATH = '/assets/branding/driftpunkt-logo-full.png';
    public const DEFAULT_ICON_PATH = '/assets/branding/driftpunkt-logo-icon.png';

    private const MAX_FILE_SIZE_BYTES = 2 * 1024 * 1024;
    private const LOGO_PREFIX = 'custom-site-logo';
    private const ICON_PREFIX = 'custom-site-icon';
    private const ALLOWED_EXTENSIONS = ['png', 'jpg', 'jpeg', 'webp', 'gif'];

    public function __construct(
        #[Autowire('%kernel.project_dir%')]
        private readonly string $projectDir,
    ) {
    }

    public function assertValidUpload(UploadedFile $uploadedFile, string $label): void
    {
        if (!$uploadedFile->isValid()) {
            throw new \RuntimeException(match ($label) {
                'Loggan' => 'Uppladdningen av loggan misslyckades.',
                'Flikikonen' => 'Uppladdningen av flikikonen misslyckades.',
                default => sprintf('Uppladdningen av %s misslyckades.', mb_strtolower($label)),
            });
        }

        if ($uploadedFile->getSize() > self::MAX_FILE_SIZE_BYTES) {
            throw new \RuntimeException(sprintf('%s får vara högst 2 MB.', $label));
        }

        $originalExtension = mb_strtolower((string) pathinfo($uploadedFile->getClientOriginalName(), \PATHINFO_EXTENSION));
        if (!\in_array($originalExtension, self::ALLOWED_EXTENSIONS, true)) {
            throw new \RuntimeException(sprintf('%s måste vara PNG, JPG, JPEG, WEBP eller GIF.', $label));
        }

        if (false === @getimagesize($uploadedFile->getPathname())) {
            throw new \RuntimeException(sprintf('%s måste vara en giltig bildfil.', $label));
        }
    }

    public function storeLogo(UploadedFile $uploadedFile, string $currentPath): string
    {
        return $this->storeUploadedAsset($uploadedFile, $currentPath, self::LOGO_PREFIX, 'Loggan');
    }

    public function storeIcon(UploadedFile $uploadedFile, string $currentPath): string
    {
        return $this->storeUploadedAsset($uploadedFile, $currentPath, self::ICON_PREFIX, 'Flikikonen');
    }

    public function resolveLogoPath(string $path): string
    {
        return $this->resolvePublicAssetPath($path, self::DEFAULT_LOGO_PATH);
    }

    public function resolveIconPath(string $path): string
    {
        return $this->resolvePublicAssetPath($path, self::DEFAULT_ICON_PATH);
    }

    public function resolvePublicAssetPath(string $path, string $fallbackPath): string
    {
        $path = trim($path);
        if ('' === $path) {
            return $fallbackPath;
        }

        if ($this->isCustomBrandingPublicPath($path) && !is_file($this->publicDirectory().$path)) {
            return $fallbackPath;
        }

        return $path;
    }

    public static function isRuntimeBrandingPath(string $relativePath): bool
    {
        $normalizedPath = trim(str_replace('\\', '/', $relativePath), '/');

        return preg_match('#^(htdocs|public)/assets/branding/custom-site-(logo|icon)(?:-[a-f0-9]{12})?\.(png|jpg|jpeg|webp|gif)$#', $normalizedPath) === 1;
    }

    private function storeUploadedAsset(UploadedFile $uploadedFile, string $currentPath, string $targetPrefix, string $label): string
    {
        $this->assertValidUpload($uploadedFile, $label);

        $publicDirectory = $this->publicDirectory();
        $brandingDirectory = $publicDirectory.'/assets/branding';
        if (!is_dir($brandingDirectory) && !mkdir($brandingDirectory, 0777, true) && !is_dir($brandingDirectory)) {
            throw new \RuntimeException('Kunde inte skapa katalogen för branding.');
        }

        if ($this->isCustomBrandingPublicPathForPrefix($currentPath, $targetPrefix)) {
            $currentFile = $publicDirectory.$currentPath;
            if (is_file($currentFile)) {
                @unlink($currentFile);
            }
        }

        $originalExtension = mb_strtolower((string) pathinfo($uploadedFile->getClientOriginalName(), \PATHINFO_EXTENSION));
        $targetName = sprintf('%s-%s.%s', $targetPrefix, $this->assetFingerprint($uploadedFile), $originalExtension);
        $uploadedFile->move($brandingDirectory, $targetName);

        return '/assets/branding/'.$targetName;
    }

    private function publicDirectory(): string
    {
        $publicDir = 'htdocs';
        $composerPath = $this->projectDir.'/composer.json';

        if (is_file($composerPath)) {
            try {
                /** @var array<string, mixed> $composer */
                $composer = json_decode((string) file_get_contents($composerPath), true, 512, \JSON_THROW_ON_ERROR);
                $extra = $composer['extra'] ?? [];
                if (\is_array($extra) && isset($extra['public-dir']) && \is_string($extra['public-dir']) && '' !== trim($extra['public-dir'])) {
                    $publicDir = trim($extra['public-dir'], '/');
                }
            } catch (\Throwable) {
                $publicDir = 'htdocs';
            }
        }

        return $this->projectDir.'/'.$publicDir;
    }

    private function isCustomBrandingPublicPath(string $path): bool
    {
        return $this->isCustomBrandingPublicPathForPrefix($path, self::LOGO_PREFIX)
            || $this->isCustomBrandingPublicPathForPrefix($path, self::ICON_PREFIX);
    }

    private function isCustomBrandingPublicPathForPrefix(string $path, string $prefix): bool
    {
        $path = trim($path);
        if (preg_match('#^/assets/branding/'.preg_quote($prefix, '#').'(?:-[a-f0-9]{12})?\.(png|jpg|jpeg|webp|gif)$#', $path) !== 1) {
            return false;
        }

        return true;
    }

    private function assetFingerprint(UploadedFile $uploadedFile): string
    {
        $hash = @hash_file('sha256', $uploadedFile->getPathname());
        if (!\is_string($hash) || '' === $hash) {
            $hash = bin2hex(random_bytes(16));
        }

        return substr($hash, 0, 12);
    }
}
