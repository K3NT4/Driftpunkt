<?php

declare(strict_types=1);

namespace App\Module\System\Service;

use Symfony\Component\DependencyInjection\Attribute\Autowire;

class BackgroundConsoleLauncher
{
    public function __construct(
        #[Autowire('%kernel.environment%')]
        private readonly string $environment,
        private readonly ?string $phpCliBinary = null,
    ) {
    }

    /**
     * @param list<string> $arguments
     */
    public function launch(array $arguments, string $workingDirectory): void
    {
        if ('test' === $this->environment) {
            return;
        }

        $arguments = $this->normalizeArguments($arguments);

        $logDirectory = $workingDirectory.\DIRECTORY_SEPARATOR.'var'.\DIRECTORY_SEPARATOR.'background_jobs';
        if (!is_dir($logDirectory) && !mkdir($logDirectory, 0775, true) && !is_dir($logDirectory)) {
            throw new \RuntimeException('Kunde inte skapa loggmappen för bakgrundskörningar.');
        }

        $logPath = $logDirectory.\DIRECTORY_SEPARATOR.sprintf(
            'job_%s_%s.log',
            (new \DateTimeImmutable())->format('Ymd_His_u'),
            bin2hex(random_bytes(3)),
        );
        touch($logPath);

        if ('Windows' === \PHP_OS_FAMILY) {
            $this->launchWindows($arguments, $workingDirectory, $logPath);

            return;
        }

        $escapedCommand = implode(' ', array_map(static fn (string $part): string => escapeshellarg($part), $arguments));
        $shellCommand = sprintf(
            'cd %s && nohup %s >> %s 2>&1 &',
            escapeshellarg($workingDirectory),
            $escapedCommand,
            escapeshellarg($logPath),
        );

        $process = proc_open(
            ['bash', '-lc', $shellCommand],
            [
                0 => ['pipe', 'r'],
                1 => ['pipe', 'w'],
                2 => ['pipe', 'w'],
            ],
            $pipes,
            $workingDirectory,
        );

        if (!\is_resource($process)) {
            throw new \RuntimeException('Kunde inte starta bakgrundskörningen för efter-uppdateringsstegen.');
        }

        foreach ($pipes as $pipe) {
            fclose($pipe);
        }

        proc_close($process);
    }

    /**
     * @param list<string> $arguments
     */
    private function launchWindows(array $arguments, string $workingDirectory, string $logPath): void
    {
        $echoArguments = $this->windowsEchoArguments($arguments);
        if (null !== $echoArguments) {
            file_put_contents($logPath, implode(' ', $echoArguments)."\n", \FILE_APPEND);

            return;
        }

        $logHandle = fopen($logPath, 'ab');
        if (false === $logHandle) {
            throw new \RuntimeException('Kunde inte öppna loggfilen för bakgrundskörningen.');
        }

        $process = proc_open(
            $this->normalizeWindowsArguments($arguments),
            [
                0 => ['pipe', 'r'],
                1 => $logHandle,
                2 => $logHandle,
            ],
            $pipes,
            $workingDirectory,
        );

        if (!\is_resource($process)) {
            fclose($logHandle);

            throw new \RuntimeException('Kunde inte starta bakgrundskörningen för efter-uppdateringsstegen.');
        }

        fclose($pipes[0]);
        proc_close($process);
        fclose($logHandle);
    }

    /**
     * @param list<string> $arguments
     * @return list<string>
     */
    private function normalizeArguments(array $arguments): array
    {
        if ([] === $arguments) {
            throw new \RuntimeException('Bakgrundskörningen saknar kommando.');
        }

        $configuredBinary = $this->configuredPhpCliBinary();
        if ('' !== $configuredBinary && ('' === trim($arguments[0]) || trim($arguments[0]) === trim(\PHP_BINARY))) {
            $arguments[0] = $configuredBinary;
        } elseif ('' === trim($arguments[0])) {
            $arguments[0] = $this->resolvePhpCliBinary();
        }

        return $arguments;
    }

    /**
     * @param list<string> $arguments
     * @return list<string>
     */
    private function normalizeWindowsArguments(array $arguments): array
    {
        return $arguments;
    }

    /**
     * @param list<string> $arguments
     * @return list<string>|null
     */
    private function windowsEchoArguments(array $arguments): ?array
    {
        $binary = str_replace('\\', '/', $arguments[0]);
        if ('/bin/echo' === $binary || 'echo' === strtolower($binary)) {
            return \array_slice($arguments, 1);
        }

        return null;
    }

    private function resolvePhpCliBinary(): string
    {
        $binary = $this->configuredPhpCliBinary();

        if ('' === $binary) {
            $binary = trim(\PHP_BINARY);
        }

        if ('' === $binary) {
            $binary = '/usr/bin/php';
        }

        return $binary;
    }

    private function configuredPhpCliBinary(): string
    {
        $binary = trim((string) $this->phpCliBinary);
        if ('' !== $binary) {
            return $binary;
        }

        $fromEnvironment = getenv('PHP_CLI_BINARY');

        return \is_string($fromEnvironment) ? trim($fromEnvironment) : '';
    }
}
