<?php

declare(strict_types=1);

namespace App\Module\System\Service;

use App\Module\Mail\Entity\SupportMailbox;
use App\Module\Mail\Service\ConfiguredMailer;
use App\Module\Mail\Service\ImapMailboxFetcher;
use App\Module\Notification\Entity\NotificationLog;
use App\Module\System\Entity\InternalReport;
use App\Module\System\Entity\InternalReportResponse;
use Doctrine\ORM\EntityManagerInterface;
use Psr\Log\LoggerInterface;
use Symfony\Component\DependencyInjection\Attribute\Autowire;
use Symfony\Component\Mime\Address;
use Symfony\Component\Mime\Email;
use Twig\Environment;

final class InternalReportNotifier
{
    public function __construct(
        private readonly EntityManagerInterface $entityManager,
        private readonly ConfiguredMailer $mailer,
        private readonly ImapMailboxFetcher $imapMailboxFetcher,
        private readonly Environment $twig,
        private readonly LoggerInterface $logger,
        private readonly SystemSettings $systemSettings,
        #[Autowire('%kernel.project_dir%')]
        private readonly string $projectDir,
    ) {
    }

    public function notify(InternalReport $report): bool
    {
        if (!InternalReport::requiresCentralNotificationType($report->getType())) {
            return true;
        }

        $report->markNotificationAttempted();
        $settings = $this->systemSettings->getInternalReportSettings();

        try {
            $recipient = $this->validatedEmail($settings['recipient'], 'Mottagaren för centrala rapporter är inte korrekt konfigurerad.');
            $replyTo = $this->validatedEmail($settings['replyTo'], 'Svarsadressen för centrala rapporter är inte konfigurerad.');
            $this->assertReplyMailboxReady($replyTo);

            $context = [
                'report' => $report,
                'applicationVersion' => $this->applicationVersion(),
            ];
            $subject = sprintf('[DRIFTPUNKT-RAPPORT %s] %s: %s', $report->getPublicReference(), $report->getTypeLabel(), $report->getSubject());

            $this->mailer->send(
                (new Email())
                    ->to($recipient)
                    ->replyTo(new Address($replyTo, 'Driftpunkt rapportmottagning'))
                    ->subject($subject)
                    ->text($this->twig->render('emails/internal_report.txt.twig', $context))
                    ->html($this->twig->render('emails/internal_report.html.twig', $context)),
                null,
                true,
            );

            $report->markNotificationSent();
            $this->logNotification($report, $recipient, $subject, true, 'Central rapportnotifiering skickad.');
            $this->entityManager->flush();

            return true;
        } catch (\Throwable $exception) {
            $safeMessage = $exception instanceof \RuntimeException
                ? $exception->getMessage()
                : 'E-posttransporten misslyckades.';
            $report->markNotificationFailed($safeMessage);
            $this->logNotification(
                $report,
                $settings['recipient'],
                sprintf('[DRIFTPUNKT-RAPPORT %s] %s', $report->getPublicReference(), $report->getSubject()),
                false,
                $safeMessage,
            );
            $this->entityManager->flush();
            $this->logger->error('Central notifiering för intern rapport misslyckades.', [
                'reportReference' => $report->getPublicReference(),
                'exception' => $exception,
            ]);

            return false;
        }
    }

    public function notifyReporterOfResponse(InternalReport $report, InternalReportResponse $response): bool
    {
        $recipient = mb_strtolower(trim($report->getReporterEmail()));
        $subject = sprintf('Nytt svar på din Driftpunkt-rapport: %s', $report->getSubject());
        if (false === filter_var($recipient, \FILTER_VALIDATE_EMAIL) || str_ends_with($recipient, '@nomail.local')) {
            $this->logNotification($report, $recipient ?: 'unknown@local', $subject, false, 'Rapportören saknar en användbar e-postadress.');
            $this->entityManager->flush();

            return false;
        }

        $context = [
            'report' => $report,
            'response' => $response,
            'reportUrl' => rtrim($report->getInstallationUrl(), '/').'/portal/technician/internrapport',
        ];

        try {
            $this->mailer->send(
                (new Email())
                    ->to($recipient)
                    ->subject($subject)
                    ->text($this->twig->render('emails/internal_report_response.txt.twig', $context))
                    ->html($this->twig->render('emails/internal_report_response.html.twig', $context)),
                $report->getReporter()?->getCompany(),
                true,
            );
            $this->logNotification($report, $recipient, $subject, true, 'Rapportören notifierades om utvecklarens svar.');
            $this->entityManager->flush();

            return true;
        } catch (\Throwable $exception) {
            $this->logNotification($report, $recipient, $subject, false, 'Rapportörens svarsnotifiering kunde inte skickas.');
            $this->entityManager->flush();
            $this->logger->error('Notifiering om svar på intern rapport misslyckades.', [
                'reportReference' => $report->getPublicReference(),
                'exception' => $exception,
            ]);

            return false;
        }
    }

    private function validatedEmail(string $value, string $errorMessage): string
    {
        $normalized = mb_strtolower(trim($value));
        if (false === filter_var($normalized, \FILTER_VALIDATE_EMAIL)) {
            throw new \RuntimeException($errorMessage);
        }

        return $normalized;
    }

    private function assertReplyMailboxReady(string $replyTo): void
    {
        $mailbox = $this->entityManager->getRepository(SupportMailbox::class)->findOneBy([
            'emailAddress' => $replyTo,
            'isActive' => true,
        ]);

        if (!$mailbox instanceof SupportMailbox || !$this->imapMailboxFetcher->supports($mailbox)) {
            throw new \RuntimeException('Svarsadressen motsvarar inte en aktiv och komplett IMAP-inkorg.');
        }
    }

    private function applicationVersion(): string
    {
        $contents = @file_get_contents($this->projectDir.'/composer.json');
        if (false === $contents) {
            return 'okänd';
        }

        try {
            $composer = json_decode($contents, true, 512, \JSON_THROW_ON_ERROR);
        } catch (\JsonException) {
            return 'okänd';
        }

        return \is_array($composer) && \is_string($composer['version'] ?? null)
            ? trim($composer['version'])
            : 'okänd';
    }

    private function logNotification(InternalReport $report, string $recipient, string $subject, bool $sent, string $message): void
    {
        $log = new NotificationLog('internal_report', $recipient, $subject, $sent, sprintf('%s Referens: %s', $message, $report->getPublicReference()));
        if (mb_strtolower(trim($recipient)) === mb_strtolower(trim($report->getReporterEmail()))) {
            $log->setRecipient($report->getReporter());
        }
        $this->entityManager->persist($log);
    }
}
