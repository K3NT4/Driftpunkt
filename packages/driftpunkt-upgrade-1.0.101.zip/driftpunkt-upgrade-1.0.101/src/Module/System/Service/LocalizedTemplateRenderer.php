<?php

declare(strict_types=1);

namespace App\Module\System\Service;

use App\Module\System\Locale\AppLocale;
use Twig\Environment;

final class LocalizedTemplateRenderer
{
    public function __construct(private readonly Environment $twig)
    {
    }

    /**
     * @param array<string, mixed> $context
     */
    public function render(string $template, array $context, string $locale): string
    {
        $context['emailLocale'] = AppLocale::normalize($locale);

        return $this->twig->render($template, $context);
    }
}
