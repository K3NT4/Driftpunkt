<?php

declare(strict_types=1);

namespace App\Module\System\Service;

use Symfony\Component\DependencyInjection\Attribute\Autowire;
use Symfony\Component\HttpFoundation\File\UploadedFile;

final class CodeUpdateManager
{
    private const VERSION_COMPARISONS = ['newer', 'same', 'older', 'unknown'];

    /**
     * Paths that define the application's core codebase and should exist in a releasable package.
     *
     * @var list<string>
     */
    private const REQUIRED_PACKAGE_PATHS = [
        '.htaccess',
        'bin/console',
        'composer.json',
        'composer.lock',
        'config',
        'htdocs/index.php',
        'index.php',
        'public/index.php',
        'src',
        'templates',
        'vendor/autoload.php',
    ];

    /**
     * Root-level code paths we manage during an update. Missing paths are removed from the target installation.
     *
     * @var list<string>
     */
    private const MANAGED_ROOT_PATHS = [
        '.htaccess',
        'bin',
        'config',
        'htdocs',
        'index.php',
        'migrations',
        'public',
        'src',
        'templates',
        'composer.json',
        'composer.lock',
        'phpunit.dist.xml',
        'symfony.lock',
    ];

    public function __construct(
        #[Autowire('%kernel.project_dir%')]
        private readonly string $projectDir,
    ) {
    }

    /**
     * @return array{name: string, version: string, summary: string}
     */
    public function describeCurrentApplication(): array
    {
        $releaseMetadata = $this->readReleaseMetadata($this->projectDir);
        if (\is_array($releaseMetadata) && !isset($releaseMetadata['_metadataError'])) {
            $metadataName = isset($releaseMetadata['applicationName']) && \is_string($releaseMetadata['applicationName']) && '' !== trim($releaseMetadata['applicationName'])
                ? trim($releaseMetadata['applicationName'])
                : 'driftpunkt';
            $metadataVersion = isset($releaseMetadata['version']) && \is_string($releaseMetadata['version']) && '' !== trim($releaseMetadata['version'])
                ? trim($releaseMetadata['version'])
                : 'okänd version';
            $builtAt = $this->formatReleaseBuiltAt($releaseMetadata['builtAt'] ?? null);

            return [
                'name' => $metadataName,
                'version' => $metadataVersion,
                'summary' => null !== $builtAt
                    ? sprintf('Installerad version byggd %s', $builtAt)
                    : 'Installerad version från release-metadata',
            ];
        }

        $composerPath = $this->projectDir.\DIRECTORY_SEPARATOR.'composer.json';
        if (!is_file($composerPath)) {
            return [
                'name' => 'okänd applikation',
                'version' => 'lokal',
                'summary' => 'composer.json kunde inte hittas',
            ];
        }

        /** @var array<string, mixed>|null $composer */
        $composer = json_decode((string) file_get_contents($composerPath), true);

        return [
            'name' => is_array($composer) && isset($composer['name']) && is_string($composer['name']) ? $composer['name'] : 'driftpunkt',
            'version' => is_array($composer) && isset($composer['version']) && is_string($composer['version']) ? $composer['version'] : 'lokal',
            'summary' => is_array($composer) && isset($composer['description']) && is_string($composer['description']) ? $composer['description'] : 'Lokal projektinstallation',
        ];
    }

    /**
     * @return list<array{
     *     id: string,
     *     originalFilename: string,
     *     packageName: string,
     *     packageVersion: string,
     *     uploadedAt: \DateTimeImmutable,
     *     valid: bool,
     *     validationMessages: list<string>,
     *     fileCount: int,
     *     includesVendor: bool,
     *     appliedAt: ?\DateTimeImmutable,
     *     applicationBackupFilename: ?string
     * }>
     */
    public function listStagedPackages(): array
    {
        $stagingDirectory = $this->stagingDirectory();
        if (!is_dir($stagingDirectory)) {
            return [];
        }

        $packages = [];
        foreach (glob($stagingDirectory.\DIRECTORY_SEPARATOR.'*'.\DIRECTORY_SEPARATOR.'manifest.json') ?: [] as $manifestPath) {
            $manifest = $this->readManifest($manifestPath);
            if (null === $manifest) {
                continue;
            }

            $packages[] = $manifest;
        }

        usort(
            $packages,
            static fn (array $left, array $right): int => $right['uploadedAt']->getTimestamp() <=> $left['uploadedAt']->getTimestamp(),
        );

        return $packages;
    }

    /**
     * @return list<array{
     *     filename: string,
     *     path: string,
     *     sizeBytes: int,
     *     createdAt: \DateTimeImmutable
     * }>
     */
    public function listApplicationBackups(): array
    {
        $directory = $this->backupDirectory();
        if (!is_dir($directory)) {
            return [];
        }

        $backups = [];
        foreach (glob($directory.\DIRECTORY_SEPARATOR.'*.zip') ?: [] as $path) {
            $backups[] = [
                'filename' => basename($path),
                'path' => $path,
                'sizeBytes' => (int) filesize($path),
                'createdAt' => (new \DateTimeImmutable())->setTimestamp((int) filemtime($path)),
            ];
        }

        usort(
            $backups,
            static fn (array $left, array $right): int => $right['createdAt']->getTimestamp() <=> $left['createdAt']->getTimestamp(),
        );

        return $backups;
    }

    /**
     * @return array{
     *     id: string,
     *     originalFilename: string,
     *     packageName: string,
     *     packageVersion: string,
     *     uploadedAt: \DateTimeImmutable,
     *     valid: bool,
     *     validationMessages: list<string>,
     *     fileCount: int,
     *     includesVendor: bool,
     *     appliedAt: ?\DateTimeImmutable,
     *     applicationBackupFilename: ?string
     * }
     */
    public function stageUploadedPackage(UploadedFile $uploadedFile): array
    {
        if (!$uploadedFile->isValid()) {
            throw new \RuntimeException('Zip-paketet kunde inte laddas upp korrekt.');
        }

        $extension = mb_strtolower((string) pathinfo((string) $uploadedFile->getClientOriginalName(), \PATHINFO_EXTENSION));
        if ('zip' !== $extension) {
            throw new \RuntimeException('Uppdateringspaketet måste vara en zip-fil.');
        }

        $id = sprintf('%s_%s', (new \DateTimeImmutable())->format('Ymd_His'), bin2hex(random_bytes(4)));
        $stagingRoot = $this->stagingDirectory().\DIRECTORY_SEPARATOR.$id;
        $sourceZipPath = $stagingRoot.\DIRECTORY_SEPARATOR.'package.zip';
        $extractDirectory = $stagingRoot.\DIRECTORY_SEPARATOR.'extracted';

        if (!mkdir($stagingRoot, 0775, true) && !is_dir($stagingRoot)) {
            throw new \RuntimeException('Kunde inte skapa stagingmappen för uppdateringspaketet.');
        }

        $uploadedFile->move($stagingRoot, 'package.zip');
        $packageChecksumSha256 = hash_file('sha256', $sourceZipPath);
        $fileCount = $this->extractArchiveSafely($sourceZipPath, $extractDirectory);
        $packageRoot = $this->detectPackageRoot($extractDirectory);
        $releaseMetadata = $this->readReleaseMetadata($packageRoot);
        $releaseMetadataMessages = $this->validateReleaseMetadata($packageRoot, $releaseMetadata);
        $changeSummary = $this->summarizePackageChanges($packageRoot);

        $validationMessages = $releaseMetadataMessages;
        foreach (self::REQUIRED_PACKAGE_PATHS as $requiredPath) {
            if (!file_exists($packageRoot.\DIRECTORY_SEPARATOR.$requiredPath)) {
                $validationMessages[] = sprintf('Saknar %s i paketet.', $requiredPath);
            }
        }

        $composerInfo = $this->readComposerMetadata($packageRoot.\DIRECTORY_SEPARATOR.'composer.json');
        $valid = [] === $validationMessages;
        $includesVendor = is_file($packageRoot.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'autoload.php');
        $releasePackageType = \is_array($releaseMetadata) && isset($releaseMetadata['packageType']) && \is_string($releaseMetadata['packageType'])
            ? $releaseMetadata['packageType']
            : 'legacy';
        $releaseNotesMetadata = $this->normalizeReleaseNotesMetadata($releaseMetadata, $releasePackageType);
        $installedVersion = $this->describeCurrentApplication()['version'];
        $cumulativeUpgrade = $this->normalizeCumulativeUpgrade($releaseMetadata, $releasePackageType);
        $minimumSupportedVersion = $this->normalizeMinimumSupportedVersion($releaseMetadata);

        $manifest = [
            'id' => $id,
            'originalFilename' => (string) ($uploadedFile->getClientOriginalName() ?: 'update.zip'),
            'packageName' => $composerInfo['name'],
            'packageVersion' => $composerInfo['version'],
            'installedVersion' => $installedVersion,
            'versionComparison' => $this->comparePackageVersionToInstalledVersion($composerInfo['version'], $installedVersion),
            'uploadedAt' => (new \DateTimeImmutable())->format(DATE_ATOM),
            'valid' => $valid,
            'validationMessages' => $validationMessages,
            'fileCount' => $fileCount,
            'includesVendor' => $includesVendor,
            'packageChecksumSha256' => $packageChecksumSha256,
            'releaseMetadataPresent' => \is_array($releaseMetadata),
            'releasePackageType' => $releasePackageType,
            'cumulativeUpgrade' => $cumulativeUpgrade,
            'minimumSupportedVersion' => $minimumSupportedVersion,
            'releaseBuiltAt' => \is_array($releaseMetadata) && isset($releaseMetadata['builtAt']) && \is_string($releaseMetadata['builtAt']) ? $releaseMetadata['builtAt'] : null,
            'releaseContentManifestSha256' => \is_array($releaseMetadata) && isset($releaseMetadata['contentManifestSha256']) && \is_string($releaseMetadata['contentManifestSha256']) ? $releaseMetadata['contentManifestSha256'] : null,
            'changeSummary' => $changeSummary['summary'],
            'changedFiles' => $changeSummary['files'],
            'releaseNotesPresent' => $releaseNotesMetadata['releaseNotesPresent'],
            'releaseNotesPath' => $releaseNotesMetadata['releaseNotesPath'],
            'releaseNotesMarkdown' => $releaseNotesMetadata['releaseNotesMarkdown'],
            'releaseHighlights' => $releaseNotesMetadata['releaseHighlights'],
            'operationalNotes' => $releaseNotesMetadata['operationalNotes'],
            'postUpdateChecklist' => $releaseNotesMetadata['postUpdateChecklist'],
            'requiresMigrations' => $releaseNotesMetadata['requiresMigrations'],
            'requiresCacheRefresh' => $releaseNotesMetadata['requiresCacheRefresh'],
            'requiresServiceReload' => $releaseNotesMetadata['requiresServiceReload'],
            'preflightChecks' => $this->buildPackagePreflightChecks($valid, $validationMessages, $includesVendor, $releaseMetadata, $changeSummary['summary'], $releaseNotesMetadata),
            'packageRoot' => $packageRoot,
            'appliedAt' => null,
            'applicationBackupFilename' => null,
        ];

        file_put_contents(
            $stagingRoot.\DIRECTORY_SEPARATOR.'manifest.json',
            json_encode($manifest, \JSON_PRETTY_PRINT | \JSON_THROW_ON_ERROR),
        );

        return $this->normalizeManifest($manifest);
    }

    /**
     * @return array{
     *     package: array{
     *         id: string,
     *         originalFilename: string,
     *         packageName: string,
     *         packageVersion: string,
     *         uploadedAt: \DateTimeImmutable,
     *         valid: bool,
     *         validationMessages: list<string>,
     *         fileCount: int,
     *         includesVendor: bool,
     *         appliedAt: ?\DateTimeImmutable,
     *         applicationBackupFilename: ?string
     *     },
     *     applicationBackup: array{
     *         filename: string,
     *         path: string,
     *         sizeBytes: int,
     *         createdAt: \DateTimeImmutable
     *     }
     * }
     */
    public function applyStagedPackage(string $id): array
    {
        $manifestPath = $this->stagingDirectory().\DIRECTORY_SEPARATOR.basename($id).DIRECTORY_SEPARATOR.'manifest.json';
        $manifest = $this->readManifest($manifestPath, true);
        if (!$manifest['valid']) {
            throw new \RuntimeException('Det uppladdade uppdateringspaketet är inte giltigt och kan inte aktiveras.');
        }

        $packageRoot = (string) (($this->readRawManifest($manifestPath)['packageRoot'] ?? ''));
        if ('' === $packageRoot || !is_dir($packageRoot)) {
            throw new \RuntimeException('Paketets stagingmapp kunde inte hittas.');
        }

        $applicationBackup = $this->createApplicationBackup();
        $this->syncPackageContents($packageRoot, $this->projectDir);

        $rawManifest = $this->readRawManifest($manifestPath);
        $rawManifest['appliedAt'] = (new \DateTimeImmutable())->format(DATE_ATOM);
        $rawManifest['applicationBackupFilename'] = $applicationBackup['filename'];
        file_put_contents($manifestPath, json_encode($rawManifest, \JSON_PRETTY_PRINT | \JSON_THROW_ON_ERROR));

        return [
            'package' => $this->normalizeManifest($rawManifest),
            'applicationBackup' => $applicationBackup,
        ];
    }

    public function assertStagedPackageCanBeApplied(string $id): void
    {
        $manifestPath = $this->stagingDirectory().\DIRECTORY_SEPARATOR.basename($id).DIRECTORY_SEPARATOR.'manifest.json';
        $manifest = $this->readManifest($manifestPath, true);
        if (!$manifest['valid']) {
            throw new \RuntimeException('Det uppladdade uppdateringspaketet är inte giltigt och kan inte aktiveras.');
        }

        $packageRoot = (string) (($this->readRawManifest($manifestPath)['packageRoot'] ?? ''));
        if ('' === $packageRoot || !is_dir($packageRoot)) {
            throw new \RuntimeException('Paketets stagingmapp kunde inte hittas.');
        }

        $problems = [];
        foreach (scandir($packageRoot) ?: [] as $entry) {
            if (\in_array($entry, ['.', '..'], true) || $this->shouldSkipRelativePath($entry)) {
                continue;
            }

            $this->collectTargetWriteProblems(
                $this->projectDir.\DIRECTORY_SEPARATOR.$entry,
                $entry,
                $problems,
            );
        }

        foreach (self::MANAGED_ROOT_PATHS as $managedRootPath) {
            if ($this->shouldSkipRelativePath($managedRootPath) || file_exists($packageRoot.\DIRECTORY_SEPARATOR.$managedRootPath)) {
                continue;
            }

            $this->collectTargetWriteProblems(
                $this->projectDir.\DIRECTORY_SEPARATOR.$managedRootPath,
                $managedRootPath,
                $problems,
            );
        }

        if ([] !== $problems) {
            throw new \RuntimeException(sprintf(
                "Förkontrollen misslyckades: uppdateringspaketet kan inte appliceras eftersom webbcontainern saknar skrivrättighet.\n%s\n\nÅtgärda filägare/rättigheter innan versionen köas, till exempel med `chown -R <webbserver-användare>:<webbserver-grupp>` för applikationsfilerna i containern. Ofta är det `www-data:www-data`, men på Apache med `mpm-itk`/`AssignUserID` kan det vara vhost-användaren.",
                implode("\n", array_map(static fn (string $problem): string => '- '.$problem, array_slice(array_unique($problems), 0, 16))),
            ));
        }
    }

    public function resolveApplicationBackupPath(string $filename): string
    {
        $safeFilename = basename(trim($filename));
        if ('' === $safeFilename) {
            throw new \RuntimeException('Backupfilen saknar giltigt namn.');
        }

        $path = $this->backupDirectory().\DIRECTORY_SEPARATOR.$safeFilename;
        if (!is_file($path)) {
            throw new \RuntimeException('Kodbackupen kunde inte hittas.');
        }

        return $path;
    }

    private function stagingDirectory(): string
    {
        $directory = $this->projectDir.\DIRECTORY_SEPARATOR.'var'.\DIRECTORY_SEPARATOR.'code_update_staging';
        if (!is_dir($directory) && !mkdir($directory, 0775, true) && !is_dir($directory)) {
            throw new \RuntimeException('Kunde inte skapa stagingmappen för koduppdateringar.');
        }

        return $directory;
    }

    private function backupDirectory(): string
    {
        $directory = $this->projectDir.\DIRECTORY_SEPARATOR.'var'.\DIRECTORY_SEPARATOR.'code_update_backups';
        if (!is_dir($directory) && !mkdir($directory, 0775, true) && !is_dir($directory)) {
            throw new \RuntimeException('Kunde inte skapa backupmappen för koduppdateringar.');
        }

        return $directory;
    }

    private function extractArchiveSafely(string $zipPath, string $targetDirectory): int
    {
        $zip = new \ZipArchive();
        if (true !== $zip->open($zipPath)) {
            throw new \RuntimeException('Kunde inte öppna zip-paketet.');
        }

        $extractedFiles = 0;
        for ($index = 0; $index < $zip->numFiles; ++$index) {
            $entryName = (string) $zip->getNameIndex($index);
            $normalizedEntryName = str_replace('\\', '/', $entryName);
            if (str_contains($normalizedEntryName, '../')) {
                $zip->close();

                throw new \RuntimeException('Zip-paketet innehåller ogiltiga sökvägar.');
            }

            $targetPath = $targetDirectory.\DIRECTORY_SEPARATOR.$normalizedEntryName;
            if (str_ends_with($normalizedEntryName, '/')) {
                if (!is_dir($targetPath) && !mkdir($targetPath, 0775, true) && !is_dir($targetPath)) {
                    $zip->close();

                    throw new \RuntimeException('Kunde inte skapa mapp under zip-extraktionen.');
                }

                continue;
            }

            $directory = dirname($targetPath);
            if (!is_dir($directory) && !mkdir($directory, 0775, true) && !is_dir($directory)) {
                $zip->close();

                throw new \RuntimeException('Kunde inte skapa mapp för extraherade filer.');
            }

            $content = $zip->getFromIndex($index);
            if (false === $content) {
                $zip->close();

                throw new \RuntimeException('Kunde inte läsa en fil ur zip-paketet.');
            }

            file_put_contents($targetPath, $content);
            ++$extractedFiles;
        }

        $zip->close();

        return $extractedFiles;
    }

    private function detectPackageRoot(string $extractDirectory): string
    {
        if (is_file($extractDirectory.\DIRECTORY_SEPARATOR.'composer.json')) {
            return $extractDirectory;
        }

        $entries = array_values(array_filter(
            scandir($extractDirectory) ?: [],
            static fn (string $entry): bool => !\in_array($entry, ['.', '..'], true),
        ));

        if (1 === \count($entries)) {
            $candidate = $extractDirectory.\DIRECTORY_SEPARATOR.$entries[0];
            if (is_dir($candidate) && is_file($candidate.\DIRECTORY_SEPARATOR.'composer.json')) {
                return $candidate;
            }
        }

        throw new \RuntimeException('Zip-paketet innehåller inte en igenkännbar applikationsrot med composer.json.');
    }

    /**
     * @return array{name: string, version: string}
     */
    private function readComposerMetadata(string $composerPath): array
    {
        if (!is_file($composerPath)) {
            return [
                'name' => 'okänt paket',
                'version' => 'okänd version',
            ];
        }

        /** @var array<string, mixed>|null $composer */
        $composer = json_decode((string) file_get_contents($composerPath), true);

        return [
            'name' => is_array($composer) && isset($composer['name']) && is_string($composer['name']) ? $composer['name'] : 'okänt paket',
            'version' => is_array($composer) && isset($composer['version']) && is_string($composer['version']) ? $composer['version'] : 'okänd version',
        ];
    }

    /**
     * @return array<string, mixed>|null
     */
    private function readReleaseMetadata(string $packageRoot): ?array
    {
        $metadataPath = $packageRoot.\DIRECTORY_SEPARATOR.'release-metadata.json';
        if (!is_file($metadataPath)) {
            return null;
        }

        try {
            /** @var array<string, mixed> $metadata */
            $metadata = json_decode((string) file_get_contents($metadataPath), true, 512, \JSON_THROW_ON_ERROR);

            return $metadata;
        } catch (\Throwable) {
            return [
                '_metadataError' => 'release-metadata.json kunde inte läsas.',
            ];
        }
    }

    /**
     * @param array<string, mixed>|null $releaseMetadata
     */
    private function normalizeCumulativeUpgrade(?array $releaseMetadata, string $packageType): bool
    {
        return 'upgrade' === $packageType && true === ($releaseMetadata['cumulativeUpgrade'] ?? false);
    }

    /**
     * @param array<string, mixed>|null $releaseMetadata
     */
    private function normalizeMinimumSupportedVersion(?array $releaseMetadata): ?string
    {
        if (!isset($releaseMetadata['minimumSupportedVersion']) || !\is_string($releaseMetadata['minimumSupportedVersion'])) {
            return null;
        }

        $version = trim($releaseMetadata['minimumSupportedVersion']);

        return '' !== $version ? $version : null;
    }

    private function comparePackageVersionToInstalledVersion(string $packageVersion, string $installedVersion): string
    {
        $normalizedPackageVersion = trim($packageVersion);
        $normalizedInstalledVersion = trim($installedVersion);
        if (!$this->isComparableVersion($normalizedPackageVersion) || !$this->isComparableVersion($normalizedInstalledVersion)) {
            return 'unknown';
        }

        $comparison = version_compare($normalizedPackageVersion, $normalizedInstalledVersion);
        if ($comparison > 0) {
            return 'newer';
        }

        if ($comparison < 0) {
            return 'older';
        }

        return 'same';
    }

    private function isComparableVersion(string $version): bool
    {
        return '' !== $version && 1 === preg_match('/^\d+(?:[._-]\d+)*(?:[A-Za-z0-9._-]*)?$/', $version);
    }

    private function formatReleaseBuiltAt(mixed $builtAt): ?string
    {
        if (!\is_string($builtAt) || '' === trim($builtAt)) {
            return null;
        }

        try {
            return (new \DateTimeImmutable($builtAt))->format('Y-m-d H:i');
        } catch (\Throwable) {
            return null;
        }
    }

    /**
     * @param array<string, mixed>|null $releaseMetadata
     * @return list<string>
     */
    private function validateReleaseMetadata(string $packageRoot, ?array $releaseMetadata): array
    {
        if (null === $releaseMetadata) {
            return [];
        }

        if (isset($releaseMetadata['_metadataError'])) {
            return [(string) $releaseMetadata['_metadataError']];
        }

        $messages = [];
        $packageType = isset($releaseMetadata['packageType']) && \is_string($releaseMetadata['packageType'])
            ? $releaseMetadata['packageType']
            : '';

        if ('install' === $packageType) {
            $messages[] = 'Paketet är ett installationspaket och ska användas för nyinstallation, inte som koduppgradering.';
        } elseif ('upgrade' !== $packageType) {
            $messages[] = 'Paketets release-metadata saknar giltig packageType=upgrade.';
        }

        $declaredContentManifestSha256 = isset($releaseMetadata['contentManifestSha256']) && \is_string($releaseMetadata['contentManifestSha256'])
            ? $releaseMetadata['contentManifestSha256']
            : '';
        $declaredFiles = $this->normalizeReleaseMetadataFiles($releaseMetadata['files'] ?? null);

        if ('' === $declaredContentManifestSha256 || null === $declaredFiles) {
            $messages[] = 'Release-metadata saknar ett verifierbart filmanifest.';

            return array_values(array_unique($messages));
        }

        $actualFiles = $this->collectPackageFiles($packageRoot);
        if ($declaredFiles !== $actualFiles || $declaredContentManifestSha256 !== $this->hashManifestFiles($actualFiles)) {
            $messages[] = 'Filmanifestet i release-metadata stämmer inte med paketets innehåll.';
        }

        return array_values(array_unique($messages));
    }

    /**
     * @param mixed $files
     * @return list<array{path: string, sizeBytes: int, sha256: string}>|null
     */
    private function normalizeReleaseMetadataFiles(mixed $files): ?array
    {
        if (!\is_array($files)) {
            return null;
        }

        $normalized = [];
        foreach ($files as $file) {
            if (!\is_array($file)) {
                return null;
            }

            $path = isset($file['path']) && \is_string($file['path']) ? str_replace('\\', '/', $file['path']) : '';
            $sha256 = isset($file['sha256']) && \is_string($file['sha256']) ? $file['sha256'] : '';
            if ('' === $path || str_contains($path, '../') || !preg_match('/^[a-f0-9]{64}$/', $sha256)) {
                return null;
            }

            $normalized[] = [
                'path' => $path,
                'sizeBytes' => (int) ($file['sizeBytes'] ?? 0),
                'sha256' => $sha256,
            ];
        }

        usort($normalized, static fn (array $left, array $right): int => $left['path'] <=> $right['path']);

        return $normalized;
    }

    /**
     * @return array{
     *     summary: array{new: int, modified: int, removed: int, unchanged: int, total: int},
     *     files: list<array{path: string, status: string, label: string}>
     * }
     */
    private function summarizePackageChanges(string $packageRoot): array
    {
        $packageFiles = $this->collectManagedComparableFiles($packageRoot);
        $currentFiles = $this->collectManagedComparableFiles($this->projectDir);
        $summary = [
            'new' => 0,
            'modified' => 0,
            'removed' => 0,
            'unchanged' => 0,
            'total' => 0,
        ];
        $changedFiles = [];

        foreach ($packageFiles as $path => $packageFile) {
            if (!isset($currentFiles[$path])) {
                ++$summary['new'];
                $changedFiles[] = ['path' => $path, 'status' => 'new', 'label' => 'Ny'];

                continue;
            }

            if ($packageFile['sha256'] !== $currentFiles[$path]['sha256']) {
                ++$summary['modified'];
                $changedFiles[] = ['path' => $path, 'status' => 'modified', 'label' => 'Ändrad'];

                continue;
            }

            ++$summary['unchanged'];
        }

        foreach ($currentFiles as $path => $_currentFile) {
            if (isset($packageFiles[$path])) {
                continue;
            }

            ++$summary['removed'];
            $changedFiles[] = ['path' => $path, 'status' => 'removed', 'label' => 'Tas bort'];
        }

        $summary['total'] = $summary['new'] + $summary['modified'] + $summary['removed'];
        usort($changedFiles, static fn (array $left, array $right): int => $left['path'] <=> $right['path']);

        return [
            'summary' => $summary,
            'files' => array_slice($changedFiles, 0, 24),
        ];
    }

    /**
     * @return array<string, array{sha256: string, sizeBytes: int}>
     */
    private function collectManagedComparableFiles(string $rootDirectory): array
    {
        $paths = [];
        foreach (array_merge(self::MANAGED_ROOT_PATHS, ['vendor/autoload.php']) as $managedPath) {
            $sourcePath = $rootDirectory.\DIRECTORY_SEPARATOR.$managedPath;
            if (!file_exists($sourcePath) || $this->shouldSkipRelativePath($managedPath)) {
                continue;
            }

            foreach ($this->collectFilesFromPath($sourcePath, $managedPath) as $file) {
                $paths[$file['path']] = [
                    'sha256' => $file['sha256'],
                    'sizeBytes' => $file['sizeBytes'],
                ];
            }
        }

        ksort($paths);

        return $paths;
    }

    /**
     * @return list<array{path: string, sizeBytes: int, sha256: string}>
     */
    private function collectPackageFiles(string $packageRoot): array
    {
        $files = $this->collectFilesFromPath($packageRoot, '');
        $files = array_values(array_filter(
            $files,
            static fn (array $file): bool => 'release-metadata.json' !== $file['path'],
        ));
        usort($files, static fn (array $left, array $right): int => $left['path'] <=> $right['path']);

        return $files;
    }

    /**
     * @return list<array{path: string, sizeBytes: int, sha256: string}>
     */
    private function collectFilesFromPath(string $sourcePath, string $relativePath): array
    {
        $normalizedRelativePath = trim(str_replace('\\', '/', $relativePath), '/');
        if (is_file($sourcePath)) {
            if ($this->shouldSkipRelativePath($normalizedRelativePath)) {
                return [];
            }

            return [[
                'path' => $normalizedRelativePath,
                'sizeBytes' => (int) filesize($sourcePath),
                'sha256' => hash_file('sha256', $sourcePath),
            ]];
        }

        if (!is_dir($sourcePath)) {
            return [];
        }

        $files = [];
        $iterator = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($sourcePath, \FilesystemIterator::SKIP_DOTS),
        );

        foreach ($iterator as $file) {
            if (!$file->isFile()) {
                continue;
            }

            $childRelativePath = str_replace('\\', '/', ltrim(substr($file->getPathname(), \strlen($sourcePath)), \DIRECTORY_SEPARATOR));
            $path = '' === $normalizedRelativePath ? $childRelativePath : $normalizedRelativePath.'/'.$childRelativePath;
            if ($this->shouldSkipRelativePath($path)) {
                continue;
            }

            $files[] = [
                'path' => $path,
                'sizeBytes' => (int) $file->getSize(),
                'sha256' => hash_file('sha256', $file->getPathname()),
            ];
        }

        usort($files, static fn (array $left, array $right): int => $left['path'] <=> $right['path']);

        return $files;
    }

    /**
     * @param list<array{path: string, sizeBytes: int, sha256: string}> $manifestFiles
     */
    private function hashManifestFiles(array $manifestFiles): string
    {
        return hash('sha256', json_encode($manifestFiles, \JSON_UNESCAPED_SLASHES | \JSON_THROW_ON_ERROR));
    }

    /**
     * @param list<string> $validationMessages
     * @param array<string, mixed>|null $releaseMetadata
     * @param array{new: int, modified: int, removed: int, unchanged: int, total: int} $changeSummary
     * @param array{
     *     releaseNotesPresent: bool,
     *     releaseNotesPath: string,
     *     releaseNotesMarkdown: string,
     *     releaseHighlights: list<array{section: string, text: string}>,
     *     operationalNotes: list<string>,
     *     postUpdateChecklist: list<string>,
     *     requiresMigrations: bool,
     *     requiresCacheRefresh: bool,
     *     requiresServiceReload: bool
     * } $releaseNotesMetadata
     * @return list<array{label: string, state: string, description: string}>
     */
    private function buildPackagePreflightChecks(bool $valid, array $validationMessages, bool $includesVendor, ?array $releaseMetadata, array $changeSummary, array $releaseNotesMetadata): array
    {
        $packageType = \is_array($releaseMetadata) && isset($releaseMetadata['packageType']) && \is_string($releaseMetadata['packageType'])
            ? $releaseMetadata['packageType']
            : 'legacy';
        $manifestHasProblems = \count(array_filter(
            $validationMessages,
            static fn (string $message): bool => str_contains($message, 'Filmanifestet') || str_contains($message, 'release-metadata') || str_contains($message, 'Release-metadata'),
        )) > 0;
        $cumulativeUpgrade = $this->normalizeCumulativeUpgrade($releaseMetadata, $packageType);
        $minimumSupportedVersion = $this->normalizeMinimumSupportedVersion($releaseMetadata);

        return [
            [
                'label' => 'Paketstruktur',
                'state' => $valid ? 'green' : 'orange',
                'description' => $valid ? 'Obligatoriska kodfiler finns i paketet.' : 'Paketet behöver åtgärdas innan det kan köas.',
            ],
            [
                'label' => 'Pakettyp',
                'state' => 'upgrade' === $packageType ? 'green' : ('legacy' === $packageType ? 'gray' : 'orange'),
                'description' => 'legacy' === $packageType ? 'Äldre paket utan release-metadata.' : sprintf('Release-metadata anger %s.', $packageType),
            ],
            [
                'label' => 'Kumulativ uppdatering',
                'state' => $cumulativeUpgrade ? 'green' : ('upgrade' === $packageType ? 'orange' : 'gray'),
                'description' => $cumulativeUpgrade
                    ? sprintf('Paketet kan uppdatera äldre 1.x-installationer direkt%s.', null !== $minimumSupportedVersion ? ' från '.$minimumSupportedVersion : '')
                    : 'Paketet saknar markering för kumulativ uppdatering.',
            ],
            [
                'label' => 'Filmanifest',
                'state' => null === $releaseMetadata ? 'gray' : ($manifestHasProblems ? 'orange' : 'green'),
                'description' => null === $releaseMetadata ? 'Saknas i äldre paket.' : ($manifestHasProblems ? 'Checksum eller filmanifest behöver kontrolleras.' : 'Manifest och filchecksummor stämmer.'),
            ],
            [
                'label' => 'Versionsinformation',
                'state' => $releaseNotesMetadata['releaseNotesPresent'] ? 'green' : 'orange',
                'description' => $releaseNotesMetadata['releaseNotesPresent']
                    ? 'Paketet innehåller versionsanteckningar, driftkrav och efterkontroller.'
                    : 'Paketet saknar versionsnotiser för versionen. Det kan appliceras, men granska ändringarna extra noggrant.',
            ],
            [
                'label' => 'Vendor',
                'state' => $includesVendor ? 'green' : 'orange',
                'description' => $includesVendor ? 'vendor/autoload.php finns med.' : 'vendor saknas och paketet kan inte appliceras i drift.',
            ],
            [
                'label' => 'Ändringar',
                'state' => $changeSummary['total'] > 0 ? 'blue' : 'gray',
                'description' => sprintf(
                    '%d nya, %d ändrade och %d borttagna filer upptäcktes.',
                    $changeSummary['new'],
                    $changeSummary['modified'],
                    $changeSummary['removed'],
                ),
            ],
            [
                'label' => 'Återställning',
                'state' => 'blue',
                'description' => 'En kodbackup skapas automatiskt precis före applicering.',
            ],
        ];
    }

    /**
     * @return array{
     *     filename: string,
     *     path: string,
     *     sizeBytes: int,
     *     createdAt: \DateTimeImmutable
     * }
     */
    private function createApplicationBackup(): array
    {
        $createdAt = new \DateTimeImmutable();
        $filename = sprintf('driftpunkt_code_backup_%s_%s.zip', $createdAt->format('Ymd_His_u'), bin2hex(random_bytes(3)));
        $path = $this->backupDirectory().\DIRECTORY_SEPARATOR.$filename;

        $zip = new \ZipArchive();
        if (true !== $zip->open($path, \ZipArchive::CREATE | \ZipArchive::OVERWRITE)) {
            throw new \RuntimeException('Kunde inte skapa kodbackupen före uppdateringen.');
        }

        $excludeExact = [
            $this->projectDir.\DIRECTORY_SEPARATOR.'db',
            $this->projectDir.\DIRECTORY_SEPARATOR.'var'.\DIRECTORY_SEPARATOR.'cache',
            $this->projectDir.\DIRECTORY_SEPARATOR.'var'.\DIRECTORY_SEPARATOR.'code_update_backups',
            $this->projectDir.\DIRECTORY_SEPARATOR.'var'.\DIRECTORY_SEPARATOR.'code_update_staging',
            $this->projectDir.\DIRECTORY_SEPARATOR.'.git',
        ];

        $directoryIterator = new \RecursiveDirectoryIterator($this->projectDir, \FilesystemIterator::SKIP_DOTS);
        $filteredIterator = new \RecursiveCallbackFilterIterator(
            $directoryIterator,
            static function (\SplFileInfo $item) use ($excludeExact): bool {
                $pathName = $item->getPathname();
                foreach ($excludeExact as $excludedPath) {
                    if ($pathName === $excludedPath || str_starts_with($pathName, $excludedPath.\DIRECTORY_SEPARATOR)) {
                        return false;
                    }
                }

                return true;
            },
        );

        $iterator = new \RecursiveIteratorIterator(
            $filteredIterator,
            \RecursiveIteratorIterator::SELF_FIRST,
            \RecursiveIteratorIterator::CATCH_GET_CHILD,
        );

        foreach ($iterator as $item) {
            $relativePath = ltrim(substr($item->getPathname(), \strlen($this->projectDir)), \DIRECTORY_SEPARATOR);
            if ('' === $relativePath) {
                continue;
            }

            if ($item->isDir()) {
                $zip->addEmptyDir(str_replace('\\', '/', $relativePath));

                continue;
            }

            $zip->addFile($item->getPathname(), str_replace('\\', '/', $relativePath));
        }

        $zip->close();

        return [
            'filename' => $filename,
            'path' => $path,
            'sizeBytes' => (int) filesize($path),
            'createdAt' => $createdAt,
        ];
    }

    private function syncPackageContents(string $sourceDirectory, string $targetDirectory): void
    {
        foreach (scandir($sourceDirectory) ?: [] as $entry) {
            if (\in_array($entry, ['.', '..'], true) || $this->shouldSkipRelativePath($entry)) {
                continue;
            }

            $sourcePath = $sourceDirectory.\DIRECTORY_SEPARATOR.$entry;
            $destinationPath = $targetDirectory.\DIRECTORY_SEPARATOR.$entry;
            $this->syncPath($sourcePath, $destinationPath, $entry);
        }

        foreach (self::MANAGED_ROOT_PATHS as $managedRootPath) {
            if ($this->shouldSkipRelativePath($managedRootPath)) {
                continue;
            }

            $sourcePath = $sourceDirectory.\DIRECTORY_SEPARATOR.$managedRootPath;
            $destinationPath = $targetDirectory.\DIRECTORY_SEPARATOR.$managedRootPath;
            if (!file_exists($sourcePath) && file_exists($destinationPath)) {
                $this->removePath($destinationPath, $managedRootPath);
            }
        }
    }

    /**
     * @param list<string> $problems
     */
    private function collectTargetWriteProblems(string $targetPath, string $relativePath, array &$problems): void
    {
        if (!file_exists($targetPath)) {
            $parentDirectory = dirname($targetPath);
            if (!is_dir($parentDirectory) || !is_writable($parentDirectory)) {
                $problems[] = sprintf('%s kan inte skapas: överordnad katalog är inte skrivbar', $relativePath);
            }

            return;
        }

        if (!is_writable($targetPath)) {
            $problems[] = sprintf('%s är inte skrivbar', $relativePath);
        }

        if (!is_dir($targetPath) || is_link($targetPath)) {
            return;
        }

        $iterator = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($targetPath, \FilesystemIterator::SKIP_DOTS),
            \RecursiveIteratorIterator::SELF_FIRST,
            \RecursiveIteratorIterator::CATCH_GET_CHILD,
        );

        $reported = 0;
        foreach ($iterator as $item) {
            $childRelativePath = $relativePath.'/'.ltrim(substr($item->getPathname(), \strlen($targetPath)), \DIRECTORY_SEPARATOR);
            if ($this->shouldSkipRelativePath($childRelativePath)) {
                continue;
            }

            if (is_writable($item->getPathname())) {
                continue;
            }

            $problems[] = sprintf('%s är inte skrivbar', str_replace('\\', '/', $childRelativePath));
            ++$reported;

            if ($reported >= 8) {
                $problems[] = sprintf('%s innehåller fler filer utan skrivrättighet', $relativePath);
                break;
            }
        }
    }

    private function syncPath(string $sourcePath, string $destinationPath, string $relativePath): void
    {
        if (is_dir($sourcePath)) {
            if (is_file($destinationPath)) {
                $this->removePath($destinationPath, $relativePath);
            }

            if (!is_dir($destinationPath) && !mkdir($destinationPath, 0775, true) && !is_dir($destinationPath)) {
                throw new \RuntimeException(sprintf('Kunde inte skapa katalogen %s under koduppdateringen.', $relativePath));
            }

            $this->syncDirectoryContents($sourcePath, $destinationPath, $relativePath);

            return;
        }

        $destinationDirectory = dirname($destinationPath);
        if (!is_dir($destinationDirectory) && !mkdir($destinationDirectory, 0775, true) && !is_dir($destinationDirectory)) {
            throw new \RuntimeException(sprintf('Kunde inte skapa katalogen för %s under koduppdateringen.', $relativePath));
        }

        if (is_dir($destinationPath)) {
            $this->removePath($destinationPath, $relativePath);
        }

        if (is_file($destinationPath) && $this->filesHaveSameContents($sourcePath, $destinationPath)) {
            return;
        }

        if (!copy($sourcePath, $destinationPath)) {
            throw new \RuntimeException(sprintf('Kunde inte uppdatera filen %s.', $relativePath));
        }
    }

    private function filesHaveSameContents(string $sourcePath, string $destinationPath): bool
    {
        $sourceSize = filesize($sourcePath);
        $destinationSize = filesize($destinationPath);
        if (false === $sourceSize || false === $destinationSize || $sourceSize !== $destinationSize) {
            return false;
        }

        return hash_file('sha256', $sourcePath) === hash_file('sha256', $destinationPath);
    }

    private function syncDirectoryContents(string $sourceDirectory, string $targetDirectory, string $relativeBasePath): void
    {
        $sourceEntries = array_values(array_filter(
            scandir($sourceDirectory) ?: [],
            static fn (string $entry): bool => !\in_array($entry, ['.', '..'], true),
        ));

        foreach ($sourceEntries as $entry) {
            $childRelativePath = $relativeBasePath.'/'.$entry;
            if ($this->shouldSkipRelativePath($childRelativePath)) {
                continue;
            }

            $this->syncPath(
                $sourceDirectory.\DIRECTORY_SEPARATOR.$entry,
                $targetDirectory.\DIRECTORY_SEPARATOR.$entry,
                $childRelativePath,
            );
        }

        foreach (array_values(array_filter(
            scandir($targetDirectory) ?: [],
            static fn (string $entry): bool => !\in_array($entry, ['.', '..'], true),
        )) as $targetEntry) {
            $childRelativePath = $relativeBasePath.'/'.$targetEntry;
            if ($this->shouldSkipRelativePath($childRelativePath)) {
                continue;
            }

            if (!file_exists($sourceDirectory.\DIRECTORY_SEPARATOR.$targetEntry)) {
                $this->removePath($targetDirectory.\DIRECTORY_SEPARATOR.$targetEntry, $childRelativePath);
            }
        }
    }

    private function removePath(string $path, string $relativePath): void
    {
        if ($this->shouldSkipRelativePath($relativePath)) {
            return;
        }

        if (is_dir($path) && !is_link($path)) {
            foreach (array_values(array_filter(
                scandir($path) ?: [],
                static fn (string $entry): bool => !\in_array($entry, ['.', '..'], true),
            )) as $entry) {
                $this->removePath(
                    $path.\DIRECTORY_SEPARATOR.$entry,
                    trim(str_replace('\\', '/', $relativePath.'/'.$entry), '/'),
                );
            }

            $remainingEntries = array_values(array_filter(
                scandir($path) ?: [],
                static fn (string $entry): bool => !\in_array($entry, ['.', '..'], true),
            ));
            if ([] !== $remainingEntries) {
                return;
            }

            if (!@rmdir($path)) {
                throw new \RuntimeException(sprintf('Kunde inte rensa katalogen %s under koduppdateringen.', $relativePath));
            }

            return;
        }

        if (file_exists($path) && !@unlink($path)) {
            throw new \RuntimeException(sprintf('Kunde inte rensa filen %s under koduppdateringen.', $relativePath));
        }
    }

    private function shouldSkipRelativePath(string $relativePath): bool
    {
        $normalizedPath = str_replace('\\', '/', $relativePath);
        if (SiteBrandingAssetStorage::isRuntimeBrandingPath($normalizedPath)) {
            return true;
        }

        $segments = explode('/', $normalizedPath);
        $firstSegment = $segments[0] ?? '';

        if (\in_array($firstSegment, ['.git', 'var'], true)) {
            return true;
        }

        $basename = basename($normalizedPath);

        return '.env' === $basename
            || str_starts_with($basename, '.env.local')
            || (str_starts_with($basename, '.env.') && '.env.example' !== $basename);
    }

    /**
     * @return array<string, mixed>|null
     */
    private function readRawManifest(string $manifestPath): ?array
    {
        if (!is_file($manifestPath)) {
            return null;
        }

        try {
            /** @var array<string, mixed> $manifest */
            $manifest = json_decode((string) file_get_contents($manifestPath), true, 512, \JSON_THROW_ON_ERROR);

            return $manifest;
        } catch (\JsonException) {
            return null;
        }
    }

    /**
     * @return array{
     *     id: string,
     *     originalFilename: string,
     *     packageName: string,
     *     packageVersion: string,
     *     uploadedAt: \DateTimeImmutable,
     *     valid: bool,
     *     validationMessages: list<string>,
     *     fileCount: int,
     *     includesVendor: bool,
     *     appliedAt: ?\DateTimeImmutable,
     *     applicationBackupFilename: ?string
     * }|null
     */
    private function readManifest(string $manifestPath, bool $mustExist = false): ?array
    {
        $manifest = $this->readRawManifest($manifestPath);
        if (null === $manifest) {
            if ($mustExist) {
                throw new \RuntimeException('Det uppladdade uppdateringspaketet kunde inte hittas.');
            }

            return null;
        }

        return $this->normalizeManifest($manifest);
    }

    /**
     * @param array<string, mixed> $manifest
     * @return array{
     *     id: string,
     *     originalFilename: string,
     *     packageName: string,
     *     packageVersion: string,
     *     uploadedAt: \DateTimeImmutable,
     *     valid: bool,
     *     validationMessages: list<string>,
     *     fileCount: int,
     *     includesVendor: bool,
     *     appliedAt: ?\DateTimeImmutable,
     *     applicationBackupFilename: ?string
     * }
     */
    private function normalizeManifest(array $manifest): array
    {
        $uploadedAt = isset($manifest['uploadedAt']) && is_string($manifest['uploadedAt'])
            ? new \DateTimeImmutable($manifest['uploadedAt'])
            : new \DateTimeImmutable();
        $appliedAt = isset($manifest['appliedAt']) && is_string($manifest['appliedAt']) && '' !== $manifest['appliedAt']
            ? new \DateTimeImmutable($manifest['appliedAt'])
            : null;
        $validationMessages = isset($manifest['validationMessages']) && is_array($manifest['validationMessages'])
            ? array_values(array_filter($manifest['validationMessages'], 'is_string'))
            : [];
        $changeSummary = $this->normalizeChangeSummary($manifest['changeSummary'] ?? null);
        $changedFiles = $this->normalizeChangedFiles($manifest['changedFiles'] ?? null);
        $preflightChecks = $this->normalizePreflightChecks($manifest['preflightChecks'] ?? null);
        $releasePackageType = isset($manifest['releasePackageType']) && \is_string($manifest['releasePackageType'])
            ? $manifest['releasePackageType']
            : 'legacy';
        $releaseNotesMetadata = $this->normalizeReleaseNotesMetadata($manifest, $releasePackageType);

        return [
            'id' => (string) ($manifest['id'] ?? ''),
            'originalFilename' => (string) ($manifest['originalFilename'] ?? 'update.zip'),
            'packageName' => (string) ($manifest['packageName'] ?? 'okänt paket'),
            'packageVersion' => (string) ($manifest['packageVersion'] ?? 'okänd version'),
            'installedVersion' => isset($manifest['installedVersion']) && \is_string($manifest['installedVersion']) ? $manifest['installedVersion'] : '',
            'versionComparison' => $this->normalizeVersionComparison($manifest['versionComparison'] ?? null),
            'uploadedAt' => $uploadedAt,
            'valid' => (bool) ($manifest['valid'] ?? false),
            'validationMessages' => $validationMessages,
            'fileCount' => (int) ($manifest['fileCount'] ?? 0),
            'includesVendor' => (bool) ($manifest['includesVendor'] ?? false),
            'packageChecksumSha256' => isset($manifest['packageChecksumSha256']) && \is_string($manifest['packageChecksumSha256'])
                ? $manifest['packageChecksumSha256']
                : '',
            'releaseMetadataPresent' => (bool) ($manifest['releaseMetadataPresent'] ?? false),
            'releasePackageType' => $releasePackageType,
            'cumulativeUpgrade' => (bool) ($manifest['cumulativeUpgrade'] ?? false),
            'minimumSupportedVersion' => isset($manifest['minimumSupportedVersion']) && \is_string($manifest['minimumSupportedVersion']) && '' !== trim($manifest['minimumSupportedVersion'])
                ? trim($manifest['minimumSupportedVersion'])
                : null,
            'releaseBuiltAt' => isset($manifest['releaseBuiltAt']) && \is_string($manifest['releaseBuiltAt']) && '' !== $manifest['releaseBuiltAt']
                ? $manifest['releaseBuiltAt']
                : null,
            'releaseContentManifestSha256' => isset($manifest['releaseContentManifestSha256']) && \is_string($manifest['releaseContentManifestSha256']) && '' !== $manifest['releaseContentManifestSha256']
                ? $manifest['releaseContentManifestSha256']
                : null,
            'changeSummary' => $changeSummary,
            'changedFiles' => $changedFiles,
            'preflightChecks' => $preflightChecks,
            'releaseNotesPresent' => $releaseNotesMetadata['releaseNotesPresent'],
            'releaseNotesPath' => $releaseNotesMetadata['releaseNotesPath'],
            'releaseNotesMarkdown' => $releaseNotesMetadata['releaseNotesMarkdown'],
            'releaseHighlights' => $releaseNotesMetadata['releaseHighlights'],
            'operationalNotes' => $releaseNotesMetadata['operationalNotes'],
            'postUpdateChecklist' => $releaseNotesMetadata['postUpdateChecklist'],
            'requiresMigrations' => $releaseNotesMetadata['requiresMigrations'],
            'requiresCacheRefresh' => $releaseNotesMetadata['requiresCacheRefresh'],
            'requiresServiceReload' => $releaseNotesMetadata['requiresServiceReload'],
            'appliedAt' => $appliedAt,
            'applicationBackupFilename' => isset($manifest['applicationBackupFilename']) && is_string($manifest['applicationBackupFilename']) && '' !== $manifest['applicationBackupFilename']
                ? $manifest['applicationBackupFilename']
                : null,
        ];
    }

    /**
     * @return array{new: int, modified: int, removed: int, unchanged: int, total: int}
     */
    private function normalizeChangeSummary(mixed $summary): array
    {
        if (!\is_array($summary)) {
            return [
                'new' => 0,
                'modified' => 0,
                'removed' => 0,
                'unchanged' => 0,
                'total' => 0,
            ];
        }

        return [
            'new' => max(0, (int) ($summary['new'] ?? 0)),
            'modified' => max(0, (int) ($summary['modified'] ?? 0)),
            'removed' => max(0, (int) ($summary['removed'] ?? 0)),
            'unchanged' => max(0, (int) ($summary['unchanged'] ?? 0)),
            'total' => max(0, (int) ($summary['total'] ?? 0)),
        ];
    }

    private function normalizeVersionComparison(mixed $comparison): string
    {
        if (!\is_string($comparison) || !\in_array($comparison, self::VERSION_COMPARISONS, true)) {
            return 'unknown';
        }

        return $comparison;
    }

    /**
     * @return array{
     *     releaseNotesPresent: bool,
     *     releaseNotesPath: string,
     *     releaseNotesMarkdown: string,
     *     releaseHighlights: list<array{section: string, text: string}>,
     *     operationalNotes: list<string>,
     *     postUpdateChecklist: list<string>,
     *     requiresMigrations: bool,
     *     requiresCacheRefresh: bool,
     *     requiresServiceReload: bool
     * }
     */
    private function normalizeReleaseNotesMetadata(mixed $metadata, string $packageType = 'legacy'): array
    {
        if (!\is_array($metadata)) {
            return [
                'releaseNotesPresent' => false,
                'releaseNotesPath' => '',
                'releaseNotesMarkdown' => '',
                'releaseHighlights' => [],
                'operationalNotes' => [],
                'postUpdateChecklist' => [],
                'requiresMigrations' => false,
                'requiresCacheRefresh' => 'upgrade' === $packageType,
                'requiresServiceReload' => false,
            ];
        }

        return [
            'releaseNotesPresent' => (bool) ($metadata['releaseNotesPresent'] ?? false),
            'releaseNotesPath' => isset($metadata['releaseNotesPath']) && \is_string($metadata['releaseNotesPath']) ? $metadata['releaseNotesPath'] : '',
            'releaseNotesMarkdown' => isset($metadata['releaseNotesMarkdown']) && \is_string($metadata['releaseNotesMarkdown']) ? $metadata['releaseNotesMarkdown'] : '',
            'releaseHighlights' => $this->normalizeReleaseHighlights($metadata['releaseHighlights'] ?? null),
            'operationalNotes' => $this->normalizeStringList($metadata['operationalNotes'] ?? null),
            'postUpdateChecklist' => $this->normalizeStringList($metadata['postUpdateChecklist'] ?? null),
            'requiresMigrations' => (bool) ($metadata['requiresMigrations'] ?? false),
            'requiresCacheRefresh' => (bool) ($metadata['requiresCacheRefresh'] ?? ('upgrade' === $packageType)),
            'requiresServiceReload' => (bool) ($metadata['requiresServiceReload'] ?? false),
        ];
    }

    /**
     * @return list<array{section: string, text: string}>
     */
    private function normalizeReleaseHighlights(mixed $highlights): array
    {
        if (!\is_array($highlights)) {
            return [];
        }

        $normalized = [];
        foreach ($highlights as $highlight) {
            if (\is_string($highlight) && '' !== trim($highlight)) {
                $normalized[] = [
                    'section' => 'Ändring',
                    'text' => trim($highlight),
                ];

                continue;
            }

            if (!\is_array($highlight)) {
                continue;
            }

            $text = isset($highlight['text']) && \is_string($highlight['text']) ? trim($highlight['text']) : '';
            if ('' === $text) {
                continue;
            }

            $normalized[] = [
                'section' => isset($highlight['section']) && \is_string($highlight['section']) && '' !== trim($highlight['section']) ? trim($highlight['section']) : 'Ändring',
                'text' => $text,
            ];
        }

        return array_slice($normalized, 0, 20);
    }

    /**
     * @return list<string>
     */
    private function normalizeStringList(mixed $items): array
    {
        if (!\is_array($items)) {
            return [];
        }

        $normalized = [];
        foreach ($items as $item) {
            if (!\is_string($item) || '' === trim($item)) {
                continue;
            }

            $normalized[] = trim($item);
        }

        return array_slice($normalized, 0, 20);
    }

    /**
     * @return list<array{path: string, status: string, label: string}>
     */
    private function normalizeChangedFiles(mixed $files): array
    {
        if (!\is_array($files)) {
            return [];
        }

        $normalized = [];
        foreach ($files as $file) {
            if (!\is_array($file)) {
                continue;
            }

            $path = isset($file['path']) && \is_string($file['path']) ? $file['path'] : '';
            if ('' === $path) {
                continue;
            }

            $normalized[] = [
                'path' => $path,
                'status' => isset($file['status']) && \is_string($file['status']) ? $file['status'] : 'modified',
                'label' => isset($file['label']) && \is_string($file['label']) ? $file['label'] : 'Ändrad',
            ];
        }

        return array_slice($normalized, 0, 24);
    }

    /**
     * @return list<array{label: string, state: string, description: string}>
     */
    private function normalizePreflightChecks(mixed $checks): array
    {
        if (!\is_array($checks)) {
            return [];
        }

        $normalized = [];
        foreach ($checks as $check) {
            if (!\is_array($check)) {
                continue;
            }

            $label = isset($check['label']) && \is_string($check['label']) ? $check['label'] : '';
            if ('' === $label) {
                continue;
            }

            $normalized[] = [
                'label' => $label,
                'state' => isset($check['state']) && \is_string($check['state']) ? $check['state'] : 'gray',
                'description' => isset($check['description']) && \is_string($check['description']) ? $check['description'] : '',
            ];
        }

        return $normalized;
    }
}
