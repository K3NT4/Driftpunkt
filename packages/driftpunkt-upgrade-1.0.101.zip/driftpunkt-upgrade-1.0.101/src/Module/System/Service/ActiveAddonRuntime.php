<?php

declare(strict_types=1);

namespace App\Module\System\Service;

final class ActiveAddonRuntime
{
    private static bool $autoloadRegistered = false;

    public static function registerAutoloader(string $projectDir): void
    {
        if (self::$autoloadRegistered) {
            return;
        }

        self::$autoloadRegistered = true;

        spl_autoload_register(static function (string $className) use ($projectDir): void {
            if (!str_starts_with($className, 'App\\')) {
                return;
            }

            $relativeClassPath = str_replace('\\', '/', substr($className, 4)).'.php';
            foreach (self::activeSourceRoots($projectDir) as $sourceRoot) {
                $candidate = $sourceRoot.\DIRECTORY_SEPARATOR.$relativeClassPath;
                if (is_file($candidate)) {
                    require $candidate;

                    return;
                }
            }
        });
    }

    /**
     * @return list<string>
     */
    public static function activeSourceRoots(string $projectDir): array
    {
        return self::existingChildDirectories($projectDir, 'src');
    }

    /**
     * @return list<string>
     */
    public static function activeRouteRoots(string $projectDir): array
    {
        $directories = [];
        foreach (self::activePackageRoots($projectDir) as $packageRoot) {
            $moduleRoot = $packageRoot.\DIRECTORY_SEPARATOR.'src'.\DIRECTORY_SEPARATOR.'Module';
            if (!is_dir($moduleRoot)) {
                continue;
            }

            $iterator = new \RecursiveIteratorIterator(
                new \RecursiveDirectoryIterator($moduleRoot, \FilesystemIterator::SKIP_DOTS),
                \RecursiveIteratorIterator::SELF_FIRST,
            );

            foreach ($iterator as $item) {
                if ($item->isDir() && 'Controller' === $item->getFilename()) {
                    $directories[] = $item->getPathname();
                }
            }
        }

        sort($directories);

        return array_values(array_unique($directories));
    }

    /**
     * @return list<string>
     */
    public static function activeTemplateRoots(string $projectDir): array
    {
        return self::existingChildDirectories($projectDir, 'templates');
    }

    /**
     * @return list<string>
     */
    private static function existingChildDirectories(string $projectDir, string $relativeDirectory): array
    {
        $directories = [];
        foreach (self::activePackageRoots($projectDir) as $packageRoot) {
            $directory = $packageRoot.\DIRECTORY_SEPARATOR.str_replace('/', \DIRECTORY_SEPARATOR, $relativeDirectory);
            if (is_dir($directory)) {
                $directories[] = $directory;
            }
        }

        return $directories;
    }

    /**
     * @return list<string>
     */
    private static function activePackageRoots(string $projectDir): array
    {
        $packagesDirectory = $projectDir.\DIRECTORY_SEPARATOR.'var'.\DIRECTORY_SEPARATOR.'addon_packages';
        $realPackagesDirectory = realpath($packagesDirectory);
        if (false === $realPackagesDirectory || !is_dir($realPackagesDirectory)) {
            return [];
        }

        $packageRoots = [];
        foreach (glob($realPackagesDirectory.\DIRECTORY_SEPARATOR.'*'.\DIRECTORY_SEPARATOR.'active-version.json') ?: [] as $activeVersionPath) {
            $activeVersion = self::readJsonFile($activeVersionPath);
            $version = isset($activeVersion['version']) && is_string($activeVersion['version']) ? trim($activeVersion['version']) : '';
            if ('' === $version || str_contains($version, '/') || str_contains($version, '\\')) {
                continue;
            }

            $slugDirectory = dirname($activeVersionPath);
            $versionDirectory = $slugDirectory.\DIRECTORY_SEPARATOR.$version;
            $manifest = self::readJsonFile($versionDirectory.\DIRECTORY_SEPARATOR.'package-manifest.json');
            if (false === (bool) ($manifest['enabled'] ?? false)) {
                continue;
            }

            $packageRoot = realpath($versionDirectory.\DIRECTORY_SEPARATOR.'package');
            if (false === $packageRoot || !is_dir($packageRoot)) {
                continue;
            }

            if (!str_starts_with($packageRoot.\DIRECTORY_SEPARATOR, $realPackagesDirectory.\DIRECTORY_SEPARATOR)) {
                continue;
            }

            $packageRoots[] = $packageRoot;
        }

        sort($packageRoots);

        return array_values(array_unique($packageRoots));
    }

    /**
     * @return array<string, mixed>
     */
    private static function readJsonFile(string $path): array
    {
        if (!is_file($path)) {
            return [];
        }

        try {
            $data = json_decode((string) file_get_contents($path), true, 512, \JSON_THROW_ON_ERROR);
        } catch (\Throwable) {
            return [];
        }

        return is_array($data) ? $data : [];
    }
}
