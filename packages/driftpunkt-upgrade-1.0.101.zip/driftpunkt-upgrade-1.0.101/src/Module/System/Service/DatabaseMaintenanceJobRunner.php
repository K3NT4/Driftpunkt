<?php

declare(strict_types=1);

namespace App\Module\System\Service;

use Symfony\Component\DependencyInjection\Attribute\Autowire;
use Symfony\Component\HttpFoundation\File\UploadedFile;

final class DatabaseMaintenanceJobRunner
{
    public function __construct(
        #[Autowire('%kernel.project_dir%')]
        private readonly string $projectDir,
        private readonly DatabaseMaintenanceService $databaseMaintenanceService,
        private readonly BackgroundConsoleLauncher $backgroundConsoleLauncher,
    ) {
    }

    /**
     * @return list<array{
     *     id: string,
     *     queuedAt: \DateTimeImmutable,
     *     startedAt: ?\DateTimeImmutable,
     *     finishedAt: ?\DateTimeImmutable,
     *     status: string,
     *     action: string,
     *     label: string,
     *     succeeded: ?bool,
     *     resultSummary: ?string,
     *     output: string
     * }>
     */
    public function listRecentJobs(): array
    {
        $jobs = [];
        foreach (glob($this->jobsDirectory().\DIRECTORY_SEPARATOR.'*.json') ?: [] as $path) {
            try {
                /** @var array<string, mixed> $raw */
                $raw = json_decode((string) file_get_contents($path), true, 512, \JSON_THROW_ON_ERROR);
            } catch (\JsonException) {
                continue;
            }

            $normalized = $this->normalizeJob($raw);
            if (null !== $normalized) {
                $jobs[] = $normalized;
            }
        }

        usort(
            $jobs,
            static fn (array $left, array $right): int => $right['queuedAt']->getTimestamp() <=> $left['queuedAt']->getTimestamp(),
        );

        return array_slice($jobs, 0, 8);
    }

    /**
     * @return array{
     *     id: string,
     *     queuedAt: \DateTimeImmutable,
     *     startedAt: ?\DateTimeImmutable,
     *     finishedAt: ?\DateTimeImmutable,
     *     status: string,
     *     action: string,
     *     label: string,
     *     succeeded: ?bool,
     *     resultSummary: ?string,
     *     output: string
     * }
     */
    public function queueOptimizeJob(string $databasePath): array
    {
        return $this->queueJob([
            'action' => 'optimize',
            'label' => 'Optimera databas',
            'databasePath' => $databasePath,
        ]);
    }

    /**
     * @return array{
     *     id: string,
     *     queuedAt: \DateTimeImmutable,
     *     startedAt: ?\DateTimeImmutable,
     *     finishedAt: ?\DateTimeImmutable,
     *     status: string,
     *     action: string,
     *     label: string,
     *     succeeded: ?bool,
     *     resultSummary: ?string,
     *     output: string
     * }
     */
    public function queueBackupJob(string $databasePath): array
    {
        return $this->queueJob([
            'action' => 'backup',
            'label' => 'Skapa databassäkerhetskopia',
            'databasePath' => $databasePath,
        ]);
    }

    /**
     * @return array{
     *     id: string,
     *     queuedAt: \DateTimeImmutable,
     *     startedAt: ?\DateTimeImmutable,
     *     finishedAt: ?\DateTimeImmutable,
     *     status: string,
     *     action: string,
     *     label: string,
     *     succeeded: ?bool,
     *     resultSummary: ?string,
     *     output: string
     * }
     */
    public function queueRestoreJob(string $databasePath, UploadedFile $uploadedFile): array
    {
        $stagedUpload = $this->databaseMaintenanceService->stageRestoreUpload($uploadedFile);

        return $this->queueJob([
            'action' => 'restore',
            'label' => 'Läs in databassäkerhetskopia',
            'databasePath' => $databasePath,
            'stagedUploadFilename' => $stagedUpload['filename'],
            'stagedUploadOriginalFilename' => $stagedUpload['originalFilename'],
        ]);
    }

    /**
     * @return array{
     *     id: string,
     *     queuedAt: \DateTimeImmutable,
     *     startedAt: ?\DateTimeImmutable,
     *     finishedAt: ?\DateTimeImmutable,
     *     status: string,
     *     action: string,
     *     label: string,
     *     succeeded: ?bool,
     *     resultSummary: ?string,
     *     output: string
     * }
     */
    public function processQueuedJob(string $jobId): array
    {
        $job = $this->readRawJob($jobId);
        if (null === $job) {
            throw new \RuntimeException('Databasjobbet kunde inte hittas.');
        }

        if (\in_array((string) ($job['status'] ?? ''), ['completed', 'failed'], true)) {
            $normalizedJob = $this->normalizeJob($job);
            if (null === $normalizedJob) {
                throw new \RuntimeException('Kunde inte läsa jobbloggen för databashanteringen.');
            }

            return $normalizedJob;
        }

        $job['status'] = 'running';
        $job['startedAt'] = (new \DateTimeImmutable())->format(DATE_ATOM);
        $job['finishedAt'] = null;
        $job['succeeded'] = null;
        $job['resultSummary'] = null;
        $job['output'] = '';
        $this->persistJob($job);

        try {
            $job = $this->executeJob($job);
            $job['status'] = 'completed';
            $job['succeeded'] = true;
        } catch (\Throwable $exception) {
            $job['status'] = 'failed';
            $job['succeeded'] = false;
            $job['output'] = trim((string) ($job['output'] ?? '')."\n".$exception->getMessage());
            $job['resultSummary'] = $exception->getMessage();
        }

        $job['finishedAt'] = (new \DateTimeImmutable())->format(DATE_ATOM);
        $this->persistJob($job);

        $normalizedJob = $this->normalizeJob($job);
        if (null === $normalizedJob) {
            throw new \RuntimeException('Kunde inte läsa jobbloggen för databashanteringen.');
        }

        return $normalizedJob;
    }

    /**
     * @return array{
     *     id: string,
     *     queuedAt: \DateTimeImmutable,
     *     startedAt: ?\DateTimeImmutable,
     *     finishedAt: ?\DateTimeImmutable,
     *     status: string,
     *     action: string,
     *     label: string,
     *     succeeded: ?bool,
     *     resultSummary: ?string,
     *     output: string
     * }
     */
    public function retryJob(string $jobId): array
    {
        $job = $this->readRawJob($jobId);
        if (null === $job) {
            throw new \RuntimeException('Det valda databasjobbet kunde inte hittas.');
        }

        $action = (string) ($job['action'] ?? '');
        $databasePath = (string) ($job['databasePath'] ?? '');
        if ('' === $databasePath) {
            throw new \RuntimeException('Databasstigen saknas för omkörningen.');
        }

        return match ($action) {
            'optimize' => $this->queueOptimizeJob($databasePath),
            'backup' => $this->queueBackupJob($databasePath),
            default => throw new \RuntimeException('Den här databaskörningen kan inte köas om automatiskt.'),
        };
    }

    /**
     * @return array{
     *     id: string,
     *     queuedAt: \DateTimeImmutable,
     *     startedAt: ?\DateTimeImmutable,
     *     finishedAt: ?\DateTimeImmutable,
     *     status: string,
     *     action: string,
     *     label: string,
     *     succeeded: ?bool,
     *     resultSummary: ?string,
     *     output: string
     * }|null
     */
    public function getJobById(string $jobId): ?array
    {
        $job = $this->readRawJob($jobId);
        if (null === $job) {
            return null;
        }

        return $this->normalizeJob($job);
    }

    public function purgeFinishedJobs(): int
    {
        $deleted = 0;

        foreach (glob($this->jobsDirectory().\DIRECTORY_SEPARATOR.'*.json') ?: [] as $path) {
            $rawJob = $this->readRawJob(pathinfo($path, \PATHINFO_FILENAME));
            if (null === $rawJob) {
                continue;
            }

            $status = (string) ($rawJob['status'] ?? '');
            if (!\in_array($status, ['completed', 'failed'], true)) {
                continue;
            }

            if (@unlink($path)) {
                ++$deleted;
            }
        }

        return $deleted;
    }

    public function failStaleQueuedJobs(\DateTimeImmutable $queuedBefore, string $reason): int
    {
        $failed = 0;

        foreach (glob($this->jobsDirectory().\DIRECTORY_SEPARATOR.'*.json') ?: [] as $path) {
            $rawJob = $this->readRawJob(pathinfo($path, \PATHINFO_FILENAME));
            if (null === $rawJob || 'queued' !== (string) ($rawJob['status'] ?? '')) {
                continue;
            }

            try {
                $queuedAt = new \DateTimeImmutable((string) ($rawJob['queuedAt'] ?? ''));
            } catch (\Throwable) {
                continue;
            }

            if ($queuedAt > $queuedBefore) {
                continue;
            }

            $rawJob['status'] = 'failed';
            $rawJob['succeeded'] = false;
            $rawJob['finishedAt'] = (new \DateTimeImmutable())->format(DATE_ATOM);
            $rawJob['resultSummary'] = $reason;
            $existingOutput = trim((string) ($rawJob['output'] ?? ''));
            $rawJob['output'] = '' !== $existingOutput ? $existingOutput."\n".$reason : $reason;
            $this->persistJob($rawJob);
            ++$failed;
        }

        return $failed;
    }

    public function failStaleRunningJobs(\DateTimeImmutable $startedBefore, string $reason): int
    {
        $failed = 0;

        foreach (glob($this->jobsDirectory().\DIRECTORY_SEPARATOR.'*.json') ?: [] as $path) {
            $rawJob = $this->readRawJob(pathinfo($path, \PATHINFO_FILENAME));
            if (null === $rawJob || 'running' !== (string) ($rawJob['status'] ?? '')) {
                continue;
            }

            try {
                $startedAt = new \DateTimeImmutable((string) ($rawJob['startedAt'] ?? ''));
            } catch (\Throwable) {
                continue;
            }

            if ($startedAt > $startedBefore) {
                continue;
            }

            $rawJob['status'] = 'failed';
            $rawJob['succeeded'] = false;
            $rawJob['finishedAt'] = (new \DateTimeImmutable())->format(DATE_ATOM);
            $rawJob['resultSummary'] = $reason;
            $existingOutput = trim((string) ($rawJob['output'] ?? ''));
            $rawJob['output'] = '' !== $existingOutput ? $existingOutput."\n".$reason : $reason;
            $this->persistJob($rawJob);
            ++$failed;
        }

        return $failed;
    }

    public function purgeOldFinishedJobs(\DateTimeImmutable $completedBefore, \DateTimeImmutable $failedBefore): int
    {
        $deleted = 0;

        foreach (glob($this->jobsDirectory().\DIRECTORY_SEPARATOR.'*.json') ?: [] as $path) {
            $rawJob = $this->readRawJob(pathinfo($path, \PATHINFO_FILENAME));
            if (null === $rawJob) {
                continue;
            }

            if (!$this->isOldFinishedRecord($rawJob, $completedBefore, $failedBefore)) {
                continue;
            }

            if (@unlink($path)) {
                ++$deleted;
            }
        }

        return $deleted;
    }

    /**
     * @param array{action: string, label: string, databasePath: string, stagedUploadFilename?: string, stagedUploadOriginalFilename?: string} $payload
     *
     * @return array{
     *     id: string,
     *     queuedAt: \DateTimeImmutable,
     *     startedAt: ?\DateTimeImmutable,
     *     finishedAt: ?\DateTimeImmutable,
     *     status: string,
     *     action: string,
     *     label: string,
     *     succeeded: ?bool,
     *     resultSummary: ?string,
     *     output: string
     * }
     */
    private function queueJob(array $payload): array
    {
        $jobId = sprintf('%s_%s', (new \DateTimeImmutable())->format('Ymd_His'), bin2hex(random_bytes(4)));
        $job = [
            'id' => $jobId,
            'queuedAt' => (new \DateTimeImmutable())->format(DATE_ATOM),
            'startedAt' => null,
            'finishedAt' => null,
            'status' => 'queued',
            'action' => $payload['action'],
            'label' => $payload['label'],
            'databasePath' => $payload['databasePath'],
            'stagedUploadFilename' => $payload['stagedUploadFilename'] ?? null,
            'stagedUploadOriginalFilename' => $payload['stagedUploadOriginalFilename'] ?? null,
            'succeeded' => null,
            'resultSummary' => null,
            'output' => '',
        ];

        $this->persistJob($job);
        $this->backgroundConsoleLauncher->launch(
            [\PHP_BINARY, 'bin/console', 'app:database-maintenance:run', $jobId],
            $this->projectDir,
        );

        $normalizedJob = $this->normalizeJob($job);
        if (null === $normalizedJob) {
            throw new \RuntimeException('Kunde inte läsa tillbaka det köade databasjobbet.');
        }

        return $normalizedJob;
    }

    /**
     * @param array<string, mixed> $job
     * @return array<string, mixed>
     */
    private function executeJob(array $job): array
    {
        $databasePath = (string) ($job['databasePath'] ?? '');
        if ('' === $databasePath) {
            throw new \RuntimeException('Databasstigen saknas för jobbet.');
        }

        $action = (string) ($job['action'] ?? '');

        if ('optimize' === $action) {
            $result = $this->databaseMaintenanceService->optimizeDatabase($databasePath);
            $savedBytes = max(0, $result['beforeSizeBytes'] - $result['afterSizeBytes']);
            $job['resultSummary'] = sprintf(
                'Databasen analyserades/optimerades%s.',
                $savedBytes > 0 ? sprintf('. Frigjort %s', $this->formatBytes($savedBytes)) : '',
            );
            $job['output'] = trim(sprintf(
                "Storlek före: %s\nStorlek efter: %s\nFrigjort: %s",
                $this->formatBytes($result['beforeSizeBytes']),
                $this->formatBytes($result['afterSizeBytes']),
                $this->formatBytes($savedBytes),
            ).("\n".(string) ($result['output'] ?? '')));

            return $job;
        }

        if ('backup' === $action) {
            $backup = $this->databaseMaintenanceService->createBackup($databasePath);
            $job['resultSummary'] = sprintf('Säkerhetskopia skapades: %s.', $backup['filename']);
            $job['output'] = sprintf(
                "Backupfil: %s\nStorlek: %s\nKälla: %s",
                $backup['filename'],
                $this->formatBytes($backup['sizeBytes']),
                $backup['sourceLabel'],
            );

            return $job;
        }

        if ('restore' === $action) {
            $stagedUploadFilename = (string) ($job['stagedUploadFilename'] ?? '');
            $stagedUploadOriginalFilename = (string) ($job['stagedUploadOriginalFilename'] ?? '');
            if ('' === $stagedUploadFilename) {
                throw new \RuntimeException('Restore-jobbet saknar stagead fil.');
            }

            $stagedUploadPath = $this->databaseMaintenanceService->resolveRestoreUploadPath($stagedUploadFilename);
            $uploadedFile = new UploadedFile(
                $stagedUploadPath,
                '' !== $stagedUploadOriginalFilename ? $stagedUploadOriginalFilename : basename($stagedUploadPath),
                null,
                null,
                true,
            );

            $result = $this->databaseMaintenanceService->restoreBackup($databasePath, $uploadedFile);
            $job['resultSummary'] = sprintf(
                'Backupen %s lästes in.',
                $result['restoredFrom'],
            );
            $job['output'] = sprintf(
                "Återläst från: %s\nSäkerhetskopia före återläsning: %s",
                $result['restoredFrom'],
                $result['previousBackup']['filename'],
            );
            @unlink($stagedUploadPath);

            return $job;
        }

        throw new \RuntimeException('Okänd databasåtgärd i jobbkön.');
    }

    private function jobsDirectory(): string
    {
        $directory = $this->projectDir.\DIRECTORY_SEPARATOR.'var'.\DIRECTORY_SEPARATOR.'database_jobs';
        if (!is_dir($directory) && !mkdir($directory, 0775, true) && !is_dir($directory)) {
            throw new \RuntimeException('Kunde inte skapa jobbmappen för databashantering.');
        }

        return $directory;
    }

    /**
     * @param array<string, mixed> $job
     */
    private function persistJob(array $job): void
    {
        file_put_contents(
            $this->jobsDirectory().\DIRECTORY_SEPARATOR.(string) $job['id'].'.json',
            json_encode($job, \JSON_PRETTY_PRINT | \JSON_THROW_ON_ERROR),
        );
    }

    /**
     * @return array<string, mixed>|null
     */
    private function readRawJob(string $jobId): ?array
    {
        $path = $this->jobsDirectory().\DIRECTORY_SEPARATOR.basename($jobId).'.json';
        if (!is_file($path)) {
            return null;
        }

        try {
            /** @var array<string, mixed> $job */
            $job = json_decode((string) file_get_contents($path), true, 512, \JSON_THROW_ON_ERROR);

            return $job;
        } catch (\JsonException) {
            return null;
        }
    }

    /**
     * @param array<string, mixed> $job
     * @return array{
     *     id: string,
     *     queuedAt: \DateTimeImmutable,
     *     startedAt: ?\DateTimeImmutable,
     *     finishedAt: ?\DateTimeImmutable,
     *     status: string,
     *     action: string,
     *     label: string,
     *     succeeded: ?bool,
     *     resultSummary: ?string,
     *     output: string
     * }|null
     */
    private function normalizeJob(array $job): ?array
    {
        if (!isset($job['id'], $job['queuedAt'], $job['status'], $job['action'], $job['label'])) {
            return null;
        }

        return [
            'id' => (string) $job['id'],
            'queuedAt' => new \DateTimeImmutable((string) $job['queuedAt']),
            'startedAt' => isset($job['startedAt']) && \is_string($job['startedAt']) ? new \DateTimeImmutable($job['startedAt']) : null,
            'finishedAt' => isset($job['finishedAt']) && \is_string($job['finishedAt']) ? new \DateTimeImmutable($job['finishedAt']) : null,
            'status' => (string) $job['status'],
            'action' => (string) $job['action'],
            'label' => (string) $job['label'],
            'succeeded' => isset($job['succeeded']) && \is_bool($job['succeeded']) ? $job['succeeded'] : null,
            'resultSummary' => isset($job['resultSummary']) && \is_string($job['resultSummary']) ? $job['resultSummary'] : null,
            'output' => isset($job['output']) && \is_string($job['output']) ? $job['output'] : '',
        ];
    }

    /**
     * @param array<string, mixed> $record
     */
    private function isOldFinishedRecord(array $record, \DateTimeImmutable $completedBefore, \DateTimeImmutable $failedBefore): bool
    {
        $status = (string) ($record['status'] ?? '');
        if (!\in_array($status, ['completed', 'failed'], true)) {
            return false;
        }

        try {
            $finishedAt = new \DateTimeImmutable((string) ($record['finishedAt'] ?? ''));
        } catch (\Throwable) {
            return false;
        }

        return 'completed' === $status
            ? $finishedAt <= $completedBefore
            : $finishedAt <= $failedBefore;
    }

    private function formatBytes(int $bytes): string
    {
        if ($bytes < 1024) {
            return sprintf('%d B', $bytes);
        }

        $units = ['KB', 'MB', 'GB', 'TB'];
        $value = (float) $bytes;
        foreach ($units as $unit) {
            $value /= 1024;
            if ($value < 1024 || 'TB' === $unit) {
                return sprintf($value >= 10 ? '%.0f %s' : '%.1f %s', $value, $unit);
            }
        }

        return sprintf('%d B', $bytes);
    }
}
