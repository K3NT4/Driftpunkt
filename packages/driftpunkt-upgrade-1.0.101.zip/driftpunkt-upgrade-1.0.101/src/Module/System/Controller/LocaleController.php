<?php

declare(strict_types=1);

namespace App\Module\System\Controller;

use App\Module\Identity\Entity\User;
use App\Module\System\Service\LocalePreferenceResolver;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Attribute\Route;

final class LocaleController extends AbstractController
{
    private const SESSION_KEY = 'app.locale';

    #[Route('/sprak/{locale}', name: 'app_locale_switch', methods: ['GET'])]
    public function switch(Request $request, string $locale, EntityManagerInterface $entityManager, LocalePreferenceResolver $localePreferenceResolver): RedirectResponse
    {
        $locale = $localePreferenceResolver->normalizeSelectable($locale);
        $request->getSession()->set(self::SESSION_KEY, $locale);
        $this->storePreferredLocale($locale, $entityManager);

        $returnTo = trim((string) $request->query->get('returnTo'));
        if ('' !== $returnTo && str_starts_with($returnTo, '/')) {
            return $this->redirect($returnTo);
        }

        $referer = trim((string) $request->headers->get('referer'));
        if ('' !== $referer) {
            return $this->redirect($referer);
        }

        return $this->redirectToRoute('app_home');
    }

    private function storePreferredLocale(string $locale, EntityManagerInterface $entityManager): void
    {
        $authenticatedUser = $this->getUser();
        if (!$authenticatedUser instanceof User || null === $authenticatedUser->getId()) {
            return;
        }

        $user = $entityManager->getRepository(User::class)->find($authenticatedUser->getId());
        if (!$user instanceof User) {
            return;
        }

        $authenticatedUser->setPreferredLocale($locale);
        $user->setPreferredLocale($locale);
        $entityManager->flush();
    }
}
