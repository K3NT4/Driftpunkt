<?php

declare(strict_types=1);

namespace App\Module\System\Entity;

use App\Module\Mail\Entity\IncomingMail;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity]
#[ORM\Table(name: 'internal_report_responses')]
#[ORM\Index(columns: ['report_id', 'created_at'], name: 'idx_internal_report_responses_report_created')]
class InternalReportResponse
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\ManyToOne(targetEntity: InternalReport::class, inversedBy: 'responses')]
    #[ORM\JoinColumn(nullable: false, onDelete: 'CASCADE')]
    private InternalReport $report;

    #[ORM\OneToOne(targetEntity: IncomingMail::class)]
    #[ORM\JoinColumn(nullable: false, unique: true, onDelete: 'CASCADE')]
    private IncomingMail $incomingMail;

    #[ORM\Column(length: 180)]
    private string $authorEmail;

    #[ORM\Column(type: 'text')]
    private string $body;

    #[ORM\Column(length: 64)]
    private string $contentHash;

    #[ORM\Column]
    private \DateTimeImmutable $createdAt;

    public function __construct(InternalReport $report, IncomingMail $incomingMail, string $authorEmail, string $body)
    {
        $this->report = $report;
        $this->incomingMail = $incomingMail;
        $this->authorEmail = mb_strtolower(trim($authorEmail));
        $this->body = trim($body);
        $this->contentHash = self::buildContentHash($report, $this->authorEmail, $this->body);
        $this->createdAt = new \DateTimeImmutable();
        $report->addResponse($this);
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getReport(): InternalReport
    {
        return $this->report;
    }

    public function getIncomingMail(): IncomingMail
    {
        return $this->incomingMail;
    }

    public function getAuthorEmail(): string
    {
        return $this->authorEmail;
    }

    public function getBody(): string
    {
        return $this->body;
    }

    public function getContentHash(): string
    {
        return $this->contentHash;
    }

    public static function buildContentHash(InternalReport $report, string $authorEmail, string $body): string
    {
        return hash('sha256', implode("\0", [
            $report->getPublicReference(),
            mb_strtolower(trim($authorEmail)),
            trim($body),
        ]));
    }

    public function getCreatedAt(): \DateTimeImmutable
    {
        return $this->createdAt;
    }
}
