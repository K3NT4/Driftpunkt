<?php

declare(strict_types=1);

namespace App\Module\System\Entity;

use App\Module\Identity\Entity\User;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Uid\Uuid;

#[ORM\Entity]
#[ORM\Table(name: 'internal_reports')]
#[ORM\Index(columns: ['status', 'created_at'], name: 'idx_internal_reports_status_created')]
#[ORM\Index(columns: ['delivery_status', 'notification_next_attempt_at'], name: 'idx_internal_reports_delivery_retry')]
#[ORM\HasLifecycleCallbacks]
class InternalReport
{
    public const TYPE_BUG = 'bug';
    public const TYPE_IMPROVEMENT = 'improvement';
    public const TYPE_MISSING_CUSTOMER = 'missing_customer';

    public const STATUS_OPEN = 'open';
    public const STATUS_IN_PROGRESS = 'in_progress';
    public const STATUS_WAITING_REPORTER = 'waiting_reporter';
    public const STATUS_RESOLVED = 'resolved';

    public const DELIVERY_NOT_REQUIRED = 'not_required';
    public const DELIVERY_PENDING = 'pending';
    public const DELIVERY_SENT = 'sent';
    public const DELIVERY_FAILED = 'failed';

    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\ManyToOne(targetEntity: User::class)]
    #[ORM\JoinColumn(nullable: true, onDelete: 'SET NULL')]
    private ?User $reporter;

    #[ORM\Column(length: 36, unique: true)]
    private string $publicReference;

    #[ORM\Column(length: 180)]
    private string $reporterEmail;

    #[ORM\Column(length: 180)]
    private string $reporterName;

    #[ORM\Column(length: 32)]
    private string $type;

    #[ORM\Column(length: 180)]
    private string $subject;

    #[ORM\Column(type: 'text')]
    private string $description;

    #[ORM\Column(length: 2048)]
    private string $installationUrl;

    #[ORM\Column(length: 2048, nullable: true)]
    private ?string $sourcePageUrl;

    #[ORM\Column(length: 24)]
    private string $deliveryStatus;

    #[ORM\Column(nullable: true)]
    private ?\DateTimeImmutable $notificationSentAt = null;

    #[ORM\Column(length: 255, nullable: true)]
    private ?string $notificationError = null;

    #[ORM\Column(options: ['default' => 0])]
    private int $notificationAttemptCount = 0;

    #[ORM\Column(nullable: true)]
    private ?\DateTimeImmutable $notificationLastAttemptAt = null;

    #[ORM\Column(nullable: true)]
    private ?\DateTimeImmutable $notificationNextAttemptAt = null;

    #[ORM\Column(length: 24)]
    private string $status = self::STATUS_OPEN;

    #[ORM\Column(type: 'text', nullable: true)]
    private ?string $adminNote = null;

    #[ORM\Column]
    private \DateTimeImmutable $createdAt;

    #[ORM\Column]
    private \DateTimeImmutable $updatedAt;

    #[ORM\Column(nullable: true)]
    private ?\DateTimeImmutable $resolvedAt = null;

    #[ORM\Column(length: 180, nullable: true)]
    private ?string $resolvedByEmail = null;

    /** @var Collection<int, InternalReportResponse> */
    #[ORM\OneToMany(mappedBy: 'report', targetEntity: InternalReportResponse::class, cascade: ['persist'], orphanRemoval: true)]
    #[ORM\OrderBy(['createdAt' => 'ASC'])]
    private Collection $responses;

    public function __construct(
        User $reporter,
        string $type,
        string $subject,
        string $description,
        string $installationUrl = '',
        ?string $sourcePageUrl = null,
    )
    {
        if (!\in_array($type, self::types(), true)) {
            throw new \InvalidArgumentException('Okänd intern rapporttyp.');
        }

        $this->reporter = $reporter;
        $this->publicReference = Uuid::v4()->toRfc4122();
        $this->reporterEmail = $reporter->getEmail();
        $this->reporterName = $reporter->getDisplayName();
        $this->type = $type;
        $this->subject = trim($subject);
        $this->description = trim($description);
        $this->installationUrl = rtrim(trim($installationUrl), '/');
        $normalizedSourcePageUrl = null !== $sourcePageUrl ? trim($sourcePageUrl) : null;
        $this->sourcePageUrl = '' !== (string) $normalizedSourcePageUrl ? $normalizedSourcePageUrl : null;
        $this->deliveryStatus = self::requiresCentralNotificationType($type)
            ? self::DELIVERY_PENDING
            : self::DELIVERY_NOT_REQUIRED;
        $this->createdAt = new \DateTimeImmutable();
        $this->updatedAt = $this->createdAt;
        $this->responses = new ArrayCollection();
    }

    /** @return list<string> */
    public static function types(): array
    {
        return [self::TYPE_BUG, self::TYPE_IMPROVEMENT, self::TYPE_MISSING_CUSTOMER];
    }

    /** @return list<string> */
    public static function statuses(): array
    {
        return [self::STATUS_OPEN, self::STATUS_IN_PROGRESS, self::STATUS_WAITING_REPORTER, self::STATUS_RESOLVED];
    }

    public static function requiresCentralNotificationType(string $type): bool
    {
        return \in_array($type, [self::TYPE_BUG, self::TYPE_IMPROVEMENT], true);
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getReporter(): ?User
    {
        return $this->reporter;
    }

    public function getPublicReference(): string
    {
        return $this->publicReference;
    }

    public function getReporterEmail(): string
    {
        return $this->reporterEmail;
    }

    public function getReporterName(): string
    {
        return $this->reporterName;
    }

    public function getType(): string
    {
        return $this->type;
    }

    public function getTypeLabel(): string
    {
        return match ($this->type) {
            self::TYPE_BUG => 'Fel',
            self::TYPE_IMPROVEMENT => 'Förbättring eller önskemål',
            self::TYPE_MISSING_CUSTOMER => 'Saknad kund',
            default => 'Intern rapport',
        };
    }

    public function getSubject(): string
    {
        return $this->subject;
    }

    public function getDescription(): string
    {
        return $this->description;
    }

    public function getInstallationUrl(): string
    {
        return $this->installationUrl;
    }

    public function getSourcePageUrl(): ?string
    {
        return $this->sourcePageUrl;
    }

    public function getDeliveryStatus(): string
    {
        return $this->deliveryStatus;
    }

    public function getNotificationSentAt(): ?\DateTimeImmutable
    {
        return $this->notificationSentAt;
    }

    public function getNotificationError(): ?string
    {
        return $this->notificationError;
    }

    public function getNotificationAttemptCount(): int
    {
        return $this->notificationAttemptCount;
    }

    public function getNotificationLastAttemptAt(): ?\DateTimeImmutable
    {
        return $this->notificationLastAttemptAt;
    }

    public function getNotificationNextAttemptAt(): ?\DateTimeImmutable
    {
        return $this->notificationNextAttemptAt;
    }

    public function markNotificationAttempted(): self
    {
        ++$this->notificationAttemptCount;
        $this->notificationLastAttemptAt = new \DateTimeImmutable();
        $this->notificationNextAttemptAt = null;

        return $this;
    }

    public function markNotificationSent(): self
    {
        $this->deliveryStatus = self::DELIVERY_SENT;
        $this->notificationSentAt = new \DateTimeImmutable();
        $this->notificationError = null;
        $this->notificationNextAttemptAt = null;
        $this->updatedAt = $this->notificationSentAt;

        return $this;
    }

    public function markNotificationFailed(string $message): self
    {
        $normalizedMessage = trim(preg_replace('/\s+/u', ' ', $message) ?? $message);
        $this->deliveryStatus = self::DELIVERY_FAILED;
        $this->notificationSentAt = null;
        $this->notificationError = mb_substr($normalizedMessage, 0, 255);
        $this->updatedAt = new \DateTimeImmutable();
        $retryMinutes = match (true) {
            $this->notificationAttemptCount <= 1 => 5,
            2 === $this->notificationAttemptCount => 30,
            default => 120,
        };
        $this->notificationNextAttemptAt = $this->notificationAttemptCount < 5
            ? $this->updatedAt->modify(sprintf('+%d minutes', $retryMinutes))
            : null;

        return $this;
    }

    public function hasNotificationFailed(): bool
    {
        return self::DELIVERY_FAILED === $this->deliveryStatus;
    }

    /** @return Collection<int, InternalReportResponse> */
    public function getResponses(): Collection
    {
        return $this->responses;
    }

    public function addResponse(InternalReportResponse $response): self
    {
        if (!$this->responses->contains($response)) {
            $this->responses->add($response);
        }

        return $this;
    }

    public function markInProgressFromResponse(): self
    {
        $this->status = self::STATUS_IN_PROGRESS;
        $this->resolvedAt = null;
        $this->resolvedByEmail = null;
        $this->updatedAt = new \DateTimeImmutable();

        return $this;
    }

    public function getStatus(): string
    {
        return $this->status;
    }

    public function getStatusLabel(): string
    {
        return match ($this->status) {
            self::STATUS_OPEN => 'Ny',
            self::STATUS_IN_PROGRESS => 'Pågår',
            self::STATUS_WAITING_REPORTER => 'Väntar på rapportör',
            self::STATUS_RESOLVED => 'Klar',
            default => 'Okänd',
        };
    }

    public function getAdminNote(): ?string
    {
        return $this->adminNote;
    }

    public function getCreatedAt(): \DateTimeImmutable
    {
        return $this->createdAt;
    }

    public function getUpdatedAt(): \DateTimeImmutable
    {
        return $this->updatedAt;
    }

    public function getResolvedAt(): ?\DateTimeImmutable
    {
        return $this->resolvedAt;
    }

    public function getResolvedByEmail(): ?string
    {
        return $this->resolvedByEmail;
    }

    public function updateStatus(string $status, ?string $adminNote, string $actorEmail): self
    {
        if (!\in_array($status, self::statuses(), true)) {
            throw new \InvalidArgumentException('Okänd status för intern rapport.');
        }

        $this->status = $status;
        $normalizedNote = null !== $adminNote ? trim($adminNote) : null;
        $this->adminNote = '' !== (string) $normalizedNote ? $normalizedNote : null;
        $this->updatedAt = new \DateTimeImmutable();

        if (self::STATUS_RESOLVED === $status) {
            $this->resolvedAt = $this->updatedAt;
            $this->resolvedByEmail = mb_strtolower(trim($actorEmail));
        } else {
            $this->resolvedAt = null;
            $this->resolvedByEmail = null;
        }

        return $this;
    }
}
