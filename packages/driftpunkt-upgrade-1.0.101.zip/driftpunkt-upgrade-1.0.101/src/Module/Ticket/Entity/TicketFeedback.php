<?php

declare(strict_types=1);

namespace App\Module\Ticket\Entity;

use App\Module\Identity\Entity\User;
use App\Module\Shared\Entity\TimestampableTrait;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity]
#[ORM\Table(name: 'ticket_feedback')]
#[ORM\UniqueConstraint(name: 'uniq_ticket_feedback_author', columns: ['ticket_id', 'author_id'])]
#[ORM\HasLifecycleCallbacks]
class TicketFeedback
{
    use TimestampableTrait;

    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\ManyToOne(inversedBy: 'feedbackEntries')]
    #[ORM\JoinColumn(nullable: false, onDelete: 'CASCADE')]
    private Ticket $ticket;

    #[ORM\ManyToOne]
    #[ORM\JoinColumn(nullable: false, onDelete: 'CASCADE')]
    private User $author;

    #[ORM\Column]
    private int $rating;

    #[ORM\Column(type: 'text', nullable: true)]
    private ?string $body = null;

    #[ORM\Column(options: ['default' => true])]
    private bool $issueResolved;

    #[ORM\Column(options: ['default' => false])]
    private bool $followUpRequested;

    public function __construct(
        Ticket $ticket,
        User $author,
        int $rating,
        bool $issueResolved,
        bool $followUpRequested,
        ?string $body = null,
    ) {
        $this->ticket = $ticket;
        $this->author = $author;
        $this->setRating($rating);
        $this->issueResolved = $issueResolved;
        $this->followUpRequested = $followUpRequested;
        $this->setBody($body);
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getTicket(): Ticket
    {
        return $this->ticket;
    }

    public function setTicket(Ticket $ticket): self
    {
        $this->ticket = $ticket;

        return $this;
    }

    public function getAuthor(): User
    {
        return $this->author;
    }

    public function getRating(): int
    {
        return $this->rating;
    }

    public function setRating(int $rating): self
    {
        if ($rating < 1 || $rating > 5) {
            throw new \InvalidArgumentException('Feedbackbetyg måste vara mellan 1 och 5.');
        }

        $this->rating = $rating;

        return $this;
    }

    public function getBody(): ?string
    {
        return $this->body;
    }

    public function setBody(?string $body): self
    {
        $normalized = null !== $body ? trim($body) : null;
        $this->body = '' !== (string) $normalized ? mb_substr((string) $normalized, 0, 2000) : null;

        return $this;
    }

    public function isIssueResolved(): bool
    {
        return $this->issueResolved;
    }

    public function setIssueResolved(bool $issueResolved): self
    {
        $this->issueResolved = $issueResolved;

        return $this;
    }

    public function isFollowUpRequested(): bool
    {
        return $this->followUpRequested;
    }

    public function setFollowUpRequested(bool $followUpRequested): self
    {
        $this->followUpRequested = $followUpRequested;

        return $this;
    }

    public function getRatingLabel(): string
    {
        return match ($this->rating) {
            1 => 'Mycket missnöjd',
            2 => 'Missnöjd',
            3 => 'Okej',
            4 => 'Nöjd',
            5 => 'Mycket nöjd',
        };
    }
}
