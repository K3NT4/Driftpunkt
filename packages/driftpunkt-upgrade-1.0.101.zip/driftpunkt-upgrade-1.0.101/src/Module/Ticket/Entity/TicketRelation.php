<?php

declare(strict_types=1);

namespace App\Module\Ticket\Entity;

use App\Module\Identity\Entity\User;
use App\Module\Shared\Entity\TimestampableTrait;
use App\Module\Ticket\Enum\TicketRelationType;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity]
#[ORM\Table(name: 'ticket_relations')]
#[ORM\UniqueConstraint(name: 'uniq_ticket_relation_pair_type', columns: ['source_ticket_id', 'target_ticket_id', 'relation_type'])]
#[ORM\HasLifecycleCallbacks]
class TicketRelation
{
    use TimestampableTrait;

    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\ManyToOne(inversedBy: 'outgoingRelations')]
    #[ORM\JoinColumn(nullable: false, onDelete: 'CASCADE')]
    private Ticket $sourceTicket;

    #[ORM\ManyToOne(inversedBy: 'incomingRelations')]
    #[ORM\JoinColumn(nullable: false, onDelete: 'CASCADE')]
    private Ticket $targetTicket;

    #[ORM\Column(length: 32, enumType: TicketRelationType::class, options: ['default' => 'related'])]
    private TicketRelationType $relationType;

    #[ORM\ManyToOne]
    #[ORM\JoinColumn(onDelete: 'SET NULL', nullable: true)]
    private ?User $createdBy = null;

    public function __construct(
        Ticket $sourceTicket,
        Ticket $targetTicket,
        TicketRelationType $relationType = TicketRelationType::RELATED,
        ?User $createdBy = null,
    ) {
        $this->sourceTicket = $sourceTicket;
        $this->targetTicket = $targetTicket;
        $this->relationType = $relationType;
        $this->createdBy = $createdBy;
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getSourceTicket(): Ticket
    {
        return $this->sourceTicket;
    }

    public function setSourceTicket(Ticket $sourceTicket): self
    {
        $this->sourceTicket = $sourceTicket;

        return $this;
    }

    public function getTargetTicket(): Ticket
    {
        return $this->targetTicket;
    }

    public function setTargetTicket(Ticket $targetTicket): self
    {
        $this->targetTicket = $targetTicket;

        return $this;
    }

    public function getRelationType(): TicketRelationType
    {
        return $this->relationType;
    }

    public function getCreatedBy(): ?User
    {
        return $this->createdBy;
    }
}
