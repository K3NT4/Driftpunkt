<?php

declare(strict_types=1);

namespace App\Module\Ticket\Entity;

use App\Module\Identity\Entity\User;
use App\Module\Shared\Entity\TimestampableTrait;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity]
#[ORM\Table(name: 'ticket_technician_assignments')]
#[ORM\UniqueConstraint(name: 'uniq_ticket_technician_assignment', columns: ['ticket_id', 'technician_id'])]
#[ORM\HasLifecycleCallbacks]
class TicketTechnicianAssignment
{
    use TimestampableTrait;

    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\ManyToOne(inversedBy: 'technicianAssignments')]
    #[ORM\JoinColumn(nullable: false, onDelete: 'CASCADE')]
    private Ticket $ticket;

    #[ORM\ManyToOne]
    #[ORM\JoinColumn(nullable: false, onDelete: 'CASCADE')]
    private User $technician;

    #[ORM\ManyToOne]
    #[ORM\JoinColumn(nullable: true, onDelete: 'SET NULL')]
    private ?User $assignedBy = null;

    public function __construct(Ticket $ticket, User $technician, ?User $assignedBy = null)
    {
        $this->ticket = $ticket;
        $this->technician = $technician;
        $this->assignedBy = $assignedBy;
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getTicket(): Ticket
    {
        return $this->ticket;
    }

    public function setTicket(Ticket $ticket): self
    {
        $this->ticket = $ticket;

        return $this;
    }

    public function getTechnician(): User
    {
        return $this->technician;
    }

    public function getAssignedBy(): ?User
    {
        return $this->assignedBy;
    }
}
