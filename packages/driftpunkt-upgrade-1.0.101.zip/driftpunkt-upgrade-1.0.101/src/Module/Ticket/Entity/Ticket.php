<?php

declare(strict_types=1);

namespace App\Module\Ticket\Entity;

use App\Module\Identity\Entity\Company;
use App\Module\Identity\Entity\TechnicianTeam;
use App\Module\Identity\Entity\User;
use App\Module\Shared\Entity\TimestampableTrait;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use App\Module\Ticket\Enum\TicketImpactLevel;
use App\Module\Ticket\Enum\TicketEscalationLevel;
use App\Module\Ticket\Enum\ImportedTicketPersonRole;
use App\Module\Ticket\Enum\TicketParticipantRole;
use App\Module\Ticket\Enum\TicketPriority;
use App\Module\Ticket\Enum\TicketRequestType;
use App\Module\Ticket\Enum\TicketStatus;
use App\Module\Ticket\Enum\TicketVisibility;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Uid\Uuid;

#[ORM\Entity]
#[ORM\Table(name: 'tickets')]
#[ORM\HasLifecycleCallbacks]
class Ticket
{
    use TimestampableTrait;

    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(type: 'uuid', unique: true)]
    private Uuid $publicId;

    #[ORM\Column(length: 32, unique: true)]
    private string $reference;

    #[ORM\Column(length: 180)]
    private string $subject;

    #[ORM\Column(type: 'text')]
    private string $summary;

    #[ORM\Column(type: 'text', nullable: true)]
    private ?string $resolutionSummary = null;

    #[ORM\Column(length: 255, nullable: true)]
    private ?string $statusReason = null;

    #[ORM\Column(nullable: true)]
    private ?\DateTimeImmutable $followUpAt = null;

    #[ORM\ManyToOne]
    #[ORM\JoinColumn(onDelete: 'SET NULL', nullable: true)]
    private ?TicketCategory $category = null;

    #[ORM\Column(enumType: TicketStatus::class)]
    private TicketStatus $status;

    #[ORM\Column(nullable: true)]
    private ?\DateTimeImmutable $closedAt = null;

    #[ORM\Column(enumType: TicketVisibility::class)]
    private TicketVisibility $visibility;

    #[ORM\Column(enumType: TicketPriority::class)]
    private TicketPriority $priority;

    #[ORM\Column(enumType: TicketRequestType::class, options: ['default' => 'incident'])]
    private TicketRequestType $requestType;

    #[ORM\Column(enumType: TicketImpactLevel::class, options: ['default' => 'single_user'])]
    private TicketImpactLevel $impactLevel;

    #[ORM\Column(enumType: TicketEscalationLevel::class)]
    private TicketEscalationLevel $escalationLevel;

    #[ORM\ManyToOne]
    #[ORM\JoinColumn(onDelete: 'SET NULL', nullable: true)]
    private ?Company $company = null;

    #[ORM\ManyToOne]
    #[ORM\JoinColumn(onDelete: 'SET NULL', nullable: true)]
    private ?User $requester = null;

    #[ORM\ManyToOne]
    #[ORM\JoinColumn(onDelete: 'SET NULL', nullable: true)]
    private ?User $assignee = null;

    #[ORM\ManyToOne]
    #[ORM\JoinColumn(onDelete: 'SET NULL', nullable: true)]
    private ?TechnicianTeam $assignedTeam = null;

    #[ORM\ManyToOne]
    #[ORM\JoinColumn(onDelete: 'SET NULL', nullable: true)]
    private ?SlaPolicy $slaPolicy = null;

    #[ORM\ManyToOne]
    #[ORM\JoinColumn(onDelete: 'SET NULL', nullable: true)]
    private ?TicketIntakeTemplate $intakeTemplate = null;

    /**
     * @var array<string, string>
     */
    #[ORM\Column(type: 'json', options: ['default' => '[]'])]
    private array $intakeAnswers = [];

    /**
     * @var array<string, bool>
     */
    #[ORM\Column(type: 'json', options: ['default' => '[]'])]
    private array $checklistProgress = [];

    /**
     * @var Collection<int, TicketComment>
     */
    #[ORM\OneToMany(mappedBy: 'ticket', targetEntity: TicketComment::class, orphanRemoval: true)]
    #[ORM\OrderBy(['createdAt' => 'ASC'])]
    private Collection $comments;

    /**
     * @var Collection<int, TicketAuditLog>
     */
    #[ORM\OneToMany(mappedBy: 'ticket', targetEntity: TicketAuditLog::class, orphanRemoval: true)]
    #[ORM\OrderBy(['createdAt' => 'DESC'])]
    private Collection $auditLogs;

    /**
     * @var Collection<int, TicketFeedback>
     */
    #[ORM\OneToMany(mappedBy: 'ticket', targetEntity: TicketFeedback::class, orphanRemoval: true, cascade: ['persist'])]
    #[ORM\OrderBy(['createdAt' => 'DESC'])]
    private Collection $feedbackEntries;

    /**
     * @var Collection<int, TicketParticipant>
     */
    #[ORM\OneToMany(mappedBy: 'ticket', targetEntity: TicketParticipant::class, orphanRemoval: true, cascade: ['persist'])]
    #[ORM\OrderBy(['role' => 'ASC', 'email' => 'ASC'])]
    private Collection $participants;

    /**
     * @var Collection<int, TicketTechnicianAssignment>
     */
    #[ORM\OneToMany(mappedBy: 'ticket', targetEntity: TicketTechnicianAssignment::class, orphanRemoval: true, cascade: ['persist'])]
    #[ORM\OrderBy(['createdAt' => 'ASC', 'id' => 'ASC'])]
    private Collection $technicianAssignments;

    /**
     * @var Collection<int, TicketRelation>
     */
    #[ORM\OneToMany(mappedBy: 'sourceTicket', targetEntity: TicketRelation::class, orphanRemoval: true, cascade: ['persist'])]
    #[ORM\OrderBy(['createdAt' => 'DESC'])]
    private Collection $outgoingRelations;

    /**
     * @var Collection<int, TicketRelation>
     */
    #[ORM\OneToMany(mappedBy: 'targetTicket', targetEntity: TicketRelation::class, orphanRemoval: true)]
    #[ORM\OrderBy(['createdAt' => 'DESC'])]
    private Collection $incomingRelations;

    #[ORM\OneToOne(mappedBy: 'sourceTicket', targetEntity: TicketMerge::class, cascade: ['persist', 'remove'], orphanRemoval: true)]
    private ?TicketMerge $merge = null;

    /**
     * @var Collection<int, TicketMerge>
     */
    #[ORM\OneToMany(mappedBy: 'targetTicket', targetEntity: TicketMerge::class)]
    #[ORM\OrderBy(['createdAt' => 'DESC'])]
    private Collection $mergedSources;

    /**
     * @var Collection<int, ImportedTicketPerson>
     */
    #[ORM\OneToMany(mappedBy: 'ticket', targetEntity: ImportedTicketPerson::class, orphanRemoval: true, cascade: ['persist'])]
    #[ORM\OrderBy(['role' => 'ASC', 'id' => 'ASC'])]
    private Collection $importedPeople;

    #[ORM\OneToOne(mappedBy: 'ticket', targetEntity: ExternalTicketImport::class, orphanRemoval: true, cascade: ['persist', 'remove'])]
    private ?ExternalTicketImport $externalImport = null;

    public function __construct(
        string $reference,
        string $subject,
        string $summary,
        TicketStatus $status = TicketStatus::NEW,
        TicketVisibility $visibility = TicketVisibility::PRIVATE,
        TicketPriority $priority = TicketPriority::NORMAL,
        TicketRequestType $requestType = TicketRequestType::INCIDENT,
        TicketImpactLevel $impactLevel = TicketImpactLevel::SINGLE_USER,
        TicketEscalationLevel $escalationLevel = TicketEscalationLevel::NONE,
    ) {
        $this->publicId = Uuid::v7();
        $this->reference = strtoupper(trim($reference));
        $this->subject = trim($subject);
        $this->summary = trim($summary);
        $this->visibility = $visibility;
        $this->priority = $priority;
        $this->requestType = $requestType;
        $this->impactLevel = $impactLevel;
        $this->escalationLevel = $escalationLevel;
        $this->comments = new ArrayCollection();
        $this->auditLogs = new ArrayCollection();
        $this->feedbackEntries = new ArrayCollection();
        $this->participants = new ArrayCollection();
        $this->technicianAssignments = new ArrayCollection();
        $this->outgoingRelations = new ArrayCollection();
        $this->incomingRelations = new ArrayCollection();
        $this->mergedSources = new ArrayCollection();
        $this->importedPeople = new ArrayCollection();
        $this->setStatus($status);
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getPublicId(): Uuid
    {
        return $this->publicId;
    }

    public function getReference(): string
    {
        return $this->reference;
    }

    public function renumber(string $reference): self
    {
        $this->reference = strtoupper(trim($reference));

        return $this;
    }

    public function getSubject(): string
    {
        return $this->subject;
    }

    public function rename(string $subject): self
    {
        $this->subject = trim($subject);

        return $this;
    }

    public function getSummary(): string
    {
        return $this->summary;
    }

    /**
     * @return Collection<int, TicketComment>
     */
    public function getComments(): Collection
    {
        return $this->comments;
    }

    public function setSummary(string $summary): self
    {
        $this->summary = trim($summary);

        return $this;
    }

    public function getResolutionSummary(): ?string
    {
        return $this->resolutionSummary;
    }

    public function setResolutionSummary(?string $resolutionSummary): self
    {
        $normalized = null !== $resolutionSummary ? trim($resolutionSummary) : null;
        $this->resolutionSummary = '' !== (string) $normalized ? $normalized : null;

        return $this;
    }

    public function getStatusReason(): ?string
    {
        return $this->statusReason;
    }

    public function setStatusReason(?string $statusReason): self
    {
        $normalized = null !== $statusReason ? trim($statusReason) : null;
        $this->statusReason = '' !== (string) $normalized ? mb_substr($normalized, 0, 255) : null;

        return $this;
    }

    public function getFollowUpAt(): ?\DateTimeImmutable
    {
        return $this->followUpAt;
    }

    public function setFollowUpAt(?\DateTimeImmutable $followUpAt): self
    {
        $this->followUpAt = $followUpAt;

        return $this;
    }

    public function getCategory(): ?TicketCategory
    {
        return $this->category;
    }

    public function setCategory(?TicketCategory $category): self
    {
        $this->category = $category;

        return $this;
    }

    public function getStatus(): TicketStatus
    {
        return $this->status;
    }

    public function setStatus(TicketStatus $status): self
    {
        $wasClosed = isset($this->status) && TicketStatus::CLOSED === $this->status;
        $this->status = $status;
        if (TicketStatus::CLOSED === $status) {
            if (!$wasClosed) {
                $this->closedAt = new \DateTimeImmutable();
            }
        } else {
            $this->closedAt = null;
        }

        return $this;
    }

    public function getClosedAt(): ?\DateTimeImmutable
    {
        return $this->closedAt;
    }

    public function setClosedAt(?\DateTimeImmutable $closedAt): self
    {
        $this->closedAt = $closedAt;

        return $this;
    }

    public function getVisibility(): TicketVisibility
    {
        return $this->visibility;
    }

    public function setVisibility(TicketVisibility $visibility): self
    {
        $this->visibility = $visibility;

        return $this;
    }

    public function getPriority(): TicketPriority
    {
        return $this->priority;
    }

    public function setPriority(TicketPriority $priority): self
    {
        $this->priority = $priority;

        return $this;
    }

    public function getRequestType(): TicketRequestType
    {
        return $this->requestType;
    }

    public function setRequestType(TicketRequestType $requestType): self
    {
        $this->requestType = $requestType;

        return $this;
    }

    public function getImpactLevel(): TicketImpactLevel
    {
        return $this->impactLevel;
    }

    public function setImpactLevel(TicketImpactLevel $impactLevel): self
    {
        $this->impactLevel = $impactLevel;

        return $this;
    }

    public function getEscalationLevel(): TicketEscalationLevel
    {
        return $this->escalationLevel;
    }

    public function setEscalationLevel(TicketEscalationLevel $escalationLevel): self
    {
        $this->escalationLevel = $escalationLevel;

        return $this;
    }

    public function getCompany(): ?Company
    {
        return $this->company;
    }

    public function setCompany(?Company $company): self
    {
        $this->company = $company;

        return $this;
    }

    /**
     * @return array<string, string>
     */
    public function getIntakeAnswers(): array
    {
        return $this->intakeAnswers;
    }

    public function getIntakeTemplate(): ?TicketIntakeTemplate
    {
        return $this->intakeTemplate;
    }

    public function setIntakeTemplate(?TicketIntakeTemplate $intakeTemplate): self
    {
        $this->intakeTemplate = $intakeTemplate;
        $this->syncChecklistProgress();

        return $this;
    }

    /**
     * @param array<string, string> $intakeAnswers
     */
    public function setIntakeAnswers(array $intakeAnswers): self
    {
        $normalized = [];
        foreach ($intakeAnswers as $key => $value) {
            $normalizedKey = trim((string) $key);
            $normalizedValue = trim((string) $value);
            if ('' !== $normalizedKey && '' !== $normalizedValue) {
                $normalized[$normalizedKey] = $normalizedValue;
            }
        }

        ksort($normalized);
        $this->intakeAnswers = $normalized;

        return $this;
    }

    /**
     * @return array<string, bool>
     */
    public function getChecklistProgress(): array
    {
        $this->syncChecklistProgress();

        return $this->checklistProgress;
    }

    /**
     * @param array<string, bool> $checklistProgress
     */
    public function setChecklistProgress(array $checklistProgress): self
    {
        $normalized = [];
        foreach ($checklistProgress as $item => $completed) {
            $normalizedItem = trim((string) $item);
            if ('' === $normalizedItem) {
                continue;
            }

            $normalized[$normalizedItem] = (bool) $completed;
        }

        $this->checklistProgress = $normalized;
        $this->syncChecklistProgress();

        return $this;
    }

    public function setChecklistItemCompleted(string $item, bool $completed): self
    {
        $normalizedItem = trim($item);
        if ('' === $normalizedItem) {
            return $this;
        }

        $this->syncChecklistProgress();
        if (\array_key_exists($normalizedItem, $this->checklistProgress)) {
            $this->checklistProgress[$normalizedItem] = $completed;
        }

        return $this;
    }

    public function getChecklistCompletionCount(): int
    {
        return \count(array_filter($this->getChecklistProgress()));
    }

    public function getChecklistItemCount(): int
    {
        return \count($this->getChecklistProgress());
    }

    public function getRequester(): ?User
    {
        return $this->requester;
    }

    public function setRequester(?User $requester): self
    {
        $this->requester = $requester;

        return $this;
    }

    public function getAssignee(): ?User
    {
        return $this->assignee;
    }

    public function setAssignee(?User $assignee): self
    {
        $this->assignee = $assignee;

        if ($assignee instanceof User) {
            foreach ($this->technicianAssignments->toArray() as $assignment) {
                if ($this->sameUser($assignee, $assignment->getTechnician())) {
                    $this->technicianAssignments->removeElement($assignment);
                }
            }
        }

        return $this;
    }

    public function getAssignedTeam(): ?TechnicianTeam
    {
        return $this->assignedTeam;
    }

    public function setAssignedTeam(?TechnicianTeam $assignedTeam): self
    {
        $this->assignedTeam = $assignedTeam;

        return $this;
    }

    public function getSlaPolicy(): ?SlaPolicy
    {
        return $this->slaPolicy;
    }

    public function setSlaPolicy(?SlaPolicy $slaPolicy): self
    {
        $this->slaPolicy = $slaPolicy;

        return $this;
    }

    public function getFirstResponseDueAt(): ?\DateTimeImmutable
    {
        if (!$this->slaPolicy instanceof SlaPolicy) {
            return null;
        }

        return $this->createdAt->modify(sprintf('+%d hours', $this->slaPolicy->getFirstResponseHours()));
    }

    public function getResolutionDueAt(): ?\DateTimeImmutable
    {
        if (!$this->slaPolicy instanceof SlaPolicy) {
            return null;
        }

        return $this->createdAt->modify(sprintf('+%d hours', $this->slaPolicy->getResolutionHours()));
    }

    public function hasFirstResponse(): bool
    {
        foreach ($this->comments as $comment) {
            if (
                !$comment->isInternal()
                && [] !== array_intersect($comment->getAuthor()->getRoles(), ['ROLE_TECHNICIAN', 'ROLE_ADMIN', 'ROLE_SUPER_ADMIN'])
            ) {
                return true;
            }
        }

        return false;
    }

    public function isFirstResponseSlaBreached(): bool
    {
        $dueAt = $this->getFirstResponseDueAt();
        if (null === $dueAt || $this->hasFirstResponse() || $this->isFirstResponseSlaPaused()) {
            return false;
        }

        return $dueAt < new \DateTimeImmutable();
    }

    public function isResolutionSlaBreached(): bool
    {
        $dueAt = $this->getResolutionDueAt();
        if (null === $dueAt || $this->isResolutionSlaPaused()) {
            return false;
        }

        return $dueAt < new \DateTimeImmutable();
    }

    public function isSlaPaused(): bool
    {
        return TicketStatus::ON_HOLD === $this->status;
    }

    public function isFirstResponseSlaPaused(): bool
    {
        return $this->status->pausesFirstResponseSla();
    }

    public function isResolutionSlaPaused(): bool
    {
        return $this->status->pausesResolutionSla();
    }

    public function addComment(TicketComment $comment): self
    {
        if (!$this->comments->contains($comment)) {
            $this->comments->add($comment);
            $comment->setTicket($this);
        }

        return $this;
    }

    /**
     * @return Collection<int, TicketAuditLog>
     */
    public function getAuditLogs(): Collection
    {
        return $this->auditLogs;
    }

    public function addAuditLog(TicketAuditLog $auditLog): self
    {
        if (!$this->auditLogs->contains($auditLog)) {
            $this->auditLogs->add($auditLog);
        }

        return $this;
    }

    /**
     * @return Collection<int, TicketFeedback>
     */
    public function getFeedbackEntries(): Collection
    {
        return $this->feedbackEntries;
    }

    public function getLatestFeedback(): ?TicketFeedback
    {
        return $this->feedbackEntries->first() instanceof TicketFeedback ? $this->feedbackEntries->first() : null;
    }

    public function getFeedbackFromAuthor(User $author): ?TicketFeedback
    {
        foreach ($this->feedbackEntries as $feedback) {
            if ($feedback->getAuthor()->getId() === $author->getId()) {
                return $feedback;
            }
        }

        return null;
    }

    public function addFeedback(TicketFeedback $feedback): self
    {
        if (!$this->feedbackEntries->contains($feedback)) {
            $this->feedbackEntries->add($feedback);
            $feedback->setTicket($this);
        }

        return $this;
    }

    /**
     * @return Collection<int, TicketParticipant>
     */
    public function getParticipants(): Collection
    {
        return $this->participants;
    }

    /**
     * @return list<TicketParticipant>
     */
    public function getNotifiableCustomerParticipants(): array
    {
        return array_values(array_filter(
            $this->participants->toArray(),
            static fn (TicketParticipant $participant): bool => TicketParticipantRole::CUSTOMER_CC === $participant->getRole()
                && $participant->shouldNotifyOnCustomerVisibleUpdates(),
        ));
    }

    public function addParticipant(TicketParticipant $participant): self
    {
        if (!$this->participants->contains($participant)) {
            $this->participants->add($participant);
            $participant->setTicket($this);
        }

        return $this;
    }

    public function removeParticipant(TicketParticipant $participant): self
    {
        $this->participants->removeElement($participant);

        return $this;
    }

    /**
     * @return Collection<int, TicketTechnicianAssignment>
     */
    public function getTechnicianAssignments(): Collection
    {
        return $this->technicianAssignments;
    }

    /**
     * @return list<User>
     */
    public function getAdditionalTechnicians(): array
    {
        return array_values(array_map(
            static fn (TicketTechnicianAssignment $assignment): User => $assignment->getTechnician(),
            $this->technicianAssignments->toArray(),
        ));
    }

    public function addTechnicianAssignment(TicketTechnicianAssignment $assignment): self
    {
        if ($this->assignee instanceof User && $this->sameUser($this->assignee, $assignment->getTechnician())) {
            return $this;
        }

        foreach ($this->technicianAssignments as $existingAssignment) {
            if ($this->sameUser($existingAssignment->getTechnician(), $assignment->getTechnician())) {
                return $this;
            }
        }

        if (!$this->technicianAssignments->contains($assignment)) {
            $this->technicianAssignments->add($assignment);
            $assignment->setTicket($this);
        }

        return $this;
    }

    public function removeTechnicianAssignment(TicketTechnicianAssignment $assignment): self
    {
        $this->technicianAssignments->removeElement($assignment);

        return $this;
    }

    public function hasAdditionalTechnician(User $technician): bool
    {
        foreach ($this->technicianAssignments as $assignment) {
            if ($this->sameUser($assignment->getTechnician(), $technician)) {
                return true;
            }
        }

        return false;
    }

    /**
     * @return Collection<int, TicketRelation>
     */
    public function getOutgoingRelations(): Collection
    {
        return $this->outgoingRelations;
    }

    /**
     * @return Collection<int, TicketRelation>
     */
    public function getIncomingRelations(): Collection
    {
        return $this->incomingRelations;
    }

    /**
     * @return list<TicketRelation>
     */
    public function getAllRelations(): array
    {
        $relations = array_merge($this->outgoingRelations->toArray(), $this->incomingRelations->toArray());
        usort(
            $relations,
            static fn (TicketRelation $left, TicketRelation $right): int => $right->getCreatedAt() <=> $left->getCreatedAt(),
        );

        return $relations;
    }

    public function addOutgoingRelation(TicketRelation $relation): self
    {
        if (!$this->outgoingRelations->contains($relation)) {
            $this->outgoingRelations->add($relation);
            $relation->setSourceTicket($this);
        }

        return $this;
    }

    public function getMerge(): ?TicketMerge
    {
        return $this->merge;
    }

    public function setMerge(?TicketMerge $merge): self
    {
        $this->merge = $merge;

        return $this;
    }

    public function isMerged(): bool
    {
        return $this->merge instanceof TicketMerge;
    }

    public function getMergedInto(): ?Ticket
    {
        return $this->merge?->getTargetTicket();
    }

    /**
     * @return Collection<int, TicketMerge>
     */
    public function getMergedSources(): Collection
    {
        return $this->mergedSources;
    }

    public function addMergedSource(TicketMerge $merge): self
    {
        if (!$this->mergedSources->contains($merge)) {
            $this->mergedSources->add($merge);
        }

        return $this;
    }

    /**
     * @return Collection<int, ImportedTicketPerson>
     */
    public function getImportedPeople(): Collection
    {
        return $this->importedPeople;
    }

    public function addImportedPerson(ImportedTicketPerson $person): self
    {
        if (!$this->importedPeople->contains($person)) {
            $this->importedPeople->add($person);
            $person->setTicket($this);
        }

        return $this;
    }

    public function getImportedRequesterPerson(): ?ImportedTicketPerson
    {
        return $this->findImportedPersonByRole(ImportedTicketPersonRole::REQUESTER);
    }

    public function getImportedAssigneePerson(): ?ImportedTicketPerson
    {
        return $this->findImportedPersonByRole(ImportedTicketPersonRole::ASSIGNEE);
    }

    public function getRequesterDisplayName(): string
    {
        return $this->requester?->getDisplayName()
            ?: $this->getImportedRequesterPerson()?->getDisplayName()
            ?: 'Okänd/ej satt';
    }

    public function getAssigneeDisplayName(): string
    {
        return $this->assignee?->getDisplayName()
            ?: $this->getImportedAssigneePerson()?->getDisplayName()
            ?: 'Ej tilldelad';
    }

    public function getExternalImport(): ?ExternalTicketImport
    {
        return $this->externalImport;
    }

    public function setExternalImport(?ExternalTicketImport $externalImport): self
    {
        $this->externalImport = $externalImport;

        return $this;
    }

    private function findImportedPersonByRole(ImportedTicketPersonRole $role): ?ImportedTicketPerson
    {
        foreach ($this->importedPeople as $person) {
            if ($person->getRole() === $role) {
                return $person;
            }
        }

        return null;
    }

    private function sameUser(User $left, User $right): bool
    {
        if ($left === $right) {
            return true;
        }

        return null !== $left->getId() && $left->getId() === $right->getId();
    }

    private function syncChecklistProgress(): void
    {
        $templateItems = $this->intakeTemplate?->getChecklistItems() ?? [];
        if ([] === $templateItems) {
            $this->checklistProgress = [];

            return;
        }

        $normalized = [];
        foreach ($templateItems as $item) {
            $normalizedItem = trim($item);
            if ('' === $normalizedItem) {
                continue;
            }

            $normalized[$normalizedItem] = (bool) ($this->checklistProgress[$normalizedItem] ?? false);
        }

        $this->checklistProgress = $normalized;
    }
}
