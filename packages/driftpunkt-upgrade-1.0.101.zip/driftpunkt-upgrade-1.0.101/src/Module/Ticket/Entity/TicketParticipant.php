<?php

declare(strict_types=1);

namespace App\Module\Ticket\Entity;

use App\Module\Identity\Entity\User;
use App\Module\Shared\Entity\TimestampableTrait;
use App\Module\Ticket\Enum\TicketParticipantRole;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity]
#[ORM\Table(name: 'ticket_participants')]
#[ORM\UniqueConstraint(name: 'uniq_ticket_participant_email_role', columns: ['ticket_id', 'email', 'role'])]
#[ORM\HasLifecycleCallbacks]
class TicketParticipant
{
    use TimestampableTrait;

    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\ManyToOne(inversedBy: 'participants')]
    #[ORM\JoinColumn(nullable: false, onDelete: 'CASCADE')]
    private Ticket $ticket;

    #[ORM\ManyToOne]
    #[ORM\JoinColumn(onDelete: 'SET NULL', nullable: true)]
    private ?User $user = null;

    #[ORM\ManyToOne]
    #[ORM\JoinColumn(onDelete: 'SET NULL', nullable: true)]
    private ?User $createdBy = null;

    #[ORM\Column(length: 180)]
    private string $email;

    #[ORM\Column(length: 180, nullable: true)]
    private ?string $displayName = null;

    #[ORM\Column(length: 32, enumType: TicketParticipantRole::class, options: ['default' => 'customer_cc'])]
    private TicketParticipantRole $role = TicketParticipantRole::CUSTOMER_CC;

    #[ORM\Column(options: ['default' => true])]
    private bool $notifyOnCustomerVisibleUpdates = true;

    public function __construct(
        Ticket $ticket,
        string $email,
        ?string $displayName = null,
        TicketParticipantRole $role = TicketParticipantRole::CUSTOMER_CC,
        ?User $user = null,
        ?User $createdBy = null,
    ) {
        $this->ticket = $ticket;
        $this->email = self::normalizeEmail($email);
        $this->displayName = self::normalizeNullable($displayName);
        $this->role = $role;
        $this->user = $user;
        $this->createdBy = $createdBy;
    }

    public static function normalizeEmail(string $email): string
    {
        return mb_strtolower(trim($email));
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getTicket(): Ticket
    {
        return $this->ticket;
    }

    public function setTicket(Ticket $ticket): self
    {
        $this->ticket = $ticket;

        return $this;
    }

    public function getUser(): ?User
    {
        return $this->user;
    }

    public function setUser(?User $user): self
    {
        $this->user = $user;

        return $this;
    }

    public function getCreatedBy(): ?User
    {
        return $this->createdBy;
    }

    public function getEmail(): string
    {
        return $this->email;
    }

    public function getDisplayName(): ?string
    {
        return $this->displayName;
    }

    public function setDisplayName(?string $displayName): self
    {
        $this->displayName = self::normalizeNullable($displayName);

        return $this;
    }

    public function getLabel(): string
    {
        if (null !== $this->displayName) {
            return sprintf('%s <%s>', $this->displayName, $this->email);
        }

        return $this->email;
    }

    public function getRole(): TicketParticipantRole
    {
        return $this->role;
    }

    public function shouldNotifyOnCustomerVisibleUpdates(): bool
    {
        return $this->notifyOnCustomerVisibleUpdates;
    }

    private static function normalizeNullable(?string $value): ?string
    {
        $normalized = null !== $value ? trim($value) : '';

        return '' !== $normalized ? $normalized : null;
    }
}
