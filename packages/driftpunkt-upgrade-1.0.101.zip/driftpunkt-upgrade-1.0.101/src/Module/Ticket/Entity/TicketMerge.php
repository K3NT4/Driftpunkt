<?php

declare(strict_types=1);

namespace App\Module\Ticket\Entity;

use App\Module\Identity\Entity\User;
use App\Module\Shared\Entity\TimestampableTrait;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity]
#[ORM\Table(name: 'ticket_merges')]
#[ORM\UniqueConstraint(name: 'uniq_ticket_merge_source', columns: ['source_ticket_id'])]
#[ORM\HasLifecycleCallbacks]
class TicketMerge
{
    use TimestampableTrait;

    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\OneToOne(inversedBy: 'merge')]
    #[ORM\JoinColumn(nullable: false, onDelete: 'CASCADE')]
    private Ticket $sourceTicket;

    #[ORM\ManyToOne(inversedBy: 'mergedSources')]
    #[ORM\JoinColumn(nullable: false, onDelete: 'RESTRICT')]
    private Ticket $targetTicket;

    #[ORM\ManyToOne]
    #[ORM\JoinColumn(nullable: true, onDelete: 'SET NULL')]
    private ?User $mergedBy = null;

    public function __construct(Ticket $sourceTicket, Ticket $targetTicket, ?User $mergedBy = null)
    {
        $this->sourceTicket = $sourceTicket;
        $this->targetTicket = $targetTicket;
        $this->mergedBy = $mergedBy;

        $sourceTicket->setMerge($this);
        $targetTicket->addMergedSource($this);
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getSourceTicket(): Ticket
    {
        return $this->sourceTicket;
    }

    public function getTargetTicket(): Ticket
    {
        return $this->targetTicket;
    }

    public function getMergedBy(): ?User
    {
        return $this->mergedBy;
    }
}
