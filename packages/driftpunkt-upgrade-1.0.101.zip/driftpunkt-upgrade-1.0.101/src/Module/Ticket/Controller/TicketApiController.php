<?php

declare(strict_types=1);

namespace App\Module\Ticket\Controller;

use App\Module\Ticket\Entity\Ticket;
use App\Module\Ticket\Enum\TicketStatus;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\DependencyInjection\Attribute\Autowire;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;

final class TicketApiController extends AbstractController
{
    public function __construct(
        private readonly EntityManagerInterface $entityManager,
        #[Autowire('%env(string:DRIFTPUNKT_API_TOKEN)%')]
        private readonly string $apiToken,
    ) {
    }

    #[Route('/api/v1/tickets', name: 'app_api_v1_tickets_index', methods: ['GET'])]
    public function index(Request $request): JsonResponse
    {
        $authResponse = $this->authenticate($request);
        if ($authResponse instanceof JsonResponse) {
            return $authResponse;
        }

        $limit = min(100, max(1, $request->query->getInt('limit', 50)));
        $status = null;
        $statusValue = trim((string) $request->query->get('status', ''));
        if ('' !== $statusValue) {
            $status = TicketStatus::tryFrom($statusValue);
            if (!$status instanceof TicketStatus) {
                return new JsonResponse(['error' => 'Ogiltig status.'], Response::HTTP_BAD_REQUEST);
            }
        }

        $queryBuilder = $this->entityManager
            ->getRepository(Ticket::class)
            ->createQueryBuilder('ticket')
            ->leftJoin('ticket.company', 'company')->addSelect('company')
            ->leftJoin('ticket.requester', 'requester')->addSelect('requester')
            ->leftJoin('ticket.assignee', 'assignee')->addSelect('assignee')
            ->leftJoin('ticket.assignedTeam', 'assignedTeam')->addSelect('assignedTeam')
            ->orderBy('ticket.updatedAt', 'DESC')
            ->addOrderBy('ticket.id', 'DESC')
            ->setMaxResults($limit);

        if ($status instanceof TicketStatus) {
            $queryBuilder
                ->andWhere('ticket.status = :status')
                ->setParameter('status', $status);
        }

        /** @var list<Ticket> $tickets */
        $tickets = $queryBuilder->getQuery()->getResult();

        return new JsonResponse([
            'data' => array_map($this->ticketPayload(...), $tickets),
            'meta' => [
                'count' => \count($tickets),
                'limit' => $limit,
            ],
        ]);
    }

    private function authenticate(Request $request): ?JsonResponse
    {
        if ('' === trim($this->apiToken)) {
            return new JsonResponse(['error' => 'API är inte aktiverat.'], Response::HTTP_NOT_FOUND);
        }

        $authorization = trim((string) $request->headers->get('Authorization'));
        $token = str_starts_with($authorization, 'Bearer ')
            ? trim(mb_substr($authorization, 7))
            : '';

        if (!hash_equals($this->apiToken, $token)) {
            return new JsonResponse(
                ['error' => 'Ogiltig eller saknad API-token.'],
                Response::HTTP_UNAUTHORIZED,
                ['WWW-Authenticate' => 'Bearer'],
            );
        }

        return null;
    }

    /**
     * @return array<string, mixed>
     */
    private function ticketPayload(Ticket $ticket): array
    {
        return [
            'reference' => $ticket->getReference(),
            'subject' => $ticket->getSubject(),
            'status' => $ticket->getStatus()->value,
            'priority' => $ticket->getPriority()->value,
            'requestType' => $ticket->getRequestType()->value,
            'impactLevel' => $ticket->getImpactLevel()->value,
            'visibility' => $ticket->getVisibility()->value,
            'company' => $ticket->getCompany()?->getName(),
            'requester' => $ticket->getRequester()?->getEmail(),
            'assignee' => $ticket->getAssignee()?->getEmail(),
            'assignedTeam' => $ticket->getAssignedTeam()?->getName(),
            'createdAt' => $ticket->getCreatedAt()->format(\DateTimeInterface::ATOM),
            'updatedAt' => $ticket->getUpdatedAt()->format(\DateTimeInterface::ATOM),
        ];
    }
}
