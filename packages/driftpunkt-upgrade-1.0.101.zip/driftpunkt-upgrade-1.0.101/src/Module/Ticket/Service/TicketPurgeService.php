<?php

declare(strict_types=1);

namespace App\Module\Ticket\Service;

use App\Module\Identity\Entity\Company;
use App\Module\Mail\Entity\DraftTicketReview;
use App\Module\Mail\Entity\IncomingMail;
use App\Module\Notification\Entity\NotificationLog;
use App\Module\Telefonstod\Entity\PhoneChangeLogEntry;
use App\Module\Ticket\Entity\Ticket;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\DependencyInjection\Attribute\Autowire;

final class TicketPurgeService
{
    public function __construct(
        private readonly EntityManagerInterface $entityManager,
        #[Autowire('%kernel.project_dir%')]
        private readonly string $projectDir,
    ) {
    }

    /**
     * @return array{
     *     company: Company,
     *     ticketCount: int,
     *     commentCount: int,
     *     attachmentCount: int,
     *     localAttachmentCount: int,
     *     externalAttachmentCount: int,
     *     attachmentBytes: int,
     *     references: list<string>
     * }
     */
    public function previewCompanyTickets(Company $company): array
    {
        $tickets = $this->findCompanyTickets($company);

        return ['company' => $company] + $this->previewTickets($tickets);
    }

    /**
     * @return array{
     *     company: Company,
     *     ticketCount: int,
     *     commentCount: int,
     *     attachmentCount: int,
     *     localAttachmentCount: int,
     *     externalAttachmentCount: int,
     *     attachmentBytes: int,
     *     references: list<string>,
     *     deletedFileCount: int,
     *     failedFileCount: int
     * }
     */
    public function purgeCompanyTickets(Company $company): array
    {
        $preview = $this->previewCompanyTickets($company);
        $tickets = $this->findCompanyTickets($company);
        $purgeResult = $this->purgeTickets($tickets);

        return $preview + [
            'deletedFileCount' => $purgeResult['deletedFileCount'],
            'failedFileCount' => $purgeResult['failedFileCount'],
        ];
    }

    /**
     * @param list<Ticket> $tickets
     * @return array{
     *     ticketCount: int,
     *     commentCount: int,
     *     attachmentCount: int,
     *     localAttachmentCount: int,
     *     externalAttachmentCount: int,
     *     attachmentBytes: int,
     *     references: list<string>,
     *     deletedFileCount: int,
     *     failedFileCount: int
     * }
     */
    public function purgeTickets(array $tickets): array
    {
        $tickets = $this->normalizeTickets($tickets);
        $this->assertMergeDependenciesIncluded($tickets);
        $preview = $this->previewTickets($tickets);
        $filePaths = $this->collectLocalAttachmentPaths($tickets);

        if ([] === $tickets) {
            return $preview + [
                'deletedFileCount' => 0,
                'failedFileCount' => 0,
            ];
        }

        $this->detachExternalReferences($tickets);

        foreach ($tickets as $ticket) {
            $this->entityManager->remove($ticket);
        }

        $this->entityManager->flush();
        $fileResult = $this->deleteFiles($filePaths);

        return $preview + $fileResult;
    }

    /**
     * @param list<Ticket> $tickets
     * @return array{
     *     ticketCount: int,
     *     commentCount: int,
     *     attachmentCount: int,
     *     localAttachmentCount: int,
     *     externalAttachmentCount: int,
     *     attachmentBytes: int,
     *     references: list<string>
     * }
     */
    private function previewTickets(array $tickets): array
    {
        $commentCount = 0;
        $attachmentCount = 0;
        $localAttachmentCount = 0;
        $externalAttachmentCount = 0;
        $attachmentBytes = 0;
        $references = [];

        foreach ($tickets as $ticket) {
            $references[] = $ticket->getReference();

            foreach ($ticket->getComments() as $comment) {
                ++$commentCount;

                foreach ($comment->getAttachments() as $attachment) {
                    ++$attachmentCount;
                    if ($attachment->isExternal()) {
                        ++$externalAttachmentCount;

                        continue;
                    }

                    ++$localAttachmentCount;
                    $attachmentBytes += max(0, (int) ($attachment->getFileSize() ?? 0));
                }
            }
        }

        return [
            'ticketCount' => \count($tickets),
            'commentCount' => $commentCount,
            'attachmentCount' => $attachmentCount,
            'localAttachmentCount' => $localAttachmentCount,
            'externalAttachmentCount' => $externalAttachmentCount,
            'attachmentBytes' => $attachmentBytes,
            'references' => $references,
        ];
    }

    /**
     * @param list<Ticket> $tickets
     * @return list<Ticket>
     */
    private function normalizeTickets(array $tickets): array
    {
        $normalized = [];

        foreach ($tickets as $ticket) {
            $id = $ticket->getId();
            $key = null !== $id ? sprintf('id:%d', $id) : sprintf('object:%d', spl_object_id($ticket));
            $normalized[$key] = $ticket;
        }

        return array_values($normalized);
    }

    /**
     * @param list<Ticket> $tickets
     */
    private function assertMergeDependenciesIncluded(array $tickets): void
    {
        $includedIds = [];
        foreach ($tickets as $ticket) {
            if (null !== $ticket->getId()) {
                $includedIds[$ticket->getId()] = true;
            }
        }

        foreach ($tickets as $ticket) {
            foreach ($ticket->getMergedSources() as $merge) {
                $source = $merge->getSourceTicket();
                if (null === $source->getId() || isset($includedIds[$source->getId()])) {
                    continue;
                }

                throw new \DomainException(sprintf(
                    'Huvudärende %s kan inte raderas utan det sammanslagna källärendet %s.',
                    $ticket->getReference(),
                    $source->getReference(),
                ));
            }
        }
    }

    /**
     * @return list<Ticket>
     */
    private function findCompanyTickets(Company $company): array
    {
        return $this->entityManager
            ->getRepository(Ticket::class)
            ->createQueryBuilder('ticket')
            ->leftJoin('ticket.comments', 'comment')->addSelect('comment')
            ->leftJoin('comment.attachments', 'attachment')->addSelect('attachment')
            ->andWhere('ticket.company = :company')
            ->setParameter('company', $company)
            ->orderBy('ticket.createdAt', 'ASC')
            ->addOrderBy('ticket.id', 'ASC')
            ->getQuery()
            ->getResult();
    }

    /**
     * @param list<Ticket> $tickets
     * @return list<string>
     */
    private function collectLocalAttachmentPaths(array $tickets): array
    {
        $paths = [];

        foreach ($tickets as $ticket) {
            $archivePath = $this->projectDir.\DIRECTORY_SEPARATOR.'var'.\DIRECTORY_SEPARATOR.'ticket_attachment_archives'.\DIRECTORY_SEPARATOR.strtolower($ticket->getReference()).'.zip';
            if (is_file($archivePath)) {
                $paths[$archivePath] = $archivePath;
            }

            foreach ($ticket->getComments() as $comment) {
                foreach ($comment->getAttachments() as $attachment) {
                    if ($attachment->isExternal()) {
                        continue;
                    }

                    $filePath = $attachment->getFilePath();
                    if (null !== $filePath && '' !== trim($filePath)) {
                        $paths[$filePath] = $filePath;
                    }
                }
            }
        }

        return array_values($paths);
    }

    /**
     * @param list<Ticket> $tickets
     */
    private function detachExternalReferences(array $tickets): void
    {
        $ticketIds = array_values(array_filter(array_map(
            static fn (Ticket $ticket): ?int => $ticket->getId(),
            $tickets,
        )));

        if ([] === $ticketIds) {
            return;
        }

        $this->entityManager->createQueryBuilder()
            ->update(NotificationLog::class, 'log')
            ->set('log.ticket', ':null')
            ->where('log.ticket IN (:ticketIds)')
            ->setParameter('null', null)
            ->setParameter('ticketIds', $ticketIds)
            ->getQuery()
            ->execute();

        $this->entityManager->createQueryBuilder()
            ->update(IncomingMail::class, 'mail')
            ->set('mail.matchedTicket', ':null')
            ->where('mail.matchedTicket IN (:ticketIds)')
            ->setParameter('null', null)
            ->setParameter('ticketIds', $ticketIds)
            ->getQuery()
            ->execute();

        $this->entityManager->createQueryBuilder()
            ->update(DraftTicketReview::class, 'review')
            ->set('review.draftTicket', ':null')
            ->where('review.draftTicket IN (:ticketIds)')
            ->setParameter('null', null)
            ->setParameter('ticketIds', $ticketIds)
            ->getQuery()
            ->execute();

        $this->entityManager->createQueryBuilder()
            ->update(DraftTicketReview::class, 'review')
            ->set('review.matchedTicket', ':null')
            ->where('review.matchedTicket IN (:ticketIds)')
            ->setParameter('null', null)
            ->setParameter('ticketIds', $ticketIds)
            ->getQuery()
            ->execute();

        $this->entityManager->createQueryBuilder()
            ->update(PhoneChangeLogEntry::class, 'entry')
            ->set('entry.ticket', ':null')
            ->where('entry.ticket IN (:ticketIds)')
            ->setParameter('null', null)
            ->setParameter('ticketIds', $ticketIds)
            ->getQuery()
            ->execute();
    }

    /**
     * @param list<string> $filePaths
     * @return array{deletedFileCount: int, failedFileCount: int}
     */
    private function deleteFiles(array $filePaths): array
    {
        $deleted = 0;
        $failed = 0;
        $directories = [];

        foreach ($filePaths as $filePath) {
            if (!is_file($filePath)) {
                continue;
            }

            if (@unlink($filePath)) {
                ++$deleted;
                $directories[dirname($filePath)] = dirname($filePath);

                continue;
            }

            ++$failed;
        }

        foreach ($directories as $directory) {
            $this->removeEmptyDirectory($directory);
        }

        return [
            'deletedFileCount' => $deleted,
            'failedFileCount' => $failed,
        ];
    }

    private function removeEmptyDirectory(string $directory): void
    {
        if (!is_dir($directory)) {
            return;
        }

        $items = scandir($directory);
        if (false !== $items && ['.', '..'] === $items) {
            @rmdir($directory);
        }
    }
}
