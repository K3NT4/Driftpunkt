<?php

declare(strict_types=1);

namespace App\Module\Ticket\Service;

use App\Module\Ticket\Entity\TicketCommentAttachment;

final class AttachmentCopyResult
{
    /**
     * @param list<TicketCommentAttachment> $createdAttachments
     * @param list<string> $skippedDuplicateNames
     */
    public function __construct(
        private array $createdAttachments = [],
        private array $skippedDuplicateNames = [],
    ) {
        $this->createdAttachments = array_values($createdAttachments);
        $this->skippedDuplicateNames = array_values(array_filter(
            array_map(static fn (string $name): string => trim($name), $skippedDuplicateNames),
            static fn (string $name): bool => '' !== $name,
        ));
    }

    public static function empty(): self
    {
        return new self();
    }

    public function addCreatedAttachment(TicketCommentAttachment $attachment): void
    {
        $this->createdAttachments[] = $attachment;
    }

    public function addSkippedDuplicate(string $displayName): void
    {
        $trimmed = trim($displayName);
        $this->skippedDuplicateNames[] = '' !== $trimmed ? $trimmed : 'bilaga';
    }

    /**
     * @return list<TicketCommentAttachment>
     */
    public function getCreatedAttachments(): array
    {
        return $this->createdAttachments;
    }

    public function getCreatedAttachmentCount(): int
    {
        return \count($this->createdAttachments);
    }

    public function getSkippedDuplicateCount(): int
    {
        return \count($this->skippedDuplicateNames);
    }

    /**
     * @return list<string>
     */
    public function getSkippedDuplicateNames(): array
    {
        return $this->skippedDuplicateNames;
    }

    public function hasSkippedDuplicates(): bool
    {
        return [] !== $this->skippedDuplicateNames;
    }
}
