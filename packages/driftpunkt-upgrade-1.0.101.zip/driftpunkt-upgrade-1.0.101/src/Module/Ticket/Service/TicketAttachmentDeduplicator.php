<?php

declare(strict_types=1);

namespace App\Module\Ticket\Service;

use App\Module\Ticket\Entity\Ticket;
use App\Module\Ticket\Entity\TicketCommentAttachment;

final class TicketAttachmentDeduplicator
{
    public function __construct(
        private readonly TicketAttachmentArchiver $ticketAttachmentArchiver,
    ) {
    }

    public function contentHashForBinary(string $content): string
    {
        return hash('sha256', $content);
    }

    public function contentHashForFile(string $filePath): ?string
    {
        if ('' === trim($filePath) || !is_file($filePath)) {
            return null;
        }

        $hash = hash_file('sha256', $filePath);

        return \is_string($hash) && $this->isSha256($hash) ? $hash : null;
    }

    public function normalizeContentHash(?string $contentHash): ?string
    {
        $normalized = mb_strtolower(trim((string) $contentHash));

        return $this->isSha256($normalized) ? $normalized : null;
    }

    public function attachmentKey(string $contentHash, int $fileSize): string
    {
        return sprintf('%s:%d', mb_strtolower($contentHash), max(0, $fileSize));
    }

    public function findDuplicateInTicket(Ticket $ticket, string $contentHash, int $fileSize): ?TicketCommentAttachment
    {
        $normalizedHash = $this->normalizeContentHash($contentHash);
        if (null === $normalizedHash || $fileSize < 0) {
            return null;
        }

        foreach ($ticket->getComments() as $comment) {
            foreach ($comment->getAttachments() as $attachment) {
                if ($attachment->isExternal()) {
                    continue;
                }

                $existingSize = $attachment->getFileSize();
                if (null === $existingSize || $existingSize !== $fileSize) {
                    continue;
                }

                $existingHash = $this->hydrateMissingContentHash($attachment);
                if ($normalizedHash === $existingHash) {
                    return $attachment;
                }
            }
        }

        return null;
    }

    public function hydrateMissingContentHash(TicketCommentAttachment $attachment): ?string
    {
        $existingHash = $this->normalizeContentHash($attachment->getContentHash());
        if (null !== $existingHash) {
            return $existingHash;
        }

        $resolvedHash = $this->resolveContentHashForAttachment($attachment);
        if (null !== $resolvedHash) {
            $attachment->setContentHash($resolvedHash);
        }

        return $resolvedHash;
    }

    public function resolveContentHashForAttachment(TicketCommentAttachment $attachment): ?string
    {
        if ($attachment->isExternal()) {
            return null;
        }

        $existingHash = $this->normalizeContentHash($attachment->getContentHash());
        if (null !== $existingHash) {
            return $existingHash;
        }

        if ($attachment->isArchivedInZip()) {
            $content = $this->ticketAttachmentArchiver->readArchivedAttachment($attachment);

            return null !== $content ? $this->contentHashForBinary($content) : null;
        }

        $filePath = $attachment->getFilePath();

        return null !== $filePath ? $this->contentHashForFile($filePath) : null;
    }

    private function isSha256(string $value): bool
    {
        return 1 === preg_match('/^[a-f0-9]{64}$/', $value);
    }
}
