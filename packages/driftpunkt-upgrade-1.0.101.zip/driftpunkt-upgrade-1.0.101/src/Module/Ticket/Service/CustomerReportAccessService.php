<?php

declare(strict_types=1);

namespace App\Module\Ticket\Service;

use App\Module\Identity\Entity\Company;
use App\Module\Identity\Entity\User;
use App\Module\Identity\Enum\UserType;
use App\Module\System\Service\SystemSettings;
use Doctrine\ORM\EntityManagerInterface;

final class CustomerReportAccessService
{
    public function __construct(
        private readonly EntityManagerInterface $entityManager,
        private readonly SystemSettings $systemSettings,
    ) {
    }

    public function canUserAccessReports(?User $user): bool
    {
        if (!$user instanceof User || !$user->isActive()) {
            return false;
        }

        if (!$this->systemSettings->getReportSettings()['customerEnabled']) {
            return false;
        }

        if (UserType::CUSTOMER !== $user->getType()) {
            return false;
        }

        return $this->canCompanyUserAccessReports($user);
    }

    public function canCompanyUserAccessReports(?User $user): bool
    {
        if (!$user instanceof User || !$user->isActive() || UserType::CUSTOMER !== $user->getType()) {
            return false;
        }

        $company = $user->getCompany();
        if (!$company instanceof Company) {
            return false;
        }

        $userId = $user->getId();
        if (null === $userId) {
            return false;
        }

        foreach ($company->getReportAllowedUsers() as $allowedUser) {
            if ($allowedUser->getId() === $userId && $this->isEligibleCustomerUser($company, $allowedUser)) {
                return true;
            }
        }

        return false;
    }

    /**
     * @param list<int> $allowedUserIds
     */
    public function setAccess(Company $company, bool $restricted, array $allowedUserIds): void
    {
        $company
            ->setReportAccessRestricted(true)
            ->clearReportAllowedUsers();

        if ([] !== $allowedUserIds) {
            $users = $this->entityManager->getRepository(User::class)->findBy(['id' => array_values(array_unique($allowedUserIds))]);
            foreach ($users as $user) {
                if ($this->isEligibleCustomerUser($company, $user)) {
                    $company->addReportAllowedUser($user);
                }
            }
        }

        $this->entityManager->flush();
    }

    /**
     * @return array{accessRestricted: bool, allowedUserIds: list<int>, allowedUsers: list<User>}
     */
    public function companySummary(?Company $company): array
    {
        if (!$company instanceof Company) {
            return [
                'accessRestricted' => false,
                'allowedUserIds' => [],
                'allowedUsers' => [],
            ];
        }

        $allowedUsers = $this->sortUsers($company->getReportAllowedUsers()->toArray());

        return [
            'accessRestricted' => true,
            'allowedUserIds' => array_values(array_filter(array_map(static fn (User $user): ?int => $user->getId(), $allowedUsers))),
            'allowedUsers' => $allowedUsers,
        ];
    }

    /**
     * @return list<User>
     */
    public function customerUsers(Company $company): array
    {
        return $this->sortUsers(array_values(array_filter(
            $company->getUsers()->toArray(),
            fn (User $user): bool => $this->isEligibleCustomerUser($company, $user),
        )));
    }

    public function isEligibleCustomerUser(Company $company, User $user): bool
    {
        return $user->isActive()
            && UserType::CUSTOMER === $user->getType()
            && $user->getCompany()?->getId() === $company->getId();
    }

    /**
     * @param list<User> $users
     *
     * @return list<User>
     */
    private function sortUsers(array $users): array
    {
        usort(
            $users,
            static fn (User $left, User $right): int => [$left->getDisplayName(), $left->getEmail()] <=> [$right->getDisplayName(), $right->getEmail()],
        );

        return $users;
    }
}
