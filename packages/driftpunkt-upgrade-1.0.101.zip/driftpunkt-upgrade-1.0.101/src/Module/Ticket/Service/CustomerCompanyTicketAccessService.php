<?php

declare(strict_types=1);

namespace App\Module\Ticket\Service;

use App\Module\Identity\Entity\Company;
use App\Module\Identity\Entity\User;
use App\Module\Identity\Enum\UserType;
use Doctrine\ORM\EntityManagerInterface;

final class CustomerCompanyTicketAccessService
{
    public function __construct(
        private readonly EntityManagerInterface $entityManager,
    ) {
    }

    public function canUserAccessAllCompanyTickets(?User $user): bool
    {
        if (!$user instanceof User || !$user->isActive() || UserType::CUSTOMER !== $user->getType()) {
            return false;
        }

        $company = $user->getCompany();
        if (!$company instanceof Company) {
            return false;
        }

        $userId = $user->getId();
        if (null === $userId) {
            return false;
        }

        foreach ($company->getTicketAllowedUsers() as $allowedUser) {
            if ($allowedUser->getId() === $userId && $this->isEligibleCustomerUser($company, $allowedUser)) {
                return true;
            }
        }

        return false;
    }

    /**
     * @param list<int> $allowedUserIds
     */
    public function setAccess(Company $company, array $allowedUserIds): void
    {
        $company->clearTicketAllowedUsers();

        if ([] !== $allowedUserIds) {
            $users = $this->entityManager->getRepository(User::class)->findBy(['id' => array_values(array_unique($allowedUserIds))]);
            foreach ($users as $user) {
                if ($this->isEligibleCustomerUser($company, $user)) {
                    $company->addTicketAllowedUser($user);
                }
            }
        }

        $this->entityManager->flush();
    }

    /**
     * @return array{allowedUserIds: list<int>, allowedUsers: list<User>}
     */
    public function companySummary(?Company $company): array
    {
        if (!$company instanceof Company) {
            return [
                'allowedUserIds' => [],
                'allowedUsers' => [],
            ];
        }

        $allowedUsers = $this->sortUsers($company->getTicketAllowedUsers()->toArray());

        return [
            'allowedUserIds' => array_values(array_filter(array_map(static fn (User $user): ?int => $user->getId(), $allowedUsers))),
            'allowedUsers' => $allowedUsers,
        ];
    }

    /**
     * @return list<User>
     */
    public function customerUsers(Company $company): array
    {
        return $this->sortUsers(array_values(array_filter(
            $company->getUsers()->toArray(),
            fn (User $user): bool => $this->isEligibleCustomerUser($company, $user),
        )));
    }

    public function isEligibleCustomerUser(Company $company, User $user): bool
    {
        return $user->isActive()
            && UserType::CUSTOMER === $user->getType()
            && $user->getCompany()?->getId() === $company->getId();
    }

    /**
     * @param list<User> $users
     *
     * @return list<User>
     */
    private function sortUsers(array $users): array
    {
        usort(
            $users,
            static fn (User $left, User $right): int => [$left->getDisplayName(), $left->getEmail()] <=> [$right->getDisplayName(), $right->getEmail()],
        );

        return $users;
    }
}
