<?php

declare(strict_types=1);

namespace App\Module\Ticket\Enum;

enum TicketRelationType: string
{
    case RELATED = 'related';
    case DUPLICATE = 'duplicate';
    case BLOCKS = 'blocks';
    case PARENT = 'parent';
    case CHILD = 'child';

    public function label(): string
    {
        return match ($this) {
            self::RELATED => 'Relaterat',
            self::DUPLICATE => 'Dubblett',
            self::BLOCKS => 'Blockerar',
            self::PARENT => 'Huvudärende',
            self::CHILD => 'Delärende',
        };
    }
}
