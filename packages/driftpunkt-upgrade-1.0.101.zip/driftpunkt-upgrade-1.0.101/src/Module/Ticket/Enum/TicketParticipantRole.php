<?php

declare(strict_types=1);

namespace App\Module\Ticket\Enum;

enum TicketParticipantRole: string
{
    case CUSTOMER_CC = 'customer_cc';
    case INTERNAL_WATCHER = 'internal_watcher';

    public function label(): string
    {
        return match ($this) {
            self::CUSTOMER_CC => 'CC/deltagare',
            self::INTERNAL_WATCHER => 'Intern bevakare',
        };
    }
}
