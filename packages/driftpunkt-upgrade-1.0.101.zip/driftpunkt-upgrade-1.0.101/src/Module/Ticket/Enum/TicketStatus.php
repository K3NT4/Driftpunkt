<?php

declare(strict_types=1);

namespace App\Module\Ticket\Enum;

enum TicketStatus: string
{
    case NEW = 'new';
    case OPEN = 'open';
    case IN_PROGRESS = 'in_progress';
    case PENDING_CUSTOMER = 'pending_customer';
    case ON_HOLD = 'on_hold';
    case RESOLVED = 'resolved';
    case CLOSED = 'closed';

    public function label(): string
    {
        return match ($this) {
            self::NEW => 'Ny',
            self::OPEN => 'Öppen',
            self::IN_PROGRESS => 'Under arbete',
            self::PENDING_CUSTOMER => 'Väntar på kund',
            self::ON_HOLD => 'On hold',
            self::RESOLVED => 'Löst',
            self::CLOSED => 'Stängd',
        };
    }

    public function color(): string
    {
        return match ($this) {
            self::NEW => '#0f766e',
            self::OPEN => '#1d4ed8',
            self::IN_PROGRESS => '#7c3aed',
            self::PENDING_CUSTOMER => '#b45309',
            self::ON_HOLD => '#64748b',
            self::RESOLVED => '#166534',
            self::CLOSED => '#6b7280',
        };
    }

    public function pausesFirstResponseSla(): bool
    {
        return self::ON_HOLD === $this;
    }

    public function pausesResolutionSla(): bool
    {
        return \in_array($this, [self::PENDING_CUSTOMER, self::ON_HOLD, self::RESOLVED, self::CLOSED], true);
    }
}
