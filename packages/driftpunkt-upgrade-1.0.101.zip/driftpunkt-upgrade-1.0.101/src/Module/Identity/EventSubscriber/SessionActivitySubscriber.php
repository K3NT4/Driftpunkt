<?php

declare(strict_types=1);

namespace App\Module\Identity\EventSubscriber;

use App\Module\Identity\Entity\User;
use Psr\Log\LoggerInterface;
use Symfony\Component\DependencyInjection\Attribute\Autowire;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpKernel\Event\RequestEvent;
use Symfony\Component\HttpKernel\KernelEvents;
use Symfony\Component\Routing\Generator\UrlGeneratorInterface;
use Symfony\Component\Security\Core\Authentication\Token\Storage\TokenStorageInterface;

final class SessionActivitySubscriber implements EventSubscriberInterface
{
    public const LAST_ACTIVITY_KEY = '_driftpunkt_last_activity_at';

    public function __construct(
        private readonly TokenStorageInterface $tokenStorage,
        private readonly UrlGeneratorInterface $urlGenerator,
        private readonly LoggerInterface $logger,
        #[Autowire('%env(int:DRIFTPUNKT_SESSION_IDLE_TIMEOUT)%')]
        private readonly int $idleTimeoutSeconds,
    ) {
    }

    public static function getSubscribedEvents(): array
    {
        return [
            KernelEvents::REQUEST => ['onKernelRequest', -5],
        ];
    }

    public function onKernelRequest(RequestEvent $event): void
    {
        if (!$event->isMainRequest()) {
            return;
        }

        if ($this->idleTimeoutSeconds <= 0) {
            return;
        }

        $request = $event->getRequest();
        if (!$request->hasSession() || '/logout' === $request->getPathInfo()) {
            return;
        }

        $token = $this->tokenStorage->getToken();
        $user = $token?->getUser();
        if (!$user instanceof User) {
            return;
        }

        $session = $request->getSession();
        $now = time();
        $lastActivity = $session->get(self::LAST_ACTIVITY_KEY);

        if (\is_numeric($lastActivity) && $now - (int) $lastActivity > $this->idleTimeoutSeconds) {
            $this->tokenStorage->setToken(null);
            $session->invalidate();
            $session->getFlashBag()->add('error', 'Du loggades ut automatiskt på grund av inaktivitet.');

            $this->logger->info('Authenticated session expired because of inactivity.', [
                'user_id' => $user->getId(),
                'timeout_seconds' => $this->idleTimeoutSeconds,
            ]);

            $event->setResponse(new RedirectResponse($this->urlGenerator->generate('app_login', [
                'expired' => '1',
            ])));

            return;
        }

        $session->set(self::LAST_ACTIVITY_KEY, $now);
    }
}
