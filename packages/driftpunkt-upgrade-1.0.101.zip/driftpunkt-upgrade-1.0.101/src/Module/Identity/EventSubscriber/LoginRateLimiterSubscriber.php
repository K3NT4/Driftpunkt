<?php

declare(strict_types=1);

namespace App\Module\Identity\EventSubscriber;

use App\Module\System\Service\FormRateLimiter;
use App\Module\System\Service\SystemAuditLogger;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\RequestStack;
use Symfony\Component\Security\Core\Exception\TooManyLoginAttemptsAuthenticationException;
use Symfony\Component\Security\Http\Authenticator\Passport\Badge\UserBadge;
use Symfony\Component\Security\Http\Event\CheckPassportEvent;
use Symfony\Component\Security\Http\Event\LoginFailureEvent;
use Symfony\Component\Security\Http\Event\LoginSuccessEvent;

final class LoginRateLimiterSubscriber implements EventSubscriberInterface
{
    private const LIMIT = 5;
    private const WINDOW_SECONDS = 900;
    private const IP_LIMIT = 30;
    private const HARD_BLOCK_LIMIT = 1;
    private const HARD_BLOCK_SECONDS = 3600;
    private const BLOCK_STRIKE_LIMIT = 3;
    private const BLOCK_STRIKE_WINDOW_SECONDS = 86400;

    public function __construct(
        private readonly FormRateLimiter $formRateLimiter,
        private readonly RequestStack $requestStack,
        private readonly SystemAuditLogger $systemAuditLogger,
    ) {
    }

    public function checkPassport(CheckPassportEvent $event): void
    {
        $request = $this->requestStack->getMainRequest();
        if (!$this->isLoginPost($request)) {
            return;
        }

        $identity = $this->identityFromPassport($event);
        if ($this->formRateLimiter->isBlocked($request, 'login_hard', self::HARD_BLOCK_LIMIT, self::HARD_BLOCK_SECONDS, $identity)) {
            $this->logSecurityEvent('security.login_hard_blocked', 'Hård inloggningsspärr aktiv', $request, $identity);
            throw new TooManyLoginAttemptsAuthenticationException((int) ceil(self::HARD_BLOCK_SECONDS / 60));
        }

        if ($this->formRateLimiter->isBlocked($request, 'login_ip', self::IP_LIMIT, self::WINDOW_SECONDS)) {
            $this->logSecurityEvent('security.login_blocked', 'IP-spärr stoppade inloggning', $request, $identity);
            throw new TooManyLoginAttemptsAuthenticationException((int) ceil(self::WINDOW_SECONDS / 60));
        }

        if (!$this->formRateLimiter->isBlocked($request, 'login', self::LIMIT, self::WINDOW_SECONDS, $identity)) {
            return;
        }

        if (!$this->formRateLimiter->consume($request, 'login_block_strikes', self::BLOCK_STRIKE_LIMIT, self::BLOCK_STRIKE_WINDOW_SECONDS, $identity)) {
            $this->formRateLimiter->forceBlock($request, 'login_hard', self::HARD_BLOCK_LIMIT, self::HARD_BLOCK_SECONDS, $identity);
            $this->logSecurityEvent('security.login_hard_blocked', 'Hård inloggningsspärr aktiverades', $request, $identity);

            throw new TooManyLoginAttemptsAuthenticationException((int) ceil(self::HARD_BLOCK_SECONDS / 60));
        }

        $this->logSecurityEvent('security.login_blocked', 'Inloggningsspärr stoppade försök', $request, $identity);
        throw new TooManyLoginAttemptsAuthenticationException((int) ceil(self::WINDOW_SECONDS / 60));
    }

    public function onFailedLogin(LoginFailureEvent $event): void
    {
        $request = $event->getRequest();
        if (!$this->isLoginPost($request)) {
            return;
        }

        $identity = $this->identityFromFailure($event);
        $this->formRateLimiter->consume($request, 'login', self::LIMIT, self::WINDOW_SECONDS, $identity);
        $this->formRateLimiter->consume($request, 'login_ip', self::IP_LIMIT, self::WINDOW_SECONDS);

        if (!$event->getException() instanceof TooManyLoginAttemptsAuthenticationException) {
            $this->logSecurityEvent('security.login_failed', 'Misslyckad inloggning', $request, $identity);
        }
    }

    public function onSuccessfulLogin(LoginSuccessEvent $event): void
    {
        $request = $event->getRequest();
        if ($this->isLoginPost($request)) {
            $identity = $this->identityFromPassportEvent($event);
            if ($this->formRateLimiter->hasAttempts($request, 'login', self::WINDOW_SECONDS, $identity)) {
                $this->logSecurityEvent('security.login_success_after_failures', 'Lyckad inloggning efter tidigare fel', $request, $identity);
            }

            $this->formRateLimiter->reset($request, 'login', $identity);
        }
    }

    public static function getSubscribedEvents(): array
    {
        return [
            CheckPassportEvent::class => ['checkPassport', 2080],
            LoginFailureEvent::class => 'onFailedLogin',
            LoginSuccessEvent::class => 'onSuccessfulLogin',
        ];
    }

    private function isLoginPost(?Request $request): bool
    {
        return $request instanceof Request && $request->isMethod('POST') && '/login' === $request->getPathInfo();
    }

    private function identityFromPassport(CheckPassportEvent $event): string
    {
        $badge = $event->getPassport()->getBadge(UserBadge::class);

        return $badge instanceof UserBadge ? mb_strtolower(trim($badge->getUserIdentifier())) : '';
    }

    private function identityFromPassportEvent(LoginSuccessEvent $event): string
    {
        $badge = $event->getPassport()->getBadge(UserBadge::class);

        return $badge instanceof UserBadge ? mb_strtolower(trim($badge->getUserIdentifier())) : '';
    }

    private function identityFromFailure(LoginFailureEvent $event): string
    {
        $passport = $event->getPassport();
        $badge = $passport?->getBadge(UserBadge::class);
        if ($badge instanceof UserBadge) {
            return mb_strtolower(trim($badge->getUserIdentifier()));
        }

        $username = $event->getRequest()->request->get('_username');

        return \is_scalar($username) || $username instanceof \Stringable ? mb_strtolower(trim((string) $username)) : '';
    }

    private function logSecurityEvent(string $action, string $title, Request $request, string $identity): void
    {
        try {
            $this->systemAuditLogger->log(null, $action, $title, sprintf(
                'E-post: %s. IP: %s. User-Agent: %s.',
                $this->maskIdentity($identity),
                $request->getClientIp() ?? 'okänd',
                mb_substr((string) $request->headers->get('User-Agent', 'okänd'), 0, 160),
            ));
        } catch (\Throwable) {
        }
    }

    private function maskIdentity(string $identity): string
    {
        $identity = mb_strtolower(trim($identity));
        if ('' === $identity || !str_contains($identity, '@')) {
            return 'okänd';
        }

        [$local, $domain] = explode('@', $identity, 2);
        $first = mb_substr($local, 0, 1);
        $last = mb_strlen($local) > 2 ? mb_substr($local, -1) : '';

        return $first.str_repeat('*', max(2, mb_strlen($local) - 2)).$last.'@'.$domain;
    }
}
