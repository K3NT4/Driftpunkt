<?php

declare(strict_types=1);

namespace App\Module\Identity\Security;

use App\Module\Identity\Entity\User;
use Symfony\Component\Routing\Generator\UrlGeneratorInterface;

final class LoginRoleTargetResolver
{
    public function __construct(
        private readonly UrlGeneratorInterface $urlGenerator,
    ) {
    }

    public function resolveTargetUrl(User $user, ?string $loginRole): ?string
    {
        $loginRole = mb_strtolower(trim((string) $loginRole));

        return match ($loginRole) {
            'admin' => $this->userHasRole($user, 'ROLE_ADMIN')
                ? $this->urlGenerator->generate('app_portal_admin')
                : null,
            'technician' => $this->userHasRole($user, 'ROLE_TECHNICIAN')
                ? $this->urlGenerator->generate('app_portal_technician')
                : null,
            'coordinator', 'koordinator' => $this->userHasRole($user, 'ROLE_TICKET_COORDINATOR')
                ? $this->urlGenerator->generate('app_portal_coordinator')
                : null,
            'customer' => $this->userHasRole($user, 'ROLE_CUSTOMER')
                ? $this->urlGenerator->generate('app_portal_customer')
                : null,
            default => null,
        };
    }

    private function userHasRole(User $user, string $role): bool
    {
        return \in_array($role, $user->getRoles(), true);
    }
}
