<?php

declare(strict_types=1);

namespace App\Module\Identity\Service;

use App\Module\Identity\Entity\User;
use App\Module\Mail\Service\ConfiguredMailer;
use App\Module\System\Service\LocalePreferenceResolver;
use App\Module\System\Service\LocalizedTemplateRenderer;
use App\Twig\AppRuntime;
use Symfony\Component\Mime\Email;

final class PasswordResetMailer
{
    public function __construct(
        private readonly ConfiguredMailer $mailer,
        private readonly LocalizedTemplateRenderer $templateRenderer,
        private readonly LocalePreferenceResolver $localePreferenceResolver,
        private readonly AppRuntime $appRuntime,
    ) {
    }

    public function sendResetLink(User $user, string $resetUrl): void
    {
        // Password resets are security emails and must ignore regular notification preferences.
        $locale = $this->localePreferenceResolver->forUser($user);
        $context = [
            'user' => $user,
            'resetUrl' => $resetUrl,
            'expiresInMinutes' => 60,
        ];

        $this->mailer->send(
            (new Email())
                ->to($user->getEmail())
                ->subject($this->appRuntime->translate('email.password_reset.subject', [], $locale))
                ->text($this->templateRenderer->render('emails/password_reset.txt.twig', $context, $locale))
                ->html($this->templateRenderer->render('emails/password_reset.html.twig', $context, $locale)),
            $user->getCompany(),
            true,
        );
    }
}
