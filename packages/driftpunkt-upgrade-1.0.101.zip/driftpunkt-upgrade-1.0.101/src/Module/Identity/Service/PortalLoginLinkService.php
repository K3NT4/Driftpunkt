<?php

declare(strict_types=1);

namespace App\Module\Identity\Service;

use App\Module\Identity\Entity\PortalLoginLink;
use App\Module\Identity\Entity\User;
use App\Module\Ticket\Entity\Ticket;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\Routing\Generator\UrlGeneratorInterface;

final class PortalLoginLinkService
{
    public const TOKEN_TTL = '+2 hours';

    public function __construct(
        private readonly EntityManagerInterface $entityManager,
        private readonly UrlGeneratorInterface $urlGenerator,
    ) {
    }

    public function createLoginUrl(User $user, Ticket $ticket, string $targetPath, string $requiredRole): ?string
    {
        if (!$user->isActive() || !\in_array($requiredRole, $user->getRoles(), true)) {
            return null;
        }

        $token = bin2hex(random_bytes(32));
        $link = new PortalLoginLink(
            $user,
            $ticket,
            $targetPath,
            $requiredRole,
            $this->hashToken($token),
            new \DateTimeImmutable(self::TOKEN_TTL),
        );

        $this->entityManager->persist($link);
        $this->entityManager->flush();

        return $this->urlGenerator->generate('app_portal_login_link', [
            'token' => $token,
        ], UrlGeneratorInterface::ABSOLUTE_URL);
    }

    public function findByToken(string $token): ?PortalLoginLink
    {
        $token = trim($token);
        if ('' === $token) {
            return null;
        }

        $link = $this->entityManager->getRepository(PortalLoginLink::class)->findOneBy([
            'tokenHash' => $this->hashToken($token),
        ]);

        return $link instanceof PortalLoginLink ? $link : null;
    }

    public function markAsUsed(PortalLoginLink $link): void
    {
        $link->markAsUsed();
        $this->entityManager->flush();
    }

    private function hashToken(string $token): string
    {
        return hash('sha256', $token);
    }
}
