<?php

declare(strict_types=1);

namespace App\Module\Identity\Service;

use App\Module\Identity\Entity\User;
use App\Module\Identity\Enum\UserType;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\PasswordHasher\Hasher\UserPasswordHasherInterface;

final class SystemAccountProvisioner
{
    public const STANDARD_SUPER_ADMIN_EMAIL = 'super@test.local';
    public const STANDARD_SUPER_ADMIN_PASSWORD = 'AdminPassword123';
    public const STANDARD_ADMIN_EMAIL = 'admin@test.local';
    public const STANDARD_ADMIN_PASSWORD = 'AdminPassword123';

    public function __construct(
        private readonly EntityManagerInterface $entityManager,
        private readonly UserPasswordHasherInterface $passwordHasher,
    ) {
    }

    public function ensureRequiredAdminAccounts(): SystemAccountProvisionResult
    {
        $created = [];
        $updated = [];

        $standardSuperAdmin = $this->entityManager->getRepository(User::class)->findOneBy([
            'email' => self::STANDARD_SUPER_ADMIN_EMAIL,
        ]);

        if (!$standardSuperAdmin instanceof User) {
            $standardSuperAdmin = new User(self::STANDARD_SUPER_ADMIN_EMAIL, 'Super', 'Admin', UserType::SUPER_ADMIN);
            $standardSuperAdmin->setPassword($this->passwordHasher->hashPassword($standardSuperAdmin, self::STANDARD_SUPER_ADMIN_PASSWORD));
            $standardSuperAdmin->requirePasswordChange();
            $this->entityManager->persist($standardSuperAdmin);
            $created[] = self::STANDARD_SUPER_ADMIN_EMAIL;
        } elseif (UserType::SUPER_ADMIN !== $standardSuperAdmin->getType()) {
            $standardSuperAdmin->setType(UserType::SUPER_ADMIN);
            $updated[] = self::STANDARD_SUPER_ADMIN_EMAIL;
        }

        $standardSuperAdmin->setFirstName('Super');
        $standardSuperAdmin->setLastName('Admin');
        $standardSuperAdmin->disableMfa();
        $standardSuperAdmin->activate();

        $standardAdmin = $this->entityManager->getRepository(User::class)->findOneBy([
            'email' => self::STANDARD_ADMIN_EMAIL,
        ]);

        if (!$standardAdmin instanceof User) {
            $standardAdmin = new User(self::STANDARD_ADMIN_EMAIL, 'Ada', 'Admin', UserType::ADMIN);
            $standardAdmin->setPassword($this->passwordHasher->hashPassword($standardAdmin, self::STANDARD_ADMIN_PASSWORD));
            $standardAdmin->requirePasswordChange();
            $this->entityManager->persist($standardAdmin);
            $created[] = self::STANDARD_ADMIN_EMAIL;
        } elseif (UserType::ADMIN !== $standardAdmin->getType()) {
            $standardAdmin->setType(UserType::ADMIN);
            $updated[] = self::STANDARD_ADMIN_EMAIL;
        }

        $standardAdmin->setFirstName('Ada');
        $standardAdmin->setLastName('Admin');
        $standardAdmin->activate();

        $this->entityManager->flush();

        return new SystemAccountProvisionResult($created, $updated);
    }

}
