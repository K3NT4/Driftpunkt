<?php

declare(strict_types=1);

namespace App\Module\Identity\Service;

use App\Module\Identity\Entity\User;
use App\Module\Identity\Enum\UserType;
use Symfony\Component\Clock\ClockInterface;
use Symfony\Component\DependencyInjection\Attribute\Autowire;
use Symfony\Component\HttpFoundation\Cookie;
use Symfony\Component\HttpFoundation\Request;

final class MfaTrustedDeviceManager
{
    public const COOKIE_NAME = 'driftpunkt_mfa_trusted_device';
    public const TRUST_DURATION_SECONDS = 604800;

    public function __construct(
        private readonly ClockInterface $clock,
        #[Autowire('%kernel.secret%')]
        private readonly string $appSecret,
    ) {
    }

    public function supports(User $user): bool
    {
        return \in_array($user->getType(), [
            UserType::TECHNICIAN,
            UserType::TICKET_COORDINATOR,
        ], true);
    }

    public function isTrusted(Request $request, User $user): bool
    {
        if (!$this->supports($user) || !$user->isMfaEnabled() || !$user->isMfaSetupCompleted()) {
            return false;
        }

        $token = $request->cookies->get(self::COOKIE_NAME);
        if (!\is_string($token) || '' === $token) {
            return false;
        }

        $parts = explode('.', $token, 2);
        if (2 !== \count($parts)) {
            return false;
        }

        [$encodedPayload, $providedSignature] = $parts;
        $expectedSignature = $this->sign($encodedPayload);
        if (!hash_equals($expectedSignature, $providedSignature)) {
            return false;
        }

        $payloadJson = $this->base64UrlDecode($encodedPayload);
        if (null === $payloadJson) {
            return false;
        }

        try {
            $payload = json_decode($payloadJson, true, 8, \JSON_THROW_ON_ERROR);
        } catch (\JsonException) {
            return false;
        }

        if (!\is_array($payload)) {
            return false;
        }

        $expiresAt = $payload['exp'] ?? null;
        if (!\is_int($expiresAt) || $expiresAt <= $this->clock->now()->getTimestamp()) {
            return false;
        }

        return ($payload['sub'] ?? null) === (string) $user->getPublicId()
            && ($payload['key'] ?? null) === $this->userSecurityFingerprint($user);
    }

    public function createCookie(User $user): Cookie
    {
        if (!$this->supports($user) || !$user->isMfaEnabled() || !$user->isMfaSetupCompleted()) {
            throw new \LogicException('Betrodd MFA-enhet kan bara skapas för tekniker och ärendekoordinatorer med aktiv MFA.');
        }

        $expiresAt = $this->clock->now()->modify(sprintf('+%d seconds', self::TRUST_DURATION_SECONDS));
        $payload = json_encode([
            'sub' => (string) $user->getPublicId(),
            'exp' => $expiresAt->getTimestamp(),
            'key' => $this->userSecurityFingerprint($user),
        ], \JSON_THROW_ON_ERROR);
        $encodedPayload = $this->base64UrlEncode($payload);
        $token = $encodedPayload.'.'.$this->sign($encodedPayload);

        return Cookie::create(
            name: self::COOKIE_NAME,
            value: $token,
            expire: $expiresAt,
            path: '/',
            secure: true,
            httpOnly: true,
            sameSite: Cookie::SAMESITE_STRICT,
        );
    }

    private function userSecurityFingerprint(User $user): string
    {
        return hash_hmac('sha256', implode("\0", [
            (string) $user->getPublicId(),
            $user->getPassword(),
            (string) $user->getMfaSecret(),
            $user->getType()->value,
        ]), $this->appSecret);
    }

    private function sign(string $encodedPayload): string
    {
        return $this->base64UrlEncode(hash_hmac('sha256', $encodedPayload, $this->appSecret, true));
    }

    private function base64UrlEncode(string $value): string
    {
        return rtrim(strtr(base64_encode($value), '+/', '-_'), '=');
    }

    private function base64UrlDecode(string $value): ?string
    {
        if ('' === $value || 1 === \strlen($value) % 4) {
            return null;
        }

        $padding = (4 - \strlen($value) % 4) % 4;
        $decoded = base64_decode(strtr($value, '-_', '+/').str_repeat('=', $padding), true);

        return false === $decoded ? null : $decoded;
    }
}
