<?php

declare(strict_types=1);

namespace App\Module\Identity\Service;

use App\Module\Identity\Entity\Company;
use App\Module\Identity\Entity\TechnicianTeam;
use App\Module\Identity\Entity\User;
use App\Module\Identity\Enum\UserType;
use App\Module\KnowledgeBase\Entity\KnowledgeBaseEntry;
use App\Module\Mail\Entity\CompanyMailOverride;
use App\Module\Mail\Entity\DraftTicketReview;
use App\Module\Mail\Entity\IncomingMail;
use App\Module\Mail\Entity\SupportMailbox;
use App\Module\News\Entity\NewsArticle;
use App\Module\Notification\Entity\NotificationLog;
use App\Module\System\Entity\SystemAuditLog;
use App\Module\System\Service\SystemSettings;
use App\Module\Telefonstod\Entity\PhoneCustomerProfile;
use App\Module\Ticket\Entity\ImportedTicketPerson;
use App\Module\Ticket\Entity\ImportExportRun;
use App\Module\Ticket\Entity\SlaPolicy;
use App\Module\Ticket\Entity\Ticket;
use App\Module\Ticket\Entity\TicketAuditLog;
use App\Module\Ticket\Entity\TicketComment;
use App\Module\Ticket\Entity\TicketFeedback;
use App\Module\Ticket\Entity\TicketImportTemplate;
use App\Module\Ticket\Entity\TicketIntakeTemplate;
use App\Module\Ticket\Entity\TicketParticipant;
use App\Module\Ticket\Entity\TicketRelation;
use App\Module\Ticket\Entity\TicketRoutingRule;
use App\Module\Ticket\Entity\TicketTechnicianAssignment;
use App\Module\Ticket\Enum\TicketVisibility;
use App\Module\Ticket\Service\TicketPurgeService;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\PasswordHasher\Hasher\UserPasswordHasherInterface;

final class IdentityDeletionService
{
    private const TRASH_COMPANY_NAME = 'Slask / Okopplade ärenden';

    public function __construct(
        private readonly EntityManagerInterface $entityManager,
        private readonly UserPasswordHasherInterface $passwordHasher,
        private readonly SystemSettings $systemSettings,
        private readonly TicketPurgeService $ticketPurgeService,
    ) {
    }

    /**
     * @return array<string, int|bool>
     */
    public function previewUserDeletion(User $user): array
    {
        $tickets = $this->countTicketsForUser($user);
        $comments = $this->countByField(TicketComment::class, 'author', $user);
        $feedback = $this->countByField(TicketFeedback::class, 'author', $user);
        $technicianAssignments = $this->countByField(TicketTechnicianAssignment::class, 'technician', $user)
            + $this->countByField(TicketTechnicianAssignment::class, 'assignedBy', $user);
        $participants = $this->countByField(TicketParticipant::class, 'user', $user)
            + $this->countByField(TicketParticipant::class, 'createdBy', $user);
        $auditLogs = $this->countByField(TicketAuditLog::class, 'actor', $user)
            + $this->countByField(SystemAuditLog::class, 'actor', $user);
        $configurationLinks = $this->countByField(SlaPolicy::class, 'defaultAssignee', $user)
            + $this->countByField(TicketRoutingRule::class, 'defaultAssignee', $user)
            + $this->countByField(TicketIntakeTemplate::class, 'defaultAssignee', $user);
        $contentLinks = $this->countByField(NewsArticle::class, 'author', $user)
            + $this->countByField(KnowledgeBaseEntry::class, 'author', $user);
        $mailAndImportLinks = $this->countByField(NotificationLog::class, 'recipient', $user)
            + $this->countByField(IncomingMail::class, 'matchedUser', $user)
            + $this->countByField(DraftTicketReview::class, 'reviewedBy', $user)
            + $this->countByField(ImportExportRun::class, 'actor', $user)
            + $this->countByField(TicketImportTemplate::class, 'createdBy', $user)
            + $this->countByField(ImportedTicketPerson::class, 'linkedUser', $user)
            + $this->countByField(TicketRelation::class, 'createdBy', $user);

        $historyCount = $tickets + $comments + $feedback + $technicianAssignments + $participants + $auditLogs + $configurationLinks + $contentLinks + $mailAndImportLinks;

        return [
            'ticketCount' => $tickets,
            'commentCount' => $comments,
            'feedbackCount' => $feedback,
            'technicianAssignmentCount' => $technicianAssignments,
            'participantCount' => $participants,
            'auditLogCount' => $auditLogs,
            'configurationLinkCount' => $configurationLinks,
            'contentLinkCount' => $contentLinks,
            'mailAndImportLinkCount' => $mailAndImportLinks,
            'historyCount' => $historyCount,
            'hasHistory' => $historyCount > 0,
            'canHardDelete' => 0 === $historyCount,
        ];
    }

    /**
     * @return array{
     *     action: 'hard_deleted'|'archived',
     *     preview: array<string, int|bool>,
     *     finalPreview: array<string, int|bool>,
     *     ticketAction: string,
     *     movedTicketCount: int,
     *     purgedTicketCount: int,
     *     trashCompany: ?Company
     * }
     */
    public function deleteOrArchiveUser(User $user, string $ticketAction = 'move_to_trash'): array
    {
        $preview = $this->previewUserDeletion($user);
        $finalPreview = $preview;
        $movedTicketCount = 0;
        $purgedTicketCount = 0;
        $trashCompany = null;

        if (($preview['ticketCount'] ?? 0) > 0 && 'delete_tickets' === $ticketAction) {
            $purgeResult = $this->ticketPurgeService->purgeTickets($this->findTicketsForUser($user));
            $purgedTicketCount = (int) $purgeResult['ticketCount'];
            $finalPreview = $this->previewUserDeletion($user);
        } elseif (($preview['ticketCount'] ?? 0) > 0) {
            $trashCompany = $this->ensureTrashCompany();
            foreach ($this->findTicketsForUser($user) as $ticket) {
                $ticket
                    ->setCompany($trashCompany)
                    ->setVisibility(TicketVisibility::INTERNAL_ONLY);

                if ($ticket->getAssignee()?->getId() === $user->getId()) {
                    $ticket->setAssignee(null);
                }

                ++$movedTicketCount;
            }
        }

        if (true === $finalPreview['canHardDelete']) {
            $this->entityManager->remove($user);
            $this->entityManager->flush();

            return [
                'action' => 'hard_deleted',
                'preview' => $preview,
                'finalPreview' => $finalPreview,
                'ticketAction' => $ticketAction,
                'movedTicketCount' => $movedTicketCount,
                'purgedTicketCount' => $purgedTicketCount,
                'trashCompany' => $trashCompany,
            ];
        }

        $userId = $user->getId() ?? 0;
        $anonymousSuffix = bin2hex(random_bytes(4));
        $user
            ->setEmail(sprintf('deleted-user-%d-%s@deleted.local', $userId, $anonymousSuffix))
            ->setFirstName('Borttagen')
            ->setLastName('Användare')
            ->setType(UserType::PRIVATE_CUSTOMER)
            ->setRoles([])
            ->setCompany(null)
            ->setTechnicianTeam(null)
            ->setTechnicianTeams([])
            ->disableMfa()
            ->clearMfaSecret()
            ->disableEmailNotifications()
            ->deactivate();
        $user->setPassword($this->passwordHasher->hashPassword($user, bin2hex(random_bytes(24))));

        $this->entityManager->flush();

        return [
            'action' => 'archived',
            'preview' => $preview,
            'finalPreview' => $finalPreview,
            'ticketAction' => $ticketAction,
            'movedTicketCount' => $movedTicketCount,
            'purgedTicketCount' => $purgedTicketCount,
            'trashCompany' => $trashCompany,
        ];
    }

    public function activeSuperAdminCount(?User $exceptUser = null): int
    {
        $queryBuilder = $this->entityManager->getRepository(User::class)->createQueryBuilder('user')
            ->select('COUNT(user.id)')
            ->andWhere('user.type = :type')
            ->andWhere('user.isActive = true')
            ->setParameter('type', UserType::SUPER_ADMIN);

        if ($exceptUser instanceof User && null !== $exceptUser->getId()) {
            $queryBuilder
                ->andWhere('user.id != :exceptUserId')
                ->setParameter('exceptUserId', $exceptUser->getId());
        }

        return (int) $queryBuilder->getQuery()->getSingleScalarResult();
    }

    /**
     * @return array<string, int|bool>
     */
    public function previewTeamDeletion(TechnicianTeam $team): array
    {
        $memberCount = $this->countTechnicianTeamMembers($team);
        $ticketCount = $this->countByField(Ticket::class, 'assignedTeam', $team);
        $slaPolicyCount = $this->countByField(SlaPolicy::class, 'defaultTeam', $team);
        $intakeTemplateCount = $this->countByField(TicketIntakeTemplate::class, 'defaultTeam', $team);
        $mailboxCount = $this->countByField(SupportMailbox::class, 'defaultTeam', $team);
        $routingRuleCount = $this->countByField(TicketRoutingRule::class, 'team', $team);
        $linkCount = $memberCount + $ticketCount + $slaPolicyCount + $intakeTemplateCount + $mailboxCount + $routingRuleCount;

        return [
            'memberCount' => $memberCount,
            'ticketCount' => $ticketCount,
            'slaPolicyCount' => $slaPolicyCount,
            'intakeTemplateCount' => $intakeTemplateCount,
            'mailboxCount' => $mailboxCount,
            'routingRuleCount' => $routingRuleCount,
            'linkCount' => $linkCount,
            'hasLinks' => $linkCount > 0,
        ];
    }

    /**
     * @return array{
     *     preview: array<string, int|bool>,
     *     ticketAction: string,
     *     movedTicketCount: int,
     *     purgedTicketCount: int,
     *     trashCompany: ?Company
     * }
     */
    public function deleteTeam(TechnicianTeam $team, string $ticketAction = 'move_to_trash'): array
    {
        $preview = $this->previewTeamDeletion($team);
        $movedTicketCount = 0;
        $purgedTicketCount = 0;
        $trashCompany = null;

        if (($preview['ticketCount'] ?? 0) > 0 && 'delete_tickets' === $ticketAction) {
            $purgeResult = $this->ticketPurgeService->purgeTickets($this->findTicketsForTeam($team));
            $purgedTicketCount = (int) $purgeResult['ticketCount'];
        } elseif (($preview['ticketCount'] ?? 0) > 0) {
            $trashCompany = $this->ensureTrashCompany();
            foreach ($this->findTicketsForTeam($team) as $ticket) {
                $ticket
                    ->setCompany($trashCompany)
                    ->setVisibility(TicketVisibility::INTERNAL_ONLY)
                    ->setAssignedTeam(null);
                ++$movedTicketCount;
            }
        }

        foreach ($team->getMembers()->toArray() as $user) {
            \assert($user instanceof User);
            $user->removeTechnicianTeam($team);
        }

        foreach ($this->entityManager->getRepository(User::class)->findBy(['technicianTeam' => $team]) as $user) {
            \assert($user instanceof User);
            $user
                ->setTechnicianTeam(null)
                ->removeTechnicianTeam($team);
        }

        foreach ($this->entityManager->getRepository(Ticket::class)->findBy(['assignedTeam' => $team]) as $ticket) {
            \assert($ticket instanceof Ticket);
            $ticket->setAssignedTeam(null);
        }

        foreach ($this->entityManager->getRepository(SlaPolicy::class)->findBy(['defaultTeam' => $team]) as $slaPolicy) {
            \assert($slaPolicy instanceof SlaPolicy);
            $slaPolicy->setDefaultTeam(null)->setDefaultTeamEnabled(false);
        }

        foreach ($this->entityManager->getRepository(TicketIntakeTemplate::class)->findBy(['defaultTeam' => $team]) as $template) {
            \assert($template instanceof TicketIntakeTemplate);
            $template->setDefaultTeam(null);
        }

        foreach ($this->entityManager->getRepository(SupportMailbox::class)->findBy(['defaultTeam' => $team]) as $mailbox) {
            \assert($mailbox instanceof SupportMailbox);
            $mailbox->setDefaultTeam(null);
        }

        foreach ($this->entityManager->getRepository(TicketRoutingRule::class)->findBy(['team' => $team]) as $routingRule) {
            \assert($routingRule instanceof TicketRoutingRule);
            $this->entityManager->remove($routingRule);
        }

        $this->entityManager->remove($team);
        $this->entityManager->flush();

        return [
            'preview' => $preview,
            'ticketAction' => $ticketAction,
            'movedTicketCount' => $movedTicketCount,
            'purgedTicketCount' => $purgedTicketCount,
            'trashCompany' => $trashCompany,
        ];
    }

    /**
     * @return array<string, int|bool>
     */
    public function previewCompanyDeletion(Company $company): array
    {
        $userCount = $this->countByField(User::class, 'company', $company);
        $childCompanyCount = $this->countByField(Company::class, 'parentCompany', $company);
        $ticketCount = $this->countByField(Ticket::class, 'company', $company);
        $mailboxCount = $this->countByField(SupportMailbox::class, 'company', $company);
        $mailOverrideCount = $this->countByField(CompanyMailOverride::class, 'company', $company);
        $incomingMailCount = $this->countByField(IncomingMail::class, 'matchedCompany', $company);
        $draftReviewCount = $this->countByField(DraftTicketReview::class, 'matchedCompany', $company);
        $phoneProfileCount = $this->countByField(PhoneCustomerProfile::class, 'company', $company);
        $linkCount = $userCount + $childCompanyCount + $ticketCount + $mailboxCount + $mailOverrideCount + $incomingMailCount + $draftReviewCount + $phoneProfileCount;

        return [
            'userCount' => $userCount,
            'childCompanyCount' => $childCompanyCount,
            'ticketCount' => $ticketCount,
            'mailboxCount' => $mailboxCount,
            'mailOverrideCount' => $mailOverrideCount,
            'incomingMailCount' => $incomingMailCount,
            'draftReviewCount' => $draftReviewCount,
            'phoneProfileCount' => $phoneProfileCount,
            'linkCount' => $linkCount,
            'hasLinks' => $linkCount > 0,
            'isTrashCompany' => $this->isTrashCompany($company),
        ];
    }

    public function isTrashCompany(Company $company): bool
    {
        $configuredId = (int) $this->systemSettings->getString(SystemSettings::IDENTITY_TRASH_COMPANY_ID, '0');

        return ($configuredId > 0 && $company->getId() === $configuredId)
            || self::TRASH_COMPANY_NAME === $company->getName();
    }

    public function ensureTrashCompany(): Company
    {
        $configuredId = (int) $this->systemSettings->getString(SystemSettings::IDENTITY_TRASH_COMPANY_ID, '0');
        if ($configuredId > 0) {
            $configuredCompany = $this->entityManager->getRepository(Company::class)->find($configuredId);
            if ($configuredCompany instanceof Company) {
                $configuredCompany
                    ->deactivate()
                    ->setAllowSharedTickets(false)
                    ->setAllowParentCompanyAccessToSharedTickets(false);

                return $configuredCompany;
            }
        }

        $trashCompany = $this->entityManager->getRepository(Company::class)->findOneBy(['name' => self::TRASH_COMPANY_NAME]);
        if (!$trashCompany instanceof Company) {
            $trashCompany = new Company(self::TRASH_COMPANY_NAME);
            $this->entityManager->persist($trashCompany);
        }

        $trashCompany
            ->deactivate()
            ->setPrimaryEmail(null)
            ->setAllowSharedTickets(false)
            ->setAllowParentCompanyAccessToSharedTickets(false)
            ->setUseCustomTicketSequence(false)
            ->setTicketReferencePrefix(null);

        $this->entityManager->flush();
        if (null !== $trashCompany->getId()) {
            $this->systemSettings->setString(SystemSettings::IDENTITY_TRASH_COMPANY_ID, (string) $trashCompany->getId());
        }

        return $trashCompany;
    }

    /**
     * @return array{
     *     preview: array<string, int|bool>,
     *     ticketAction: string,
     *     movedTicketCount: int,
     *     purgedTicketCount: int,
     *     trashCompany: ?Company
     * }
     */
    public function deleteCompany(Company $company, string $ticketAction): array
    {
        $preview = $this->previewCompanyDeletion($company);
        $movedTicketCount = 0;
        $purgedTicketCount = 0;
        $trashCompany = null;

        if (($preview['ticketCount'] ?? 0) > 0 && 'delete_tickets' === $ticketAction) {
            $purgeResult = $this->ticketPurgeService->purgeCompanyTickets($company);
            $purgedTicketCount = (int) $purgeResult['ticketCount'];
        } elseif (($preview['ticketCount'] ?? 0) > 0) {
            $trashCompany = $this->ensureTrashCompany();
            foreach ($this->entityManager->getRepository(Ticket::class)->findBy(['company' => $company]) as $ticket) {
                \assert($ticket instanceof Ticket);
                $ticket
                    ->setCompany($trashCompany)
                    ->setVisibility(TicketVisibility::INTERNAL_ONLY);
                ++$movedTicketCount;
            }
        }

        foreach ($this->entityManager->getRepository(SupportMailbox::class)->findBy(['company' => $company]) as $mailbox) {
            \assert($mailbox instanceof SupportMailbox);
            $mailbox->setCompany(null);
        }

        foreach ($this->entityManager->getRepository(IncomingMail::class)->findBy(['matchedCompany' => $company]) as $incomingMail) {
            \assert($incomingMail instanceof IncomingMail);
            $incomingMail->setMatchedCompany(null);
        }

        foreach ($this->entityManager->getRepository(DraftTicketReview::class)->findBy(['matchedCompany' => $company]) as $review) {
            \assert($review instanceof DraftTicketReview);
            $review->setMatchedCompany(null);
        }

        foreach ($this->entityManager->getRepository(CompanyMailOverride::class)->findBy(['company' => $company]) as $override) {
            \assert($override instanceof CompanyMailOverride);
            $this->entityManager->remove($override);
        }

        foreach ($this->entityManager->getRepository(PhoneCustomerProfile::class)->findBy(['company' => $company]) as $profile) {
            \assert($profile instanceof PhoneCustomerProfile);
            $this->entityManager->remove($profile);
        }

        $this->entityManager->remove($company);
        $this->entityManager->flush();

        return [
            'preview' => $preview,
            'ticketAction' => $ticketAction,
            'movedTicketCount' => $movedTicketCount,
            'purgedTicketCount' => $purgedTicketCount,
            'trashCompany' => $trashCompany,
        ];
    }

    private function countTicketsForUser(User $user): int
    {
        return (int) $this->entityManager->getRepository(Ticket::class)->createQueryBuilder('ticket')
            ->select('COUNT(ticket.id)')
            ->andWhere('ticket.requester = :user OR ticket.assignee = :user')
            ->setParameter('user', $user)
            ->getQuery()
            ->getSingleScalarResult();
    }

    /**
     * @return list<Ticket>
     */
    private function findTicketsForUser(User $user): array
    {
        return $this->entityManager->getRepository(Ticket::class)->createQueryBuilder('ticket')
            ->leftJoin('ticket.comments', 'comment')->addSelect('comment')
            ->leftJoin('comment.attachments', 'attachment')->addSelect('attachment')
            ->andWhere('ticket.requester = :user OR ticket.assignee = :user')
            ->setParameter('user', $user)
            ->orderBy('ticket.createdAt', 'ASC')
            ->addOrderBy('ticket.id', 'ASC')
            ->getQuery()
            ->getResult();
    }

    /**
     * @return list<Ticket>
     */
    private function findTicketsForTeam(TechnicianTeam $team): array
    {
        return $this->entityManager->getRepository(Ticket::class)->createQueryBuilder('ticket')
            ->leftJoin('ticket.comments', 'comment')->addSelect('comment')
            ->leftJoin('comment.attachments', 'attachment')->addSelect('attachment')
            ->andWhere('ticket.assignedTeam = :team')
            ->setParameter('team', $team)
            ->orderBy('ticket.createdAt', 'ASC')
            ->addOrderBy('ticket.id', 'ASC')
            ->getQuery()
            ->getResult();
    }

    private function countTechnicianTeamMembers(TechnicianTeam $team): int
    {
        return (int) $this->entityManager->getRepository(User::class)->createQueryBuilder('user')
            ->select('COUNT(DISTINCT user.id)')
            ->innerJoin('user.technicianTeams', 'technicianTeam')
            ->andWhere('technicianTeam = :team')
            ->setParameter('team', $team)
            ->getQuery()
            ->getSingleScalarResult();
    }

    private function countByField(string $entityClass, string $field, object $value): int
    {
        return (int) $this->entityManager->getRepository($entityClass)->createQueryBuilder('entity')
            ->select('COUNT(entity.id)')
            ->andWhere(sprintf('entity.%s = :value', $field))
            ->setParameter('value', $value)
            ->getQuery()
            ->getSingleScalarResult();
    }
}
