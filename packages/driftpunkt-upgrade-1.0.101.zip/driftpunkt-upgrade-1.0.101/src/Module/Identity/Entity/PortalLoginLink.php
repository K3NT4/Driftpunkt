<?php

declare(strict_types=1);

namespace App\Module\Identity\Entity;

use App\Module\Shared\Entity\TimestampableTrait;
use App\Module\Ticket\Entity\Ticket;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity]
#[ORM\Table(name: 'portal_login_links')]
#[ORM\HasLifecycleCallbacks]
class PortalLoginLink
{
    use TimestampableTrait;

    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\ManyToOne(targetEntity: User::class, fetch: 'EAGER')]
    #[ORM\JoinColumn(nullable: false, onDelete: 'CASCADE')]
    private User $user;

    #[ORM\ManyToOne(targetEntity: Ticket::class, fetch: 'EAGER')]
    #[ORM\JoinColumn(nullable: false, onDelete: 'CASCADE')]
    private Ticket $ticket;

    #[ORM\Column(length: 255)]
    private string $targetPath;

    #[ORM\Column(length: 80)]
    private string $requiredRole;

    #[ORM\Column(length: 64, unique: true)]
    private string $tokenHash;

    #[ORM\Column]
    private \DateTimeImmutable $expiresAt;

    #[ORM\Column(nullable: true)]
    private ?\DateTimeImmutable $usedAt = null;

    public function __construct(
        User $user,
        Ticket $ticket,
        string $targetPath,
        string $requiredRole,
        string $tokenHash,
        \DateTimeImmutable $expiresAt,
    ) {
        $this->user = $user;
        $this->ticket = $ticket;
        $this->targetPath = $this->normalizeTargetPath($targetPath);
        $this->requiredRole = trim($requiredRole);
        $this->tokenHash = $tokenHash;
        $this->expiresAt = $expiresAt;
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getUser(): User
    {
        return $this->user;
    }

    public function getTicket(): Ticket
    {
        return $this->ticket;
    }

    public function getTargetPath(): string
    {
        return $this->targetPath;
    }

    public function getRequiredRole(): string
    {
        return $this->requiredRole;
    }

    public function getTokenHash(): string
    {
        return $this->tokenHash;
    }

    public function getExpiresAt(): \DateTimeImmutable
    {
        return $this->expiresAt;
    }

    public function getUsedAt(): ?\DateTimeImmutable
    {
        return $this->usedAt;
    }

    public function isExpired(\DateTimeImmutable $now = new \DateTimeImmutable()): bool
    {
        return $this->expiresAt <= $now;
    }

    public function isActive(\DateTimeImmutable $now = new \DateTimeImmutable()): bool
    {
        return null === $this->usedAt && !$this->isExpired($now);
    }

    public function markAsUsed(\DateTimeImmutable $usedAt = new \DateTimeImmutable()): self
    {
        $this->usedAt = $usedAt;

        return $this;
    }

    private function normalizeTargetPath(string $targetPath): string
    {
        $targetPath = trim($targetPath);
        if (!str_starts_with($targetPath, '/portal/') || str_starts_with($targetPath, '//')) {
            throw new \InvalidArgumentException('Portal login links must target an internal portal path.');
        }

        return $targetPath;
    }
}
