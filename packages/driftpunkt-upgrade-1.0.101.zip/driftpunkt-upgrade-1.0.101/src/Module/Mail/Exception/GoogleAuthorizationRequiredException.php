<?php

declare(strict_types=1);

namespace App\Module\Mail\Exception;

final class GoogleAuthorizationRequiredException extends \RuntimeException
{
    public function __construct()
    {
        parent::__construct('Google-kontot måste anslutas igen för den här inkorgen.');
    }
}
