<?php

declare(strict_types=1);

namespace App\Module\Mail\Enum;

enum ImapMessageState: string
{
    case DISCOVERED = 'discovered';
    case RETRY_PENDING = 'retry_pending';
    case PROCESSED_PENDING_MOVE = 'processed_pending_move';
    case FAILED_PENDING_MOVE = 'failed_pending_move';
    case COMPLETED = 'completed';
    case QUARANTINED = 'quarantined';
    case REMOTE_MISSING = 'remote_missing';
}
