<?php

declare(strict_types=1);

namespace App\Module\Mail\Enum;

enum MailEncryption: string
{
    case NONE = 'none';
    case TLS = 'tls';
    case SSL = 'ssl';
    case STARTTLS = 'starttls';

    public function label(): string
    {
        return match ($this) {
            self::NONE => 'Ingen',
            self::TLS => 'TLS',
            self::SSL => 'SSL',
            self::STARTTLS => 'STARTTLS',
        };
    }
}
