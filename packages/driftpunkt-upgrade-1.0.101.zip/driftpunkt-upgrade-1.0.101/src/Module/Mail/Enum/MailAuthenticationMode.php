<?php

declare(strict_types=1);

namespace App\Module\Mail\Enum;

enum MailAuthenticationMode: string
{
    case PASSWORD = 'password';
    case MICROSOFT_OAUTH = 'microsoft_oauth';
    case GOOGLE_OAUTH = 'google_oauth';

    public function label(): string
    {
        return match ($this) {
            self::PASSWORD => 'Användarnamn + lösenord/token',
            self::MICROSOFT_OAUTH => 'Microsoft OAuth 2.0 (appregistrering)',
            self::GOOGLE_OAUTH => 'Google OAuth 2.0 (per inkorg)',
        };
    }
}
