<?php

declare(strict_types=1);

namespace App\Module\Mail\Enum;

enum IncomingMailProcessingResult: string
{
    case TICKET_CREATED = 'ticket_created';
    case COMMENT_ADDED = 'comment_added';
    case INTERNAL_REPORT_RESPONSE_ADDED = 'internal_report_response_added';
    case DRAFT_REVIEW_CREATED = 'draft_review_created';
    case REJECTED = 'rejected';

    public function label(): string
    {
        return match ($this) {
            self::TICKET_CREATED => 'Ärende skapat',
            self::COMMENT_ADDED => 'Svar kopplat till ärende',
            self::INTERNAL_REPORT_RESPONSE_ADDED => 'Svar kopplat till intern rapport',
            self::DRAFT_REVIEW_CREATED => 'Utkastgranskning skapad',
            self::REJECTED => 'Avvisat',
        };
    }
}
