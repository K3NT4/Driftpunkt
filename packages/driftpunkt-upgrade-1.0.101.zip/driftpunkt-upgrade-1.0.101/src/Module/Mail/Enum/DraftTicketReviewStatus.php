<?php

declare(strict_types=1);

namespace App\Module\Mail\Enum;

enum DraftTicketReviewStatus: string
{
    case PENDING = 'pending';
    case APPROVED = 'approved';
    case REJECTED = 'rejected';

    public function label(): string
    {
        return match ($this) {
            self::PENDING => 'Väntar på granskning',
            self::APPROVED => 'Godkänd',
            self::REJECTED => 'Avvisad',
        };
    }
}
