<?php

declare(strict_types=1);

namespace App\Module\Mail\Enum;

enum MailServerDirection: string
{
    case INCOMING = 'incoming';
    case OUTGOING = 'outgoing';
    case BOTH = 'both';

    public function label(): string
    {
        return match ($this) {
            self::INCOMING => 'Inkommande',
            self::OUTGOING => 'Utgående',
            self::BOTH => 'Både inkommande och utgående',
        };
    }

    public function supportsIncoming(): bool
    {
        return \in_array($this, [self::INCOMING, self::BOTH], true);
    }

    public function supportsOutgoing(): bool
    {
        return \in_array($this, [self::OUTGOING, self::BOTH], true);
    }
}
