<?php

declare(strict_types=1);

namespace App\Module\Mail\Controller;

use App\Module\Mail\Entity\SupportMailbox;
use App\Module\Mail\Service\GoogleOAuthTokenProvider;
use App\Module\Mail\Service\ImapMailboxFetcher;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Attribute\Route;
use Symfony\Component\Routing\Generator\UrlGeneratorInterface;
use Symfony\Component\Security\Http\Attribute\IsGranted;

#[IsGranted('ROLE_SUPER_ADMIN')]
final class GoogleMailboxOAuthController extends AbstractController
{
    private const SESSION_KEY = 'google_mail_oauth';

    public function __construct(
        private readonly EntityManagerInterface $entityManager,
        private readonly GoogleOAuthTokenProvider $googleOAuthTokenProvider,
        private readonly ImapMailboxFetcher $imapMailboxFetcher,
        private readonly UrlGeneratorInterface $urlGenerator,
    ) {
    }

    #[Route('/portal/admin/mailboxes/{id}/google-oauth/connect', name: 'app_portal_admin_mailbox_google_connect', methods: ['GET'])]
    public function connect(Request $request, SupportMailbox $mailbox): RedirectResponse
    {
        if (!$mailbox->getIncomingServer()?->usesGoogleOAuth()) {
            $this->addFlash('error', 'Inkorgens server använder inte Google OAuth.');

            return $this->mailboxRedirect($mailbox);
        }
        if (!$this->googleOAuthTokenProvider->isConfigured()) {
            $this->addFlash('error', 'Google OAuth saknar klientkonfiguration eller krypteringsnyckel.');

            return $this->mailboxRedirect($mailbox);
        }

        $state = $this->base64Url(random_bytes(32));
        $verifier = $this->base64Url(random_bytes(64));
        $challenge = $this->base64Url(hash('sha256', $verifier, true));
        $redirectUri = $this->urlGenerator->generate('app_portal_admin_mailbox_google_callback', [], UrlGeneratorInterface::ABSOLUTE_URL);
        $request->getSession()->set(self::SESSION_KEY, [
            'mailbox_id' => $mailbox->getId(),
            'state' => $state,
            'verifier' => $verifier,
            'redirect_uri' => $redirectUri,
            'created_at' => time(),
        ]);

        return new RedirectResponse($this->googleOAuthTokenProvider->authorizationUrl($redirectUri, $state, $challenge));
    }

    #[Route('/portal/admin/mailboxes/google-oauth/callback', name: 'app_portal_admin_mailbox_google_callback', methods: ['GET'])]
    public function callback(Request $request): RedirectResponse
    {
        $oauthState = $request->getSession()->remove(self::SESSION_KEY);
        if (!\is_array($oauthState) || time() - (int) ($oauthState['created_at'] ?? 0) > 600) {
            $this->addFlash('error', 'Google OAuth-sessionen saknas eller har gått ut. Starta anslutningen igen.');

            return $this->redirectToRoute('app_portal_admin_mailboxes');
        }

        $mailbox = $this->entityManager->getRepository(SupportMailbox::class)->find((int) ($oauthState['mailbox_id'] ?? 0));
        if (!$mailbox instanceof SupportMailbox) {
            $this->addFlash('error', 'Inkorgen för Google OAuth kunde inte hittas.');

            return $this->redirectToRoute('app_portal_admin_mailboxes');
        }

        $state = (string) $request->query->get('state');
        $code = (string) $request->query->get('code');
        if (!hash_equals((string) ($oauthState['state'] ?? ''), $state) || '' === trim($code)) {
            $this->addFlash('error', 'Google OAuth-svaret kunde inte verifieras. Inga tokens sparades.');

            return $this->mailboxRedirect($mailbox);
        }

        try {
            $authorization = $this->googleOAuthTokenProvider->exchangeAuthorizationCode(
                $code,
                (string) $oauthState['redirect_uri'],
                (string) $oauthState['verifier'],
            );
            if ($authorization['email'] !== $mailbox->getEmailAddress()) {
                throw new \RuntimeException(sprintf('Google-kontot %s matchar inte inkorgen %s.', $authorization['email'], $mailbox->getEmailAddress()));
            }
            $mailbox->authorizeGoogle(
                $this->googleOAuthTokenProvider->encryptRefreshToken($authorization['refresh_token']),
                $authorization['email'],
            );
            $this->entityManager->flush();
            $this->addFlash('success', sprintf('Google-kontot %s anslöts till inkorgen.', $authorization['email']));
        } catch (\Throwable $exception) {
            $this->addFlash('error', $exception->getMessage());
        }

        return $this->mailboxRedirect($mailbox);
    }

    #[Route('/portal/admin/mailboxes/{id}/google-oauth/disconnect', name: 'app_portal_admin_mailbox_google_disconnect', methods: ['POST'])]
    public function disconnect(Request $request, SupportMailbox $mailbox): RedirectResponse
    {
        if (!$this->isCsrfTokenValid(sprintf('disconnect_google_mailbox_%d', $mailbox->getId()), (string) $request->request->get('_token'))) {
            $this->addFlash('error', 'Google-frånkopplingen kunde inte verifieras.');

            return $this->mailboxRedirect($mailbox);
        }
        try {
            $this->googleOAuthTokenProvider->revokeFor($mailbox);
        } catch (\Throwable) {
            $this->addFlash('warning', 'Google kunde inte bekräfta tokenåterkallningen, men den lokala token tas bort.');
        }
        $mailbox->disconnectGoogle();
        $this->entityManager->flush();
        $this->addFlash('success', 'Google-kontot kopplades från inkorgen.');

        return $this->mailboxRedirect($mailbox);
    }

    #[Route('/portal/admin/mailboxes/{id}/test', name: 'app_portal_admin_mailbox_test', methods: ['POST'])]
    public function test(Request $request, SupportMailbox $mailbox): RedirectResponse
    {
        if (!$this->isCsrfTokenValid(sprintf('test_support_mailbox_%d', $mailbox->getId()), (string) $request->request->get('_token'))) {
            $this->addFlash('error', 'Inkorgstestet kunde inte verifieras.');

            return $this->mailboxRedirect($mailbox);
        }
        try {
            $this->imapMailboxFetcher->testMailbox($mailbox);
            $this->addFlash('success', 'IMAP-anslutning, UID-stöd och destinationsmappar verifierades.');
        } catch (\Throwable $exception) {
            $this->addFlash('error', sprintf('Inkorgstestet misslyckades: %s', $exception->getMessage()));
        }

        return $this->mailboxRedirect($mailbox);
    }

    private function mailboxRedirect(SupportMailbox $mailbox): RedirectResponse
    {
        return $this->redirectToRoute('app_portal_admin_mailboxes', ['mailbox_panel' => $mailbox->getId()]);
    }

    private function base64Url(string $value): string
    {
        return rtrim(strtr(base64_encode($value), '+/', '-_'), '=');
    }
}
