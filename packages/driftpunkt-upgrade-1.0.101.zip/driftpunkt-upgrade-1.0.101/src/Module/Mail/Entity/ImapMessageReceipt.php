<?php

declare(strict_types=1);

namespace App\Module\Mail\Entity;

use App\Module\Mail\Enum\ImapMessageState;
use App\Module\Shared\Entity\TimestampableTrait;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity]
#[ORM\Table(name: 'imap_message_receipts')]
#[ORM\UniqueConstraint(name: 'uniq_imap_receipt_remote_message', columns: ['mailbox_id', 'uid_validity', 'remote_uid'])]
#[ORM\Index(name: 'idx_imap_receipt_mailbox_state', columns: ['mailbox_id', 'state'])]
#[ORM\HasLifecycleCallbacks]
class ImapMessageReceipt
{
    use TimestampableTrait;

    public const MAX_PROCESSING_ATTEMPTS = 3;

    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\ManyToOne]
    #[ORM\JoinColumn(nullable: false, onDelete: 'CASCADE')]
    private SupportMailbox $mailbox;

    #[ORM\ManyToOne]
    #[ORM\JoinColumn(nullable: true, onDelete: 'SET NULL')]
    private ?IncomingMail $incomingMail = null;

    #[ORM\Column(length: 20)]
    private string $uidValidity;

    #[ORM\Column(length: 20)]
    private string $remoteUid;

    #[ORM\Column]
    private int $attemptCount = 0;

    #[ORM\Column(enumType: ImapMessageState::class)]
    private ImapMessageState $state = ImapMessageState::DISCOVERED;

    #[ORM\Column(type: 'text', nullable: true)]
    private ?string $lastError = null;

    #[ORM\Column(nullable: true)]
    private ?\DateTimeImmutable $lastAttemptAt = null;

    #[ORM\Column(nullable: true)]
    private ?\DateTimeImmutable $completedAt = null;

    public function __construct(SupportMailbox $mailbox, string $uidValidity, string $remoteUid)
    {
        $this->mailbox = $mailbox;
        $this->uidValidity = trim($uidValidity);
        $this->remoteUid = trim($remoteUid);
    }

    public function getId(): ?int { return $this->id; }
    public function getMailbox(): SupportMailbox { return $this->mailbox; }
    public function getIncomingMail(): ?IncomingMail { return $this->incomingMail; }
    public function getUidValidity(): string { return $this->uidValidity; }
    public function getRemoteUid(): string { return $this->remoteUid; }
    public function getAttemptCount(): int { return $this->attemptCount; }
    public function getState(): ImapMessageState { return $this->state; }
    public function getLastError(): ?string { return $this->lastError; }
    public function getLastAttemptAt(): ?\DateTimeImmutable { return $this->lastAttemptAt; }
    public function getCompletedAt(): ?\DateTimeImmutable { return $this->completedAt; }

    public function setIncomingMail(?IncomingMail $incomingMail): self
    {
        $this->incomingMail = $incomingMail;

        return $this;
    }

    public function markProcessingSucceeded(): self
    {
        ++$this->attemptCount;
        $this->lastAttemptAt = new \DateTimeImmutable();
        $this->lastError = null;
        $this->state = ImapMessageState::PROCESSED_PENDING_MOVE;

        return $this;
    }

    public function markProcessingFailed(string $error): self
    {
        ++$this->attemptCount;
        $this->lastAttemptAt = new \DateTimeImmutable();
        $this->lastError = mb_substr(trim($error), 0, 4000);
        $this->state = $this->attemptCount >= self::MAX_PROCESSING_ATTEMPTS
            ? ImapMessageState::FAILED_PENDING_MOVE
            : ImapMessageState::RETRY_PENDING;

        return $this;
    }

    public function markCompleted(): self
    {
        $this->state = ImapMessageState::COMPLETED;
        $this->completedAt = new \DateTimeImmutable();
        $this->lastError = null;

        return $this;
    }

    public function markQuarantined(): self
    {
        $this->state = ImapMessageState::QUARANTINED;
        $this->completedAt = new \DateTimeImmutable();

        return $this;
    }

    public function markRemoteMissing(): self
    {
        $this->state = ImapMessageState::REMOTE_MISSING;
        $this->completedAt = new \DateTimeImmutable();

        return $this;
    }
}
