<?php

declare(strict_types=1);

namespace App\Module\Mail\Entity;

use App\Module\Identity\Entity\Company;
use App\Module\Identity\Entity\User;
use App\Module\Mail\Enum\DraftTicketReviewStatus;
use App\Module\Shared\Entity\TimestampableTrait;
use App\Module\Ticket\Entity\Ticket;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity]
#[ORM\Table(name: 'draft_ticket_reviews')]
#[ORM\HasLifecycleCallbacks]
class DraftTicketReview
{
    use TimestampableTrait;

    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\ManyToOne]
    #[ORM\JoinColumn(nullable: false, onDelete: 'CASCADE')]
    private IncomingMail $incomingMail;

    #[ORM\ManyToOne]
    #[ORM\JoinColumn(onDelete: 'SET NULL', nullable: true)]
    private ?SupportMailbox $mailbox = null;

    #[ORM\ManyToOne]
    #[ORM\JoinColumn(onDelete: 'SET NULL', nullable: true)]
    private ?Ticket $draftTicket = null;

    #[ORM\ManyToOne]
    #[ORM\JoinColumn(onDelete: 'SET NULL', nullable: true)]
    private ?Ticket $matchedTicket = null;

    #[ORM\ManyToOne]
    #[ORM\JoinColumn(onDelete: 'SET NULL', nullable: true)]
    private ?Company $matchedCompany = null;

    #[ORM\Column(enumType: DraftTicketReviewStatus::class)]
    private DraftTicketReviewStatus $status = DraftTicketReviewStatus::PENDING;

    #[ORM\Column(length: 255)]
    private string $reason;

    #[ORM\ManyToOne]
    #[ORM\JoinColumn(onDelete: 'SET NULL', nullable: true)]
    private ?User $reviewedBy = null;

    #[ORM\Column(nullable: true)]
    private ?\DateTimeImmutable $reviewedAt = null;

    public function __construct(IncomingMail $incomingMail, string $reason)
    {
        $this->incomingMail = $incomingMail;
        $this->reason = trim($reason);
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getIncomingMail(): IncomingMail
    {
        return $this->incomingMail;
    }

    public function getMailbox(): ?SupportMailbox
    {
        return $this->mailbox;
    }

    public function setMailbox(?SupportMailbox $mailbox): self
    {
        $this->mailbox = $mailbox;

        return $this;
    }

    public function getDraftTicket(): ?Ticket
    {
        return $this->draftTicket;
    }

    public function setDraftTicket(?Ticket $draftTicket): self
    {
        $this->draftTicket = $draftTicket;

        return $this;
    }

    public function getMatchedTicket(): ?Ticket
    {
        return $this->matchedTicket;
    }

    public function setMatchedTicket(?Ticket $matchedTicket): self
    {
        $this->matchedTicket = $matchedTicket;

        return $this;
    }

    public function getMatchedCompany(): ?Company
    {
        return $this->matchedCompany;
    }

    public function setMatchedCompany(?Company $matchedCompany): self
    {
        $this->matchedCompany = $matchedCompany;

        return $this;
    }

    public function getStatus(): DraftTicketReviewStatus
    {
        return $this->status;
    }

    public function getReason(): string
    {
        return $this->reason;
    }

    public function setReason(string $reason): self
    {
        $this->reason = trim($reason);

        return $this;
    }

    public function getReviewedBy(): ?User
    {
        return $this->reviewedBy;
    }

    public function getReviewedAt(): ?\DateTimeImmutable
    {
        return $this->reviewedAt;
    }

    public function isPending(): bool
    {
        return DraftTicketReviewStatus::PENDING === $this->status;
    }

    public function markApproved(?User $reviewedBy = null): self
    {
        $this->status = DraftTicketReviewStatus::APPROVED;
        $this->reviewedBy = $reviewedBy;
        $this->reviewedAt = new \DateTimeImmutable();

        return $this;
    }

    public function markRejected(?User $reviewedBy = null): self
    {
        $this->status = DraftTicketReviewStatus::REJECTED;
        $this->reviewedBy = $reviewedBy;
        $this->reviewedAt = new \DateTimeImmutable();

        return $this;
    }
}
