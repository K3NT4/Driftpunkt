<?php

declare(strict_types=1);

namespace App\Module\Mail\Entity;

use App\Module\Identity\Entity\Company;
use App\Module\Shared\Entity\TimestampableTrait;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity]
#[ORM\Table(name: 'company_mail_overrides')]
#[ORM\HasLifecycleCallbacks]
class CompanyMailOverride
{
    use TimestampableTrait;

    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\ManyToOne]
    #[ORM\JoinColumn(nullable: false, onDelete: 'CASCADE')]
    private Company $company;

    #[ORM\ManyToOne]
    #[ORM\JoinColumn(onDelete: 'SET NULL', nullable: true)]
    private ?MailServer $outboundServer = null;

    #[ORM\Column(length: 180, nullable: true)]
    private ?string $fromAddress = null;

    #[ORM\Column(length: 180, nullable: true)]
    private ?string $fromName = null;

    #[ORM\Column]
    private bool $fallbackToPrimary = true;

    #[ORM\Column]
    private bool $isActive = true;

    public function __construct(Company $company)
    {
        $this->company = $company;
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getCompany(): Company
    {
        return $this->company;
    }

    public function setCompany(Company $company): self
    {
        $this->company = $company;

        return $this;
    }

    public function getOutboundServer(): ?MailServer
    {
        return $this->outboundServer;
    }

    public function setOutboundServer(?MailServer $outboundServer): self
    {
        $this->outboundServer = $outboundServer;

        return $this;
    }

    public function getFromAddress(): ?string
    {
        return $this->fromAddress;
    }

    public function setFromAddress(?string $fromAddress): self
    {
        if (null === $fromAddress) {
            $this->fromAddress = null;

            return $this;
        }

        $trimmed = trim($fromAddress);
        $this->fromAddress = '' !== $trimmed ? mb_strtolower($trimmed) : null;

        return $this;
    }

    public function getFromName(): ?string
    {
        return $this->fromName;
    }

    public function setFromName(?string $fromName): self
    {
        if (null === $fromName) {
            $this->fromName = null;

            return $this;
        }

        $trimmed = trim($fromName);
        $this->fromName = '' !== $trimmed ? $trimmed : null;

        return $this;
    }

    public function fallbackToPrimary(): bool
    {
        return $this->fallbackToPrimary;
    }

    public function isFallbackToPrimary(): bool
    {
        return $this->fallbackToPrimary();
    }

    public function setFallbackToPrimary(bool $fallbackToPrimary): self
    {
        $this->fallbackToPrimary = $fallbackToPrimary;

        return $this;
    }

    public function isActive(): bool
    {
        return $this->isActive;
    }

    public function activate(): self
    {
        $this->isActive = true;

        return $this;
    }

    public function deactivate(): self
    {
        $this->isActive = false;

        return $this;
    }
}
