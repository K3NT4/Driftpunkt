<?php

declare(strict_types=1);

namespace App\Module\Mail\Service;

use App\Module\Mail\Entity\SupportMailbox;
use Symfony\Component\DependencyInjection\Attribute\Autowire;

final class IncomingMailSpoolReader
{
    public function __construct(
        #[Autowire('%kernel.project_dir%')]
        private readonly string $projectDir,
    ) {
    }

    public function inboxDirectory(SupportMailbox $mailbox): string
    {
        return $this->projectDir.\DIRECTORY_SEPARATOR.'var'.\DIRECTORY_SEPARATOR.'mail_ingest'.\DIRECTORY_SEPARATOR.(string) $mailbox->getId();
    }

    public function processedDirectory(SupportMailbox $mailbox): string
    {
        return $this->projectDir.\DIRECTORY_SEPARATOR.'var'.\DIRECTORY_SEPARATOR.'mail_ingest_processed'.\DIRECTORY_SEPARATOR.(string) $mailbox->getId();
    }

    public function failedDirectory(SupportMailbox $mailbox): string
    {
        return $this->projectDir.\DIRECTORY_SEPARATOR.'var'.\DIRECTORY_SEPARATOR.'mail_ingest_failed'.\DIRECTORY_SEPARATOR.(string) $mailbox->getId();
    }

    /**
     * @return list<array{
     *     path: string,
     *     filename: string,
     *     from: string,
     *     subject: string,
     *     body: string,
     *     from_name: ?string,
     *     raw_message: ?string,
     *     attachments: list<array{
     *         displayName: string,
     *         mimeType: ?string,
     *         content: string
     *     }>
     * }>
     */
    public function readPendingMessages(SupportMailbox $mailbox): array
    {
        $directory = $this->inboxDirectory($mailbox);
        if (!is_dir($directory)) {
            return [];
        }

        $paths = array_merge(
            glob($directory.\DIRECTORY_SEPARATOR.'*.json') ?: [],
            glob($directory.\DIRECTORY_SEPARATOR.'*.eml') ?: [],
        );

        sort($paths);
        $messages = [];

        foreach ($paths as $path) {
            if ('eml' === mb_strtolower((string) pathinfo($path, \PATHINFO_EXTENSION))) {
                $rawMessage = (string) file_get_contents($path);
                if ('' === trim($rawMessage)) {
                    $this->moveFile($path, $this->failedDirectory($mailbox));
                    continue;
                }

                $messages[] = [
                    'path' => $path,
                    'filename' => basename($path),
                    'from' => '',
                    'subject' => '',
                    'body' => '',
                    'from_name' => null,
                    'raw_message' => $rawMessage,
                    'attachments' => [],
                ];

                continue;
            }

            $payload = json_decode((string) file_get_contents($path), true);
            if (!\is_array($payload)) {
                $this->moveFile($path, $this->failedDirectory($mailbox));
                continue;
            }

            $from = trim((string) ($payload['from'] ?? ''));
            $subject = trim((string) ($payload['subject'] ?? ''));
            $body = trim((string) ($payload['body'] ?? ''));

            if ('' === $from || '' === $subject || '' === $body) {
                $this->moveFile($path, $this->failedDirectory($mailbox));
                continue;
            }

            $messages[] = [
                'path' => $path,
                'filename' => basename($path),
                'from' => $from,
                'subject' => $subject,
                'body' => $body,
                'from_name' => $this->normalizeNullableString($payload['from_name'] ?? null),
                'raw_message' => $this->normalizeNullableString($payload['raw_message'] ?? null),
                'attachments' => $this->normalizeAttachments($payload['attachments'] ?? []),
            ];
        }

        return $messages;
    }

    public function acknowledge(SupportMailbox $mailbox, string $path): void
    {
        $this->moveFile($path, $this->processedDirectory($mailbox));
    }

    private function moveFile(string $path, string $targetDirectory): void
    {
        if (!is_file($path)) {
            return;
        }

        if (!is_dir($targetDirectory) && !mkdir($targetDirectory, 0775, true) && !is_dir($targetDirectory)) {
            throw new \RuntimeException('Kunde inte skapa spool-katalogen för mailimport.');
        }

        $targetPath = $targetDirectory.\DIRECTORY_SEPARATOR.$this->uniqueTargetName($targetDirectory, basename($path));

        if (!rename($path, $targetPath)) {
            throw new \RuntimeException('Kunde inte flytta spool-filen efter import.');
        }
    }

    private function uniqueTargetName(string $targetDirectory, string $filename): string
    {
        $name = pathinfo($filename, \PATHINFO_FILENAME);
        $extension = pathinfo($filename, \PATHINFO_EXTENSION);
        $candidate = $filename;
        $suffix = 1;

        while (is_file($targetDirectory.\DIRECTORY_SEPARATOR.$candidate)) {
            $candidate = sprintf(
                '%s-%d%s',
                $name,
                $suffix,
                '' !== $extension ? '.'.$extension : '',
            );
            ++$suffix;
        }

        return $candidate;
    }

    private function normalizeNullableString(mixed $value): ?string
    {
        if (!\is_string($value)) {
            return null;
        }

        $trimmed = trim($value);

        return '' !== $trimmed ? $trimmed : null;
    }

    /**
     * @return list<array{displayName: string, mimeType: ?string, content: string}>
     */
    private function normalizeAttachments(mixed $value): array
    {
        if (!\is_array($value)) {
            return [];
        }

        $attachments = [];

        foreach ($value as $attachment) {
            if (!\is_array($attachment)) {
                continue;
            }

            $displayName = trim((string) ($attachment['displayName'] ?? $attachment['display_name'] ?? ''));
            if ('' === $displayName) {
                continue;
            }

            $content = '';
            if (\is_string($attachment['content'] ?? null)) {
                $content = $attachment['content'];
            } elseif (\is_string($attachment['content_base64'] ?? null)) {
                $decoded = base64_decode($attachment['content_base64'], true);
                $content = \is_string($decoded) ? $decoded : '';
            }

            if ('' === $content) {
                continue;
            }

            $attachments[] = [
                'displayName' => $displayName,
                'mimeType' => $this->normalizeNullableString($attachment['mimeType'] ?? $attachment['mime_type'] ?? null),
                'content' => $content,
            ];
        }

        return $attachments;
    }
}
