<?php

declare(strict_types=1);

namespace App\Module\Mail\Service;

use App\Module\Mail\Entity\SupportMailbox;

final class ImapMailboxSession
{
    private int $tagCounter = 0;
    /** @var list<string> */
    private array $capabilities = [];
    private string $uidValidity = '1';
    private bool $closed = false;

    /** @param resource $stream */
    public function __construct(private $stream, private readonly SupportMailbox $mailbox)
    {
    }

    /** @return array{lines: list<string>, literals: list<string>, ok: bool} */
    public function command(string $command, bool $throwOnFailure = true, bool $emptyResponseToContinuation = false): array
    {
        $tag = sprintf('A%04d', ++$this->tagCounter);
        if (false === fwrite($this->stream, sprintf("%s %s\r\n", $tag, $command))) {
            throw new \RuntimeException('Kunde inte skriva IMAP-kommandot.');
        }
        $lines = [];
        $literals = [];
        while (($line = fgets($this->stream)) !== false) {
            $trimmed = rtrim($line, "\r\n");
            $lines[] = $trimmed;
            if ($emptyResponseToContinuation && str_starts_with($trimmed, '+')) {
                fwrite($this->stream, "\r\n");
                continue;
            }
            if (preg_match('/\{(\d+)\}$/', $trimmed, $matches)) {
                $length = (int) $matches[1];
                $literal = '';
                while (\strlen($literal) < $length) {
                    $chunk = fread($this->stream, $length - \strlen($literal));
                    if (false === $chunk || '' === $chunk) {
                        throw new \RuntimeException('Kunde inte läsa IMAP-literal fullt ut.');
                    }
                    $literal .= $chunk;
                }
                $literals[] = $literal;
                continue;
            }
            if (str_starts_with($trimmed, $tag.' ')) {
                $ok = 1 === preg_match('/^'.preg_quote($tag, '/').'\s+OK\b/i', $trimmed);
                if (!$ok && $throwOnFailure) {
                    throw new \RuntimeException(sprintf('IMAP-kommandot misslyckades: %s', $trimmed));
                }

                return ['lines' => $lines, 'literals' => $literals, 'ok' => $ok];
            }
        }

        throw new \RuntimeException('IMAP-anslutningen stängdes innan kommandot blev klart.');
    }

    public function initialize(): void
    {
        $capability = $this->command('CAPABILITY', false);
        foreach ($capability['lines'] as $line) {
            if (str_starts_with(mb_strtoupper($line), '* CAPABILITY ')) {
                $this->capabilities = preg_split('/\s+/', mb_strtoupper(trim(substr($line, 13)))) ?: [];
            }
        }
        $selected = $this->command('SELECT "INBOX"');
        foreach ($selected['lines'] as $line) {
            if (preg_match('/\[UIDVALIDITY\s+(\d+)\]/i', $line, $matches)) {
                $this->uidValidity = $matches[1];
                break;
            }
        }
    }

    public function getUidValidity(): string { return $this->uidValidity; }

    public function prepareDestinationFolders(): void
    {
        $this->command('UID SEARCH ALL');
        $this->ensureFolder($this->mailbox->getProcessedFolderName());
        $this->ensureFolder($this->mailbox->getErrorFolderName());
    }

    /** @return list<array{remote_id: string, uid_validity: string, raw_message: string}> */
    public function fetchPendingMessages(): array
    {
        return iterator_to_array($this->iteratePendingMessages(), false);
    }

    /** @return \Generator<int, array{remote_id: string, uid_validity: string, raw_message: string}> */
    public function iteratePendingMessages(): \Generator
    {
        foreach ($this->pendingUids() as $uid) {
            yield $this->fetchMessage($uid);
        }
    }

    /** @return list<string> */
    public function pendingUids(): array
    {
        return $this->parseSearchIds($this->command('UID SEARCH UNSEEN')['lines']);
    }

    /** @return array{remote_id: string, uid_validity: string, raw_message: string} */
    public function fetchMessage(string $uid): array
    {
        $response = $this->command(sprintf('UID FETCH %s BODY.PEEK[]', $this->assertUid($uid)));
        $rawMessage = $response['literals'][0] ?? '';
        if ('' === trim($rawMessage)) {
            throw new \RuntimeException(sprintf('IMAP-meddelande UID %s saknar läsbart innehåll.', $uid));
        }

        return ['remote_id' => $uid, 'uid_validity' => $this->uidValidity, 'raw_message' => $rawMessage];
    }

    public function messageExists(string $uid): bool
    {
        $response = $this->command(sprintf('UID FETCH %s UID', $this->assertUid($uid)), false);
        foreach ($response['lines'] as $line) {
            if (preg_match('/^\*\s+\d+\s+FETCH\b/i', $line)) {
                return true;
            }
        }

        return false;
    }

    public function moveToProcessed(string $uid): void { $this->move($uid, $this->mailbox->getProcessedFolderName()); }
    public function moveToError(string $uid): void { $this->move($uid, $this->mailbox->getErrorFolderName()); }
    public function markSeen(string $uid): void { $this->command(sprintf('UID STORE %s +FLAGS.SILENT (\\Seen)', $this->assertUid($uid))); }

    public function close(): void
    {
        if ($this->closed) {
            return;
        }
        $this->closed = true;
        try { $this->command('LOGOUT'); } catch (\Throwable) {}
        fclose($this->stream);
    }

    public function __destruct() { $this->close(); }

    private function ensureFolder(string $folder): void
    {
        $list = $this->command(sprintf('LIST "" %s', $this->quote($folder)), false);
        $exists = false;
        foreach ($list['lines'] as $line) {
            if (str_starts_with(mb_strtoupper($line), '* LIST ')) { $exists = true; break; }
        }
        if (!$exists) { $this->command(sprintf('CREATE %s', $this->quote($folder))); }
    }

    private function move(string $uid, string $folder): void
    {
        $uid = $this->assertUid($uid);
        $destination = $this->quote($folder);
        if (\in_array('MOVE', $this->capabilities, true)) {
            $this->command(sprintf('UID STORE %s +FLAGS.SILENT (\\Seen)', $uid));
            $this->command(sprintf('UID MOVE %s %s', $uid, $destination));
            return;
        }
        $this->command(sprintf('UID COPY %s %s', $uid, $destination));
        $this->command(sprintf('UID STORE %s +FLAGS.SILENT (\\Seen \\Deleted)', $uid));
        if (\in_array('UIDPLUS', $this->capabilities, true)) {
            $this->command(sprintf('UID EXPUNGE %s', $uid));
        }
    }

    /** @param list<string> $lines
     *  @return list<string>
     */
    private function parseSearchIds(array $lines): array
    {
        foreach ($lines as $line) {
            if (str_starts_with(mb_strtoupper($line), '* SEARCH')) {
                $parts = preg_split('/\s+/', trim(substr($line, \strlen('* SEARCH')))) ?: [];
                return array_values(array_filter($parts, static fn (string $part): bool => 1 === preg_match('/^\d+$/', $part)));
            }
        }
        return [];
    }

    private function assertUid(string $uid): string
    {
        if (1 !== preg_match('/^\d+$/', $uid)) { throw new \InvalidArgumentException('Ogiltigt IMAP-UID.'); }
        return $uid;
    }

    private function quote(string $value): string
    {
        $encoded = mb_convert_encoding($value, 'UTF7-IMAP', 'UTF-8');

        return '"'.str_replace(['\\', '"'], ['\\\\', '\\"'], $encoded).'"';
    }
}
