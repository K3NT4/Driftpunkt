<?php

declare(strict_types=1);

namespace App\Module\Mail\Service;

interface MicrosoftOAuthSmtpConnectionFactoryInterface
{
    public function create(string $host, int $port, float $timeoutSeconds = 30.0): MicrosoftOAuthSmtpConnection;
}
