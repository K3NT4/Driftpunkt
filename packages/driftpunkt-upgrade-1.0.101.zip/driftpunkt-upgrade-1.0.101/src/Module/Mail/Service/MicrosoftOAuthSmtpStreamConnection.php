<?php

declare(strict_types=1);

namespace App\Module\Mail\Service;

final class MicrosoftOAuthSmtpStreamConnection implements MicrosoftOAuthSmtpConnection
{
    /**
     * @var resource
     */
    private $stream;

    /**
     * @param resource $stream
     */
    public function __construct($stream)
    {
        if (!\is_resource($stream)) {
            throw new \InvalidArgumentException('SMTP stream connection requires a valid stream resource.');
        }

        $this->stream = $stream;
    }

    public function readLine(): string
    {
        $line = fgets($this->stream);
        if (false === $line || '' === $line) {
            $meta = stream_get_meta_data($this->stream);
            if (($meta['timed_out'] ?? false) === true) {
                throw new \RuntimeException('SMTP-anslutningen tog för lång tid att läsa från.');
            }

            throw new \RuntimeException('SMTP-anslutningen stängdes oväntat.');
        }

        return $line;
    }

    public function write(string $command): void
    {
        $remaining = $command;
        while ('' !== $remaining) {
            $written = fwrite($this->stream, $remaining);
            if (false === $written || 0 === $written) {
                throw new \RuntimeException('Kunde inte skriva till SMTP-anslutningen.');
            }

            $remaining = substr($remaining, $written);
        }
    }

    public function enableCrypto(): bool
    {
        return true === stream_socket_enable_crypto(
            $this->stream,
            true,
            \STREAM_CRYPTO_METHOD_TLS_CLIENT | \STREAM_CRYPTO_METHOD_TLSv1_2_CLIENT,
        );
    }

    public function close(): void
    {
        if (\is_resource($this->stream)) {
            fclose($this->stream);
        }
    }
}
