<?php

declare(strict_types=1);

namespace App\Module\Mail\Service;

use App\Module\Mail\Entity\MailServer;
use Symfony\Component\DependencyInjection\Attribute\Autowire;
use Symfony\Component\Mime\Address;
use Symfony\Component\Mime\Email;

final class MicrosoftOAuthSmtpClient
{
    public function __construct(
        private readonly MicrosoftOAuthSmtpConnectionFactoryInterface $connectionFactory = new MicrosoftOAuthSmtpConnectionFactory(),
        #[Autowire('%env(DEFAULT_URI)%')]
        private readonly string $defaultUri = '',
    ) {
    }

    public function test(MailServer $server, string $accessToken): void
    {
        $connection = $this->connectAndAuthenticate($server, $accessToken);

        try {
            $this->command($connection, "QUIT\r\n", [221], 'SMTP QUIT misslyckades');
        } finally {
            $connection->close();
        }
    }

    public function send(MailServer $server, Email $email, string $accessToken): void
    {
        $email->ensureValidity();
        $connection = $this->connectAndAuthenticate($server, $accessToken);

        try {
            $sender = $this->senderAddress($email);
            $recipients = $this->recipientAddresses($email);

            if ([] === $recipients) {
                throw new \RuntimeException('E-postmeddelandet saknar mottagare.');
            }

            $this->command($connection, sprintf("MAIL FROM:<%s>\r\n", $sender), [250], 'SMTP MAIL FROM misslyckades');
            foreach ($recipients as $recipient) {
                $this->command($connection, sprintf("RCPT TO:<%s>\r\n", $recipient), [250, 251, 252], 'SMTP RCPT TO misslyckades');
            }

            $this->command($connection, "DATA\r\n", [354], 'SMTP DATA misslyckades');
            $connection->write($this->smtpData($email));
            $this->expect($connection, [250], 'SMTP-meddelandet kunde inte köas');
            $this->command($connection, "QUIT\r\n", [221], 'SMTP QUIT misslyckades');
        } finally {
            $connection->close();
        }
    }

    private function connectAndAuthenticate(MailServer $server, string $accessToken): MicrosoftOAuthSmtpConnection
    {
        $username = trim((string) $server->getUsername());
        if ('' === $username) {
            throw new \RuntimeException(sprintf('E-postservern "%s" kräver postlåda/UPN i användarnamnsfältet för Microsoft OAuth.', $server->getName()));
        }

        $connection = $this->createConnection($server);
        try {
            $this->expect($connection, [220], 'SMTP-servern svarade inte korrekt vid anslutning');

            $ehloDomain = $this->ehloDomain($server);
            $capabilities = $this->command($connection, sprintf("EHLO %s\r\n", $ehloDomain), [250], 'SMTP EHLO misslyckades');
            if (!$this->hasCapability($capabilities, 'STARTTLS')) {
                throw new \RuntimeException(sprintf(
                    'SMTP-servern annonserar inte STARTTLS efter EHLO (%s). Svar: %s',
                    $ehloDomain,
                    trim($capabilities),
                ));
            }

            $this->command($connection, "STARTTLS\r\n", [220], 'SMTP STARTTLS nekades av servern');
            if (!$connection->enableCrypto()) {
                throw new \RuntimeException('Kunde inte aktivera TLS på SMTP-anslutningen.');
            }

            $capabilities = $this->command($connection, sprintf("EHLO %s\r\n", $ehloDomain), [250], 'SMTP EHLO efter STARTTLS misslyckades');
            if (!$this->hasAuthMode($capabilities, 'XOAUTH2')) {
                throw new \RuntimeException('SMTP-servern annonserar inte XOAUTH2 efter STARTTLS.');
            }

            $payload = base64_encode(sprintf("user=%s\x01auth=Bearer %s\x01\x01", $username, $accessToken));
            $this->command($connection, sprintf("AUTH XOAUTH2 %s\r\n", $payload), [235], 'SMTP XOAUTH2-autentisering misslyckades');

            return $connection;
        } catch (\Throwable $exception) {
            $connection->close();

            throw $exception;
        }
    }

    private function createConnection(MailServer $server): MicrosoftOAuthSmtpConnection
    {
        return $this->connectionFactory->create($server->getHost(), $server->getPort(), 30.0);
    }

    /**
     * @param list<int> $expectedCodes
     */
    private function command(MicrosoftOAuthSmtpConnection $connection, string $command, array $expectedCodes, string $context): string
    {
        $connection->write($command);

        return $this->expect($connection, $expectedCodes, $context);
    }

    /**
     * @param list<int> $expectedCodes
     */
    private function expect(MicrosoftOAuthSmtpConnection $connection, array $expectedCodes, string $context): string
    {
        $response = '';
        $lastCode = null;

        do {
            $line = $connection->readLine();
            $response .= $line;
            $lastCode = (int) substr($line, 0, 3);
        } while (isset($line[3]) && '-' === $line[3]);

        if (!\in_array($lastCode, $expectedCodes, true)) {
            throw new \RuntimeException(sprintf('%s. Förväntade SMTP-kod %s men fick: %s', $context, implode('/', $expectedCodes), trim($response)));
        }

        return $response;
    }

    private function hasCapability(string $response, string $capability): bool
    {
        return 1 === preg_match(sprintf('/^250[ -]%s\b/im', preg_quote($capability, '/')), $response);
    }

    private function hasAuthMode(string $response, string $mode): bool
    {
        return 1 === preg_match(sprintf('/^250[ -]AUTH\b.*\b%s\b/im', preg_quote($mode, '/')), $response);
    }

    private function ehloDomain(MailServer $server): string
    {
        foreach ($this->ehloDomainCandidates($server) as $candidate) {
            $domain = $this->normalizeEhloDomain($candidate);
            if (null !== $domain) {
                return $domain;
            }
        }

        return 'localhost.localdomain';
    }

    /**
     * @return list<?string>
     */
    private function ehloDomainCandidates(MailServer $server): array
    {
        $hostname = gethostname();

        return [
            $this->defaultUri,
            $_SERVER['DEFAULT_URI'] ?? null,
            $_ENV['DEFAULT_URI'] ?? null,
            $_SERVER['HTTP_HOST'] ?? null,
            $_SERVER['SERVER_NAME'] ?? null,
            $this->addressDomain($server->getFromAddress()),
            $this->addressDomain($server->getUsername()),
            \is_string($hostname) ? $hostname : null,
        ];
    }

    private function normalizeEhloDomain(?string $candidate): ?string
    {
        $candidate = trim((string) $candidate);
        if ('' === $candidate) {
            return null;
        }

        $host = parse_url($candidate, \PHP_URL_HOST);
        if (!\is_string($host) || '' === trim($host)) {
            $host = $candidate;
        }

        $host = strtolower(trim($host));
        $host = preg_replace('/:\d+$/', '', $host) ?? $host;

        if (false !== filter_var($host, \FILTER_VALIDATE_IP)) {
            return null;
        }

        if (1 !== preg_match('/\A[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?(?:\.[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)+\z/', $host)) {
            return null;
        }

        return $host;
    }

    private function addressDomain(?string $address): ?string
    {
        $address = trim((string) $address);
        if (!str_contains($address, '@')) {
            return null;
        }

        return substr(strrchr($address, '@') ?: '', 1) ?: null;
    }

    private function senderAddress(Email $email): string
    {
        $sender = $email->getSender();
        if ($sender instanceof Address) {
            return $sender->getAddress();
        }

        $from = $email->getFrom();
        if ([] === $from) {
            throw new \RuntimeException('E-postmeddelandet saknar avsändare.');
        }

        return $from[0]->getAddress();
    }

    /**
     * @return list<string>
     */
    private function recipientAddresses(Email $email): array
    {
        $addresses = [];
        foreach ([$email->getTo(), $email->getCc(), $email->getBcc()] as $addressList) {
            foreach ($addressList as $address) {
                $addresses[$address->getAddress()] = $address->getAddress();
            }
        }

        return array_values($addresses);
    }

    private function smtpData(Email $email): string
    {
        $message = str_replace(["\r\n", "\r"], "\n", $email->toString());
        $message = preg_replace('/^\./m', '..', $message) ?? $message;
        $message = str_replace("\n", "\r\n", $message);

        return rtrim($message, "\r\n")."\r\n.\r\n";
    }
}
