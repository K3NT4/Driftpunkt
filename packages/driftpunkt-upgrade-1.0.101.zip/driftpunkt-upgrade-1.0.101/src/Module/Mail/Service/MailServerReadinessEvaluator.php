<?php

declare(strict_types=1);

namespace App\Module\Mail\Service;

use App\Module\Mail\Entity\MailServer;
use App\Module\Mail\Enum\MailAuthenticationMode;
use App\Module\Mail\Enum\MailEncryption;

final class MailServerReadinessEvaluator
{
    public function __construct(
        private readonly GoogleOAuthTokenProvider $googleOAuthTokenProvider,
    ) {
    }

    /**
     * @return array{
     *     status: 'ready'|'needs_attention',
     *     summary: string,
     *     issues: list<string>,
     *     requirements: list<string>
     * }
     */
    public function evaluate(MailServer $server): array
    {
        $issues = [];
        $requirements = [];

        if (!$server->isActive()) {
            $issues[] = 'Servern är sparad som inaktiv.';
        }

        if (MailAuthenticationMode::MICROSOFT_OAUTH === $server->getAuthenticationMode()) {
            $issues = [...$issues, ...$this->microsoftOAuthIssues($server)];
            $requirements = $this->microsoftOAuthRequirements($server);
        } elseif (MailAuthenticationMode::GOOGLE_OAUTH === $server->getAuthenticationMode()) {
            if (!$this->googleOAuthTokenProvider->isConfigured()) {
                $issues[] = 'Google OAuth-klient eller mailens krypteringsnyckel saknas i miljökonfigurationen.';
            }
            if ('imap.gmail.com' !== mb_strtolower($server->getHost()) || 993 !== $server->getPort() || MailEncryption::SSL !== $server->getEncryption()) {
                $issues[] = 'Google Workspace IMAP ska använda `imap.gmail.com:993` med SSL/TLS.';
            }
            $requirements = [
                'Google Cloud OAuth-klient med en registrerad callback-URL.',
                'Gmail-scope `https://mail.google.com/` och offlineåtkomst.',
                'Varje supportinkorg måste anslutas separat av superadmin.',
            ];
        } else {
            if (null === $server->getUsername()) {
                $issues[] = 'Användarnamn saknas.';
            }

            if (null === $server->getPassword()) {
                $issues[] = 'Lösenord eller token saknas.';
            }
        }

        return [
            'status' => [] === $issues ? 'ready' : 'needs_attention',
            'summary' => [] === $issues ? 'Konfigurationen ser komplett ut.' : 'Konfigurationen behöver kompletteras innan den är redo.',
            'issues' => $issues,
            'requirements' => $requirements,
        ];
    }

    /**
     * @return list<string>
     */
    private function microsoftOAuthIssues(MailServer $server): array
    {
        $issues = [];

        if (null === $server->getUsername()) {
            $issues[] = 'Postlådans UPN saknas i användarnamnsfältet.';
        }

        if (null === $server->getOauthTenantId()) {
            $issues[] = 'Tenant ID saknas.';
        }

        if (null === $server->getOauthClientId()) {
            $issues[] = 'Client ID saknas.';
        }

        if (null === $server->getOauthClientSecret()) {
            $issues[] = 'Client secret saknas.';
        }

        if ('imap' === $server->getTransportType()) {
            if ('outlook.office365.com' !== mb_strtolower($server->getHost())) {
                $issues[] = 'Microsoft 365 IMAP bör använda host `outlook.office365.com`.';
            }

            if (993 !== $server->getPort()) {
                $issues[] = 'Microsoft 365 IMAP bör använda port 993.';
            }

            if (MailEncryption::SSL !== $server->getEncryption()) {
                $issues[] = 'Microsoft 365 IMAP bör använda kryptering `SSL/TLS`.';
            }
        }

        if ('smtp' === $server->getTransportType()) {
            if ('smtp.office365.com' !== mb_strtolower($server->getHost())) {
                $issues[] = 'Microsoft 365 SMTP bör använda host `smtp.office365.com`.';
            }

            if (587 !== $server->getPort()) {
                $issues[] = 'Microsoft 365 SMTP bör använda port 587.';
            }

            if (MailEncryption::STARTTLS !== $server->getEncryption()) {
                $issues[] = 'Microsoft 365 SMTP bör använda kryptering `STARTTLS`.';
            }

            if (null === $server->getFromAddress()) {
                $issues[] = 'Från-adress saknas för utgående Microsoft 365-server.';
            }
        }

        return $issues;
    }

    /**
     * @return list<string>
     */
    private function microsoftOAuthRequirements(MailServer $server): array
    {
        $requirements = [
            'App registration i Microsoft Entra ID.',
            'Admin consent för Exchange Online-behörigheter.',
            'Registrerad service principal i Exchange Online för app-only access.',
        ];

        if ('imap' === $server->getTransportType()) {
            $requirements[] = 'Application permission `IMAP.AccessAsApp` i Office 365 Exchange Online.';
        }

        if ('smtp' === $server->getTransportType()) {
            $requirements[] = 'Application permission `SMTP.SendAsApp` i Office 365 Exchange Online.';
            $requirements[] = 'Domänen i Från-adressen bör ha korrekt SPF, DKIM och DMARC.';
        }

        return $requirements;
    }
}
