<?php

declare(strict_types=1);

namespace App\Module\Mail\Service;

use App\Module\Mail\Entity\SupportMailbox;
use App\Module\Mail\Exception\GoogleAuthorizationRequiredException;
use App\Module\System\Service\SystemSettings;
use Symfony\Component\DependencyInjection\Attribute\Autowire;
use Symfony\Contracts\HttpClient\HttpClientInterface;

final class GoogleOAuthTokenProvider
{
    private const AUTHORIZATION_ENDPOINT = 'https://accounts.google.com/o/oauth2/v2/auth';
    private const TOKEN_ENDPOINT = 'https://oauth2.googleapis.com/token';
    private const USERINFO_ENDPOINT = 'https://openidconnect.googleapis.com/v1/userinfo';
    private const REVOCATION_ENDPOINT = 'https://oauth2.googleapis.com/revoke';
    private const SCOPES = 'openid email https://mail.google.com/';

    /** @var array<int, array{access_token: string, expires_at: int}> */
    private array $tokenCache = [];

    public function __construct(
        private readonly HttpClientInterface $httpClient,
        private readonly MailSecretCipher $mailSecretCipher,
        #[Autowire('%env(GOOGLE_MAIL_OAUTH_CLIENT_ID)%')]
        private readonly string $clientId,
        #[Autowire('%env(GOOGLE_MAIL_OAUTH_CLIENT_SECRET)%')]
        private readonly string $clientSecret,
        private readonly ?SystemSettings $systemSettings = null,
    ) {
    }

    public function isConfigured(): bool
    {
        if (!$this->mailSecretCipher->isConfigured()) {
            return false;
        }

        try {
            return '' !== $this->configuredClientId() && '' !== $this->configuredClientSecret();
        } catch (\Throwable) {
            return false;
        }
    }

    /** @return array{configured: bool, clientId: string, clientSecretStored: bool, source: 'admin'|'environment'|'none', encryptionReady: bool} */
    public function configurationStatus(): array
    {
        $storedClientId = $this->storedClientId();
        $storedSecret = $this->storedEncryptedClientSecret();
        $source = '' !== $storedClientId || '' !== $storedSecret
            ? 'admin'
            : ('' !== trim($this->clientId) || '' !== trim($this->clientSecret) ? 'environment' : 'none');

        return [
            'configured' => $this->isConfigured(),
            'clientId' => '' !== $storedClientId ? $storedClientId : trim($this->clientId),
            'clientSecretStored' => '' !== $storedSecret || '' !== trim($this->clientSecret),
            'source' => $source,
            'encryptionReady' => $this->mailSecretCipher->isConfigured(),
        ];
    }

    public function saveConfiguration(string $clientId, ?string $clientSecret): void
    {
        if (!$this->systemSettings instanceof SystemSettings) {
            throw new \RuntimeException('Google OAuth-konfiguration kan inte sparas i den här körmiljön.');
        }
        $clientId = trim($clientId);
        $clientSecret = null !== $clientSecret ? trim($clientSecret) : null;
        if ('' === $clientId || mb_strlen($clientId) > 500) {
            throw new \InvalidArgumentException('Ange ett giltigt Google OAuth klient-ID.');
        }
        if (null !== $clientSecret && '' !== $clientSecret && mb_strlen($clientSecret) > 2000) {
            throw new \InvalidArgumentException('Google OAuth-klienthemligheten är för lång.');
        }
        if ((null === $clientSecret || '' === $clientSecret) && '' === $this->configuredClientSecret()) {
            throw new \InvalidArgumentException('Ange Google OAuth-klienthemligheten.');
        }

        $encryptedSecret = null;
        if (null !== $clientSecret && '' !== $clientSecret) {
            $encryptedSecret = $this->mailSecretCipher->encrypt($clientSecret);
        }
        $this->systemSettings->setString(SystemSettings::GOOGLE_MAIL_OAUTH_CLIENT_ID, $clientId);
        if (null !== $encryptedSecret) {
            $this->systemSettings->setString(SystemSettings::GOOGLE_MAIL_OAUTH_CLIENT_SECRET_ENCRYPTED, $encryptedSecret);
        }
    }

    public function clearStoredConfiguration(): void
    {
        if (!$this->systemSettings instanceof SystemSettings) {
            throw new \RuntimeException('Google OAuth-konfiguration kan inte rensas i den här körmiljön.');
        }
        $this->systemSettings->setString(SystemSettings::GOOGLE_MAIL_OAUTH_CLIENT_ID, '');
        $this->systemSettings->setString(SystemSettings::GOOGLE_MAIL_OAUTH_CLIENT_SECRET_ENCRYPTED, '');
    }

    public function authorizationUrl(string $redirectUri, string $state, string $codeChallenge): string
    {
        $this->assertConfigured();
        $clientId = $this->configuredClientId();

        return self::AUTHORIZATION_ENDPOINT.'?'.http_build_query([
            'client_id' => $clientId,
            'redirect_uri' => $redirectUri,
            'response_type' => 'code',
            'scope' => self::SCOPES,
            'access_type' => 'offline',
            'prompt' => 'consent',
            'include_granted_scopes' => 'true',
            'state' => $state,
            'code_challenge' => $codeChallenge,
            'code_challenge_method' => 'S256',
        ], '', '&', \PHP_QUERY_RFC3986);
    }

    /** @return array{refresh_token: string, email: string} */
    public function exchangeAuthorizationCode(string $code, string $redirectUri, string $codeVerifier): array
    {
        $this->assertConfigured();
        $clientId = $this->configuredClientId();
        $clientSecret = $this->configuredClientSecret();
        $payload = $this->tokenRequest([
            'client_id' => $clientId,
            'client_secret' => $clientSecret,
            'code' => $code,
            'code_verifier' => $codeVerifier,
            'redirect_uri' => $redirectUri,
            'grant_type' => 'authorization_code',
        ]);

        $refreshToken = trim((string) ($payload['refresh_token'] ?? ''));
        $accessToken = trim((string) ($payload['access_token'] ?? ''));
        if ('' === $refreshToken || '' === $accessToken) {
            throw new \RuntimeException('Google returnerade inte nödvändig offlineåtkomst. Försök ansluta kontot igen.');
        }

        $userinfo = $this->httpClient->request('GET', self::USERINFO_ENDPOINT, [
            'auth_bearer' => $accessToken,
        ])->toArray(false);
        $email = mb_strtolower(trim((string) ($userinfo['email'] ?? '')));
        if ('' === $email || false === (bool) ($userinfo['email_verified'] ?? false)) {
            throw new \RuntimeException('Google-kontots verifierade e-postadress kunde inte läsas.');
        }

        return ['refresh_token' => $refreshToken, 'email' => $email];
    }

    public function encryptRefreshToken(string $refreshToken): string
    {
        return $this->mailSecretCipher->encrypt($refreshToken);
    }

    public function accessTokenFor(SupportMailbox $mailbox): string
    {
        $this->assertConfigured();
        $mailboxId = $mailbox->getId();
        if (null === $mailboxId || !$mailbox->hasGoogleAuthorization()) {
            throw new \RuntimeException('Google-kontot måste anslutas igen för den här inkorgen.');
        }

        $cached = $this->tokenCache[$mailboxId] ?? null;
        if (\is_array($cached) && $cached['expires_at'] > time() + 60) {
            return $cached['access_token'];
        }

        try {
            $refreshToken = $this->mailSecretCipher->decrypt((string) $mailbox->getGoogleRefreshTokenEncrypted());
        } catch (\Throwable) {
            throw new GoogleAuthorizationRequiredException();
        }

        $response = $this->httpClient->request('POST', self::TOKEN_ENDPOINT, ['body' => [
            'client_id' => $this->configuredClientId(),
            'client_secret' => $this->configuredClientSecret(),
            'refresh_token' => $refreshToken,
            'grant_type' => 'refresh_token',
        ]]);
        $payload = $response->toArray(false);
        if (\is_array($payload) && 'invalid_grant' === ($payload['error'] ?? null)) {
            throw new GoogleAuthorizationRequiredException();
        }
        if (!\is_array($payload) || isset($payload['error'])) {
            throw new \RuntimeException('Google OAuth kunde inte förnya åtkomsten. Försök igen senare.');
        }
        $accessToken = trim((string) ($payload['access_token'] ?? ''));
        if ('' === $accessToken) {
            throw new GoogleAuthorizationRequiredException();
        }

        $this->tokenCache[$mailboxId] = [
            'access_token' => $accessToken,
            'expires_at' => time() + max(120, (int) ($payload['expires_in'] ?? 300)),
        ];

        return $accessToken;
    }

    public function revokeFor(SupportMailbox $mailbox): void
    {
        if (!$mailbox->hasGoogleAuthorization() || !$this->mailSecretCipher->isConfigured()) {
            return;
        }
        $refreshToken = $this->mailSecretCipher->decrypt((string) $mailbox->getGoogleRefreshTokenEncrypted());
        $this->httpClient->request('POST', self::REVOCATION_ENDPOINT, [
            'body' => ['token' => $refreshToken],
        ])->getStatusCode();
        if (null !== $mailbox->getId()) {
            unset($this->tokenCache[$mailbox->getId()]);
        }
    }

    /** @param array<string, string> $body
     *  @return array<string, mixed>
     */
    private function tokenRequest(array $body): array
    {
        $response = $this->httpClient->request('POST', self::TOKEN_ENDPOINT, ['body' => $body]);
        $payload = $response->toArray(false);
        if (!\is_array($payload) || isset($payload['error'])) {
            throw new \RuntimeException('Google OAuth kunde inte slutföras. Kontot kan behöva anslutas igen.');
        }

        return $payload;
    }

    private function assertConfigured(): void
    {
        if (!$this->isConfigured()) {
            throw new \RuntimeException('Google OAuth måste konfigureras av superadmin innan en Google-inkorg kan anslutas.');
        }
    }

    private function configuredClientId(): string
    {
        $stored = $this->storedClientId();

        return '' !== $stored ? $stored : trim($this->clientId);
    }

    private function configuredClientSecret(): string
    {
        $stored = $this->storedEncryptedClientSecret();
        if ('' !== $stored) {
            return $this->mailSecretCipher->decrypt($stored);
        }

        return trim($this->clientSecret);
    }

    private function storedClientId(): string
    {
        return $this->systemSettings?->getString(SystemSettings::GOOGLE_MAIL_OAUTH_CLIENT_ID, '') ?? '';
    }

    private function storedEncryptedClientSecret(): string
    {
        return $this->systemSettings?->getString(SystemSettings::GOOGLE_MAIL_OAUTH_CLIENT_SECRET_ENCRYPTED, '') ?? '';
    }
}
