<?php

declare(strict_types=1);

namespace App\Module\Mail\Service;

final class MicrosoftOAuthSmtpConnectionFactory implements MicrosoftOAuthSmtpConnectionFactoryInterface
{
    public function create(string $host, int $port, float $timeoutSeconds = 30.0): MicrosoftOAuthSmtpConnection
    {
        $target = sprintf('tcp://%s:%d', $host, $port);
        $context = stream_context_create([
            'ssl' => [
                'crypto_method' => \STREAM_CRYPTO_METHOD_TLS_CLIENT | \STREAM_CRYPTO_METHOD_TLSv1_2_CLIENT,
                'peer_name' => $host,
                'verify_peer' => true,
                'verify_peer_name' => true,
            ],
        ]);

        $stream = @stream_socket_client(
            $target,
            $errno,
            $error,
            $timeoutSeconds,
            \STREAM_CLIENT_CONNECT,
            $context,
        );

        if (false === $stream) {
            throw new \RuntimeException(sprintf('Kunde inte ansluta till SMTP-servern "%s": %s (%d).', $target, $error, $errno));
        }

        stream_set_blocking($stream, true);
        stream_set_timeout($stream, (int) $timeoutSeconds, (int) (($timeoutSeconds - (int) $timeoutSeconds) * 1000000));

        return new MicrosoftOAuthSmtpStreamConnection($stream);
    }
}
