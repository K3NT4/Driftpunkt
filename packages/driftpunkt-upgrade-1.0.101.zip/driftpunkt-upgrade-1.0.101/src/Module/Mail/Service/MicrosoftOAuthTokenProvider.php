<?php

declare(strict_types=1);

namespace App\Module\Mail\Service;

use App\Module\Mail\Entity\MailServer;
use Symfony\Contracts\HttpClient\HttpClientInterface;

final class MicrosoftOAuthTokenProvider
{
    /**
     * @var array<string, array{access_token: string, expires_at: int}>
     */
    private array $tokenCache = [];

    public function __construct(
        private readonly HttpClientInterface $httpClient,
    ) {
    }

    public function accessTokenFor(MailServer $server): string
    {
        if (!$server->usesMicrosoftOAuth()) {
            throw new \RuntimeException('Microsoft OAuth är inte aktiverat för den här mailservern.');
        }

        $tenantId = trim((string) $server->getOauthTenantId());
        $clientId = trim((string) $server->getOauthClientId());
        $clientSecret = trim((string) $server->getOauthClientSecret());

        if ('' === $tenantId || '' === $clientId || '' === $clientSecret) {
            throw new \RuntimeException('Microsoft OAuth kräver tenant ID, client ID och client secret.');
        }

        $cacheKey = hash('sha256', implode('|', [$tenantId, $clientId, (string) $server->getId()]));
        $cachedToken = $this->tokenCache[$cacheKey] ?? null;
        if (\is_array($cachedToken) && ($cachedToken['expires_at'] ?? 0) > time() + 60) {
            return $cachedToken['access_token'];
        }

        $response = $this->httpClient->request('POST', sprintf('https://login.microsoftonline.com/%s/oauth2/v2.0/token', rawurlencode($tenantId)), [
            'body' => [
                'client_id' => $clientId,
                'client_secret' => $clientSecret,
                'scope' => 'https://outlook.office365.com/.default',
                'grant_type' => 'client_credentials',
            ],
        ]);

        /** @var array{access_token?: string, expires_in?: int, error?: string, error_description?: string} $payload */
        $payload = $response->toArray(false);
        $accessToken = (string) ($payload['access_token'] ?? '');

        if ('' === $accessToken) {
            throw new \RuntimeException(sprintf(
                'Microsoft OAuth-token kunde inte hämtas.%s',
                isset($payload['error_description']) ? ' '.$payload['error_description'] : '',
            ));
        }

        $this->tokenCache[$cacheKey] = [
            'access_token' => $accessToken,
            'expires_at' => time() + max(120, (int) ($payload['expires_in'] ?? 300)),
        ];

        return $accessToken;
    }
}
