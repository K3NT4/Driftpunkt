<?php

declare(strict_types=1);

namespace App\Module\Mail\Service;

interface MicrosoftOAuthSmtpConnection
{
    public function readLine(): string;

    public function write(string $command): void;

    public function enableCrypto(): bool;

    public function close(): void;
}
