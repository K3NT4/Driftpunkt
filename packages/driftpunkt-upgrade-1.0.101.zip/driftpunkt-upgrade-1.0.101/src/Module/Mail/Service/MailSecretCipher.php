<?php

declare(strict_types=1);

namespace App\Module\Mail\Service;

use Symfony\Component\DependencyInjection\Attribute\Autowire;

final class MailSecretCipher
{
    private const CIPHER = 'aes-256-gcm';
    private const KEY_BYTES = 32;
    private const NONCE_BYTES = 12;
    private const TAG_BYTES = 16;

    private ?string $key = null;

    public function __construct(
        #[Autowire('%env(DRIFTPUNKT_MAIL_SECRET_KEY)%')]
        string $encodedKey,
        #[Autowire('%env(APP_SECRET)%')]
        string $appSecret = '',
    ) {
        $decoded = base64_decode(trim($encodedKey), true);
        if (\is_string($decoded) && self::KEY_BYTES === \strlen($decoded)) {
            $this->key = $decoded;
        } elseif ('' !== trim($appSecret)) {
            $this->key = hash_hkdf('sha256', $appSecret, self::KEY_BYTES, 'driftpunkt-mail-secret-v1');
        }
    }

    public function isConfigured(): bool
    {
        return null !== $this->key;
    }

    public function encrypt(string $plaintext): string
    {
        if (null === $this->key) {
            throw new \RuntimeException('Tokenkryptering kräver APP_SECRET eller en separat DRIFTPUNKT_MAIL_SECRET_KEY.');
        }

        $nonce = random_bytes(self::NONCE_BYTES);
        $tag = '';
        $ciphertext = openssl_encrypt($plaintext, self::CIPHER, $this->key, \OPENSSL_RAW_DATA, $nonce, $tag);
        if (false === $ciphertext || self::TAG_BYTES !== \strlen($tag)) {
            throw new \RuntimeException('Mailhemligheten kunde inte krypteras.');
        }

        return 'v1:'.base64_encode($nonce.$tag.$ciphertext);
    }

    public function decrypt(string $encrypted): string
    {
        if (null === $this->key) {
            throw new \RuntimeException('DRIFTPUNKT_MAIL_SECRET_KEY saknas eller är ogiltig.');
        }

        if (!str_starts_with($encrypted, 'v1:')) {
            throw new \RuntimeException('Den lagrade mailhemligheten har ett okänt format.');
        }

        $payload = base64_decode(substr($encrypted, 3), true);
        if (!\is_string($payload) || \strlen($payload) <= self::NONCE_BYTES + self::TAG_BYTES) {
            throw new \RuntimeException('Den lagrade mailhemligheten är skadad.');
        }

        $nonce = substr($payload, 0, self::NONCE_BYTES);
        $tag = substr($payload, self::NONCE_BYTES, self::TAG_BYTES);
        $ciphertext = substr($payload, self::NONCE_BYTES + self::TAG_BYTES);
        $plaintext = openssl_decrypt($ciphertext, self::CIPHER, $this->key, \OPENSSL_RAW_DATA, $nonce, $tag);

        if (false === $plaintext) {
            throw new \RuntimeException('Den lagrade mailhemligheten kunde inte dekrypteras.');
        }

        return $plaintext;
    }
}
