<?php

declare(strict_types=1);

namespace App\Module\Mail\Service;

use App\Module\Mail\Entity\MailServer;
use App\Module\Mail\Entity\SupportMailbox;
use App\Module\Mail\Enum\MailEncryption;

final class ImapMailboxFetcher
{
    public function __construct(
        private readonly MicrosoftOAuthTokenProvider $microsoftOAuthTokenProvider,
        private readonly GoogleOAuthTokenProvider $googleOAuthTokenProvider,
    ) {
    }

    public function supports(SupportMailbox $mailbox): bool
    {
        $server = $mailbox->getIncomingServer();
        if (!$server instanceof MailServer || !$server->supportsIncoming() || 'imap' !== $server->getTransportType()) {
            return false;
        }
        if ($server->usesGoogleOAuth()) {
            return $mailbox->hasGoogleAuthorization() && $this->googleOAuthTokenProvider->isConfigured();
        }

        return null !== $server->getUsername()
            && (($server->usesPasswordAuthentication() && null !== $server->getPassword()) || $server->usesMicrosoftOAuth());
    }

    public function openSession(SupportMailbox $mailbox): ImapMailboxSession
    {
        $server = $mailbox->getIncomingServer();
        if (!$server instanceof MailServer) {
            throw new \RuntimeException('Inkorgen saknar inkommande IMAP-server.');
        }
        $stream = $this->openStream($server);
        $session = new ImapMailboxSession($stream, $mailbox);
        try {
            if (\in_array($server->getEncryption(), [MailEncryption::TLS, MailEncryption::STARTTLS], true)) {
                $session->command('STARTTLS');
                if (!stream_socket_enable_crypto($stream, true, \STREAM_CRYPTO_METHOD_TLS_CLIENT)) {
                    throw new \RuntimeException('Kunde inte starta TLS mot IMAP-servern.');
                }
            }
            if ($server->usesMicrosoftOAuth()) {
                $this->authenticateXoauth2($session, (string) $server->getUsername(), $this->microsoftOAuthTokenProvider->accessTokenFor($server), 'Microsoft');
            } elseif ($server->usesGoogleOAuth()) {
                $this->authenticateXoauth2($session, $mailbox->getEmailAddress(), $this->googleOAuthTokenProvider->accessTokenFor($mailbox), 'Google');
            } else {
                $session->command(sprintf('LOGIN %s %s', $this->quote((string) $server->getUsername()), $this->quote((string) $server->getPassword())));
            }
            $session->initialize();

            return $session;
        } catch (\Throwable $exception) {
            $session->close();
            throw $exception;
        }
    }

    /** @return list<array{remote_id: string, uid_validity: string, raw_message: string}> */
    public function fetchPendingMessages(SupportMailbox $mailbox): array
    {
        $session = $this->openSession($mailbox);
        try { return $session->fetchPendingMessages(); } finally { $session->close(); }
    }

    public function acknowledge(SupportMailbox $mailbox, string $remoteId): void
    {
        $session = $this->openSession($mailbox);
        try { $session->markSeen($remoteId); } finally { $session->close(); }
    }

    public function testIncomingServer(MailServer $server): void
    {
        if ($server->usesGoogleOAuth()) {
            throw new \RuntimeException('Google OAuth testas från den anslutna supportinkorgen.');
        }
        $mailbox = (new SupportMailbox('Anslutningstest', (string) ($server->getUsername() ?? 'test@example.invalid')))
            ->setIncomingServer($server);
        $session = $this->openSession($mailbox);
        $session->close();
    }

    public function testMailbox(SupportMailbox $mailbox): void
    {
        $session = $this->openSession($mailbox);
        try { $session->prepareDestinationFolders(); } finally { $session->close(); }
    }

    /** @return resource */
    private function openStream(MailServer $server)
    {
        $remote = MailEncryption::SSL === $server->getEncryption()
            ? sprintf('ssl://%s:%d', $server->getHost(), $server->getPort())
            : sprintf('tcp://%s:%d', $server->getHost(), $server->getPort());
        $stream = @stream_socket_client($remote, $errorCode, $errorMessage, 15, \STREAM_CLIENT_CONNECT);
        if (!\is_resource($stream)) {
            throw new \RuntimeException(sprintf('Kunde inte ansluta till IMAP-servern: %s (%d).', $errorMessage, $errorCode));
        }
        stream_set_timeout($stream, 15);
        $line = fgets($stream);
        if (false === $line || !str_starts_with(trim($line), '* OK')) {
            fclose($stream);
            throw new \RuntimeException('IMAP-servern svarade inte med en giltig greeting.');
        }

        return $stream;
    }

    private function authenticateXoauth2(ImapMailboxSession $session, string $user, string $accessToken, string $provider): void
    {
        if ('' === trim($user)) { throw new \RuntimeException(sprintf('%s OAuth kräver en e-postadress/UPN.', $provider)); }
        $payload = base64_encode(sprintf("user=%s\x01auth=Bearer %s\x01\x01", trim($user), $accessToken));
        $session->command(sprintf('AUTHENTICATE XOAUTH2 %s', $payload), true, true);
    }

    private function quote(string $value): string
    {
        return '"'.str_replace(['\\', '"'], ['\\\\', '\\"'], $value).'"';
    }
}
