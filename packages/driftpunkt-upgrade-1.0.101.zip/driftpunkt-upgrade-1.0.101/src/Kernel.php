<?php

namespace App;

use App\Infrastructure\Database\DatabaseUrlRequirement;
use App\Module\System\Service\ActiveAddonRuntime;
use Symfony\Bundle\FrameworkBundle\Kernel\MicroKernelTrait;
use Symfony\Component\Config\Loader\LoaderInterface;
use Symfony\Component\DependencyInjection\ContainerBuilder;
use Symfony\Component\DependencyInjection\Loader\Configurator\ContainerConfigurator;
use Symfony\Component\HttpKernel\Kernel as BaseKernel;
use Symfony\Component\Routing\Loader\Configurator\RoutingConfigurator;

class Kernel extends BaseKernel
{
    use MicroKernelTrait {
        configureContainer as private configureBaseContainer;
        configureRoutes as private configureBaseRoutes;
    }

    public function __construct(string $environment, bool $debug)
    {
        ActiveAddonRuntime::registerAutoloader(dirname(__DIR__));
        DatabaseUrlRequirement::assertSatisfied($environment, self::databaseUrl());

        parent::__construct($environment, $debug);
    }

    private function configureContainer(ContainerConfigurator $container, LoaderInterface $loader, ContainerBuilder $builder): void
    {
        $this->configureBaseContainer($container, $loader, $builder);

        $addonSourceRoots = ActiveAddonRuntime::activeSourceRoots($this->getProjectDir());
        if ([] !== $addonSourceRoots) {
            $services = $container->services()
                ->defaults()
                    ->autowire()
                    ->autoconfigure();

            foreach ($addonSourceRoots as $sourceRoot) {
                $services->load('App\\', $sourceRoot.\DIRECTORY_SEPARATOR)
                    ->exclude([
                        $sourceRoot.\DIRECTORY_SEPARATOR.'DependencyInjection',
                        $sourceRoot.\DIRECTORY_SEPARATOR.'Entity',
                        $sourceRoot.\DIRECTORY_SEPARATOR.'Kernel.php',
                    ]);
            }
        }

        $addonTemplateRoots = ActiveAddonRuntime::activeTemplateRoots($this->getProjectDir());
        if ([] !== $addonTemplateRoots) {
            $container->extension('twig', [
                'paths' => $addonTemplateRoots,
            ]);
        }
    }

    private function configureRoutes(RoutingConfigurator $routes): void
    {
        $this->configureBaseRoutes($routes);

        foreach (ActiveAddonRuntime::activeRouteRoots($this->getProjectDir()) as $routeRoot) {
            $routes->import($routeRoot.\DIRECTORY_SEPARATOR, 'attribute');
        }
    }

    public function getCacheDir(): string
    {
        $cacheDir = $_SERVER['APP_CACHE_DIR'] ?? $_ENV['APP_CACHE_DIR'] ?? getenv('APP_CACHE_DIR');
        if (is_string($cacheDir) && '' !== trim($cacheDir)) {
            return $cacheDir;
        }

        return parent::getCacheDir();
    }

    private static function databaseUrl(): ?string
    {
        $databaseUrl = $_SERVER['DATABASE_URL'] ?? $_ENV['DATABASE_URL'] ?? getenv('DATABASE_URL');

        return false === $databaseUrl ? null : (string) $databaseUrl;
    }
}
