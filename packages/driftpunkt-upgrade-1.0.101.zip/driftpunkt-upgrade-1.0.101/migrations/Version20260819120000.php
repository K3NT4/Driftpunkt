<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

final class Version20260819120000 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Adds durable logical merges between source and target tickets';
    }

    public function up(Schema $schema): void
    {
        if ($schema->hasTable('ticket_merges') || !$schema->hasTable('tickets') || !$schema->hasTable('users')) {
            return;
        }

        $table = $schema->createTable('ticket_merges');
        $table->addColumn('id', 'integer', ['autoincrement' => true]);
        $table->addColumn('source_ticket_id', 'integer');
        $table->addColumn('target_ticket_id', 'integer');
        $table->addColumn('merged_by_id', 'integer', ['notnull' => false]);
        $table->addColumn('created_at', 'datetime_immutable');
        $table->addColumn('updated_at', 'datetime_immutable');
        $table->setPrimaryKey(['id']);
        $table->addUniqueIndex(['source_ticket_id'], 'uniq_ticket_merge_source');
        $table->addIndex(['target_ticket_id'], 'IDX_TICKET_MERGE_TARGET');
        $table->addIndex(['merged_by_id'], 'IDX_TICKET_MERGE_ACTOR');
        $table->addForeignKeyConstraint('tickets', ['source_ticket_id'], ['id'], ['onDelete' => 'CASCADE'], 'FK_TICKET_MERGE_SOURCE');
        $table->addForeignKeyConstraint('tickets', ['target_ticket_id'], ['id'], ['onDelete' => 'RESTRICT'], 'FK_TICKET_MERGE_TARGET');
        $table->addForeignKeyConstraint('users', ['merged_by_id'], ['id'], ['onDelete' => 'SET NULL'], 'FK_TICKET_MERGE_ACTOR');
    }

    public function down(Schema $schema): void
    {
        if ($schema->hasTable('ticket_merges')) {
            $schema->dropTable('ticket_merges');
        }
    }
}
