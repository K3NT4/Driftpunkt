<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

final class Version20260718170000 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Adds internal reports from technicians and ticket coordinators';
    }

    public function up(Schema $schema): void
    {
        if ($schema->hasTable('internal_reports')) {
            return;
        }

        $table = $schema->createTable('internal_reports');
        $table->addColumn('id', 'integer', ['autoincrement' => true]);
        $table->addColumn('reporter_id', 'integer', ['notnull' => false]);
        $table->addColumn('reporter_email', 'string', ['length' => 180]);
        $table->addColumn('reporter_name', 'string', ['length' => 180]);
        $table->addColumn('type', 'string', ['length' => 32]);
        $table->addColumn('subject', 'string', ['length' => 180]);
        $table->addColumn('description', 'text');
        $table->addColumn('status', 'string', ['length' => 24, 'default' => 'open']);
        $table->addColumn('admin_note', 'text', ['notnull' => false]);
        $table->addColumn('created_at', 'datetime_immutable');
        $table->addColumn('updated_at', 'datetime_immutable');
        $table->addColumn('resolved_at', 'datetime_immutable', ['notnull' => false]);
        $table->addColumn('resolved_by_email', 'string', ['length' => 180, 'notnull' => false]);
        $table->setPrimaryKey(['id']);
        $table->addIndex(['status', 'created_at'], 'idx_internal_reports_status_created');
        $table->addIndex(['reporter_id'], 'idx_internal_reports_reporter');
        $table->addForeignKeyConstraint('users', ['reporter_id'], ['id'], ['onDelete' => 'SET NULL'], 'fk_internal_reports_reporter');
    }

    public function down(Schema $schema): void
    {
        if ($schema->hasTable('internal_reports')) {
            $schema->dropTable('internal_reports');
        }
    }
}
