<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

final class Version20260428143000 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Adds structured details to ticket audit logs';
    }

    public function up(Schema $schema): void
    {
        if (!$schema->hasTable('ticket_audit_logs')) {
            return;
        }

        $table = $schema->getTable('ticket_audit_logs');
        if (!$table->hasColumn('details')) {
            $table->addColumn('details', 'json', ['default' => '[]']);
        }
    }

    public function down(Schema $schema): void
    {
        if (!$schema->hasTable('ticket_audit_logs')) {
            return;
        }

        $table = $schema->getTable('ticket_audit_logs');
        if ($table->hasColumn('details')) {
            $table->dropColumn('details');
        }
    }
}
