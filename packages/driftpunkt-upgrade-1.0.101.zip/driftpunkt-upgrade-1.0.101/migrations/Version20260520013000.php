<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Platforms\AbstractMySQLPlatform;
use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

final class Version20260520013000 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Repairs missing technician team memberships table after interrupted 1.0.52 updates';
    }

    public function up(Schema $schema): void
    {
        if (!$schema->hasTable('users') || !$schema->hasTable('technician_teams')) {
            return;
        }

        if (!$schema->hasTable('technician_team_memberships')) {
            if ($this->connection->getDatabasePlatform() instanceof AbstractMySQLPlatform) {
                $this->addSql('CREATE TABLE technician_team_memberships (user_id INT NOT NULL, technician_team_id INT NOT NULL, INDEX IDX_TECH_TEAM_MEMBERSHIP_TEAM (technician_team_id), PRIMARY KEY(user_id, technician_team_id))');
                $this->addSql('ALTER TABLE technician_team_memberships ADD CONSTRAINT FK_TECH_TEAM_MEMBERSHIP_USER FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE');
                $this->addSql('ALTER TABLE technician_team_memberships ADD CONSTRAINT FK_TECH_TEAM_MEMBERSHIP_TEAM FOREIGN KEY (technician_team_id) REFERENCES technician_teams (id) ON DELETE CASCADE');
            } else {
                $this->addSql('CREATE TABLE technician_team_memberships (user_id INTEGER NOT NULL, technician_team_id INTEGER NOT NULL, PRIMARY KEY(user_id, technician_team_id), CONSTRAINT FK_TECH_TEAM_MEMBERSHIP_USER FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE NOT DEFERRABLE INITIALLY IMMEDIATE, CONSTRAINT FK_TECH_TEAM_MEMBERSHIP_TEAM FOREIGN KEY (technician_team_id) REFERENCES technician_teams (id) ON DELETE CASCADE NOT DEFERRABLE INITIALLY IMMEDIATE)');
                $this->addSql('CREATE INDEX IDX_TECH_TEAM_MEMBERSHIP_TEAM ON technician_team_memberships (technician_team_id)');
            }
        }

        if ($schema->getTable('users')->hasColumn('technician_team_id')) {
            $this->addSql('INSERT INTO technician_team_memberships (user_id, technician_team_id) SELECT u.id, u.technician_team_id FROM users u WHERE u.technician_team_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM technician_team_memberships existing WHERE existing.user_id = u.id AND existing.technician_team_id = u.technician_team_id)');
        }
    }

    public function down(Schema $schema): void
    {
        // Intentionally no-op: this repair migration must not drop membership data owned by the original 1.0.52 migration.
    }
}
