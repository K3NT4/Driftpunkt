<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

final class Version20260521100000 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Adds per-user customer access controls for all company tickets';
    }

    public function up(Schema $schema): void
    {
        if (!$schema->hasTable('company_ticket_allowed_users')) {
            $table = $schema->createTable('company_ticket_allowed_users');
            $table->addColumn('company_id', 'integer');
            $table->addColumn('user_id', 'integer');
            $table->setPrimaryKey(['company_id', 'user_id']);
            $table->addIndex(['user_id'], 'idx_company_ticket_allowed_user');
            $table->addForeignKeyConstraint('companies', ['company_id'], ['id'], ['onDelete' => 'CASCADE']);
            $table->addForeignKeyConstraint('users', ['user_id'], ['id'], ['onDelete' => 'CASCADE']);
        }
    }

    public function down(Schema $schema): void
    {
        if ($schema->hasTable('company_ticket_allowed_users')) {
            $schema->dropTable('company_ticket_allowed_users');
        }
    }
}
