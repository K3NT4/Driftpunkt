<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

final class Version20260428120000 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Adds ticket participants, relations, status reason and follow-up date';
    }

    public function up(Schema $schema): void
    {
        if ($schema->hasTable('tickets')) {
            $tickets = $schema->getTable('tickets');
            if (!$tickets->hasColumn('status_reason')) {
                $tickets->addColumn('status_reason', 'string', ['length' => 255, 'notnull' => false]);
            }
            if (!$tickets->hasColumn('follow_up_at')) {
                $tickets->addColumn('follow_up_at', 'datetime_immutable', ['notnull' => false]);
            }
        }

        if (!$schema->hasTable('ticket_participants')) {
            $table = $schema->createTable('ticket_participants');
            $table->addColumn('id', 'integer', ['autoincrement' => true]);
            $table->addColumn('ticket_id', 'integer');
            $table->addColumn('user_id', 'integer', ['notnull' => false]);
            $table->addColumn('created_by_id', 'integer', ['notnull' => false]);
            $table->addColumn('email', 'string', ['length' => 180]);
            $table->addColumn('display_name', 'string', ['length' => 180, 'notnull' => false]);
            $table->addColumn('role', 'string', ['length' => 32, 'default' => 'customer_cc']);
            $table->addColumn('notify_on_customer_visible_updates', 'boolean', ['default' => true]);
            $table->addColumn('created_at', 'datetime_immutable');
            $table->addColumn('updated_at', 'datetime_immutable');
            $table->setPrimaryKey(['id']);
            $table->addIndex(['ticket_id'], 'IDX_TICKET_PARTICIPANTS_TICKET');
            $table->addIndex(['user_id'], 'IDX_TICKET_PARTICIPANTS_USER');
            $table->addIndex(['created_by_id'], 'IDX_TICKET_PARTICIPANTS_CREATED_BY');
            $table->addUniqueIndex(['ticket_id', 'email', 'role'], 'uniq_ticket_participant_email_role');

            if ($schema->hasTable('tickets')) {
                $table->addForeignKeyConstraint('tickets', ['ticket_id'], ['id'], ['onDelete' => 'CASCADE']);
            }
            if ($schema->hasTable('users')) {
                $table->addForeignKeyConstraint('users', ['user_id'], ['id'], ['onDelete' => 'SET NULL']);
                $table->addForeignKeyConstraint('users', ['created_by_id'], ['id'], ['onDelete' => 'SET NULL']);
            }
        }

        if (!$schema->hasTable('ticket_relations')) {
            $table = $schema->createTable('ticket_relations');
            $table->addColumn('id', 'integer', ['autoincrement' => true]);
            $table->addColumn('source_ticket_id', 'integer');
            $table->addColumn('target_ticket_id', 'integer');
            $table->addColumn('relation_type', 'string', ['length' => 32, 'default' => 'related']);
            $table->addColumn('created_by_id', 'integer', ['notnull' => false]);
            $table->addColumn('created_at', 'datetime_immutable');
            $table->addColumn('updated_at', 'datetime_immutable');
            $table->setPrimaryKey(['id']);
            $table->addIndex(['source_ticket_id'], 'IDX_TICKET_RELATIONS_SOURCE');
            $table->addIndex(['target_ticket_id'], 'IDX_TICKET_RELATIONS_TARGET');
            $table->addIndex(['created_by_id'], 'IDX_TICKET_RELATIONS_CREATED_BY');
            $table->addUniqueIndex(['source_ticket_id', 'target_ticket_id', 'relation_type'], 'uniq_ticket_relation_pair_type');

            if ($schema->hasTable('tickets')) {
                $table->addForeignKeyConstraint('tickets', ['source_ticket_id'], ['id'], ['onDelete' => 'CASCADE']);
                $table->addForeignKeyConstraint('tickets', ['target_ticket_id'], ['id'], ['onDelete' => 'CASCADE']);
            }
            if ($schema->hasTable('users')) {
                $table->addForeignKeyConstraint('users', ['created_by_id'], ['id'], ['onDelete' => 'SET NULL']);
            }
        }
    }

    public function down(Schema $schema): void
    {
        if ($schema->hasTable('ticket_relations')) {
            $schema->dropTable('ticket_relations');
        }

        if ($schema->hasTable('ticket_participants')) {
            $schema->dropTable('ticket_participants');
        }

        if ($schema->hasTable('tickets')) {
            $tickets = $schema->getTable('tickets');
            if ($tickets->hasColumn('follow_up_at')) {
                $tickets->dropColumn('follow_up_at');
            }
            if ($tickets->hasColumn('status_reason')) {
                $tickets->dropColumn('status_reason');
            }
        }
    }
}
