<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Platforms\AbstractMySQLPlatform;
use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

final class Version20260514100000 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Makes customer portal report access opt-in per company user';
    }

    public function up(Schema $schema): void
    {
        if (!$schema->hasTable('companies')) {
            return;
        }

        $table = $schema->getTable('companies');
        if ($table->hasColumn('report_access_restricted')) {
            if ($this->connection->getDatabasePlatform() instanceof AbstractMySQLPlatform) {
                $this->addSql('ALTER TABLE companies MODIFY report_access_restricted BOOLEAN DEFAULT 1 NOT NULL');
            }
            $this->addSql('UPDATE companies SET report_access_restricted = 1');
        }
    }

    public function down(Schema $schema): void
    {
        if (!$schema->hasTable('companies')) {
            return;
        }

        $table = $schema->getTable('companies');
        if ($table->hasColumn('report_access_restricted')) {
            if ($this->connection->getDatabasePlatform() instanceof AbstractMySQLPlatform) {
                $this->addSql('ALTER TABLE companies MODIFY report_access_restricted BOOLEAN DEFAULT 0 NOT NULL');
            }
        }
    }
}
