<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

final class Version20260725120001 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Backfills and requires unique public references for existing internal reports';
    }

    public function up(Schema $schema): void
    {
        if (!$schema->hasTable('internal_reports') || !$schema->getTable('internal_reports')->hasColumn('public_reference')) {
            return;
        }

        $this->addSql('UPDATE internal_reports SET public_reference = UUID() WHERE public_reference IS NULL');
        $this->addSql('ALTER TABLE internal_reports MODIFY public_reference VARCHAR(36) NOT NULL');
    }

    public function down(Schema $schema): void
    {
        if (!$schema->hasTable('internal_reports') || !$schema->getTable('internal_reports')->hasColumn('public_reference')) {
            return;
        }

        $this->addSql('ALTER TABLE internal_reports MODIFY public_reference VARCHAR(36) DEFAULT NULL');
    }
}
