<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

final class Version20260815210000 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Adds UID-based IMAP retry tracking, destination folders and per-mailbox Google OAuth authorization';
    }

    public function up(Schema $schema): void
    {
        if ($schema->hasTable('support_mailboxes')) {
            $mailboxes = $schema->getTable('support_mailboxes');
            if (!$mailboxes->hasColumn('processed_folder_name')) {
                $mailboxes->addColumn('processed_folder_name', 'string', ['length' => 190, 'default' => 'Behandlade']);
                $mailboxes->addColumn('error_folder_name', 'string', ['length' => 190, 'default' => 'Fel']);
                $mailboxes->addColumn('last_polling_error', 'text', ['notnull' => false]);
                $mailboxes->addColumn('last_polling_error_at', 'datetime_immutable', ['notnull' => false]);
                $mailboxes->addColumn('google_refresh_token_encrypted', 'text', ['notnull' => false]);
                $mailboxes->addColumn('google_authorized_email', 'string', ['length' => 180, 'notnull' => false]);
                $mailboxes->addColumn('google_authorized_at', 'datetime_immutable', ['notnull' => false]);
            }
        }

        if ($schema->hasTable('incoming_mails')) {
            $incomingMails = $schema->getTable('incoming_mails');
            if ($incomingMails->hasIndex('uniq_incoming_mails_message_id')) {
                $incomingMails->dropIndex('uniq_incoming_mails_message_id');
            }
            if (!$incomingMails->hasIndex('uniq_incoming_mails_mailbox_message_id')) {
                $incomingMails->addUniqueIndex(['mailbox_id', 'message_id'], 'uniq_incoming_mails_mailbox_message_id');
            }
        }

        if (!$schema->hasTable('imap_message_receipts')) {
            $receipts = $schema->createTable('imap_message_receipts');
            $receipts->addColumn('id', 'integer', ['autoincrement' => true]);
            $receipts->addColumn('mailbox_id', 'integer');
            $receipts->addColumn('incoming_mail_id', 'integer', ['notnull' => false]);
            $receipts->addColumn('uid_validity', 'string', ['length' => 20]);
            $receipts->addColumn('remote_uid', 'string', ['length' => 20]);
            $receipts->addColumn('attempt_count', 'integer', ['default' => 0]);
            $receipts->addColumn('state', 'string', ['length' => 255]);
            $receipts->addColumn('last_error', 'text', ['notnull' => false]);
            $receipts->addColumn('last_attempt_at', 'datetime_immutable', ['notnull' => false]);
            $receipts->addColumn('completed_at', 'datetime_immutable', ['notnull' => false]);
            $receipts->addColumn('created_at', 'datetime_immutable');
            $receipts->addColumn('updated_at', 'datetime_immutable');
            $receipts->setPrimaryKey(['id']);
            $receipts->addUniqueIndex(['mailbox_id', 'uid_validity', 'remote_uid'], 'uniq_imap_receipt_remote_message');
            $receipts->addIndex(['mailbox_id', 'state'], 'idx_imap_receipt_mailbox_state');
            $receipts->addIndex(['incoming_mail_id'], 'idx_imap_receipt_incoming_mail');
            $receipts->addForeignKeyConstraint('support_mailboxes', ['mailbox_id'], ['id'], ['onDelete' => 'CASCADE'], 'fk_imap_receipt_mailbox');
            $receipts->addForeignKeyConstraint('incoming_mails', ['incoming_mail_id'], ['id'], ['onDelete' => 'SET NULL'], 'fk_imap_receipt_incoming_mail');
        }
    }

    public function down(Schema $schema): void
    {
        if ($schema->hasTable('imap_message_receipts')) {
            $schema->dropTable('imap_message_receipts');
        }
        if ($schema->hasTable('incoming_mails')) {
            $incomingMails = $schema->getTable('incoming_mails');
            if ($incomingMails->hasIndex('uniq_incoming_mails_mailbox_message_id')) {
                $incomingMails->dropIndex('uniq_incoming_mails_mailbox_message_id');
            }
            if (!$incomingMails->hasIndex('uniq_incoming_mails_message_id')) {
                $incomingMails->addUniqueIndex(['message_id'], 'uniq_incoming_mails_message_id');
            }
        }
        if ($schema->hasTable('support_mailboxes')) {
            $mailboxes = $schema->getTable('support_mailboxes');
            foreach (['processed_folder_name', 'error_folder_name', 'last_polling_error', 'last_polling_error_at', 'google_refresh_token_encrypted', 'google_authorized_email', 'google_authorized_at'] as $column) {
                if ($mailboxes->hasColumn($column)) { $mailboxes->dropColumn($column); }
            }
        }
    }
}
