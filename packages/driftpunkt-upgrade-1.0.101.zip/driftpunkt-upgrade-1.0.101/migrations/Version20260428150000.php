<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

final class Version20260428150000 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Adds preferred locale fields to users and companies';
    }

    public function up(Schema $schema): void
    {
        if ($schema->hasTable('users')) {
            $users = $schema->getTable('users');
            if (!$users->hasColumn('preferred_locale')) {
                $users->addColumn('preferred_locale', 'string', ['length' => 16, 'notnull' => false]);
            }
        }

        if ($schema->hasTable('companies')) {
            $companies = $schema->getTable('companies');
            if (!$companies->hasColumn('preferred_locale')) {
                $companies->addColumn('preferred_locale', 'string', ['length' => 16, 'notnull' => false]);
            }
        }
    }

    public function down(Schema $schema): void
    {
        if ($schema->hasTable('users')) {
            $users = $schema->getTable('users');
            if ($users->hasColumn('preferred_locale')) {
                $users->dropColumn('preferred_locale');
            }
        }

        if ($schema->hasTable('companies')) {
            $companies = $schema->getTable('companies');
            if ($companies->hasColumn('preferred_locale')) {
                $companies->dropColumn('preferred_locale');
            }
        }
    }
}
