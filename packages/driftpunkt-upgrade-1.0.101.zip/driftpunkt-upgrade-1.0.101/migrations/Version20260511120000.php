<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

final class Version20260511120000 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Adds content hash metadata for ticket comment attachments';
    }

    public function up(Schema $schema): void
    {
        if (!$schema->hasTable('ticket_comment_attachments')) {
            return;
        }

        $table = $schema->getTable('ticket_comment_attachments');
        if (!$table->hasColumn('content_hash')) {
            $table->addColumn('content_hash', 'string', ['length' => 64, 'notnull' => false]);
        }

        if (!$table->hasIndex('IDX_TICKET_COMMENT_ATTACHMENT_HASH_SIZE')) {
            $table->addIndex(['content_hash', 'file_size'], 'IDX_TICKET_COMMENT_ATTACHMENT_HASH_SIZE');
        }
    }

    public function down(Schema $schema): void
    {
        if (!$schema->hasTable('ticket_comment_attachments')) {
            return;
        }

        $table = $schema->getTable('ticket_comment_attachments');
        if ($table->hasIndex('IDX_TICKET_COMMENT_ATTACHMENT_HASH_SIZE')) {
            $table->dropIndex('IDX_TICKET_COMMENT_ATTACHMENT_HASH_SIZE');
        }

        if ($table->hasColumn('content_hash')) {
            $table->dropColumn('content_hash');
        }
    }
}
