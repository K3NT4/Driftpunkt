<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Platforms\AbstractMySQLPlatform;
use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

final class Version20260520120000 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Adds one-time portal login links for internal ticket notification emails';
    }

    public function up(Schema $schema): void
    {
        if ($schema->hasTable('portal_login_links') || !$schema->hasTable('users') || !$schema->hasTable('tickets')) {
            return;
        }

        if ($this->connection->getDatabasePlatform() instanceof AbstractMySQLPlatform) {
            $this->addSql('CREATE TABLE portal_login_links (id INT AUTO_INCREMENT NOT NULL, user_id INT NOT NULL, ticket_id INT NOT NULL, target_path VARCHAR(255) NOT NULL, required_role VARCHAR(80) NOT NULL, token_hash VARCHAR(64) NOT NULL, expires_at DATETIME NOT NULL COMMENT \'(DC2Type:datetime_immutable)\', used_at DATETIME DEFAULT NULL COMMENT \'(DC2Type:datetime_immutable)\', created_at DATETIME NOT NULL COMMENT \'(DC2Type:datetime_immutable)\', updated_at DATETIME NOT NULL COMMENT \'(DC2Type:datetime_immutable)\', INDEX IDX_PORTAL_LOGIN_LINK_USER (user_id), INDEX IDX_PORTAL_LOGIN_LINK_TICKET (ticket_id), UNIQUE INDEX UNIQ_PORTAL_LOGIN_LINK_TOKEN_HASH (token_hash), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
            $this->addSql('ALTER TABLE portal_login_links ADD CONSTRAINT FK_PORTAL_LOGIN_LINK_USER FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE');
            $this->addSql('ALTER TABLE portal_login_links ADD CONSTRAINT FK_PORTAL_LOGIN_LINK_TICKET FOREIGN KEY (ticket_id) REFERENCES tickets (id) ON DELETE CASCADE');
        } else {
            $this->addSql('CREATE TABLE portal_login_links (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, user_id INTEGER NOT NULL, ticket_id INTEGER NOT NULL, target_path VARCHAR(255) NOT NULL, required_role VARCHAR(80) NOT NULL, token_hash VARCHAR(64) NOT NULL, expires_at DATETIME NOT NULL, used_at DATETIME DEFAULT NULL, created_at DATETIME NOT NULL, updated_at DATETIME NOT NULL, CONSTRAINT FK_PORTAL_LOGIN_LINK_USER FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE NOT DEFERRABLE INITIALLY IMMEDIATE, CONSTRAINT FK_PORTAL_LOGIN_LINK_TICKET FOREIGN KEY (ticket_id) REFERENCES tickets (id) ON DELETE CASCADE NOT DEFERRABLE INITIALLY IMMEDIATE)');
            $this->addSql('CREATE INDEX IDX_PORTAL_LOGIN_LINK_USER ON portal_login_links (user_id)');
            $this->addSql('CREATE INDEX IDX_PORTAL_LOGIN_LINK_TICKET ON portal_login_links (ticket_id)');
            $this->addSql('CREATE UNIQUE INDEX UNIQ_PORTAL_LOGIN_LINK_TOKEN_HASH ON portal_login_links (token_hash)');
        }
    }

    public function down(Schema $schema): void
    {
        if (!$schema->hasTable('portal_login_links')) {
            return;
        }

        $this->addSql('DROP TABLE portal_login_links');
    }
}
