<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

final class Version20260521140000 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Adds customer notification suppression for customer-visible ticket comments';
    }

    public function up(Schema $schema): void
    {
        if (!$schema->hasTable('ticket_comments')) {
            return;
        }

        $table = $schema->getTable('ticket_comments');
        if (!$table->hasColumn('customer_notification_suppressed')) {
            $table->addColumn('customer_notification_suppressed', 'boolean', ['default' => false]);
        }
    }

    public function down(Schema $schema): void
    {
        if (!$schema->hasTable('ticket_comments')) {
            return;
        }

        $table = $schema->getTable('ticket_comments');
        if ($table->hasColumn('customer_notification_suppressed')) {
            $table->dropColumn('customer_notification_suppressed');
        }
    }
}
