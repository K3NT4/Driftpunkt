<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

final class Version20260508120000 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Adds extra technician assignments for tickets';
    }

    public function up(Schema $schema): void
    {
        if ($schema->hasTable('ticket_technician_assignments')) {
            return;
        }

        $table = $schema->createTable('ticket_technician_assignments');
        $table->addColumn('id', 'integer', ['autoincrement' => true]);
        $table->addColumn('ticket_id', 'integer');
        $table->addColumn('technician_id', 'integer');
        $table->addColumn('assigned_by_id', 'integer', ['notnull' => false]);
        $table->addColumn('created_at', 'datetime_immutable');
        $table->addColumn('updated_at', 'datetime_immutable');
        $table->setPrimaryKey(['id']);
        $table->addIndex(['ticket_id'], 'IDX_TICKET_TECH_ASSIGN_TICKET');
        $table->addIndex(['technician_id'], 'IDX_TICKET_TECH_ASSIGN_TECHNICIAN');
        $table->addIndex(['assigned_by_id'], 'IDX_TICKET_TECH_ASSIGN_ASSIGNED_BY');
        $table->addUniqueIndex(['ticket_id', 'technician_id'], 'uniq_ticket_technician_assignment');

        if ($schema->hasTable('tickets')) {
            $table->addForeignKeyConstraint('tickets', ['ticket_id'], ['id'], ['onDelete' => 'CASCADE']);
        }
        if ($schema->hasTable('users')) {
            $table->addForeignKeyConstraint('users', ['technician_id'], ['id'], ['onDelete' => 'CASCADE']);
            $table->addForeignKeyConstraint('users', ['assigned_by_id'], ['id'], ['onDelete' => 'SET NULL']);
        }
    }

    public function down(Schema $schema): void
    {
        if ($schema->hasTable('ticket_technician_assignments')) {
            $schema->dropTable('ticket_technician_assignments');
        }
    }
}
