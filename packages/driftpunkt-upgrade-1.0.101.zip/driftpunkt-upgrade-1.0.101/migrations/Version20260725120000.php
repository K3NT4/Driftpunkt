<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

final class Version20260725120000 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Adds central delivery metadata and email response threads for internal reports';
    }

    public function up(Schema $schema): void
    {
        if (!$schema->hasTable('internal_reports')) {
            return;
        }

        $reports = $schema->getTable('internal_reports');
        if (!$reports->hasColumn('public_reference')) {
            $reports->addColumn('public_reference', 'string', ['length' => 36, 'notnull' => false]);
            $reports->addColumn('installation_url', 'string', ['length' => 2048, 'default' => '']);
            $reports->addColumn('source_page_url', 'string', ['length' => 2048, 'notnull' => false]);
            $reports->addColumn('delivery_status', 'string', ['length' => 24, 'default' => 'not_required']);
            $reports->addColumn('notification_sent_at', 'datetime_immutable', ['notnull' => false]);
            $reports->addColumn('notification_error', 'string', ['length' => 255, 'notnull' => false]);
            $reports->addUniqueIndex(['public_reference'], 'uniq_internal_reports_public_reference');
        }

        if (!$schema->hasTable('internal_report_responses')) {
            $responses = $schema->createTable('internal_report_responses');
            $responses->addColumn('id', 'integer', ['autoincrement' => true]);
            $responses->addColumn('report_id', 'integer');
            $responses->addColumn('incoming_mail_id', 'integer');
            $responses->addColumn('author_email', 'string', ['length' => 180]);
            $responses->addColumn('body', 'text');
            $responses->addColumn('content_hash', 'string', ['length' => 64]);
            $responses->addColumn('created_at', 'datetime_immutable');
            $responses->setPrimaryKey(['id']);
            $responses->addIndex(['report_id', 'created_at'], 'idx_internal_report_responses_report_created');
            $responses->addUniqueIndex(['incoming_mail_id'], 'uniq_internal_report_responses_incoming_mail');
            $responses->addUniqueIndex(['content_hash'], 'uniq_internal_report_responses_content_hash');
            $responses->addForeignKeyConstraint('internal_reports', ['report_id'], ['id'], ['onDelete' => 'CASCADE'], 'fk_internal_report_responses_report');
            $responses->addForeignKeyConstraint('incoming_mails', ['incoming_mail_id'], ['id'], ['onDelete' => 'CASCADE'], 'fk_internal_report_responses_incoming_mail');
        }

    }

    public function down(Schema $schema): void
    {
        if ($schema->hasTable('internal_report_responses')) {
            $schema->dropTable('internal_report_responses');
        }

        if (!$schema->hasTable('internal_reports')) {
            return;
        }

        $reports = $schema->getTable('internal_reports');
        foreach (['public_reference', 'installation_url', 'source_page_url', 'delivery_status', 'notification_sent_at', 'notification_error'] as $column) {
            if ($reports->hasColumn($column)) {
                $reports->dropColumn($column);
            }
        }
    }
}
