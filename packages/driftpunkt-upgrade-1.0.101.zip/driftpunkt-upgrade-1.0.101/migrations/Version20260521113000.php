<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

final class Version20260521113000 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Reopens imported assignee shadow people that were linked to internal users';
    }

    public function up(Schema $schema): void
    {
        if (!$schema->hasTable('imported_ticket_people') || !$schema->hasTable('users')) {
            return;
        }

        $this->addSql(
            "UPDATE imported_ticket_people SET linked_user_id = NULL, linked_at = NULL WHERE role = 'assignee' AND linked_user_id IN (SELECT id FROM users WHERE type IN ('super_admin', 'admin', 'technician'))"
        );
    }

    public function down(Schema $schema): void
    {
        // This repair is intentionally not reversible: the original linked_at values are not recoverable.
    }
}
