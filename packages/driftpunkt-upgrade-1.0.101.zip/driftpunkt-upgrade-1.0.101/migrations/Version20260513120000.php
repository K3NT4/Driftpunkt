<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

final class Version20260513120000 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Adds per-user customer access controls for inventory lists';
    }

    public function up(Schema $schema): void
    {
        if ($schema->hasTable('inventory_list_settings')) {
            $table = $schema->getTable('inventory_list_settings');
            if (!$table->hasColumn('access_restricted')) {
                $table->addColumn('access_restricted', 'boolean', ['default' => false]);
            }
        }

        if (!$schema->hasTable('inventory_list_allowed_users')) {
            $table = $schema->createTable('inventory_list_allowed_users');
            $table->addColumn('list_setting_id', 'integer');
            $table->addColumn('user_id', 'integer');
            $table->setPrimaryKey(['list_setting_id', 'user_id']);
            $table->addIndex(['user_id'], 'idx_inventory_list_allowed_user');
            $table->addForeignKeyConstraint('inventory_list_settings', ['list_setting_id'], ['id'], ['onDelete' => 'CASCADE']);
            $table->addForeignKeyConstraint('users', ['user_id'], ['id'], ['onDelete' => 'CASCADE']);
        }
    }

    public function down(Schema $schema): void
    {
        if ($schema->hasTable('inventory_list_allowed_users')) {
            $schema->dropTable('inventory_list_allowed_users');
        }

        if ($schema->hasTable('inventory_list_settings')) {
            $table = $schema->getTable('inventory_list_settings');
            if ($table->hasColumn('access_restricted')) {
                $table->dropColumn('access_restricted');
            }
        }
    }
}
