<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

final class Version20260726100000 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Adds reliable report notification retries and RFC Message-ID deduplication';
    }

    public function up(Schema $schema): void
    {
        if ($schema->hasTable('internal_reports')) {
            $reports = $schema->getTable('internal_reports');
            if (!$reports->hasColumn('notification_attempt_count')) {
                $reports->addColumn('notification_attempt_count', 'integer', ['default' => 0]);
                $reports->addColumn('notification_last_attempt_at', 'datetime_immutable', ['notnull' => false]);
                $reports->addColumn('notification_next_attempt_at', 'datetime_immutable', ['notnull' => false]);
                $reports->addIndex(['delivery_status', 'notification_next_attempt_at'], 'idx_internal_reports_delivery_retry');
            }
        }

        if ($schema->hasTable('incoming_mails')) {
            $incomingMails = $schema->getTable('incoming_mails');
            if (!$incomingMails->hasColumn('message_id')) {
                $incomingMails->addColumn('message_id', 'string', ['length' => 255, 'notnull' => false]);
                $incomingMails->addUniqueIndex(['message_id'], 'uniq_incoming_mails_message_id');
            }
        }

        if ($schema->hasTable('internal_report_responses')) {
            $responses = $schema->getTable('internal_report_responses');
            if ($responses->hasIndex('uniq_internal_report_responses_content_hash')) {
                $responses->dropIndex('uniq_internal_report_responses_content_hash');
                $responses->addIndex(['content_hash'], 'idx_internal_report_responses_content_hash');
            }
        }
    }

    public function down(Schema $schema): void
    {
        if ($schema->hasTable('internal_report_responses')) {
            $responses = $schema->getTable('internal_report_responses');
            if ($responses->hasIndex('idx_internal_report_responses_content_hash')) {
                $responses->dropIndex('idx_internal_report_responses_content_hash');
                $responses->addUniqueIndex(['content_hash'], 'uniq_internal_report_responses_content_hash');
            }
        }

        if ($schema->hasTable('incoming_mails') && $schema->getTable('incoming_mails')->hasColumn('message_id')) {
            $schema->getTable('incoming_mails')->dropColumn('message_id');
        }

        if ($schema->hasTable('internal_reports')) {
            $reports = $schema->getTable('internal_reports');
            foreach (['notification_attempt_count', 'notification_last_attempt_at', 'notification_next_attempt_at'] as $column) {
                if ($reports->hasColumn($column)) {
                    $reports->dropColumn($column);
                }
            }
        }
    }
}
