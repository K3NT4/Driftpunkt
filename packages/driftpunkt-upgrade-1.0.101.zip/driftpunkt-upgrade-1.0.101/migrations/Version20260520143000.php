<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Platforms\AbstractMySQLPlatform;
use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

final class Version20260520143000 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Adds incoming mail aliases for customer and company matching';
    }

    public function up(Schema $schema): void
    {
        if ($schema->hasTable('incoming_mail_aliases') || !$schema->hasTable('users') || !$schema->hasTable('companies')) {
            return;
        }

        if ($this->connection->getDatabasePlatform() instanceof AbstractMySQLPlatform) {
            $this->addSql('CREATE TABLE incoming_mail_aliases (id INT AUTO_INCREMENT NOT NULL, user_id INT DEFAULT NULL, company_id INT DEFAULT NULL, email VARCHAR(180) NOT NULL, created_at DATETIME NOT NULL COMMENT \'(DC2Type:datetime_immutable)\', updated_at DATETIME NOT NULL COMMENT \'(DC2Type:datetime_immutable)\', INDEX IDX_INCOMING_MAIL_ALIAS_USER (user_id), INDEX IDX_INCOMING_MAIL_ALIAS_COMPANY (company_id), UNIQUE INDEX UNIQ_INCOMING_MAIL_ALIAS_EMAIL (email), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
            $this->addSql('ALTER TABLE incoming_mail_aliases ADD CONSTRAINT FK_INCOMING_MAIL_ALIAS_USER FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE SET NULL');
            $this->addSql('ALTER TABLE incoming_mail_aliases ADD CONSTRAINT FK_INCOMING_MAIL_ALIAS_COMPANY FOREIGN KEY (company_id) REFERENCES companies (id) ON DELETE SET NULL');
        } else {
            $this->addSql('CREATE TABLE incoming_mail_aliases (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, user_id INTEGER DEFAULT NULL, company_id INTEGER DEFAULT NULL, email VARCHAR(180) NOT NULL, created_at DATETIME NOT NULL, updated_at DATETIME NOT NULL, CONSTRAINT FK_INCOMING_MAIL_ALIAS_USER FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE SET NULL NOT DEFERRABLE INITIALLY IMMEDIATE, CONSTRAINT FK_INCOMING_MAIL_ALIAS_COMPANY FOREIGN KEY (company_id) REFERENCES companies (id) ON DELETE SET NULL NOT DEFERRABLE INITIALLY IMMEDIATE)');
            $this->addSql('CREATE INDEX IDX_INCOMING_MAIL_ALIAS_USER ON incoming_mail_aliases (user_id)');
            $this->addSql('CREATE INDEX IDX_INCOMING_MAIL_ALIAS_COMPANY ON incoming_mail_aliases (company_id)');
            $this->addSql('CREATE UNIQUE INDEX UNIQ_INCOMING_MAIL_ALIAS_EMAIL ON incoming_mail_aliases (email)');
        }
    }

    public function down(Schema $schema): void
    {
        if (!$schema->hasTable('incoming_mail_aliases')) {
            return;
        }

        $this->addSql('DROP TABLE incoming_mail_aliases');
    }
}
