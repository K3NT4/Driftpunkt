<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

final class Version20260512160000 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Tracks whether MFA setup has been completed by the user';
    }

    public function up(Schema $schema): void
    {
        if (!$schema->hasTable('users')) {
            return;
        }

        $table = $schema->getTable('users');
        if (!$table->hasColumn('mfa_setup_completed')) {
            $table->addColumn('mfa_setup_completed', 'boolean', ['notnull' => false]);
        }
    }

    public function down(Schema $schema): void
    {
        if (!$schema->hasTable('users')) {
            return;
        }

        $table = $schema->getTable('users');
        if ($table->hasColumn('mfa_setup_completed')) {
            $table->dropColumn('mfa_setup_completed');
        }
    }
}
