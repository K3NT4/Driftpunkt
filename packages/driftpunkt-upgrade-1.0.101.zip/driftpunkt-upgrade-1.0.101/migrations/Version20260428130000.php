<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

final class Version20260428130000 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Adds structured customer feedback for closed tickets';
    }

    public function up(Schema $schema): void
    {
        if ($schema->hasTable('ticket_feedback')) {
            return;
        }

        $table = $schema->createTable('ticket_feedback');
        $table->addColumn('id', 'integer', ['autoincrement' => true]);
        $table->addColumn('ticket_id', 'integer');
        $table->addColumn('author_id', 'integer');
        $table->addColumn('rating', 'integer');
        $table->addColumn('body', 'text', ['notnull' => false]);
        $table->addColumn('issue_resolved', 'boolean', ['default' => true]);
        $table->addColumn('follow_up_requested', 'boolean', ['default' => false]);
        $table->addColumn('created_at', 'datetime_immutable');
        $table->addColumn('updated_at', 'datetime_immutable');
        $table->setPrimaryKey(['id']);
        $table->addIndex(['ticket_id'], 'IDX_TICKET_FEEDBACK_TICKET');
        $table->addIndex(['author_id'], 'IDX_TICKET_FEEDBACK_AUTHOR');
        $table->addUniqueIndex(['ticket_id', 'author_id'], 'uniq_ticket_feedback_author');

        if ($schema->hasTable('tickets')) {
            $table->addForeignKeyConstraint('tickets', ['ticket_id'], ['id'], ['onDelete' => 'CASCADE']);
        }
        if ($schema->hasTable('users')) {
            $table->addForeignKeyConstraint('users', ['author_id'], ['id'], ['onDelete' => 'CASCADE']);
        }
    }

    public function down(Schema $schema): void
    {
        if ($schema->hasTable('ticket_feedback')) {
            $schema->dropTable('ticket_feedback');
        }
    }
}
