<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

final class Version20260513100000 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Adds customer inventory computer and printer lists';
    }

    public function up(Schema $schema): void
    {
        if (!$schema->hasTable('inventory_list_settings')) {
            $table = $schema->createTable('inventory_list_settings');
            $table->addColumn('id', 'integer', ['autoincrement' => true]);
            $table->addColumn('company_id', 'integer');
            $table->addColumn('type', 'string', ['length' => 255]);
            $table->addColumn('enabled', 'boolean', ['default' => false]);
            $table->addColumn('last_imported_at', 'datetime_immutable', ['notnull' => false]);
            $table->addColumn('last_import_filename', 'string', ['length' => 255, 'notnull' => false]);
            $table->addColumn('created_at', 'datetime_immutable');
            $table->addColumn('updated_at', 'datetime_immutable');
            $table->setPrimaryKey(['id']);
            $table->addUniqueIndex(['company_id', 'type'], 'uniq_inventory_list_company_type');
            $table->addForeignKeyConstraint('companies', ['company_id'], ['id'], ['onDelete' => 'CASCADE']);
        }

        if (!$schema->hasTable('inventory_items')) {
            $table = $schema->createTable('inventory_items');
            $table->addColumn('id', 'integer', ['autoincrement' => true]);
            $table->addColumn('company_id', 'integer');
            $table->addColumn('type', 'string', ['length' => 255]);
            foreach ([
                'hostname', 'assigned_to', 'manufacturer', 'model', 'serial_number', 'operating_system',
                'processor', 'memory', 'storage', 'ip_address', 'printer_kind', 'printer_name', 'area', 'color', 'pin',
            ] as $column) {
                $table->addColumn($column, 'string', ['length' => \in_array($column, ['ip_address', 'color'], true) ? 64 : ('pin' === $column ? 80 : 255), 'notnull' => false]);
            }
            $table->addColumn('purchase_date', 'datetime_immutable', ['notnull' => false]);
            $table->addColumn('warranty_ends_at', 'datetime_immutable', ['notnull' => false]);
            $table->addColumn('broken', 'boolean', ['default' => false]);
            $table->addColumn('comment', 'text', ['notnull' => false]);
            $table->addColumn('available', 'boolean', ['default' => false]);
            $table->addColumn('installation_date', 'datetime_immutable', ['notnull' => false]);
            $table->addColumn('created_at', 'datetime_immutable');
            $table->addColumn('updated_at', 'datetime_immutable');
            $table->setPrimaryKey(['id']);
            $table->addIndex(['company_id', 'type'], 'idx_inventory_item_company_type');
            $table->addForeignKeyConstraint('companies', ['company_id'], ['id'], ['onDelete' => 'CASCADE']);
        }

        if (!$schema->hasTable('inventory_audit_logs')) {
            $table = $schema->createTable('inventory_audit_logs');
            $table->addColumn('id', 'integer', ['autoincrement' => true]);
            $table->addColumn('company_id', 'integer');
            $table->addColumn('type', 'string', ['length' => 255]);
            $table->addColumn('actor_id', 'integer', ['notnull' => false]);
            $table->addColumn('action', 'string', ['length' => 80]);
            $table->addColumn('details', 'json');
            $table->addColumn('created_at', 'datetime_immutable');
            $table->setPrimaryKey(['id']);
            $table->addIndex(['company_id', 'type'], 'idx_inventory_audit_company_type');
            $table->addForeignKeyConstraint('companies', ['company_id'], ['id'], ['onDelete' => 'CASCADE']);
            $table->addForeignKeyConstraint('users', ['actor_id'], ['id'], ['onDelete' => 'SET NULL']);
        }
    }

    public function down(Schema $schema): void
    {
        foreach (['inventory_audit_logs', 'inventory_items', 'inventory_list_settings'] as $tableName) {
            if ($schema->hasTable($tableName)) {
                $schema->dropTable($tableName);
            }
        }
    }
}
