<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

final class Version20260819210000 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Adds explicit subsidiary opt-in for selected parent-company customers to access all customer-visible tickets';
    }

    public function up(Schema $schema): void
    {
        if (!$schema->hasTable('companies')) {
            return;
        }

        $table = $schema->getTable('companies');
        if (!$table->hasColumn('allow_parent_company_access_to_all_tickets')) {
            $table->addColumn('allow_parent_company_access_to_all_tickets', 'boolean', ['default' => false]);
        }
    }

    public function down(Schema $schema): void
    {
        if (!$schema->hasTable('companies')) {
            return;
        }

        $table = $schema->getTable('companies');
        if ($table->hasColumn('allow_parent_company_access_to_all_tickets')) {
            $table->dropColumn('allow_parent_company_access_to_all_tickets');
        }
    }
}
