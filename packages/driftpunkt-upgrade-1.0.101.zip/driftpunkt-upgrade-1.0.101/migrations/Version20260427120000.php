<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

final class Version20260427120000 extends AbstractMigration
{
    private const LEGACY_SUPER_ADMIN_EMAIL = 'kenta@spelhubben.se';
    private const STANDARD_SUPER_ADMIN_EMAIL = 'super@test.local';
    private const STANDARD_SUPER_ADMIN_PASSWORD = 'AdminPassword123';

    public function getDescription(): string
    {
        return 'Replaces the legacy hidden super admin with the standard test super admin account';
    }

    public function up(Schema $schema): void
    {
        if (!$schema->hasTable('users')) {
            return;
        }

        $legacyUser = $this->connection->fetchAssociative(
            'SELECT id FROM users WHERE email = :email',
            ['email' => self::LEGACY_SUPER_ADMIN_EMAIL],
        );

        if (false === $legacyUser) {
            return;
        }

        $standardSuperAdminExists = (bool) $this->connection->fetchOne(
            'SELECT 1 FROM users WHERE email = :email',
            ['email' => self::STANDARD_SUPER_ADMIN_EMAIL],
        );

        if (!$standardSuperAdminExists) {
            $this->addSql(
                <<<'SQL'
UPDATE users
SET email = :standard_email,
    first_name = 'Super',
    last_name = 'Admin',
    type = 'super_admin',
    password = :password,
    is_active = 1,
    mfa_enabled = 0,
    email_notifications_enabled = 1,
    password_change_required = 1,
    updated_at = CURRENT_TIMESTAMP
WHERE email = :legacy_email
SQL,
                [
                    'legacy_email' => self::LEGACY_SUPER_ADMIN_EMAIL,
                    'standard_email' => self::STANDARD_SUPER_ADMIN_EMAIL,
                    'password' => password_hash(self::STANDARD_SUPER_ADMIN_PASSWORD, \PASSWORD_BCRYPT),
                ],
            );

            return;
        }

        $this->addSql(
            <<<'SQL'
UPDATE users
SET email = :disabled_email,
    is_active = 0,
    password = :password,
    password_change_required = 1,
    updated_at = CURRENT_TIMESTAMP
WHERE email = :legacy_email
SQL,
            [
                'legacy_email' => self::LEGACY_SUPER_ADMIN_EMAIL,
                'disabled_email' => sprintf('disabled-super-admin-%d@local.invalid', (int) $legacyUser['id']),
                'password' => password_hash(self::STANDARD_SUPER_ADMIN_PASSWORD, \PASSWORD_BCRYPT),
            ],
        );
    }

    public function down(Schema $schema): void
    {
        // The migration intentionally does not restore the removed hidden account.
    }
}
