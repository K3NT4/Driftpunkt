# API för integrationer

Driftpunkt har ett litet read-only JSON-API för ticketexport:

```http
GET /api/v1/tickets
Authorization: Bearer <DRIFTPUNKT_API_TOKEN>
```

API:t är avstängt om `DRIFTPUNKT_API_TOKEN` är tomt. Sätt token som riktig miljövariabel eller i `.env.local`, inte i versionshanterad produktionskonfiguration.

## Parametrar

- `status`: valfri ticketstatus, exempelvis `open`, `pending_customer` eller `closed`
- `limit`: antal poster, 1 till 100, standard 50

## Exempel

```bash
curl -H "Authorization: Bearer $DRIFTPUNKT_API_TOKEN" \
  "https://driftpunkt.example/api/v1/tickets?status=open&limit=25"
```

API:t är avsett för kontrollerad export till rapportering eller enkel integration. Skrivoperationer, webhooks, OAuth och separata integrationstokens per kund ingår inte i den här versionen.
