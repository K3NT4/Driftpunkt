# Konfiguration av e-post i Driftpunkt

Driftpunkt har två huvudbegrepp för e-post:

- `MailServer`
- `SupportMailbox`

Dessutom finns `CompanyMailOverride` för matchning eller överstyrning.

## MailServer

Mailserverobjekt beskriver hur Driftpunkt ska prata med en e-posttjänst.

Servern kan användas för:

- inkommande trafik
- utgående trafik

Konfigurationen omfattar bland annat:

- värdnamn och port
- kryptering
- autentiseringsläge
- riktning
- eventuella OAuth-relaterade uppgifter i de flöden som stödjer det

## SupportMailbox

Supportinkorgar kopplas till en inkommande server och representerar konkreta inkorgar som ska läsas.

De används av:

- spool-baserade flöden
- pollingkommandot `app:mail:poll`

Varje IMAP-inkorg har två destinationsmappar, med standardnamnen `Behandlade` och `Fel`. Driftpunkt skapar dem vid behov. Namnen kan ändras per inkorg, men de måste vara olika och får inte vara `INBOX`.

### Microsoft 365

Använd en inkommande IMAP-server med `outlook.office365.com`, port 993, SSL/TLS och autentiseringsläget Microsoft OAuth. Entra-appen behöver Exchange Online-behörigheten `IMAP.AccessAsApp`, admin consent, registrerad service principal och åtkomst till postlådan.

### Google Workspace

Använd `imap.gmail.com`, port 993, SSL/TLS och autentiseringsläget Google OAuth. Funktionen är valfri och påverkar inte andra mailflöden när den inte används. Superadmin konfigurerar klient-ID och klienthemlighet under **E-post & inkorgar**. Klienthemligheten visas aldrig efter att den sparats och både klienthemligheten och inkorgarnas refresh tokens krypteras med en nyckel som härleds från installationens befintliga `APP_SECRET`.

Miljövariablerna nedan finns kvar som frivillig override för installationer som vill hantera hemligheter utanför databasen, men de behöver inte läggas till när konfigurationen görs i superadmin:

```dotenv
DRIFTPUNKT_MAIL_SECRET_KEY=<base64-kodad-32-byte-nyckel>
GOOGLE_MAIL_OAUTH_CLIENT_ID=<google-client-id>
GOOGLE_MAIL_OAUTH_CLIENT_SECRET=<google-client-secret>
```

`DRIFTPUNKT_MAIL_SECRET_KEY` är också valfri. Om den anges skapas den med `openssl rand -base64 32` och ersätter den APP_SECRET-härledda nyckeln. Byt inte `APP_SECRET` eller den separata mailnyckeln efter att tokens har sparats utan en planerad tokenrotation. Lägg aldrig riktiga värden i repo. När servern och supportinkorgen sparats ansluter superadmin Google-kontot från inkorgens redigeringspanel. Kontots verifierade e-postadress måste matcha inkorgsadressen.

OAuth-klienten ska använda Driftpunkts callback-URL:

```text
https://driftpunkt.example.com/portal/admin/mailboxes/google-oauth/callback
```

En OAuth-app som används mot flera kunders Workspace-domäner kan behöva Googles verifiering för Gmail-scope `https://mail.google.com/`.

## CompanyMailOverride

Används när ett företag eller viss avsändarklass ska matchas mer exakt än standardlogiken klarar. Det är viktigt i miljöer där:

- flera kunder delar domänliknande adresser
- viss inkorg alltid ska kopplas till visst företag
- okända avsändare ska styras mer kontrollerat

## Test av mailserver

Admin kan trigga test av konfigurerad server via adminportalen. Detta ska användas innan produktionssatt polling.

## Rekommenderad grunduppsättning

1. lägg upp inkommande mailserver
2. lägg upp supportinkorg
3. kör servertest
4. verifiera ingest med en testmail
5. aktivera schemalagd polling

## Utgående e-post

Utgående e-post används bland annat för:

- lösenordsåterställning
- ticketnotifieringar
- bekräftelser vid inkommande ticketflöden

Kontrollera att `mailer`-konfigurationen i Symfony och relevanta systeminställningar stämmer innan skarp drift.
