# Driftguide för mailbox polling

## Kommando

```bash
php bin/console app:mail:poll
php bin/console app:internal-reports:retry-notifications
```

Kommandot läser aktiva supportinkorgar och skickar varje hittat meddelande vidare till ingestflödet.

Kommandot respekterar inkorgens hämtningsintervall. `--mailbox=<namn-eller-adress>` tvingar en viss aktiv inkorg att köras direkt.

## Behandling, retry och IMAP-mappar

- färdigbehandlade mejl flyttas lästa till inkorgens mapp `Behandlade`
- avvisade mejl och mejl som skapar granskningsutkast räknas som färdigbehandlade
- tekniska fel lämnas olästa och försöks igen vid nästa schemalagda pollning
- efter det tredje misslyckade försöket flyttas mejlet läst till `Fel`
- flyttfel försöks igen utan att ärende, kommentar eller utkast skapas på nytt
- ett felaktigt mejl stoppar inte resterande mejl eller andra inkorgar

Driftpunkt använder IMAP UIDVALIDITY och UID för beständig identifiering. Flytta ett korrigerat mejl manuellt från `Fel` tillbaka till `INBOX` om det ska behandlas igen.

## När polling ska användas

Polling ska användas när Driftpunkt själv ska hämta ny supportpost från konfigurerade inkorgar.

Det ska inte förväxlas med:

- `app:mail:ingest`, som behandlar ett enskilt inkommande meddelande
- manuell adminhantering av draftgranskningar

## Förberedelser

Innan polling aktiveras ska följande vara klart:

- minst en inkommande `MailServer`
- minst en aktiv `SupportMailbox`
- verifierad anslutning mot mailservern
- fungerande utgående e-post om notifieringar ska skickas

## Schemaläggning

Repoexempel finns i:

- `deploy/systemd/driftpunkt-mail-poll.service`
- `deploy/systemd/driftpunkt-mail-poll.timer`
- `deploy/cron/driftpunkt-mail-poll.cron`

## Rekommenderad cron

```cron
*/5 * * * * cd /path/to/driftpunkt && php bin/console app:mail:poll --env=prod >> var/log/mail-poll.log 2>&1
*/5 * * * * cd /path/to/driftpunkt && php bin/console app:internal-reports:retry-notifications --env=prod >> var/log/internal-report-retry.log 2>&1
```

## Rekommenderad systemd-timer

1. kopiera mallfilerna till `/etc/systemd/system/`
2. ersätt sökvägar och användare
3. kör:

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now driftpunkt-mail-poll.timer
sudo systemctl list-timers | grep driftpunkt-mail-poll
```

Systemd-mallen skriver stdout och stderr till `var/log/mail-poll.log`, så samma logg kan följas från adminvyn eller med `tail`.

## Driftobservationer

Efter aktivering bör du följa upp:

- att nya mail markeras som behandlade
- att tickets eller draftgranskningar faktiskt skapas
- att loggar inte visar upprepade anslutningsfel
- att notifieringar skickas som förväntat

## Felsökning

Kör kommandot manuellt med mer loggning:

```bash
php bin/console app:mail:poll -vvv
```

Kontrollera sedan:

- serveruppgifter
- autentisering
- att inkorgen verkligen är aktiv
- att databasen och lagringsmappar är skrivbara
- att Google OAuth är konfigurerat i superadmin om inkorgen använder Google Workspace
- att Google-kontot är anslutet på supportinkorgen
- att serverkontot får skapa eller flytta till Behandlade och Fel
