#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "${SCRIPT_DIR}/../.." && pwd)"
ENV_FILE="${ENV_FILE:-${SCRIPT_DIR}/.env}"
COMPOSE_FILE="${COMPOSE_FILE:-${SCRIPT_DIR}/compose.yaml}"
STAMP="$(date +%Y%m%d-%H%M%S)"
ARCHIVE="${1:-}"
WORK_DIR=""

if [ -z "${ARCHIVE}" ]; then
  echo "Anvandning: CONFIRM=restore $0 /sokvag/till/driftpunkt-backup.tar.gz" >&2
  exit 1
fi

if [ "${CONFIRM:-}" != "restore" ]; then
  echo "Restore skriver over databas och deploy/nas/data/var." >&2
  echo "Kor igen med CONFIRM=restore nar du ar saker." >&2
  exit 1
fi

if [ ! -f "${ARCHIVE}" ]; then
  echo "Backupfilen finns inte: ${ARCHIVE}" >&2
  exit 1
fi

if [ ! -f "${ENV_FILE}" ]; then
  echo "Saknar env-fil: ${ENV_FILE}" >&2
  exit 1
fi

if [ ! -f "${COMPOSE_FILE}" ]; then
  echo "Saknar compose-fil: ${COMPOSE_FILE}" >&2
  exit 1
fi

cleanup() {
  if [ -n "${WORK_DIR}" ] && [ -d "${WORK_DIR}" ]; then
    rm -rf "${WORK_DIR}"
  fi
}
trap cleanup EXIT

mkdir -p "${SCRIPT_DIR}/backups"
WORK_DIR="$(mktemp -d "${SCRIPT_DIR}/backups/.restore-${STAMP}-XXXXXX")"
tar -xzf "${ARCHIVE}" -C "${WORK_DIR}"

if [ ! -f "${WORK_DIR}/database.sql" ]; then
  echo "Backupen saknar database.sql." >&2
  exit 1
fi

cd "${PROJECT_DIR}"

docker compose -f "${COMPOSE_FILE}" --env-file "${ENV_FILE}" stop app scheduler >/dev/null 2>&1 || true
docker compose -f "${COMPOSE_FILE}" --env-file "${ENV_FILE}" up -d database

if [ -d "${WORK_DIR}/var" ]; then
  mkdir -p "${SCRIPT_DIR}/data"
  if [ -d "${SCRIPT_DIR}/data/var" ]; then
    mv "${SCRIPT_DIR}/data/var" "${SCRIPT_DIR}/data/var.before-restore-${STAMP}"
  fi
  cp -a "${WORK_DIR}/var" "${SCRIPT_DIR}/data/var"
fi

docker compose -f "${COMPOSE_FILE}" --env-file "${ENV_FILE}" exec -T database \
  sh -c 'mariadb -u root -p"$MARIADB_ROOT_PASSWORD" "$MARIADB_DATABASE"' \
  < "${WORK_DIR}/database.sql"

docker compose -f "${COMPOSE_FILE}" --env-file "${ENV_FILE}" up -d

echo "Restore klar fran: ${ARCHIVE}"
