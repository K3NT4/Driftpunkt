#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "${SCRIPT_DIR}/../.." && pwd)"
BACKUP_DIR="${BACKUP_DIR:-${SCRIPT_DIR}/backups}"
ENV_FILE="${ENV_FILE:-${SCRIPT_DIR}/.env}"
COMPOSE_FILE="${COMPOSE_FILE:-${SCRIPT_DIR}/compose.yaml}"
BACKUP_RETENTION_DAYS="${BACKUP_RETENTION_DAYS:-14}"
STAMP="$(date +%Y%m%d-%H%M%S)"
ARCHIVE="${BACKUP_DIR}/driftpunkt-${STAMP}.tar.gz"
LOCK_DIR="${BACKUP_DIR}/.backup.lock"
WORK_DIR=""

mkdir -p "${BACKUP_DIR}"

if ! mkdir "${LOCK_DIR}" 2>/dev/null; then
  echo "En backup verkar redan kora (${LOCK_DIR})." >&2
  exit 1
fi

cleanup() {
  if [ -n "${WORK_DIR}" ] && [ -d "${WORK_DIR}" ]; then
    rm -rf "${WORK_DIR}"
  fi
  rmdir "${LOCK_DIR}" 2>/dev/null || true
}
trap cleanup EXIT

if [ ! -f "${ENV_FILE}" ]; then
  echo "Saknar env-fil: ${ENV_FILE}" >&2
  exit 1
fi

if [ ! -f "${COMPOSE_FILE}" ]; then
  echo "Saknar compose-fil: ${COMPOSE_FILE}" >&2
  exit 1
fi

cd "${PROJECT_DIR}"
mkdir -p "${SCRIPT_DIR}/data/var"
WORK_DIR="$(mktemp -d "${BACKUP_DIR}/.tmp-${STAMP}-XXXXXX")"

docker compose -f "${COMPOSE_FILE}" --env-file "${ENV_FILE}" ps database >/dev/null

docker compose -f "${COMPOSE_FILE}" --env-file "${ENV_FILE}" exec -T database \
  sh -c 'mariadb-dump --single-transaction --quick --routines --triggers --events -u root -p"$MARIADB_ROOT_PASSWORD" "$MARIADB_DATABASE"' \
  > "${WORK_DIR}/database.sql"

{
  echo "created_at=$(date -Iseconds)"
  echo "project_dir=${PROJECT_DIR}"
  echo "compose_file=${COMPOSE_FILE}"
  echo "env_file=${ENV_FILE}"
  echo "git_commit=$(git rev-parse --short HEAD 2>/dev/null || echo unknown)"
  echo "database_dump=database.sql"
  echo "var_path=var"
} > "${WORK_DIR}/manifest.txt"

tar -czf "${ARCHIVE}" \
  -C "${SCRIPT_DIR}/data" var \
  -C "${WORK_DIR}" database.sql manifest.txt

tar -tzf "${ARCHIVE}" >/dev/null

if [ "${BACKUP_RETENTION_DAYS}" -gt 0 ] 2>/dev/null; then
  find "${BACKUP_DIR}" -maxdepth 1 -type f -name 'driftpunkt-*.tar.gz' -mtime "+${BACKUP_RETENTION_DAYS}" -delete
fi

echo "Backup skapad: ${ARCHIVE}"
