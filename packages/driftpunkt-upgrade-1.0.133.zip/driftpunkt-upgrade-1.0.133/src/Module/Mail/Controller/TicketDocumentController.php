<?php

declare(strict_types=1);

namespace App\Module\Mail\Controller;

use App\Module\Identity\Entity\User;
use App\Module\Mail\Service\AttachedEmailReader;
use App\Module\Mail\Service\TnefAttachmentReader;
use App\Module\Ticket\Entity\TicketCommentAttachment;
use App\Module\Ticket\Service\TicketAccessPolicy;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;
use Symfony\Component\Security\Http\Attribute\IsGranted;

#[IsGranted('IS_AUTHENTICATED_FULLY')]
final class TicketDocumentController extends AbstractController
{
    public function __construct(private readonly AttachedEmailReader $reader, private readonly TnefAttachmentReader $tnef, private readonly TicketAccessPolicy $accessPolicy) {}

    #[Route('/portal/ticket-attachments/{id}/pdf', name: 'app_ticket_attachment_pdf', methods: ['GET'], requirements: ['id' => '\d+'])]
    public function pdf(TicketCommentAttachment $attachment): Response
    {
        $this->denyUnlessAllowed($attachment);
        if (!$attachment->isPdf()) { throw $this->createNotFoundException(); }
        try { $content = $this->reader->content($attachment); }
        catch (\InvalidArgumentException $exception) { throw $this->createNotFoundException($exception->getMessage()); }
        if (!str_starts_with($content, '%PDF-')) { throw $this->createNotFoundException('Bilagan är inte en verifierad PDF.'); }
        $response = new Response($content);
        $response->headers->set('Content-Type', 'application/pdf');
        $response->headers->set('Content-Disposition', $response->headers->makeDisposition('inline', $attachment->getDisplayName(), 'document.pdf'));
        $response->headers->set('Content-Security-Policy', "default-src 'none'; sandbox");
        return $this->privateResponse($response);
    }

    #[Route('/portal/ticket-attachments/{id}/tnef', name: 'app_ticket_attachment_tnef', methods: ['GET'], requirements: ['id' => '\d+'])]
    public function tnef(Request $request, TicketCommentAttachment $attachment): Response
    {
        $this->denyUnlessAllowed($attachment);
        if (!$attachment->isTnef()) { throw $this->createNotFoundException(); }
        $files = [];
        $error = null;
        try { $files = $this->tnef->extract($this->reader->content($attachment)); }
        catch (\InvalidArgumentException $exception) { $error = $exception->getMessage(); }
        if ($request->query->has('file')) {
            $index = (string) $request->query->get('file');
            if (!ctype_digit($index) || !isset($files[(int) $index])) { throw $this->createNotFoundException(); }
            $file = $files[(int) $index];
            $response = new Response($file['content']);
            $response->headers->set('Content-Type', 'application/octet-stream');
            $response->headers->set('Content-Disposition', $response->headers->makeDisposition('attachment', $file['displayName'], preg_replace('/[^\x20-\x7e]|%/', '_', $file['displayName']) ?: 'attachment.bin'));
        } else {
            $response = $this->render('portal/tnef_attachment.html.twig', ['attachment' => $attachment, 'files' => $files, 'readError' => $error]);
        }
        return $this->privateResponse($response);
    }

    #[Route('/portal/mail-attachment-recoveries/{id}/retry', name: 'app_mail_attachment_recovery_retry', methods: ['POST'], requirements: ['id' => '\d+'])]
    public function retry(Request $request, \App\Module\Mail\Entity\MailAttachmentRecovery $recovery, \App\Module\Mail\Service\MailAttachmentRecoverySender $sender): Response
    {
        $ticket = $recovery->getComment()->getTicket();
        $this->denyUnlessTicket($ticket);
        if (!$this->isCsrfTokenValid('mail_recovery_'.$recovery->getId(), (string) $request->request->get('_token'))) { throw $this->createAccessDeniedException(); }
        $sender->retryNow($recovery);
        $this->addFlash('sent' === $recovery->getState() ? 'success' : 'error', 'sent' === $recovery->getState() ? 'Originalmejlet är vidarebefordrat.' : ($recovery->getLastError() ?? 'Vidarebefordringen misslyckades.'));
        return $this->redirectToRoute($this->isGranted('ROLE_TICKET_COORDINATOR') ? 'app_portal_coordinator_ticket_show' : 'app_portal_technician_ticket_show', ['id' => $ticket->getId()]);
    }

    private function denyUnlessAllowed(TicketCommentAttachment $attachment): void
    {
        $this->denyUnlessTicket($attachment->getComment()->getTicket());
    }

    private function denyUnlessTicket(\App\Module\Ticket\Entity\Ticket $ticket): void
    {
        $user = $this->getUser();
        if (!$user instanceof User || !($this->isGranted('ROLE_ADMIN') || $this->isGranted('ROLE_TICKET_COORDINATOR')
            || ($this->isGranted('ROLE_TECHNICIAN') && $this->accessPolicy->technicianCanReadTicket($user, $ticket)))) {
            throw $this->createAccessDeniedException();
        }
    }

    private function privateResponse(Response $response): Response
    {
        $response->headers->set('Cache-Control', 'private, no-store');
        $response->headers->set('X-Content-Type-Options', 'nosniff');
        return $response;
    }
}
