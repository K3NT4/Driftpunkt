<?php

declare(strict_types=1);

namespace App\Module\Mail\Controller;

use App\Module\Identity\Entity\User;
use App\Module\Mail\Service\AttachedEmailReader;
use App\Module\Ticket\Entity\TicketCommentAttachment;
use App\Module\Ticket\Service\TicketAccessPolicy;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\ResponseHeaderBag;
use Symfony\Component\Routing\Attribute\Route;
use Symfony\Component\Security\Http\Attribute\IsGranted;

#[IsGranted('IS_AUTHENTICATED_FULLY')]
final class AttachedEmailController extends AbstractController
{
    public function __construct(
        private readonly AttachedEmailReader $reader,
        private readonly TicketAccessPolicy $accessPolicy,
        private readonly \Doctrine\ORM\EntityManagerInterface $entityManager,
        private readonly \App\Module\Mail\Service\AttachedEmailTicketCreator $ticketCreator,
    ) {
    }

    #[Route('/portal/ticket-attachments/{id}/mail', name: 'app_ticket_attached_email', methods: ['GET'], requirements: ['id' => '\d+'])]
    public function show(Request $request, TicketCommentAttachment $attachment): Response
    {
        $this->denyUnlessAllowed($attachment);
        $part = (string) $request->query->get('part', '');
        $message = null;
        $error = null;
        try {
            $message = $this->reader->messageAt($this->reader->read($attachment), $part);
        } catch (\OutOfBoundsException) {
            throw $this->createNotFoundException();
        } catch (\InvalidArgumentException $exception) {
            $error = $exception->getMessage();
        }
        $ticket = $attachment->getComment()->getTicket();
        $response = $this->render('portal/attached_email.html.twig', [
            'ticket' => $ticket,
            'attachment' => $attachment,
            'message' => $message,
            'bodyText' => null !== $message ? $this->reader->bodyText($message) : '',
            'part' => $part,
            'readError' => $error,
            'companies' => $this->entityManager->getRepository(\App\Module\Identity\Entity\Company::class)->findBy([], ['name' => 'ASC']),
            'customers' => $this->entityManager->getRepository(User::class)->findBy(['type' => \App\Module\Identity\Enum\UserType::CUSTOMER, 'isActive' => true], ['firstName' => 'ASC', 'lastName' => 'ASC']),
            'backUrl' => $this->isGranted('ROLE_TICKET_COORDINATOR')
                ? $this->generateUrl('app_portal_coordinator_ticket_show', ['id' => $ticket->getId()])
                : $this->generateUrl('app_portal_technician_ticket_show', ['id' => $ticket->getId()]),
        ]);

        return $this->privateResponse($response);
    }

    #[Route('/portal/ticket-attachments/{id}/mail/attachments/{part}', name: 'app_ticket_attached_email_download', methods: ['GET'], requirements: ['id' => '\d+', 'part' => '\d+(?:\.\d+)*'])]
    public function download(TicketCommentAttachment $attachment, string $part): Response
    {
        $this->denyUnlessAllowed($attachment);
        try {
            $nested = $this->reader->attachmentAt($this->reader->read($attachment), $part);
        } catch (\InvalidArgumentException|\OutOfBoundsException) {
            throw $this->createNotFoundException('Bilagan kunde inte läsas.');
        }
        $response = new Response($nested->content());
        $response->headers->set('Content-Type', 'application/octet-stream');
        $response->headers->set('Content-Disposition', $response->headers->makeDisposition(
            ResponseHeaderBag::DISPOSITION_ATTACHMENT,
            $nested->filename,
            preg_replace('/[^\x20-\x7E]|%/', '_', $nested->filename) ?: 'attachment.bin',
        ));

        return $this->privateResponse($response);
    }

    #[Route('/portal/ticket-attachments/{id}/mail/create-ticket', name: 'app_ticket_attached_email_create_ticket', methods: ['POST'], requirements: ['id' => '\d+'])]
    public function createTicket(Request $request, TicketCommentAttachment $attachment): Response
    {
        $this->denyUnlessAllowed($attachment);
        if (!$this->isCsrfTokenValid('attached_email_ticket_'.$attachment->getId(), (string) $request->request->get('_token'))) {
            throw $this->createAccessDeniedException('Kunde inte verifiera formuläret.');
        }
        $part = (string) $request->request->get('part', '');
        $company = $this->entityManager->find(\App\Module\Identity\Entity\Company::class, $request->request->getInt('company_id'));
        $customer = $this->entityManager->find(User::class, $request->request->getInt('customer_id'));
        if (!$company instanceof \App\Module\Identity\Entity\Company || !$customer instanceof User || !$request->request->getBoolean('confirm_content')) {
            $this->addFlash('error', 'Välj kund och företag och bekräfta att du har kontrollerat mejlets innehåll.');
            return $this->redirectToRoute('app_ticket_attached_email', ['id' => $attachment->getId(), 'part' => $part]);
        }
        $actor = $this->getUser();
        \assert($actor instanceof User);
        try {
            $ticket = $this->ticketCreator->create($attachment, $part, $company, $customer, $actor, $request->request->getBoolean('customer_visible'));
        } catch (\InvalidArgumentException|\OutOfBoundsException $exception) {
            $this->addFlash('error', $exception->getMessage());
            return $this->redirectToRoute('app_ticket_attached_email', ['id' => $attachment->getId(), 'part' => $part]);
        }
        if (!$this->isGranted('ROLE_ADMIN') && !$this->isGranted('ROLE_TICKET_COORDINATOR') && !$this->accessPolicy->technicianCanReadTicket($actor, $ticket)) {
            $this->addFlash('error', 'Ett ärende har redan skapats från det här mejlet. Kontakta koordinatorn för åtkomst.');
            return $this->redirectToRoute('app_ticket_attached_email', ['id' => $attachment->getId(), 'part' => $part]);
        }
        $this->addFlash('success', sprintf('Ärende %s är kopplat till ursprungsärendet. Inget kundmejl har skickats.', $ticket->getReference()));
        return $this->redirectToRoute($this->isGranted('ROLE_TICKET_COORDINATOR') ? 'app_portal_coordinator_ticket_show' : 'app_portal_technician_ticket_show', ['id' => $ticket->getId()]);
    }

    private function denyUnlessAllowed(TicketCommentAttachment $attachment): void
    {
        $user = $this->getUser();
        if (!$user instanceof User || !($this->isGranted('ROLE_ADMIN') || $this->isGranted('ROLE_TICKET_COORDINATOR')
            || ($this->isGranted('ROLE_TECHNICIAN') && $this->accessPolicy->technicianCanReadTicket($user, $attachment->getComment()->getTicket())))) {
            throw $this->createAccessDeniedException();
        }
        if (!$attachment->isEmailMessage()) {
            throw $this->createNotFoundException();
        }
    }

    private function privateResponse(Response $response): Response
    {
        $response->headers->set('Cache-Control', 'private, no-store');
        $response->headers->set('X-Content-Type-Options', 'nosniff');
        $response->headers->set('X-Frame-Options', 'SAMEORIGIN');

        return $response;
    }
}
