<?php

declare(strict_types=1);

namespace App\Module\Mail\Entity;

use App\Module\Ticket\Entity\TicketComment;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity]
#[ORM\Table(name: 'mail_attachment_recoveries')]
class MailAttachmentRecovery
{
    #[ORM\Id, ORM\GeneratedValue, ORM\Column]
    private ?int $id = null;

    #[ORM\OneToOne(targetEntity: IncomingMail::class)]
    #[ORM\JoinColumn(nullable: false, onDelete: 'CASCADE')]
    private IncomingMail $incomingMail;

    #[ORM\OneToOne(targetEntity: TicketComment::class, inversedBy: 'attachmentRecovery')]
    #[ORM\JoinColumn(nullable: false, onDelete: 'CASCADE')]
    private TicketComment $comment;

    #[ORM\Column(type: 'json')]
    private array $failures;

    #[ORM\Column]
    private int $savedCount;

    #[ORM\Column]
    private int $duplicateCount;

    #[ORM\Column]
    private int $attempts = 0;

    #[ORM\Column(length: 20)]
    private string $state = 'pending';

    #[ORM\Column(type: 'text', nullable: true)]
    private ?string $lastError = null;

    #[ORM\Column(nullable: true)]
    private ?\DateTimeImmutable $sentAt = null;

    #[ORM\Column(nullable: true)]
    private ?\DateTimeImmutable $retryAt = null;

    public function __construct(IncomingMail $mail, TicketComment $comment, array $failures, int $savedCount, int $duplicateCount)
    {
        $this->incomingMail = $mail;
        $this->comment = $comment;
        $this->failures = $failures;
        $this->savedCount = $savedCount;
        $this->duplicateCount = $duplicateCount;
        $comment->setAttachmentRecovery($this);
    }

    public function getId(): ?int { return $this->id; }
    public function getIncomingMail(): IncomingMail { return $this->incomingMail; }
    public function getComment(): TicketComment { return $this->comment; }
    public function getFailures(): array { return $this->failures; }
    public function getSavedCount(): int { return $this->savedCount; }
    public function getDuplicateCount(): int { return $this->duplicateCount; }
    public function getState(): string { return $this->state; }
    public function getLastError(): ?string { return $this->lastError; }
    public function getSentAt(): ?\DateTimeImmutable { return $this->sentAt; }
    public function canRetry(): bool { return 'sent' !== $this->state && $this->attempts < 3 && (null === $this->retryAt || $this->retryAt <= new \DateTimeImmutable()); }
    public function resetRetry(): void { $this->attempts = 0; $this->retryAt = null; }
    public function beginAttempt(): void { ++$this->attempts; $this->state = 'pending'; $this->retryAt = new \DateTimeImmutable('+5 minutes'); }
    public function markSent(): void { $this->state = 'sent'; $this->sentAt = new \DateTimeImmutable(); $this->lastError = null; }
    public function markFailed(string $error): void { $this->state = 'failed'; $this->lastError = $error; }
}
