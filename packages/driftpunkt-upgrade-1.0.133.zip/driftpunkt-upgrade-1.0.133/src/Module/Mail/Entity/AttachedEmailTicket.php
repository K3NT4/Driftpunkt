<?php

declare(strict_types=1);

namespace App\Module\Mail\Entity;

use App\Module\Ticket\Entity\Ticket;
use App\Module\Ticket\Entity\TicketCommentAttachment;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity]
#[ORM\Table(name: 'attached_email_tickets')]
#[ORM\UniqueConstraint(name: 'uniq_attached_email_ticket_source', columns: ['attachment_id', 'part'])]
class AttachedEmailTicket
{
    #[ORM\Id, ORM\GeneratedValue, ORM\Column]
    private ?int $id = null;

    #[ORM\ManyToOne(targetEntity: TicketCommentAttachment::class)]
    #[ORM\JoinColumn(nullable: false, onDelete: 'CASCADE')]
    private TicketCommentAttachment $attachment;

    #[ORM\Column(length: 30)]
    private string $part;

    #[ORM\ManyToOne(targetEntity: Ticket::class)]
    #[ORM\JoinColumn(nullable: false, onDelete: 'CASCADE')]
    private Ticket $ticket;

    public function __construct(TicketCommentAttachment $attachment, string $part, Ticket $ticket)
    {
        $this->attachment = $attachment;
        $this->part = $part;
        $this->ticket = $ticket;
    }
    public function getTicket(): Ticket { return $this->ticket; }
}
