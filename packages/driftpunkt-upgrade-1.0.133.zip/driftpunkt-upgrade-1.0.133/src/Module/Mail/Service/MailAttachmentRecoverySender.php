<?php

declare(strict_types=1);

namespace App\Module\Mail\Service;

use App\Module\Identity\Entity\User;
use App\Module\Mail\Entity\IncomingMail;
use App\Module\Mail\Entity\MailAttachmentRecovery;
use App\Module\Notification\Entity\NotificationLog;
use App\Module\System\Service\SystemSettings;
use App\Module\Ticket\Entity\TicketComment;
use App\Module\Ticket\Service\AttachmentCopyResult;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\Lock\LockFactory;
use Symfony\Component\Mime\Email;

final class MailAttachmentRecoverySender
{
    public function __construct(
        private readonly EntityManagerInterface $entityManager,
        private readonly ConfiguredMailer $mailer,
        private readonly SystemSettings $settings,
        private readonly LockFactory $lockFactory,
    ) {
    }

    public function report(IncomingMail $mail, TicketComment $comment, AttachmentCopyResult $result): void
    {
        if ([] === $result->getFailures()) {
            return;
        }
        $recovery = $this->entityManager->getRepository(MailAttachmentRecovery::class)->findOneBy(['incomingMail' => $mail]);
        if (!$recovery instanceof MailAttachmentRecovery) {
            $recovery = new MailAttachmentRecovery($mail, $comment, $result->getFailures(), $result->getCreatedAttachmentCount(), $result->getSkippedDuplicateCount());
            $this->entityManager->persist($comment);
            $this->entityManager->persist($recovery);
            $this->entityManager->flush();
        }
        $this->send($recovery);
    }

    public function retryPending(): void
    {
        $pending = $this->entityManager->getRepository(MailAttachmentRecovery::class)->createQueryBuilder('r')
            ->where('r.state <> :sent')->andWhere('r.attempts < 3')
            ->andWhere('r.retryAt IS NULL OR r.retryAt <= :now')
            ->setParameter('sent', 'sent')->setParameter('now', new \DateTimeImmutable())
            ->setMaxResults(25)->getQuery()->getResult();
        foreach ($pending as $recovery) {
            $this->send($recovery);
        }
    }

    public function retryNow(MailAttachmentRecovery $recovery): void { $this->send($recovery, true); }

    private function send(MailAttachmentRecovery $recovery, bool $force = false): void
    {
        $lock = $this->lockFactory->createLock('mail-attachment-recovery-'.$recovery->getId(), 300);
        if (!$lock->acquire()) { return; }
        $recipients = [];
        try {
            $this->entityManager->refresh($recovery);
            if ('sent' === $recovery->getState()) { return; }
            if ($force) { $recovery->resetRetry(); }
            if (!$recovery->canRetry()) { return; }
            $recovery->beginAttempt();
            $this->entityManager->flush();
            $mail = $recovery->getIncomingMail();
            $ticket = $recovery->getComment()->getTicket();
            $recipients = $this->recipients();
            if ([] === $recipients) {
                throw new \InvalidArgumentException('Ingen koordinatoradress eller triagemottagare är vald i inställningarna.');
            }
            $originalPath = $mail->getRawMessagePath();
            $email = (new Email())->to(...$recipients)
                ->subject(sprintf('[%s] Bilagor behöver hanteras manuellt', $ticket->getReference()))
                ->text(sprintf("Kundmejlet från %s kunde inte tas in med alla bilagor.\n\n%d filer sparades och %d fanns redan i ärendet.\n\n%s\n\nOriginalmejlet finns bifogat. Kontrollera bilagorna och komplettera ärendet manuellt.", $mail->getFromEmail(), $recovery->getSavedCount(), $recovery->getDuplicateCount(), implode("\n", array_map(static fn (array $f): string => $f['name'].': '.$f['reason'], $recovery->getFailures()))));
            $email->getHeaders()->addTextHeader('Auto-Submitted', 'auto-replied');
            $email->getHeaders()->addTextHeader('X-Auto-Response-Suppress', 'All');
            $email->getHeaders()->addTextHeader('X-Driftpunkt-Attachment-Recovery', '1');
            $email->getHeaders()->addTextHeader('X-Driftpunkt-Recovery-Id', (string) $recovery->getId());
            if (null !== $originalPath && is_file($originalPath)) {
                $email->attachFromPath($originalPath, 'originalmejl.eml', 'message/rfc822');
            } else {
                $original = (new Email())->from($mail->getFromEmail())->subject($mail->getSubject())->text($mail->getOriginalBody() ?? $mail->getBody());
                foreach ($mail->getAttachmentMetadata() as $file) {
                    if (is_file($file['filePath'] ?? '')) {
                        $original->attachFromPath($file['filePath'], $file['displayName'], $file['mimeType'] ?? 'application/octet-stream');
                    }
                }
                $email->attach($original->toString(), 'rekonstruerat-originalmejl.eml', 'message/rfc822');
                $email->text($email->getTextBody()."\n\nDen ursprungliga .eml-filen saknas. Bilagan är en rekonstruerad kopia av tillgänglig text och de filer som fortfarande finns kvar.");
            }
            $this->mailer->send($email, $ticket->getCompany(), true);
            $recovery->markSent();
            $this->log($recovery, $recipients, true, 'Originalmejlet vidarebefordrades till koordinatorn.');
        } catch (\Throwable $exception) {
            $error = $exception instanceof \InvalidArgumentException
                ? $exception->getMessage() : 'Vidarebefordringen misslyckades. Kontrollera utgående e-post och notifieringsloggen.';
            $recovery->markFailed(mb_substr($error, 0, 1000));
            $this->log($recovery, $recipients, false, mb_substr($error, 0, 255));
        } finally {
            $this->entityManager->flush();
            $lock->release();
        }
    }

    /** @return list<string> */
    private function recipients(): array
    {
        $settings = $this->settings->getTicketTriageSettings();
        if ('' !== $settings['generalRecipientEmail']) {
            return filter_var($settings['generalRecipientEmail'], FILTER_VALIDATE_EMAIL) ? [$settings['generalRecipientEmail']] : [];
        }
        $emails = [];
        foreach ($settings['recipientIds'] as $id) {
            $user = $this->entityManager->find(User::class, $id);
            if ($user instanceof User && $user->isActive() && \in_array($user->getType(), [\App\Module\Identity\Enum\UserType::SUPER_ADMIN, \App\Module\Identity\Enum\UserType::ADMIN, \App\Module\Identity\Enum\UserType::TICKET_COORDINATOR, \App\Module\Identity\Enum\UserType::TECHNICIAN], true)) {
                $emails[] = $user->getEmail();
            }
        }
        return array_values(array_unique($emails));
    }

    private function log(MailAttachmentRecovery $recovery, array $recipients, bool $sent, string $message): void
    {
        foreach ($recipients ?: [''] as $recipient) {
            $log = (new NotificationLog('mail_attachment_recovery', mb_substr($recipient, 0, 180), 'Bilagor behöver hanteras manuellt', $sent, $message))
                ->setTicket($recovery->getComment()->getTicket());
            $this->entityManager->persist($log);
        }
    }
}
