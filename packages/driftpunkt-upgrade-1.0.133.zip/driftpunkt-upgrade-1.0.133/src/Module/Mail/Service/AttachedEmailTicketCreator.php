<?php

declare(strict_types=1);

namespace App\Module\Mail\Service;

use App\Module\Identity\Entity\Company;
use App\Module\Identity\Entity\User;
use App\Module\Mail\Entity\AttachedEmailTicket;
use App\Module\System\Service\SystemSettings;
use App\Module\Ticket\Entity\Ticket;
use App\Module\Ticket\Entity\TicketComment;
use App\Module\Ticket\Entity\TicketCommentAttachment;
use App\Module\Ticket\Entity\TicketRelation;
use App\Module\Ticket\Enum\TicketRelationType;
use App\Module\Ticket\Enum\TicketStatus;
use App\Module\Ticket\Enum\TicketVisibility;
use App\Module\Ticket\Service\TicketAttachmentStorage;
use App\Module\Ticket\Service\TicketAuditLogger;
use App\Module\Ticket\Service\TicketReferenceGenerator;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\Lock\LockFactory;

final class AttachedEmailTicketCreator
{
    public function __construct(
        private readonly EntityManagerInterface $entityManager,
        private readonly AttachedEmailReader $reader,
        private readonly TicketReferenceGenerator $references,
        private readonly TicketAttachmentStorage $storage,
        private readonly SystemSettings $settings,
        private readonly TicketAuditLogger $audit,
        private readonly LockFactory $locks,
    ) {}

    public function create(TicketCommentAttachment $source, string $part, Company $company, User $customer, User $actor, bool $customerVisible): Ticket
    {
        if (!$customer->isActive() || $customer->getCompany()?->getId() !== $company->getId()
            || \App\Module\Identity\Enum\UserType::CUSTOMER !== $customer->getType()) {
            throw new \InvalidArgumentException('Välj en aktiv kundanvändare som tillhör det valda företaget.');
        }
        if ('' !== $part && (\strlen($part) > 30 || !preg_match('/^\d{1,3}(?:\.\d{1,3}){0,4}$/D', $part))) { throw new \OutOfBoundsException('Ogiltigt bifogat mejl.'); }
        $settings = $this->settings->getTicketAttachmentSettings();
        if (!$settings['enabled']) { throw new \InvalidArgumentException('Aktivera bilagefunktionen för att bevara originalmejlet i det nya ärendet.'); }
        $lock = $this->locks->createLock('attached-email-ticket-'.$source->getId().'-'.hash('sha256', $part), 300);
        if (!$lock->acquire(true)) { throw new \RuntimeException('Kunde inte låsa ärendeskapandet.'); }
        $storedPath = null;
        try {
            $existing = $this->entityManager->getRepository(AttachedEmailTicket::class)->findOneBy(['attachment' => $source, 'part' => $part]);
            if ($existing instanceof AttachedEmailTicket) { return $existing->getTicket(); }
            $message = $this->reader->messageAt($this->reader->read($source), $part);
            $content = '' === $part ? $this->reader->content($source) : ($message->originalContent ?? $message->toEml());
            if (\strlen($content) > $settings['maxUploadMb'] * 1024 * 1024) { throw new \InvalidArgumentException('Originalmejlet överskrider ärendets uppladdningsgräns.'); }
            $filename = '' === $part ? $source->getDisplayName() : 'bifogat-mejl.eml';
            return $this->entityManager->wrapInTransaction(function () use ($source, $part, $company, $customer, $actor, $customerVisible, $message, $content, $filename, $settings, &$storedPath): Ticket {
                $ticket = (new Ticket($this->references->nextReference($company), mb_substr($message->subject ?: 'Bifogat mejl', 0, 255), $this->reader->bodyText($message) ?: 'Se bifogat originalmejl.', TicketStatus::OPEN, $customerVisible ? TicketVisibility::PRIVATE : TicketVisibility::INTERNAL_ONLY))
                    ->setCompany($company)->setRequester($customer)->setAssignee($actor);
                $this->entityManager->persist($ticket);
                $comment = new TicketComment($ticket, $actor, 'Originalmejl från bifogat meddelande.', !$customerVisible, true);
                $ticket->addComment($comment);
                $stored = $this->storage->storeBinaryContent($content, $filename, str_ends_with(mb_strtolower($filename), '.msg') ? 'application/vnd.ms-outlook' : 'message/rfc822', $ticket, $settings['storagePath']);
                $storedPath = $stored['filePath'];
                $comment->addAttachment(TicketCommentAttachment::fromLocalFile($comment, $stored['displayName'], $storedPath, $stored['mimeType'], $stored['fileSize'], $stored['contentHash']));
                $this->entityManager->persist($comment);
                $relation = new TicketRelation($source->getComment()->getTicket(), $ticket, TicketRelationType::RELATED, $actor);
                $this->entityManager->persist($relation);
                $this->entityManager->persist(new AttachedEmailTicket($source, $part, $ticket));
                $this->audit->log($ticket, 'ticket_created_from_attached_email', 'Ärende skapat från bifogat mejl efter kontroll av kund, företag och innehåll.', $actor, ['sourceTicketId' => $source->getComment()->getTicket()->getId(), 'sourceAttachmentId' => $source->getId(), 'part' => $part]);
                $this->audit->log($source->getComment()->getTicket(), 'related_ticket_created', sprintf('Ärende %s skapades från ett bifogat mejl.', $ticket->getReference()), $actor);
                return $ticket;
            });
        } catch (\Throwable $exception) {
            if (null !== $storedPath && is_file($storedPath)) { @unlink($storedPath); }
            throw $exception;
        } finally { $lock->release(); }
    }
}
