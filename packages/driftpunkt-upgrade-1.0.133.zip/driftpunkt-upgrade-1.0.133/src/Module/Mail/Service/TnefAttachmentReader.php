<?php

declare(strict_types=1);

namespace App\Module\Mail\Service;

/** Bounded extraction of by-value attachments, based on Microsoft's MS-OXTNEF specification. */
final class TnefAttachmentReader
{
    /** @return list<array{displayName: string, mimeType: ?string, content: string}> */
    public function extract(string $bytes): array
    {
        if (\strlen($bytes) > AttachedEmailReader::MAX_BYTES || !str_starts_with($bytes, "\x78\x9f\x3e\x22")) {
            throw new \InvalidArgumentException('winmail.dat är ogiltig eller större än 20 MB.');
        }
        $offset = 6;
        $files = [];
        $current = null;
        $charset = 'Windows-1252';
        $attributes = 0;
        $budget = 10000;
        while ($offset < \strlen($bytes)) {
            if (++$attributes > 2000) { throw new \InvalidArgumentException('För många TNEF-attribut.'); }
            $level = ord($this->take($bytes, $offset, 1));
            $id = $this->u32($bytes, $offset) & 0xffff;
            $length = $this->u32($bytes, $offset);
            $data = $this->take($bytes, $offset, $length);
            $expected = unpack('v', $this->take($bytes, $offset, 2))[1];
            $sum = 0;
            for ($i = 0; $i < $length; ++$i) { $sum = ($sum + ord($data[$i])) & 0xffff; }
            if ($sum !== $expected) { throw new \InvalidArgumentException('Felaktig kontrollsumma i winmail.dat.'); }
            if (1 === $level && 0x9007 === $id && $length >= 4) {
                $codepage = unpack('V', substr($data, 0, 4))[1];
                $charset = 65001 === $codepage ? 'UTF-8' : 'Windows-'.$codepage;
            }
            if (2 !== $level) { continue; }
            if (0x9002 === $id) {
                if (null !== $current) { $files[] = $this->file($current, $charset); }
                if (\count($files) >= 100) { throw new \InvalidArgumentException('För många filer i winmail.dat.'); }
                $current = [];
            }
            if (null === $current) { throw new \InvalidArgumentException('Bilagestrukturen i winmail.dat är ogiltig.'); }
            if (0x8010 === $id || 0x9001 === $id) { $current['name'] = rtrim($data, "\0"); }
            if (0x800f === $id) { $current['content'] = $data; }
            if (0x9005 === $id) { $current = array_replace($current, $this->properties($data, $charset, $budget)); }
        }
        if (null !== $current) { $files[] = $this->file($current, $charset); }

        return $files;
    }

    private function file(array $file, string $charset): array
    {
        if (!isset($file['content']) || (isset($file['method']) && 1 !== $file['method'])) {
            throw new \InvalidArgumentException('Ett inbäddat objekt i winmail.dat kunde inte packas upp som vanlig fil.');
        }
        $name = $file['unicodeName'] ?? $this->text($file['name'] ?? 'bilaga.bin', $charset);
        $name = basename(str_replace('\\', '/', $name));
        $name = preg_replace('/[\x00-\x1f\x7f]/', '', $name) ?: 'bilaga.bin';

        return ['displayName' => mb_substr($name, 0, 255), 'mimeType' => isset($file['mime']) && preg_match('~^[a-zA-Z0-9!#$&^_.+-]+/[a-zA-Z0-9!#$&^_.+-]+$~D', $file['mime']) ? mb_substr($file['mime'], 0, 191) : null, 'content' => $file['content']];
    }

    private function properties(string $data, string $charset, int &$budget): array
    {
        $offset = 0;
        $count = $this->u32($data, $offset);
        if ($count > 2000) { throw new \InvalidArgumentException('För många MAPI-egenskaper.'); }
        $result = [];
        for ($p = 0; $p < $count; ++$p) {
            if (--$budget < 0) { throw new \InvalidArgumentException('För många MAPI-egenskaper i winmail.dat.'); }
            $tag = $this->u32($data, $offset);
            $id = $tag >> 16;
            $type = $tag & 0xffff;
            if ($id >= 0x8000) {
                $this->take($data, $offset, 16);
                $kind = $this->u32($data, $offset);
                if (0 === $kind) { $this->take($data, $offset, 4); }
                elseif (1 === $kind) { $size = $this->u32($data, $offset); $this->take($data, $offset, $size + ((4 - $size % 4) % 4)); }
                else { throw new \InvalidArgumentException('Ogiltig namngiven MAPI-egenskap.'); }
            }
            $baseType = $type & ~0x1000;
            $variable = \in_array($baseType, [0x001e, 0x001f, 0x0102, 0x000d], true);
            $values = $variable || ($type & 0x1000) ? $this->u32($data, $offset) : 1;
            if ($values > 1000) { throw new \InvalidArgumentException('För många MAPI-värden.'); }
            for ($v = 0; $v < $values; ++$v) {
                if (--$budget < 0) { throw new \InvalidArgumentException('För många MAPI-värden i winmail.dat.'); }
                if ($variable) {
                    $size = $this->u32($data, $offset);
                    $value = $this->take($data, $offset, $size);
                    $this->take($data, $offset, (4 - $size % 4) % 4);
                } else {
                    $size = match ($baseType) { 0x0001 => 0, 0x0002, 0x0003, 0x0004, 0x000a, 0x000b => 4, 0x0005, 0x0006, 0x0007, 0x0014, 0x0040 => 8, 0x0048 => 16, default => throw new \InvalidArgumentException('MAPI-datatypen stöds inte.') };
                    $value = $this->take($data, $offset, $size);
                }
                if (0 !== $v) { continue; }
                if (0x3701 === $id && 0x0102 === $baseType) { $result['content'] = $value; }
                if (\in_array($id, [0x3707, 0x3704], true) && \in_array($baseType, [0x001e, 0x001f], true)) {
                    $decoded = $this->text($value, 0x001f === $baseType ? 'UTF-16LE' : $charset);
                    if (0x3707 === $id || !isset($result['unicodeName'])) { $result['unicodeName'] = $decoded; }
                }
                if (0x370e === $id) { $result['mime'] = $this->text($value, 0x001f === $baseType ? 'UTF-16LE' : $charset); }
                if (0x3705 === $id && 4 === \strlen($value)) { $result['method'] = unpack('V', $value)[1]; }
            }
        }

        return $result;
    }

    private function text(string $bytes, string $charset): string
    {
        try { return rtrim(mb_convert_encoding($bytes, 'UTF-8', $charset), "\0"); }
        catch (\ValueError) { throw new \InvalidArgumentException('Teckenkodningen i winmail.dat stöds inte.'); }
    }

    private function u32(string $bytes, int &$offset): int { return unpack('V', $this->take($bytes, $offset, 4))[1]; }
    private function take(string $bytes, int &$offset, int $length): string
    {
        if ($length < 0 || $offset + $length > \strlen($bytes)) { throw new \InvalidArgumentException('winmail.dat är avklippt.'); }
        $value = substr($bytes, $offset, $length);
        $offset += $length;
        return $value;
    }
}
