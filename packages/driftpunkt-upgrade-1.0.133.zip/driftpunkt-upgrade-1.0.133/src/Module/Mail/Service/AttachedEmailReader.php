<?php

declare(strict_types=1);

namespace App\Module\Mail\Service;

use App\Module\Ticket\Entity\TicketCommentAttachment;
use JhumanJ\EmailParser\Attachment;
use JhumanJ\EmailParser\EmailMessage;
use JhumanJ\EmailParser\EmailParser;
use JhumanJ\EmailParser\ParseOptions;

final class AttachedEmailReader
{
    public const MAX_BYTES = 20 * 1024 * 1024;

    public function read(TicketCommentAttachment $attachment): EmailMessage
    {
        if (!$attachment->isEmailMessage()) { throw new \InvalidArgumentException('Bilagan är inte ett mejl.'); }
        return $this->parse($this->content($attachment));
    }

    public function content(TicketCommentAttachment $attachment): string
    {
        $path = $attachment->getFilePath();
        if ($attachment->isExternal() || null === $path || !is_file($path)) {
            throw new \InvalidArgumentException('Bilagan kunde inte hittas.');
        }

        if ($attachment->isArchivedInZip()) {
            $zip = new \ZipArchive();
            if (true !== $zip->open($path)) {
                throw new \InvalidArgumentException('Bilagans arkiv kunde inte öppnas.');
            }
            try {
                $entry = $attachment->getArchiveEntryName() ?? '';
                $stat = $zip->statName($entry);
                if (false === $stat || $stat['size'] > self::MAX_BYTES) {
                    throw new \InvalidArgumentException('Bilagan saknas eller är för stor för att visas (högst 20 MB).');
                }
                $content = $zip->getFromName($entry, self::MAX_BYTES + 1);
            } finally {
                $zip->close();
            }
        } else {
            $content = @file_get_contents($path, false, null, 0, self::MAX_BYTES + 1);
        }

        if (!\is_string($content) || '' === $content || \strlen($content) > self::MAX_BYTES) {
            throw new \InvalidArgumentException('Bilagan är tom eller för stor för att visas (högst 20 MB).');
        }

        return $content;
    }

    public function parse(string $content): EmailMessage
    {
        try {
            return (new EmailParser(new ParseOptions(
                maxInputBytes: self::MAX_BYTES,
                maxBodyBytes: 2 * 1024 * 1024,
                maxAttachmentBytes: self::MAX_BYTES,
                maxTotalAttachmentBytes: self::MAX_BYTES,
                maxAttachments: 100,
                maxNestingDepth: 5,
                maxDirectoryEntries: 10000,
                maxMimeParts: 1000,
            )))->parse($content)->message;
        } catch (\Throwable $exception) {
            throw new \InvalidArgumentException('Mejlet kunde inte läsas. Filen kan vara skadad, krypterad eller överskrida läsarens storleksgränser. Du kan fortfarande ladda ner originalfilen.', 0, $exception);
        }
    }

    public function messageAt(EmailMessage $message, string $part): EmailMessage
    {
        if ('' === $part) {
            return $message;
        }
        foreach ($this->indexes($part) as $index) {
            $message = $message->attachments[$index]->embeddedMessage ?? null;
            if (!$message instanceof EmailMessage) {
                throw new \OutOfBoundsException('Det bifogade mejlet kunde inte hittas.');
            }
        }

        return $message;
    }

    public function attachmentAt(EmailMessage $message, string $part): Attachment
    {
        $indexes = $this->indexes($part);
        $index = array_pop($indexes);
        $parent = $this->messageAt($message, implode('.', $indexes));
        $attachment = $parent->attachments[$index] ?? null;
        if (!$attachment instanceof Attachment) {
            throw new \OutOfBoundsException('Bilagan kunde inte hittas.');
        }

        return $attachment;
    }

    public function bodyText(EmailMessage $message): string
    {
        if (null !== $message->textBody && '' !== trim($message->textBody)) {
            return $message->textBody;
        }
        $html = preg_replace('~<(script|style|head)\b[^>]*>.*?</\1\s*>~is', '', $message->htmlBody ?? '') ?? '';
        $html = preg_replace('~<(?:br\s*/?|/p|/div|/tr|/li|/h[1-6])\s*>~i', "\n", $html) ?? $html;

        return trim(html_entity_decode(strip_tags($html), ENT_QUOTES | ENT_HTML5, 'UTF-8'));
    }

    /** @return list<int> */
    private function indexes(string $part): array
    {
        if (1 !== preg_match('/^\d{1,3}(?:\.\d{1,3}){0,5}$/D', $part)) {
            throw new \OutOfBoundsException('Ogiltig bilagereferens.');
        }

        return array_map('intval', explode('.', $part));
    }
}
