<?php

declare(strict_types=1);

namespace App\Module\Mail\Service;

use App\Module\Mail\Entity\IncomingMail;
use App\Module\Ticket\Entity\Ticket;
use App\Module\Ticket\Entity\TicketComment;
use App\Module\Ticket\Entity\TicketCommentAttachment;
use App\Module\Ticket\Service\AttachmentCopyResult;
use App\Module\Ticket\Service\TicketAttachmentDeduplicator;
use App\Module\Ticket\Service\TicketAttachmentStorage;
use Symfony\Component\DependencyInjection\Attribute\Autowire;

final class IncomingMailAttachmentStorage
{
    public function __construct(
        #[Autowire('%kernel.project_dir%')]
        private readonly string $projectDir,
        private readonly TicketAttachmentStorage $ticketAttachmentStorage,
        private readonly TicketAttachmentDeduplicator $ticketAttachmentDeduplicator,
        private readonly ?MailAttachmentRecoverySender $recoverySender = null,
    ) {
    }

    /**
     * @param list<array{displayName: string, mimeType: ?string, content: string}> $attachments
     * @return list<array{displayName: string, mimeType: ?string, fileSize: int, filePath: string, contentHash: string}>
     */
    public function storeIncomingMailAttachments(IncomingMail $incomingMail, array $attachments): array
    {
        if ([] === $attachments || null === $incomingMail->getId()) {
            return [];
        }

        $directory = $this->incomingMailAttachmentDirectory($incomingMail);
        if (!is_dir($directory) && !mkdir($directory, 0775, true) && !is_dir($directory)) {
            throw new \RuntimeException('Kunde inte skapa lagringsmappen för inkommande e-postbilagor.');
        }

        $stored = [];
        foreach ($attachments as $attachment) {
            $displayName = trim($attachment['displayName']);
            if ('' === $displayName) {
                continue;
            }

            $extension = pathinfo($displayName, \PATHINFO_EXTENSION);
            $storedName = sprintf(
                '%s%s',
                bin2hex(random_bytes(12)),
                '' !== $extension ? '.'.mb_strtolower((string) $extension) : '',
            );
            $filePath = $directory.\DIRECTORY_SEPARATOR.$storedName;
            file_put_contents($filePath, $attachment['content']);

            $stored[] = [
                ...(isset($attachment['inlineToken']) ? ['inlineToken' => $attachment['inlineToken']] : []),
                ...(isset($attachment['importError']) ? ['importError' => $attachment['importError']] : []),
                'displayName' => $displayName,
                'mimeType' => $attachment['mimeType'],
                'fileSize' => (int) filesize($filePath),
                'filePath' => $filePath,
                'contentHash' => hash('sha256', $attachment['content']),
            ];
        }

        return $stored;
    }

    /**
     * @param array{
     *     enabled: bool,
     *     maxUploadMb: int,
     *     storagePath: string,
     *     allowedExtensions: list<string>
     * } $attachmentSettings
     */
    public function copyIncomingMailAttachmentsToTicketComment(IncomingMail $incomingMail, Ticket $ticket, TicketComment $comment, array $attachmentSettings): AttachmentCopyResult
    {
        $result = AttachmentCopyResult::empty();

        $metadata = $incomingMail->getAttachmentMetadata();
        $metadataChanged = false;
        $createdKeys = [];

        foreach ($metadata as $index => $attachment) {
            $displayName = trim((string) ($attachment['displayName'] ?? ''));
            $sourcePath = (string) ($attachment['filePath'] ?? '');
            $mimeType = \is_string($attachment['mimeType'] ?? null) ? $attachment['mimeType'] : null;
            $extension = ltrim(mb_strtolower(pathinfo($displayName, \PATHINFO_EXTENSION)), '.');
            if (isset($attachment['importError'])) {
                $result->addFailure($displayName, (string) $attachment['importError']);
            }

            if (!$attachmentSettings['enabled']) {
                $result->addFailure($displayName, 'Bilagefunktionen är avstängd.');
                continue;
            }
            if ('' === $displayName || '' === $sourcePath || !is_file($sourcePath)) {
                $result->addFailure($displayName, 'Källfilen saknas.');
                continue;
            }

            if ('' === $extension || !\in_array($extension, $attachmentSettings['allowedExtensions'], true)) {
                $result->addFailure($displayName, 'Filtypen är inte tillåten.');
                continue;
            }

            $fileSize = (int) filesize($sourcePath);
            if ($fileSize > $attachmentSettings['maxUploadMb'] * 1024 * 1024) {
                $result->addFailure($displayName, sprintf('Filen är för stor (gräns %d MB).', $attachmentSettings['maxUploadMb']));
                continue;
            }
            $contentHash = $this->ticketAttachmentDeduplicator->normalizeContentHash(\is_string($attachment['contentHash'] ?? null) ? $attachment['contentHash'] : null)
                ?? $this->ticketAttachmentDeduplicator->contentHashForFile($sourcePath);
            if (null === $contentHash) {
                $result->addFailure($displayName, 'Filen kunde inte läsas.');
                continue;
            }

            if (!isset($metadata[$index]['contentHash']) || $metadata[$index]['contentHash'] !== $contentHash) {
                $metadata[$index]['contentHash'] = $contentHash;
                $metadataChanged = true;
            }

            if (!isset($metadata[$index]['fileSize']) || (int) $metadata[$index]['fileSize'] !== $fileSize) {
                $metadata[$index]['fileSize'] = $fileSize;
                $metadataChanged = true;
            }

            $attachmentKey = $this->ticketAttachmentDeduplicator->attachmentKey($contentHash, $fileSize);
            if (!isset($attachment['inlineToken']) && (isset($createdKeys[$attachmentKey]) || null !== $this->ticketAttachmentDeduplicator->findDuplicateInTicket($ticket, $contentHash, $fileSize))) {
                $result->addSkippedDuplicate($displayName);
                continue;
            }

            $content = @file_get_contents($sourcePath);
            if (false === $content) {
                $result->addFailure($displayName, 'Filen kunde inte läsas.');
                continue;
            }

            try {
                $storedFile = $this->ticketAttachmentStorage->storeBinaryContent(
                    $content,
                    $displayName,
                    $mimeType,
                    $ticket,
                    $attachmentSettings['storagePath'],
                );

            } catch (\RuntimeException) {
                $result->addFailure($displayName, 'Filen kunde inte sparas.');
                continue;
            }

            $result->addCreatedAttachment(TicketCommentAttachment::fromLocalFile(
                $comment,
                $storedFile['displayName'],
                $storedFile['filePath'],
                $storedFile['mimeType'],
                $storedFile['fileSize'],
                $storedFile['contentHash'],
            )->setInlineToken($attachment['inlineToken'] ?? null));
            $createdKeys[$attachmentKey] = true;
        }

        if ($metadataChanged) {
            $incomingMail->setAttachmentMetadata($metadata);
        }

        foreach ($result->getCreatedAttachments() as $createdAttachment) {
            $comment->addAttachment($createdAttachment);
        }
        $this->recoverySender?->report($incomingMail, $comment, $result);

        return $result;
    }

    /**
     * Keeps the untouched message so technicians can download it and it can be re-imported later.
     */
    public function storeRawMessage(IncomingMail $incomingMail, string $rawMessage): ?string
    {
        if ('' === trim($rawMessage) || null === $incomingMail->getId()) {
            return null;
        }

        $directory = $this->incomingMailAttachmentDirectory($incomingMail);
        if (!is_dir($directory) && !mkdir($directory, 0775, true) && !is_dir($directory)) {
            throw new \RuntimeException('Kunde inte skapa lagringsmappen för inkommande e-post.');
        }

        $filePath = $directory.\DIRECTORY_SEPARATOR.'original.eml';
        file_put_contents($filePath, $rawMessage);

        return $filePath;
    }

    private function incomingMailAttachmentDirectory(IncomingMail $incomingMail): string
    {
        return $this->projectDir.\DIRECTORY_SEPARATOR.'var'.\DIRECTORY_SEPARATOR.'incoming_mail_attachments'.\DIRECTORY_SEPARATOR.(string) $incomingMail->getId();
    }
}
