<?php

declare(strict_types=1);

namespace App\Module\Mail\Service;

use App\Module\Mail\Entity\IncomingMail;
use App\Module\Mail\Entity\MailAttachmentRecovery;
use App\Module\Ticket\Entity\Ticket;
use Doctrine\ORM\EntityManagerInterface;

final class TicketIntakeViewBuilder
{
    public function __construct(private readonly EntityManagerInterface $entityManager)
    {
    }

    /** @return array{mails: list<IncomingMail>, recoveries: list<MailAttachmentRecovery>} */
    public function build(Ticket $ticket): array
    {
        $tickets = [$ticket];
        foreach ($ticket->getMergedSources() as $merge) {
            $tickets[] = $merge->getSourceTicket();
        }

        $mails = $this->entityManager->getRepository(IncomingMail::class)->createQueryBuilder('mail')
            ->leftJoin('mail.mailbox', 'mailbox')->addSelect('mailbox')
            ->leftJoin('mail.matchedCompany', 'company')->addSelect('company')
            ->andWhere('mail.matchedTicket IN (:tickets)')->setParameter('tickets', $tickets)
            ->orderBy('mail.createdAt', 'DESC')->setMaxResults(25)->getQuery()->getResult();

        $recoveries = $this->entityManager->getRepository(MailAttachmentRecovery::class)->createQueryBuilder('recovery')
            ->join('recovery.comment', 'comment')->addSelect('comment')
            ->andWhere('comment.ticket IN (:tickets)')->setParameter('tickets', $tickets)
            ->orderBy('recovery.id', 'DESC')->getQuery()->getResult();

        return ['mails' => $mails, 'recoveries' => $recoveries];
    }
}
