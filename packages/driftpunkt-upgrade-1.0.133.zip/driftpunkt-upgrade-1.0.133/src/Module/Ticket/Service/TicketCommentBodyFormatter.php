<?php

declare(strict_types=1);

namespace App\Module\Ticket\Service;

final class TicketCommentBodyFormatter
{
    private const DEFAULT_PREVIEW_LENGTH = 160;

    /**
     * Webbläsarens redigerare lägger varje rad efter den första i en div; de tas bort men ska ge radbrott.
     */
    private const LINE_BLOCK_TAGS = ['div', 'section', 'article'];

    private const ALLOWED_COLOR_CLASSES = [
        'comment-color-important' => '#b42318',
        'comment-color-warning' => '#b45309',
        'comment-color-success' => '#166534',
        'comment-color-info' => '#1d4ed8',
    ];

    /**
     * @return string Safe HTML or legacy plain text.
     */
    public function sanitizeForStorage(string $body): string
    {
        $body = trim(str_replace(["\r\n", "\r"], "\n", $body));
        if ('' === $body) {
            return '';
        }

        if (!$this->looksLikeHtml($body)) {
            return $body;
        }

        return trim($this->sanitizeHtml($body));
    }

    public function isEmpty(string $body): bool
    {
        $plainText = trim($this->toPlainText($body));

        return '' === $plainText;
    }

    public function renderHtml(string $body, bool $email = false): string
    {
        $body = trim(str_replace(["\r\n", "\r"], "\n", $body));
        if ('' === $body) {
            return '';
        }

        if (!$this->looksLikeHtml($body)) {
            return nl2br(htmlspecialchars($body, \ENT_QUOTES | \ENT_SUBSTITUTE, 'UTF-8'), false);
        }

        return $this->sanitizeHtml($body, $email);
    }

    public function toPlainText(string $body): string
    {
        $body = preg_replace('/\[\[dp-image:[a-f0-9]{64}\]\]/', '[Bifogad bild]', $body) ?? $body;
        $body = str_replace(["\r\n", "\r"], "\n", trim($body));
        if ('' === $body) {
            return '';
        }

        if (!$this->looksLikeHtml($body)) {
            return $body;
        }

        $html = $this->sanitizeHtml($body);
        $html = preg_replace('/<br\s*\/?>/i', "\n", $html) ?? $html;
        $html = preg_replace('/<hr\s*\/?>/i', "\n---\n", $html) ?? $html;
        $html = preg_replace('/<\/h3\s*>/i', "\n\n", $html) ?? $html;
        $html = preg_replace('/<\/p\s*>/i', "\n\n", $html) ?? $html;
        $html = preg_replace('/<pre[^>]*>/i', "\n", $html) ?? $html;
        $html = preg_replace_callback(
            '/<ul class="ticket-checklist">(.*?)<\/ul>/is',
            static function (array $matches): string {
                $list = preg_replace('/<li class="is-checked">/i', "\n- [x] ", $matches[1]) ?? $matches[1];
                $list = preg_replace('/<li>/i', "\n- [ ] ", $list) ?? $list;
                $list = preg_replace('/<\/li>/i', '', $list) ?? $list;

                return $list."\n";
            },
            $html,
        ) ?? $html;
        $html = preg_replace('/<li[^>]*>/i', "\n- ", $html) ?? $html;
        $html = preg_replace('/<\/(?:ul|ol|blockquote|pre)\s*>/i', "\n", $html) ?? $html;
        $text = html_entity_decode(strip_tags($html), \ENT_QUOTES | \ENT_HTML5, 'UTF-8');
        $text = preg_replace("/[ \t]+\n/", "\n", $text) ?? $text;
        $text = preg_replace("/\n{3,}/", "\n\n", $text) ?? $text;

        return trim($text);
    }

    public function toPreviewText(string $body, int $maxLength = self::DEFAULT_PREVIEW_LENGTH): string
    {
        $plainText = $this->toPlainText($body);
        $plainText = preg_replace('/\s+/u', ' ', $plainText) ?? $plainText;
        $plainText = trim($plainText);

        if ('' === $plainText || mb_strlen($plainText) <= $maxLength) {
            return $plainText;
        }

        $preview = rtrim(mb_substr($plainText, 0, max(1, $maxLength - 1)));
        $lastSpace = mb_strrpos($preview, ' ');
        if (false !== $lastSpace && $lastSpace >= (int) floor($maxLength * 0.6)) {
            $preview = rtrim(mb_substr($preview, 0, $lastSpace));
        }

        return rtrim($preview, " \t\n\r\0\x0B,.;:-").'…';
    }

    private function looksLikeHtml(string $body): bool
    {
        return preg_match('/<\/?(?:p|br|hr|strong|b|em|i|u|s|strike|del|mark|ul|ol|li|blockquote|a|span|h[1-6]|pre|code|div|section|article|table|thead|tbody|tr|td|th|script|style|img|iframe|object|embed|svg|math)\b/i', $body) === 1;
    }

    private function sanitizeHtml(string $html, bool $email = false): string
    {
        $document = new \DOMDocument('1.0', 'UTF-8');
        $previous = libxml_use_internal_errors(true);
        $document->loadHTML(
            '<?xml encoding="UTF-8"><div>'.$html.'</div>',
            \LIBXML_HTML_NOIMPLIED | \LIBXML_HTML_NODEFDTD,
        );
        libxml_clear_errors();
        libxml_use_internal_errors($previous);

        $root = $document->getElementsByTagName('div')->item(0);
        if (!$root instanceof \DOMElement) {
            return '';
        }

        $sanitized = trim($this->sanitizeNodeList($root->childNodes, $email));

        return trim((string) preg_replace('/(?:<br>)+$/', '', $sanitized));
    }

    private function sanitizeNode(\DOMNode $node, bool $email): string
    {
        if ($node instanceof \DOMText || $node instanceof \DOMCdataSection) {
            return htmlspecialchars($node->textContent, \ENT_QUOTES | \ENT_SUBSTITUTE, 'UTF-8');
        }

        if (!$node instanceof \DOMElement) {
            return '';
        }

        $tag = strtolower($node->tagName);
        if (\in_array($tag, ['script', 'style'], true)) {
            return '';
        }

        $tag = match ($tag) {
            'b' => 'strong',
            'i' => 'em',
            'strike', 'del' => 's',
            'h1', 'h2', 'h4', 'h5', 'h6' => 'h3',
            default => $tag,
        };

        if (\in_array($tag, self::LINE_BLOCK_TAGS, true)) {
            $children = $this->sanitizeChildren($node, $email);

            return '' === $children || str_ends_with($children, '<br>') ? $children : $children.'<br>';
        }

        if (!\in_array($tag, ['p', 'br', 'hr', 'strong', 'em', 'u', 's', 'mark', 'ul', 'ol', 'li', 'blockquote', 'a', 'span', 'h3', 'pre', 'code'], true)) {
            return $this->sanitizeChildren($node, $email);
        }

        if ('br' === $tag) {
            return '<br>';
        }

        if ('hr' === $tag) {
            return '<hr>';
        }

        $children = $this->sanitizeChildren($node, $email);
        if ('' === trim(strip_tags($children, '<br>')) && !str_contains($children, '<br>')) {
            return '';
        }

        $attributes = '';
        if ('a' === $tag) {
            $href = trim($node->getAttribute('href'));
            if (!preg_match('#^https?://#i', $href)) {
                return $children;
            }

            $attributes = sprintf(
                ' href="%s" target="_blank" rel="noopener noreferrer"',
                htmlspecialchars($href, \ENT_QUOTES | \ENT_SUBSTITUTE, 'UTF-8'),
            );
        } elseif ('span' === $tag) {
            $class = $this->allowedColorClass($node);
            if (null === $class) {
                return $children;
            }

            $attributes = $email
                ? sprintf(' style="color:%s;font-weight:700;"', self::ALLOWED_COLOR_CLASSES[$class])
                : sprintf(' class="%s"', $class);
        } elseif ('mark' === $tag && $email) {
            $attributes = ' style="background-color:#fef08a;"';
        } elseif ('ul' === $tag && $this->hasClass($node, 'ticket-checklist')) {
            $attributes = ' class="ticket-checklist"';
        } elseif ('li' === $tag && $this->hasClass($node, 'is-checked')) {
            $attributes = ' class="is-checked"';
        }

        return sprintf('<%1$s%2$s>%3$s</%1$s>', $tag, $attributes, $children);
    }

    private function sanitizeChildren(\DOMNode $node, bool $email): string
    {
        return $this->sanitizeNodeList($node->childNodes, $email);
    }

    /**
     * @param \DOMNodeList<\DOMNode> $nodes
     */
    private function sanitizeNodeList(\DOMNodeList $nodes, bool $email): string
    {
        $output = '';
        foreach ($nodes as $node) {
            $isLineBlock = $node instanceof \DOMElement && \in_array(strtolower($node->tagName), self::LINE_BLOCK_TAGS, true);
            $rendered = $this->sanitizeNode($node, $email);
            if ($isLineBlock && '' !== $rendered && '' !== $output && 1 !== preg_match('/(?:<br>|<hr>|<\/(?:p|h3|ul|ol|li|blockquote|pre)>)$/', $output)) {
                $output .= '<br>';
            }
            $output .= $rendered;
        }

        return $output;
    }

    private function allowedColorClass(\DOMElement $node): ?string
    {
        $classes = preg_split('/\s+/', trim($node->getAttribute('class'))) ?: [];
        foreach ($classes as $class) {
            if (isset(self::ALLOWED_COLOR_CLASSES[$class])) {
                return $class;
            }
        }

        $style = strtolower($node->getAttribute('style'));
        foreach (self::ALLOWED_COLOR_CLASSES as $class => $color) {
            if (str_contains($style, strtolower($color))) {
                return $class;
            }
        }

        $color = strtolower(trim($node->getAttribute('color')));
        foreach (self::ALLOWED_COLOR_CLASSES as $class => $allowedColor) {
            if ($color === strtolower($allowedColor)) {
                return $class;
            }
        }

        return null;
    }

    private function hasClass(\DOMElement $node, string $expectedClass): bool
    {
        $classes = preg_split('/\s+/', trim($node->getAttribute('class'))) ?: [];

        return \in_array($expectedClass, $classes, true);
    }
}
