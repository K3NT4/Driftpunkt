<?php

declare(strict_types=1);

namespace App\Module\Ticket\Service;

use App\Module\Identity\Entity\Company;
use App\Module\Identity\Entity\User;
use App\Module\Identity\Enum\UserType;
use Doctrine\ORM\EntityManagerInterface;

final class CustomerCompanyTicketAccessService
{
    public function __construct(
        private readonly EntityManagerInterface $entityManager,
    ) {
    }

    public function canUserAccessAllCompanyTickets(?User $user, bool $includeHierarchyAccess = true): bool
    {
        if (!$user instanceof User || !$user->isActive() || UserType::CUSTOMER !== $user->getType()) {
            return false;
        }

        $company = $user->getCompany();
        if (!$company instanceof Company) {
            return false;
        }

        $userId = $user->getId();
        if (null === $userId) {
            return false;
        }

        foreach ($company->getTicketAllowedUsers() as $allowedUser) {
            if ($allowedUser->getId() === $userId && $this->isEligibleCustomerUser($company, $allowedUser)) {
                return true;
            }
        }

        return $includeHierarchyAccess && $this->canUserReadHierarchyTickets($user);
    }

    public function canUserReadHierarchyTickets(?User $user): bool
    {
        if (!$user instanceof User || !$user->getCompany() instanceof Company || null === $user->getId()
            || !$this->isEligibleCustomerUser($user->getCompany(), $user)) {
            return false;
        }
        foreach ($user->getCompany()->getHierarchyTicketReaders() as $reader) {
            if ($reader->getId() === $user->getId()) {
                return true;
            }
        }

        return false;
    }

    /**
     * @param list<int> $allowedUserIds
     * @param list<int> $hierarchyReaderIds
     */
    public function setAccess(Company $company, array $allowedUserIds, array $hierarchyReaderIds = []): void
    {
        $company->clearTicketAllowedUsers();
        $company->clearHierarchyTicketReaders();
        $selectedIds = array_values(array_unique([...$allowedUserIds, ...$hierarchyReaderIds]));

        if ([] !== $selectedIds) {
            $users = $this->entityManager->getRepository(User::class)->findBy(['id' => $selectedIds]);
            foreach ($users as $user) {
                if ($this->isEligibleCustomerUser($company, $user)) {
                    if (\in_array($user->getId(), $allowedUserIds, true)) {
                        $company->addTicketAllowedUser($user);
                    }
                    if (\in_array($user->getId(), $hierarchyReaderIds, true)) {
                        $company->addHierarchyTicketReader($user);
                    }
                }
            }
        }

        $this->entityManager->flush();
    }

    /**
     * @return array{allowedUserIds: list<int>, allowedUsers: list<User>, hierarchyReaderIds: list<int>}
     */
    public function companySummary(?Company $company): array
    {
        if (!$company instanceof Company) {
            return [
                'allowedUserIds' => [],
                'allowedUsers' => [],
                'hierarchyReaderIds' => [],
            ];
        }

        $allowedUsers = $this->sortUsers($company->getTicketAllowedUsers()->toArray());

        return [
            'allowedUserIds' => array_values(array_filter(array_map(static fn (User $user): ?int => $user->getId(), $allowedUsers))),
            'allowedUsers' => $allowedUsers,
            'hierarchyReaderIds' => array_values(array_filter($company->getHierarchyTicketReaders()->map(static fn (User $user): ?int => $user->getId())->toArray())),
        ];
    }

    /**
     * @return list<User>
     */
    public function customerUsers(Company $company): array
    {
        return $this->sortUsers(array_values(array_filter(
            $company->getUsers()->toArray(),
            fn (User $user): bool => $this->isEligibleCustomerUser($company, $user),
        )));
    }

    public function isEligibleCustomerUser(Company $company, User $user): bool
    {
        return $user->isActive()
            && UserType::CUSTOMER === $user->getType()
            && $user->getCompany()?->getId() === $company->getId();
    }

    /**
     * @param list<User> $users
     *
     * @return list<User>
     */
    private function sortUsers(array $users): array
    {
        usort(
            $users,
            static fn (User $left, User $right): int => [$left->getDisplayName(), $left->getEmail()] <=> [$right->getDisplayName(), $right->getEmail()],
        );

        return $users;
    }
}
