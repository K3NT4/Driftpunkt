<?php

declare(strict_types=1);

namespace App\Module\Ticket\Service;

use App\Module\Identity\Entity\Company;
use App\Module\Identity\Entity\User;
use App\Module\Identity\Enum\UserType;
use App\Module\Ticket\Entity\Ticket;
use Doctrine\ORM\EntityManagerInterface;

/** Suggestions only: neither routing nor visibility is changed by this service. */
final class TicketDuplicateFinder
{
    public function __construct(
        private readonly EntityManagerInterface $entityManager,
        private readonly TicketAccessPolicy $accessPolicy,
        private readonly TicketLifecycleService $lifecycle,
    ) {
    }

    /** @return list<array{ticket: Ticket, exact: bool}> */
    public function find(string $subject, ?Company $company, User $actor, ?Ticket $source = null): array
    {
        if (null === $company || !\in_array($actor->getType(), [UserType::SUPER_ADMIN, UserType::ADMIN, UserType::TICKET_COORDINATOR, UserType::TECHNICIAN], true)) {
            return [];
        }

        $normalized = TicketSubjectNormalizer::normalize($subject);
        if (mb_strlen($normalized) < 5) {
            return [];
        }

        $candidates = $this->entityManager->getRepository(Ticket::class)->createQueryBuilder('ticket')
            ->leftJoin('ticket.merge', 'merge')
            ->andWhere('ticket.company = :company')
            ->andWhere('ticket.status NOT IN (:closed)')
            ->andWhere('merge.id IS NULL')
            ->setParameter('company', $company)
            ->setParameter('closed', $this->lifecycle->closedStatuses())
            ->orderBy('ticket.updatedAt', 'DESC')
            ->setMaxResults(100)->getQuery()->getResult();

        $left = $this->words($normalized);
        $suggestions = [];
        foreach ($candidates as $candidate) {
            if ($candidate->getId() === $source?->getId()
                || (UserType::TECHNICIAN === $actor->getType() && !$this->accessPolicy->technicianCanReadTicket($actor, $candidate))) {
                continue;
            }
            $candidateSubject = TicketSubjectNormalizer::normalize($candidate->getSubject());
            $exact = $normalized === $candidateSubject;
            $right = $this->words($candidateSubject);
            $common = \count(array_intersect($left, $right));
            $union = \count(array_unique([...$left, ...$right]));
            $score = $exact ? 1.0 : ($union > 0 ? $common / $union : 0.0);
            if ($exact || ($common >= 2 && $score >= 0.6)) {
                $suggestions[] = ['ticket' => $candidate, 'exact' => $exact, 'score' => $score];
            }
        }
        usort($suggestions, static fn (array $a, array $b): int => $b['score'] <=> $a['score'] ?: $b['ticket']->getUpdatedAt() <=> $a['ticket']->getUpdatedAt());

        return array_map(static fn (array $item): array => ['ticket' => $item['ticket'], 'exact' => $item['exact']], array_slice($suggestions, 0, 3));
    }

    /** @return list<string> */
    private function words(string $subject): array
    {
        return array_values(array_unique(array_filter(
            preg_split('/[^\p{L}\p{N}]+/u', $subject) ?: [],
            static fn (string $word): bool => mb_strlen($word) >= 3,
        )));
    }
}
