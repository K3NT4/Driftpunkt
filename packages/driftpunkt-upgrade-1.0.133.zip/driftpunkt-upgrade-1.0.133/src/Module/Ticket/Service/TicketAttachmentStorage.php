<?php

declare(strict_types=1);

namespace App\Module\Ticket\Service;

use App\Module\Ticket\Entity\Ticket;
use Symfony\Component\DependencyInjection\Attribute\Autowire;
use Symfony\Component\HttpFoundation\File\UploadedFile;

final class TicketAttachmentStorage
{
    public function __construct(
        #[Autowire('%kernel.project_dir%')]
        private readonly string $projectDir,
    ) {
    }

    /**
     * @return array{
     *     displayName: string,
     *     filePath: string,
     *     mimeType: ?string,
     *     fileSize: int,
     *     contentHash: string
     * }
     */
    public function storeUploadedFile(UploadedFile $uploadedFile, Ticket $ticket, string $storagePath): array
    {
        $targetDirectory = $this->resolveStorageDirectory($storagePath, $ticket);
        if (!is_dir($targetDirectory) && !mkdir($targetDirectory, 0775, true) && !is_dir($targetDirectory)) {
            throw new \RuntimeException('Kunde inte skapa lagringsmappen för bilagor.');
        }

        $originalName = trim($uploadedFile->getClientOriginalName());
        $safeOriginalName = '' !== $originalName ? $originalName : 'bilaga';
        // Använd ändelsen som kontrollerats mot tillåtna filtyper, aldrig en ändelse gissad från innehållet (t.ex. .php).
        $extension = pathinfo($safeOriginalName, \PATHINFO_EXTENSION);
        $storedName = sprintf(
            '%s%s',
            bin2hex(random_bytes(12)),
            '' !== $extension ? '.'.mb_strtolower((string) $extension) : '',
        );

        $uploadedFile->move($targetDirectory, $storedName);
        $filePath = $targetDirectory.\DIRECTORY_SEPARATOR.$storedName;
        $contentHash = hash_file('sha256', $filePath);
        if (!\is_string($contentHash)) {
            throw new \RuntimeException('Kunde inte beräkna filens kontrollsumma.');
        }

        return [
            'displayName' => $safeOriginalName,
            'filePath' => $filePath,
            'mimeType' => $this->detectSafeMimeType($filePath),
            'fileSize' => (int) filesize($filePath),
            'contentHash' => $contentHash,
        ];
    }

    /**
     * @return array{
     *     displayName: string,
     *     filePath: string,
     *     mimeType: ?string,
     *     fileSize: int,
     *     contentHash: string
     * }
     */
    public function storeBinaryContent(string $content, string $displayName, ?string $mimeType, Ticket $ticket, string $storagePath): array
    {
        $targetDirectory = $this->resolveStorageDirectory($storagePath, $ticket);
        if (!is_dir($targetDirectory) && !mkdir($targetDirectory, 0775, true) && !is_dir($targetDirectory)) {
            throw new \RuntimeException('Kunde inte skapa lagringsmappen för bilagor.');
        }

        $safeOriginalName = '' !== trim($displayName) ? trim($displayName) : 'bilaga';
        $extension = pathinfo($safeOriginalName, \PATHINFO_EXTENSION);
        $storedName = sprintf(
            '%s%s',
            bin2hex(random_bytes(12)),
            '' !== $extension ? '.'.mb_strtolower((string) $extension) : '',
        );

        $filePath = $targetDirectory.\DIRECTORY_SEPARATOR.$storedName;
        if (@file_put_contents($filePath, $content) !== \strlen($content)) {
            @unlink($filePath);
            throw new \RuntimeException('Bilagan kunde inte skrivas till lagringen.');
        }

        return [
            'displayName' => $safeOriginalName,
            'filePath' => $filePath,
            'mimeType' => $this->detectSafeMimeType($filePath),
            'fileSize' => (int) filesize($filePath),
            'contentHash' => hash('sha256', $content),
        ];
    }

    private function detectSafeMimeType(string $filePath): string
    {
        $detected = (new \finfo(\FILEINFO_MIME_TYPE))->file($filePath);
        if (!\is_string($detected) || '' === $detected) {
            return 'application/octet-stream';
        }

        $previewableImages = ['image/png', 'image/jpeg', 'image/gif', 'image/webp'];
        if (!\in_array($detected, $previewableImages, true)) {
            return $detected;
        }

        $imageInfo = @getimagesize($filePath);
        $verifiedMime = \is_array($imageInfo) ? ($imageInfo['mime'] ?? null) : null;

        return \is_string($verifiedMime) && $verifiedMime === $detected
            ? $detected
            : 'application/octet-stream';
    }

    private function resolveStorageDirectory(string $storagePath, Ticket $ticket): string
    {
        $normalizedPath = trim($storagePath);
        if ('' === $normalizedPath) {
            $normalizedPath = 'var/ticket_attachments';
        }

        if (!$this->isAbsolutePath($normalizedPath)) {
            $normalizedPath = rtrim($this->projectDir, \DIRECTORY_SEPARATOR).\DIRECTORY_SEPARATOR.ltrim($normalizedPath, \DIRECTORY_SEPARATOR);
        }

        return rtrim($normalizedPath, \DIRECTORY_SEPARATOR).\DIRECTORY_SEPARATOR.strtolower($ticket->getReference());
    }

    private function isAbsolutePath(string $path): bool
    {
        return str_starts_with($path, '/')
            || preg_match('/^[A-Za-z]:[\\\\\\/]/', $path) === 1;
    }
}
