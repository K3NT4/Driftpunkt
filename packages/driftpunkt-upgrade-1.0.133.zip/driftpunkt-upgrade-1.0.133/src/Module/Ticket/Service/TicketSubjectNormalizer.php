<?php

declare(strict_types=1);

namespace App\Module\Ticket\Service;

final class TicketSubjectNormalizer
{
    public static function normalize(string $subject): string
    {
        $normalized = trim($subject);
        do {
            $previous = $normalized;
            $normalized = trim((string) preg_replace('/^(?:re|sv|fw|fwd|vb)\s*:\s*/iu', '', $normalized));
        } while ($normalized !== $previous);

        $normalized = trim((string) preg_replace('/\[[A-Z0-9]+(?:-[A-Z0-9]+)+\]\s*/iu', '', $normalized));

        return mb_strtolower((string) preg_replace('/\s+/u', ' ', $normalized));
    }
}
