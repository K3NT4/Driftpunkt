<?php

declare(strict_types=1);

namespace App\Module\Ticket\Entity;

use App\Module\Identity\Entity\User;
use App\Module\Shared\Entity\TimestampableTrait;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity]
#[ORM\Table(name: 'ticket_comments')]
#[ORM\HasLifecycleCallbacks]
class TicketComment
{
    use TimestampableTrait;

    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\ManyToOne(inversedBy: 'comments')]
    #[ORM\JoinColumn(nullable: false, onDelete: 'CASCADE')]
    private Ticket $ticket;

    #[ORM\ManyToOne]
    #[ORM\JoinColumn(nullable: false, onDelete: 'CASCADE')]
    private User $author;

    #[ORM\Column(type: 'text')]
    private string $body;

    #[ORM\Column]
    private bool $internal = false;

    #[ORM\Column]
    private bool $customerNotificationSuppressed = false;

    #[ORM\OneToOne(mappedBy: 'comment', targetEntity: \App\Module\Mail\Entity\MailAttachmentRecovery::class)]
    private ?\App\Module\Mail\Entity\MailAttachmentRecovery $attachmentRecovery = null;

    public function getAttachmentRecovery(): ?\App\Module\Mail\Entity\MailAttachmentRecovery { return $this->attachmentRecovery; }
    public function setAttachmentRecovery(\App\Module\Mail\Entity\MailAttachmentRecovery $recovery): void { $this->attachmentRecovery = $recovery; }

    /**
     * @var Collection<int, TicketCommentAttachment>
     */
    #[ORM\OneToMany(mappedBy: 'comment', targetEntity: TicketCommentAttachment::class, orphanRemoval: true, cascade: ['persist'])]
    #[ORM\OrderBy(['createdAt' => 'ASC'])]
    private Collection $attachments;

    public function __construct(Ticket $ticket, User $author, string $body, bool $internal = false, bool $customerNotificationSuppressed = false)
    {
        $this->ticket = $ticket;
        $this->author = $author;
        $this->body = trim($body);
        $this->internal = $internal;
        $this->customerNotificationSuppressed = $customerNotificationSuppressed;
        $this->attachments = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getTicket(): Ticket
    {
        return $this->ticket;
    }

    public function setTicket(Ticket $ticket): self
    {
        $this->ticket = $ticket;

        return $this;
    }

    public function getAuthor(): User
    {
        return $this->author;
    }

    public function getBody(): string
    {
        return $this->body;
    }

    public function isInternal(): bool
    {
        return $this->internal;
    }

    public function isCustomerNotificationSuppressed(): bool
    {
        return $this->customerNotificationSuppressed;
    }

    public function shouldNotifyCustomer(): bool
    {
        return !$this->internal && !$this->customerNotificationSuppressed;
    }

    /**
     * @return Collection<int, TicketCommentAttachment>
     */
    public function getAttachments(): Collection
    {
        return $this->attachments;
    }

    public function addAttachment(TicketCommentAttachment $attachment): self
    {
        if (!$this->attachments->contains($attachment)) {
            $this->attachments->add($attachment);
            $attachment->setComment($this);
        }

        return $this;
    }
}
