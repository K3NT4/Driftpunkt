<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

final class Version20261105120000 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Adds customer computer-list management permissions and inventory archiving';
    }

    public function up(Schema $schema): void
    {
        $schema->getTable('inventory_items')->addColumn('archived_at', 'datetime_immutable', ['notnull' => false]);
        $table = $schema->createTable('inventory_list_managing_users');
        $table->addColumn('list_setting_id', 'integer');
        $table->addColumn('user_id', 'integer');
        $table->setPrimaryKey(['list_setting_id', 'user_id']);
        $table->addIndex(['user_id'], 'idx_inventory_list_managing_user');
        $table->addForeignKeyConstraint('inventory_list_settings', ['list_setting_id'], ['id'], ['onDelete' => 'CASCADE']);
        $table->addForeignKeyConstraint('users', ['user_id'], ['id'], ['onDelete' => 'CASCADE']);
    }

    public function down(Schema $schema): void
    {
        $schema->dropTable('inventory_list_managing_users');
        $schema->getTable('inventory_items')->dropColumn('archived_at');
    }
}
