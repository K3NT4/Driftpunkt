<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

final class Version20261105130000 extends AbstractMigration
{
    public function getDescription(): string { return 'Adds attachment recovery forwarding, inline image tokens and linked tickets from attached emails'; }

    public function up(Schema $schema): void
    {
        $schema->getTable('ticket_comment_attachments')->addColumn('inline_token', 'string', ['length' => 64, 'notnull' => false]);
        $table = $schema->createTable('mail_attachment_recoveries');
        $table->addColumn('id', 'integer', ['autoincrement' => true]);
        $table->setPrimaryKey(['id']);
        $table->addColumn('incoming_mail_id', 'integer');
        $table->addColumn('comment_id', 'integer');
        $table->addUniqueIndex(['incoming_mail_id']);
        $table->addUniqueIndex(['comment_id']);
        $table->addForeignKeyConstraint('incoming_mails', ['incoming_mail_id'], ['id'], ['onDelete' => 'CASCADE']);
        $table->addForeignKeyConstraint('ticket_comments', ['comment_id'], ['id'], ['onDelete' => 'CASCADE']);
        $table->addColumn('failures', 'json');
        foreach (['saved_count', 'duplicate_count', 'attempts'] as $name) { $table->addColumn($name, 'integer'); }
        $table->addColumn('state', 'string', ['length' => 20]);
        $table->addColumn('last_error', 'text', ['notnull' => false]);
        $table->addColumn('sent_at', 'datetime_immutable', ['notnull' => false]);
        $table->addColumn('retry_at', 'datetime_immutable', ['notnull' => false]);

        $table = $schema->createTable('attached_email_tickets');
        $table->addColumn('id', 'integer', ['autoincrement' => true]);
        $table->setPrimaryKey(['id']);
        $table->addColumn('attachment_id', 'integer');
        $table->addColumn('ticket_id', 'integer');
        $table->addColumn('part', 'string', ['length' => 30]);
        $table->addUniqueIndex(['attachment_id', 'part'], 'uniq_attached_email_ticket_source');
        $table->addIndex(['ticket_id']);
        $table->addForeignKeyConstraint('ticket_comment_attachments', ['attachment_id'], ['id'], ['onDelete' => 'CASCADE']);
        $table->addForeignKeyConstraint('tickets', ['ticket_id'], ['id'], ['onDelete' => 'CASCADE']);
    }

    public function down(Schema $schema): void
    {
        $schema->dropTable('attached_email_tickets');
        $schema->dropTable('mail_attachment_recoveries');
        $schema->getTable('ticket_comment_attachments')->dropColumn('inline_token');
    }
}
