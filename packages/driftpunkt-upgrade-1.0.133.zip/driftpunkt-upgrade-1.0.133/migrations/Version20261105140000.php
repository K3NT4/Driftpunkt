<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

final class Version20261105140000 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Adds explicit customer read access to all customer-visible tickets throughout a company subtree';
    }

    public function up(Schema $schema): void
    {
        $table = $schema->createTable('company_hierarchy_ticket_readers');
        $table->addColumn('company_id', 'integer');
        $table->addColumn('user_id', 'integer');
        $table->setPrimaryKey(['company_id', 'user_id']);
        $table->addIndex(['user_id'], 'idx_company_hierarchy_ticket_reader');
        $table->addForeignKeyConstraint('companies', ['company_id'], ['id'], ['onDelete' => 'CASCADE']);
        $table->addForeignKeyConstraint('users', ['user_id'], ['id'], ['onDelete' => 'CASCADE']);
    }

    public function down(Schema $schema): void
    {
        $schema->dropTable('company_hierarchy_ticket_readers');
    }
}
