# Koncernansvarigs läsåtkomst till ärenden

En kundanvändare på ett moderbolag kan uttryckligen få läsa alla kundsynliga ärenden i bolaget och hela dess underbolagsträd. Det omfattar privata ärenden, både aktiva och avslutade, även flera nivåer ned. Nya underbolag inom samma gren omfattas automatiskt.

## Aktivering

1. Logga in som superadmin och öppna **Företag**.
2. Öppna det företag där den koncernansvarigas kundkonto finns.
3. Under **Företagsärenden i kundportalen**, markera användarens **Läs alla ärenden i företaget och samtliga underbolag, även privata**.
4. Spara ärendesynligheten.
5. Kontrollera med användaren att **Företagets ärenden** innehåller de förväntade underbolagen. Välj alla företag för en samlad lista, eller använd företagsfilter, sökning och CSV-export.

Den nya kryssrutan är avstängd tills den uttryckligen tilldelas. Den kräver inte att varje underbolag markerar tillåtelse för moderbolaget. Det tidigare valet för företagsärenden finns kvar och följer fortsatt underbolagens individuella tillåtelse.

## Behörighetsgränser

- Behörigheten gäller aktiva kundanvändare på det företag där tilldelningen har gjorts. Andra användare på moderbolaget får ingen extra åtkomst.
- En ansvarig på ett mellanbolag får åtkomst till sitt eget bolag och dess underbolag, inte till moderbolagets eller syskonbolagens privata ärenden.
- Andra koncerner omfattas aldrig.
- Interna ärenden, interna anteckningar och interna bilagor visas inte.
- Vanliga kundsynliga bilagor kan läsas enligt samma ärendeåtkomst som ärendet.
- Den nya tilldelningen ger läsåtkomst. Den utökar inte rätt att kommentera, lämna feedback, återöppna eller skapa ärenden på underbolagen. Befintliga rättigheter, exempelvis till egna ärenden eller delade ärenden, fortsätter att gälla.
- Mejlsvar följer samma skrivbehörighet som portalen; enbart den nya läsåtkomsten ger inte rätt att lägga ett mejlsvar direkt på någon annans privata ärende.
- Tilldelningen slutar gälla när den tas bort, kontot inaktiveras, kontotypen ändras eller användaren flyttas till ett annat företag. Behörigheten följer inte automatiskt med användaren till det nya företaget.

Superadmins ändringar loggas med företag, administratör samt tilldelade användar-ID:n före och efter ändringen.

## Installation

Migrationen `Version20261105140000` skapar kopplingstabellen `company_hierarchy_ticket_readers`. Befintliga företag, användare och äldre ärendeåtkomster ändras inte. Ingen behörighet tilldelas automatiskt av migrationen.

Ta ordinarie backup före produktionsuppgradering. Kör projektets normala migreringsflöde innan den nya koden används:

```bash
php bin/console doctrine:migrations:status --env=prod
php bin/console doctrine:migrations:migrate --env=prod --no-interaction
```

Det andra kommandot ändrar databasschemat och kör även andra väntande migrationer. Granska statusen först. Inga nya miljövariabler eller Composer-paket behövs. En återställning av just denna migration tar bort de nya tilldelningarna, men lämnar äldre företagsåtkomster kvar.

## Verifiering

```bash
php -d memory_limit=512M bin/phpunit --filter 'CompanyHierarchyTicketAccessTest|CompanyHierarchyTicketAccessMigrationTest|TicketAccessPolicyTest'
APP_ENV=test php bin/console lint:twig templates
APP_ENV=test php bin/console doctrine:schema:validate --skip-sync
```

Verifiera minst ett privat ärende på barn- och barnbarnsbolag, ett avslutat ärende, ett internt ärende som ska nekas och ett privat ärende i en annan koncern. Kontrollera även borttagen tilldelning, kundsynliga respektive interna bilagor, sökning och CSV-export.
