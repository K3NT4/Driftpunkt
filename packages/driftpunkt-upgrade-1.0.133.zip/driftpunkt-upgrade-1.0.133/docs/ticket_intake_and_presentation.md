# Mottagning och intern ärendevy

Tekniker och ärendekoordinatorer har samma mottagningsinformation på ärendets detaljsida. Informationen visas inte i kundportalen.

## Mottagning och importproblem

- Mottagningsrutan visar det senast registrerade mejlets avsändare, mottagande inkorg, ärendets nuvarande företag och sparad behandlingsorsak.
- Mottagningstiden är tiden när mejlet registrerades i Driftpunkt, inte avsändarens skickat-datum.
- Mottagningshistoriken visar högst 25 mejl, nyast först, inklusive mejl kopplade till sammanslagna källärenden. Även mejl utan bevarad originalfil tas med. Originalmejl finns fortsatt i beskrivningens befintliga läsvy när de har sparats.
- Nya automatiskt kopplade svar anger om kopplingen gjordes via ärendenummer i ämnet, ärendenummer i texten eller entydigt ämne inom företaget. Tidigare mejl behåller sin sparade behandlingsnotering; en saknad orsak rekonstrueras inte i efterhand.
- Bilagefel samlas högt upp. Vidarebefordrat originalmejl innebär inte att bilagefelet är åtgärdat. Filnamn, orsaker, utskicksstatus och den befintliga återförsöksknappen finns under respektive varning.

## Möjliga dubbletter

`TicketDuplicateFinder` söker bland högst 100 av samma företags senast uppdaterade aktiva ärenden. Lösta, stängda och sammanslagna källärenden samt det aktuella ärendet utesluts. Tekniker får bara förslag på ärenden som de redan har läsbehörighet till.

Högst tre förslag visas. Matchningen jämför normaliserade rubriker utan svarsprefix och ärendereferenser. Exakt ämne prioriteras; liknande ämne kräver minst två gemensamma ord och minst 60 procent gemensamma ord av alla unika ord. Ord kortare än tre tecken används inte i likhetsjämförelsen. Ingen AI-tjänst eller extern överföring av ärendedata används.

Förslagen ändrar inte inkommande mejlroutning och slår aldrig ihop ärenden automatiskt. Handläggaren öppnar förslaget och kontrollerar innehållet. Ordinarie sammanslagning behåller sina befintliga bekräftelser och behörighetskontroller. Företagslösa ärenden ger inga förslag. Förslagen är ett hjälpmedel, inte en fullständig dubblettkontroll.

## Konversation, filer och nästa steg

- Konversationen ligger före svarsrutan. Interna anteckningar och kundsynliga kommentarer har skilda markeringar och textetiketter.
- Bilagor visas som kompakta filrader med namn, typ, storlek och tillgängliga öppna-/nedladdningsval. Efter de första tre filerna kan resten fällas ut. Fristående bilder har små, skyddade miniatyrer som laddas vid behov; CID-bilder visas fortfarande i texten.
- Arbetsverktygen ligger i sidopanelen på bred skärm. Nästa steg utgår från sammanslagning, slutstatus, ansvarig och väntan på kund. Det är vägledning, inte en ny arbetsflödesstatus.
- Historik och mer omfattande uppgifter kan fällas ihop. Ingen historik eller befintlig åtgärd tas bort.

## Synlighet och planerade utskick

Svarsrutan visar vad vald kommentartyp innebär. Kundsvar visar planerade huvud- och deltagarmottagare enligt befintliga notifieringsregler. Intern anteckning och kundsynlig kommentar utan mejl visar att inget kundmejl skickas. Egen kopia visas när den är vald och skickas fortsatt separat om kundutskicket lyckas.

Förhandsvisningen garanterar inte SMTP-leverans. Notifieringsloggen är underlaget för faktiska utskick och fel. Ändrade kontoinställningar efter att sidan öppnats kan påverka vilka mottagare som får mejl.

## Granskning före godkännande

Koordinatorns granskning grupperar kund/företag och ansvar/team. Kategori och startstatus kan fällas ihop; synlighet ligger kvar som ett primärt val. Både admin och koordinator får en sammanfattning som uppdateras med formulärvalen när JavaScript är aktivt. Utan JavaScript finns formulär och granskningsinstruktion kvar.

En uttryckligen vald kund och ett uttryckligen valt annat företag nekas på serversidan. Ingen aktivering sker i det fallet. Om företagsvalet lämnas tomt används fortsatt kundens företag enligt befintligt flöde. Godkännande följer ordinarie notifieringsregler.

## Installation och verifiering

Inga nya beroenden, miljövariabler eller databasmigrationer införs av dessa förbättringar. Tidigare migrationer för mejlläsaren och bilageåterförsök måste fortfarande vara applicerade.

```bash
php -d memory_limit=512M bin/phpunit tests/Functional/TicketIntakePresentationTest.php
APP_ENV=test php bin/console lint:twig templates
APP_ENV=test php bin/console lint:container
```

Verifiera även mobilvy, långa rubriker/mejl, många bilagor, ändring av kommentartyp och kund-/företagsval. Kontrollera ett ärende med bilagefel och ett utan sparad originalfil. Prova med en tekniker vars breda läsbehörighet är avstängd och bekräfta att inga obehöriga dubblettförslag visas.
