<?php

declare(strict_types=1);

namespace App\Twig;

use App\Module\Identity\Entity\Company;
use App\Module\Identity\Entity\User;
use App\Module\Identity\Enum\UserType;
use App\Module\Inventory\Entity\InventoryItem;
use App\Module\Inventory\Enum\InventoryListType;
use App\Module\Inventory\Service\InventoryService;
use App\Module\Maintenance\Service\MaintenanceMode;
use App\Module\Maintenance\Service\MaintenanceNoticeProvider;
use App\Module\System\Entity\AddonModule;
use App\Module\System\Service\AppDateTimeFormatter;
use App\Module\System\Service\CodeUpdateManager;
use App\Module\System\Service\SiteBrandingAssetStorage;
use App\Module\System\Service\SystemSettings;
use App\Module\Ticket\Entity\SlaPolicy;
use App\Module\Ticket\Entity\TicketCategory;
use App\Module\Ticket\Service\TicketCommentBodyFormatter;
use App\Module\Ticket\Service\CustomerCompanyTicketAccessService;
use App\Module\Ticket\Service\CustomerReportAccessService;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\DependencyInjection\Attribute\Autowire;
use Symfony\Component\HttpFoundation\RequestStack;
use Symfony\Component\Yaml\Yaml;

final class AppRuntime
{
    private const DRIFTPUNKT_PUBLIC_GITHUB_URL = 'https://github.com/K3NT4/Driftpunkt';

    /**
     * @var array<string, array<string, mixed>>
     */
    private array $translationFileCatalogues = [];

    /**
     * @var array<string, array<string, string>>
     */
    private array $translationCatalogues = [];

    /**
     * @var array<string, array<string, string>>
     */
    private array $sourceTextLookups = [];

    /**
     * @var array<string, list<array{regex: string, target: string, parameters: list<string>}>>
     */
    private array $sourceTextPatterns = [];

    /**
     * @var list<string>|null
     */
    private ?array $dynamicTranslationSourceTexts = null;

    public function __construct(
        private readonly MaintenanceMode $maintenanceMode,
        private readonly MaintenanceNoticeProvider $maintenanceNoticeProvider,
        private readonly AppDateTimeFormatter $dateTimeFormatter,
        private readonly SystemSettings $systemSettings,
        private readonly SiteBrandingAssetStorage $siteBrandingAssetStorage,
        private readonly CodeUpdateManager $codeUpdateManager,
        private readonly EntityManagerInterface $entityManager,
        private readonly RequestStack $requestStack,
        private readonly InventoryService $inventoryService,
        private readonly CustomerCompanyTicketAccessService $customerCompanyTicketAccessService,
        private readonly CustomerReportAccessService $customerReportAccessService,
        private readonly TicketCommentBodyFormatter $ticketCommentBodyFormatter,
        #[Autowire('%kernel.project_dir%')]
        private readonly string $projectDir,
    ) {
    }

    public function maintenanceMode(): MaintenanceMode
    {
        return $this->maintenanceMode;
    }

    /**
     * @return array{
     *     status: 'upcoming'|'active',
     *     eyebrow: string,
     *     title: string,
     *     summary: string,
     *     schedule: ?string,
     *     href: ?string,
     *     linkLabel: string
     * }|null
     */
    public function maintenanceNotice(): ?array
    {
        return $this->maintenanceNoticeProvider->getNotice();
    }

    /**
     * @return array{
     *     name: string,
     *     logoPath: string,
     *     footerText: string,
     *     iconPath: string,
     *     appVersion: string,
     *     githubUrl: string,
     *     copyrightLabel: string,
     *     theme: array{primaryColor: string, accentColor: string, backgroundColor: string, surfaceColor: string, textColor: string}
     * }
     */
    public function siteBranding(): array
    {
        $branding = $this->systemSettings->getSiteBrandingSettings();
        $application = $this->codeUpdateManager->describeCurrentApplication();

        return [
            'name' => $branding['name'],
            'logoPath' => $this->siteBrandingAssetStorage->resolveLogoPath($branding['logoPath']),
            'footerText' => $branding['footerText'],
            'iconPath' => $this->siteBrandingAssetStorage->resolveIconPath($branding['iconPath']),
            'theme' => $branding['theme'],
            'appVersion' => (string) ($application['version'] ?? 'lokal'),
            'githubUrl' => self::DRIFTPUNKT_PUBLIC_GITHUB_URL,
            'copyrightLabel' => sprintf('© %s Driftpunkt', $this->dateTimeFormatter->format($this->dateTimeFormatter->now(), 'Y')),
        ];
    }

    public function userComboboxLabel(User $user): string
    {
        $displayName = trim($user->getDisplayName());
        $email = trim($user->getEmail());

        return '' !== $email
            ? sprintf('%s (%s)', $displayName, $email)
            : $displayName;
    }

    public function userComboboxOptionLabel(User $user): string
    {
        return sprintf('%s - %s', $this->userComboboxLabel($user), $this->userComboboxContextLabel($user));
    }

    private function userComboboxContextLabel(User $user): string
    {
        $company = $user->getCompany();
        if (!$company instanceof Company) {
            return \in_array($user->getType(), [UserType::CUSTOMER, UserType::PRIVATE_CUSTOMER], true)
                ? 'Privatkund'
                : $user->getType()->label();
        }

        $companyNames = [$company->getName()];
        $parentCompany = $company->getParentCompany();
        while ($parentCompany instanceof Company) {
            array_unshift($companyNames, $parentCompany->getName());
            $parentCompany = $parentCompany->getParentCompany();
        }

        return implode(' / ', $companyNames);
    }

    public function formatDateTime(mixed $dateTime, string $format = AppDateTimeFormatter::DEFAULT_DATETIME_FORMAT): string
    {
        return $this->dateTimeFormatter->format($dateTime, $format);
    }

    public function formatDate(mixed $dateTime, string $format = AppDateTimeFormatter::DEFAULT_DATE_FORMAT): string
    {
        return $this->dateTimeFormatter->formatDate($dateTime, $format);
    }

    public function formatTime(mixed $dateTime, string $format = AppDateTimeFormatter::DEFAULT_TIME_FORMAT): string
    {
        return $this->dateTimeFormatter->formatTime($dateTime, $format);
    }

    public function formatDateTimeInput(mixed $dateTime): string
    {
        return $this->dateTimeFormatter->formatDateTimeInput($dateTime);
    }

    public function timeZoneLabel(): string
    {
        return $this->dateTimeFormatter->timeZoneLabel();
    }

    public function inventoryListEnabled(?Company $company, string $type): bool
    {
        return $this->inventoryService->isEnabled($company, $type);
    }

    public function inventoryListAccessible(?User $user, string $type): bool
    {
        return $this->inventoryService->canUserAccessList($user, $type);
    }

    public function inventoryAnyEnabled(): bool
    {
        return $this->inventoryService->hasAnyEnabledList();
    }

    /**
     * @return array<string, array<string, mixed>>
     */
    public function inventoryCompanySummary(?Company $company): array
    {
        if (!$company instanceof Company) {
            return [];
        }

        return $this->inventoryService->companySummary($company);
    }

    public function inventoryItemValue(InventoryItem $item, string $key): string
    {
        return $this->inventoryService->value($item, $key);
    }

    public function renderTicketCommentBody(string $body, bool $email = false): string
    {
        return $this->ticketCommentBodyFormatter->renderHtml($body, $email);
    }

    public function ticketCommentPlainText(string $body): string
    {
        return $this->ticketCommentBodyFormatter->toPlainText($body);
    }

    public function renderTicketRichTextBody(string $body, bool $email = false): string
    {
        return $this->ticketCommentBodyFormatter->renderHtml($body, $email);
    }

    public function ticketRichTextPlainText(string $body): string
    {
        return $this->ticketCommentBodyFormatter->toPlainText($body);
    }

    /**
     * @return list<User>
     */
    public function inventoryCustomerUsers(?Company $company): array
    {
        if (!$company instanceof Company) {
            return [];
        }

        return $this->inventoryService->customerUsers($company);
    }

    public function customerReportsAccessible(?User $user): bool
    {
        return $this->customerReportAccessService->canUserAccessReports($user);
    }

    /**
     * @return array{allowedUserIds: list<int>, allowedUsers: list<User>}
     */
    public function customerCompanyTicketAccessSummary(?Company $company): array
    {
        return $this->customerCompanyTicketAccessService->companySummary($company);
    }

    /**
     * @return list<User>
     */
    public function customerCompanyTicketCustomerUsers(?Company $company): array
    {
        if (!$company instanceof Company) {
            return [];
        }

        return $this->customerCompanyTicketAccessService->customerUsers($company);
    }

    /**
     * @return array{accessRestricted: bool, allowedUserIds: list<int>, allowedUsers: list<User>}
     */
    public function customerReportAccessSummary(?Company $company): array
    {
        return $this->customerReportAccessService->companySummary($company);
    }

    /**
     * @return list<User>
     */
    public function customerReportCustomerUsers(?Company $company): array
    {
        if (!$company instanceof Company) {
            return [];
        }

        return $this->customerReportAccessService->customerUsers($company);
    }

    /**
     * @param array<string, scalar|\Stringable|null> $parameters
     */
    public function translate(string $key, array $parameters = [], ?string $locale = null): string
    {
        $locale ??= $this->requestStack->getCurrentRequest()?->getLocale();
        $locale = \is_string($locale) && '' !== trim($locale) ? trim($locale) : 'sv';
        $catalogue = $this->loadTranslationCatalogue($locale);
        $message = $catalogue[$key] ?? null;

        if (!\is_string($message) || '' === $message) {
            $message = $this->translateSourceText($key, $locale);
        }

        if (!\is_string($message) || '' === $message) {
            $fallbackCatalogue = 'sv' === $locale ? $catalogue : $this->loadTranslationCatalogue('sv');
            $message = $fallbackCatalogue[$key] ?? $key;
        }

        $parameters = $this->withDefaultTranslationParameters($message, $parameters);
        foreach ($parameters as $parameter => $value) {
            $message = str_replace((string) $parameter, (string) $value, $message);
        }

        return $message;
    }

    /**
     * @param array<string, scalar|\Stringable|null> $parameters
     *
     * @return array<string, scalar|\Stringable|null>
     */
    private function withDefaultTranslationParameters(string $message, array $parameters): array
    {
        if (str_contains($message, '%site_name%') && !array_key_exists('%site_name%', $parameters)) {
            $parameters['%site_name%'] = $this->systemSettings->getSiteBrandingSettings()['name'];
        }

        return $parameters;
    }

    /**
     * @return list<array{code: string, name: string}>
     */
    public function availableLocales(): array
    {
        return $this->systemSettings->getSelectableTranslationLocales();
    }

    public function clearTranslationRuntimeCaches(): void
    {
        $this->translationCatalogues = [];
        $this->sourceTextLookups = [];
        $this->sourceTextPatterns = [];
        $this->dynamicTranslationSourceTexts = null;
    }

    /**
     * @return array{
     *     locales: list<array{code: string, name: string}>,
     *     languageSettings: array{
     *         defaultLocale: string,
     *         selectableLocaleCodes: list<string>,
     *         selectableLocales: list<array{code: string, name: string}>
     *     },
     *     selectedLocale: string,
     *     entries: list<array{
     *         key: string,
     *         base: string,
     *         translation: string,
     *         hasOverride: bool,
     *         isMissing: bool,
     *         isTranslated: bool,
     *         group: string,
     *         groupLabel: string,
     *         label: string,
     *         description: string
     *     }>,
     *     groups: list<array{code: string, label: string, count: int}>,
     *     summary: array{total: int, translated: int, missing: int, overrides: int},
     *     filters: array{query: string, group: string, state: string}
     * }
     */
    public function translationEditor(string $locale, string $query = '', string $group = 'all', string $state = 'all', int $page = 1, int $perPage = 10): array
    {
        $selectedLocale = trim($locale) !== '' ? trim($locale) : 'en';
        $selectedLocale = strtolower(str_replace('_', '-', $selectedLocale));
        $locales = $this->systemSettings->getTranslationLocales();
        $query = trim($query);
        $group = '' !== trim($group) ? trim($group) : 'all';
        $state = '' !== trim($state) ? trim($state) : 'all';
        $page = max(1, $page);
        $allowedPerPage = [10, 25, 50, 100];
        if (!\in_array($perPage, $allowedPerPage, true)) {
            $perPage = 10;
        }

        $keys = $this->knownTranslationSourceKeys($selectedLocale);

        $baseCatalogue = $this->loadTranslationCatalogue('sv');
        $selectedFileCatalogue = 'sv' === $selectedLocale ? $baseCatalogue : $this->loadTranslationFileCatalogue($selectedLocale);
        $selectedOverrides = $this->systemSettings->getTranslationOverridesForLocale($selectedLocale);
        $groupDefinitions = $this->translationGroupDefinitions();
        $entries = [];
        $sortedKeys = array_keys($keys);
        usort(
            $sortedKeys,
            static function (string $left, string $right): int {
                return strcmp($left, $right);
            },
        );

        foreach ($sortedKeys as $key) {
            $base = (string) ($baseCatalogue[$key] ?? $key);
            $translation = 'sv' === $selectedLocale
                ? (string) ($selectedOverrides[$key] ?? $base)
                : (string) ($selectedOverrides[$key] ?? $selectedFileCatalogue[$key] ?? '');
            $meta = $this->translationKeyMeta($key);
            $isMissing = '' === trim($translation);
            $isTranslated = !$isMissing;
            $searchHaystack = mb_strtolower(implode(' ', [
                $key,
                $meta['label'],
                $meta['description'],
                $base,
                $translation,
                $meta['groupLabel'],
            ]));

            if ('all' !== $group && $meta['group'] !== $group) {
                continue;
            }

            if ('' !== $query && !str_contains($searchHaystack, mb_strtolower($query))) {
                continue;
            }

            if ('missing' === $state && !$isMissing) {
                continue;
            }

            if ('translated' === $state && !$isTranslated) {
                continue;
            }

            if ('overrides' === $state && !isset($selectedOverrides[$key])) {
                continue;
            }

            $entries[] = [
                'key' => $key,
                'base' => $base,
                'translation' => $translation,
                'hasOverride' => isset($selectedOverrides[$key]),
                'isMissing' => $isMissing,
                'isTranslated' => $isTranslated,
                'group' => $meta['group'],
                'groupLabel' => $meta['groupLabel'],
                'label' => $meta['label'],
                'description' => $meta['description'],
            ];
        }

        usort(
            $entries,
            static function (array $left, array $right): int {
                if ($left['isMissing'] !== $right['isMissing']) {
                    return $left['isMissing'] ? -1 : 1;
                }

                $groupCompare = strcmp($left['groupLabel'], $right['groupLabel']);
                if (0 !== $groupCompare) {
                    return $groupCompare;
                }

                return strcmp($left['key'], $right['key']);
            },
        );

        $allEntries = [];
        foreach ($sortedKeys as $key) {
            $base = (string) ($baseCatalogue[$key] ?? $key);
            $translation = 'sv' === $selectedLocale
                ? (string) ($selectedOverrides[$key] ?? $base)
                : (string) ($selectedOverrides[$key] ?? $selectedFileCatalogue[$key] ?? '');
            $meta = $this->translationKeyMeta($key);
            $allEntries[] = [
                'group' => $meta['group'],
                'hasOverride' => isset($selectedOverrides[$key]),
                'isTranslated' => '' !== trim($translation),
            ];
        }

        $groups = [];
        foreach ($groupDefinitions as $groupCode => $definition) {
            $groupEntries = array_values(array_filter(
                $allEntries,
                static fn (array $entry): bool => $entry['group'] === $groupCode,
            ));
            $count = \count($groupEntries);

            if ($count <= 0) {
                continue;
            }

            $translatedCount = \count(array_filter($groupEntries, static fn (array $entry): bool => $entry['isTranslated']));
            $missingCount = \count(array_filter($groupEntries, static fn (array $entry): bool => !$entry['isTranslated']));
            $groups[] = [
                'code' => $groupCode,
                'label' => $definition['label'],
                'count' => $count,
                'missing' => $missingCount,
                'translated' => $translatedCount,
                'overrides' => \count(array_filter($groupEntries, static fn (array $entry): bool => $entry['hasOverride'])),
                'description' => $definition['description'],
                'completionPercent' => $count > 0 ? (int) round(($translatedCount / $count) * 100) : 0,
            ];
        }

        usort(
            $groups,
            static function (array $left, array $right): int {
                if ($left['missing'] !== $right['missing']) {
                    return $right['missing'] <=> $left['missing'];
                }

                return strcmp($left['label'], $right['label']);
            },
        );

        $recommendedGroup = null;
        foreach ($groups as $groupInfo) {
            if (($groupInfo['missing'] ?? 0) > 0) {
                $recommendedGroup = $groupInfo;
                break;
            }
        }

        $activeGroup = null;
        foreach ($groups as $groupInfo) {
            if (($groupInfo['code'] ?? null) === $group) {
                $activeGroup = $groupInfo;
                break;
            }
        }

        $nextMissingEntry = null;
        foreach ($entries as $entry) {
            if ($entry['isMissing']) {
                $nextMissingEntry = $entry;
                break;
            }
        }

        $filteredEntryCount = \count($entries);
        $pageCount = max(1, (int) ceil($filteredEntryCount / $perPage));
        $page = min($page, $pageCount);
        $offset = ($page - 1) * $perPage;
        $paginatedEntries = array_slice($entries, $offset, $perPage);

        return [
            'locales' => $locales,
            'languageSettings' => [
                'defaultLocale' => $this->systemSettings->getDefaultLocale(),
                'selectableLocaleCodes' => $this->systemSettings->getSelectableLocaleCodes(),
                'selectableLocales' => $this->systemSettings->getSelectableTranslationLocales(),
            ],
            'selectedLocale' => $selectedLocale,
            'entries' => $paginatedEntries,
            'groups' => $groups,
            'summary' => [
                'total' => \count($allEntries),
                'translated' => \count(array_filter($allEntries, static fn (array $entry): bool => $entry['isTranslated'])),
                'missing' => \count(array_filter($allEntries, static fn (array $entry): bool => !$entry['isTranslated'])),
                'overrides' => \count(array_filter($allEntries, static fn (array $entry): bool => $entry['hasOverride'])),
            ],
            'workspace' => [
                'filteredTotal' => $filteredEntryCount,
                'page' => $page,
                'perPage' => $perPage,
                'pageCount' => $pageCount,
                'from' => $filteredEntryCount > 0 ? $offset + 1 : 0,
                'to' => min($filteredEntryCount, $offset + $perPage),
                'hasPreviousPage' => $page > 1,
                'hasNextPage' => $page < $pageCount,
                'completionPercent' => \count($allEntries) > 0
                    ? (int) round((\count(array_filter($allEntries, static fn (array $entry): bool => $entry['isTranslated'])) / \count($allEntries)) * 100)
                    : 0,
                'recommendedGroup' => $recommendedGroup,
                'activeGroup' => $activeGroup,
                'nextMissingEntry' => $nextMissingEntry,
                'isFocusedView' => '' === $query && 'missing' === $state,
                'batchSize' => min($perPage, max(1, $filteredEntryCount)),
            ],
            'filters' => [
                'query' => $query,
                'group' => $group,
                'state' => $state,
                'page' => $page,
                'perPage' => $perPage,
            ],
        ];
    }

    public function pruneTranslationOverridesToKnownSources(string $locale): int
    {
        $locale = strtolower(str_replace('_', '-', trim($locale)));
        if ('' === $locale || preg_match('/^[a-z]{2,3}(?:-[a-z0-9]{2,8})*$/', $locale) !== 1) {
            return 0;
        }

        $this->clearTranslationRuntimeCaches();
        $allowedKeys = $this->knownTranslationSourceKeys($locale);
        $currentOverrides = $this->systemSettings->getTranslationOverridesForLocale($locale);
        $prunedOverrides = [];

        foreach ($currentOverrides as $key => $message) {
            if (isset($allowedKeys[$key])) {
                $prunedOverrides[$key] = $message;
            }
        }

        $removedCount = \count($currentOverrides) - \count($prunedOverrides);
        if ($removedCount > 0) {
            $this->systemSettings->setTranslationOverridesForLocale($locale, $prunedOverrides);
            $this->clearTranslationRuntimeCaches();
        }

        return $removedCount;
    }

    /**
     * @return array<string, true>
     */
    private function knownTranslationSourceKeys(string $selectedLocale): array
    {
        $keys = [];

        foreach ($this->translationSourceLocales($selectedLocale) as $knownLocale) {
            foreach (array_keys($this->loadTranslationFileCatalogue($knownLocale)) as $key) {
                if (\is_string($key) && '' !== trim($key)) {
                    $keys[$key] = true;
                }
            }
        }

        foreach ($this->dynamicTranslationSourceTexts() as $sourceText) {
            $keys[$sourceText] = true;
        }

        return $keys;
    }

    /**
     * @return list<string>
     */
    private function translationSourceLocales(string $selectedLocale): array
    {
        return array_values(array_unique(array_merge(
            ['sv', 'en', strtolower(str_replace('_', '-', trim($selectedLocale)))],
            array_map(static fn (array $entry): string => $entry['code'], $this->systemSettings->getTranslationLocales()),
            array_keys($this->systemSettings->getTranslationOverrides()),
        )));
    }

    /**
     * @return array<string, array{label: string, description: string}>
     */
    private function translationGroupDefinitions(): array
    {
        return [
            'global' => [
                'label' => $this->translate('portal.admin.translation_groups.global.label'),
                'description' => $this->translate('portal.admin.translation_groups.global.description'),
            ],
            'navigation' => [
                'label' => $this->translate('portal.admin.translation_groups.navigation.label'),
                'description' => $this->translate('portal.admin.translation_groups.navigation.description'),
            ],
            'home' => [
                'label' => $this->translate('portal.admin.translation_groups.home.label'),
                'description' => $this->translate('portal.admin.translation_groups.home.description'),
            ],
            'login' => [
                'label' => $this->translate('portal.admin.translation_groups.login.label'),
                'description' => $this->translate('portal.admin.translation_groups.login.description'),
            ],
            'contact' => [
                'label' => $this->translate('portal.admin.translation_groups.contact.label'),
                'description' => $this->translate('portal.admin.translation_groups.contact.description'),
            ],
            'status' => [
                'label' => $this->translate('portal.admin.translation_groups.status.label'),
                'description' => $this->translate('portal.admin.translation_groups.status.description'),
            ],
            'news' => [
                'label' => $this->translate('portal.admin.translation_groups.news.label'),
                'description' => $this->translate('portal.admin.translation_groups.news.description'),
            ],
            'other' => [
                'label' => $this->translate('portal.admin.translation_groups.other.label'),
                'description' => $this->translate('portal.admin.translation_groups.other.description'),
            ],
        ];
    }

    /**
     * @return array{group: string, groupLabel: string, label: string, description: string}
     */
    private function translationKeyMeta(string $key): array
    {
        $group = match (true) {
            str_starts_with($key, 'ui.'), str_starts_with($key, 'brand.') => 'global',
            str_starts_with($key, 'nav.') => 'navigation',
            str_starts_with($key, 'home.') => 'home',
            str_starts_with($key, 'login.') => 'login',
            str_starts_with($key, 'contact.') => 'contact',
            str_starts_with($key, 'status.') => 'status',
            str_starts_with($key, 'news.') => 'news',
            default => 'other',
        };

        $definitions = $this->translationGroupDefinitions();
        $groupLabel = $definitions[$group]['label'] ?? $this->translate('portal.admin.translation_groups.other.label');

        $segments = explode('.', $key);
        $last = end($segments);
        $label = ucfirst(str_replace(['_', '-'], ' ', \is_string($last) ? $last : $key));

        $description = match ($key) {
            'ui.language' => 'Label för språkväxlaren.',
            'brand.logo_alt' => 'Alt-text för logotypen.',
            'nav.home' => 'Länk till startsidan.',
            'nav.portal' => 'Länk till portalen för inloggade användare.',
            'nav.login' => 'Knapp/länk för inloggning.',
            'nav.logout' => 'Knapp/länk för utloggning.',
            'nav.news' => 'Länk till nyhetssidan.',
            'nav.contact' => 'Länk till kontaktsidan.',
            'nav.status' => 'Länk till driftstatus.',
            'nav.support' => 'Länk eller etikett för support.',
            default => sprintf('%s · %s', $groupLabel, $key),
        };

        return [
            'group' => $group,
            'groupLabel' => $groupLabel,
            'label' => $label,
            'description' => $description,
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function loadTranslationCatalogue(string $locale): array
    {
        $locale = strtolower(str_replace('_', '-', $locale));
        if (isset($this->translationCatalogues[$locale])) {
            return $this->translationCatalogues[$locale];
        }

        $baseCatalogue = array_map(
            static fn (mixed $value): string => \is_scalar($value) ? (string) $value : '',
            $this->loadTranslationFileCatalogue('sv'),
        );
        $baseOverrides = $this->systemSettings->getTranslationOverridesForLocale('sv');
        $baseCatalogue = array_replace($baseCatalogue, $baseOverrides);

        if ('sv' === $locale) {
            return $this->translationCatalogues[$locale] = $baseCatalogue;
        }

        $localeCatalogue = array_map(
            static fn (mixed $value): string => \is_scalar($value) ? (string) $value : '',
            $this->loadTranslationFileCatalogue($locale),
        );
        $localeOverrides = $this->systemSettings->getTranslationOverridesForLocale($locale);

        return $this->translationCatalogues[$locale] = array_replace($baseCatalogue, $localeCatalogue, $localeOverrides);
    }

    private function translateSourceText(string $sourceText, string $locale): ?string
    {
        $sourceText = trim($sourceText);
        $locale = strtolower(str_replace('_', '-', $locale));

        if ('' === $sourceText || 'sv' === $locale) {
            return null;
        }

        $lookups = $this->sourceTextLookup($locale);
        $lookupKey = $this->normalizeSourceText($sourceText);
        if (isset($lookups[$lookupKey])) {
            return $lookups[$lookupKey];
        }

        foreach ($this->sourceTextPatterns($locale) as $pattern) {
            if (preg_match($pattern['regex'], $sourceText, $matches) !== 1) {
                continue;
            }

            $parameters = [];
            foreach ($pattern['parameters'] as $parameter) {
                if (isset($matches[$parameter]) && \is_string($matches[$parameter])) {
                    $parameters['%'.$parameter.'%'] = $matches[$parameter];
                }
            }

            return strtr($pattern['target'], $parameters);
        }

        return null;
    }

    /**
     * @return array<string, string>
     */
    private function sourceTextLookup(string $locale): array
    {
        $locale = strtolower(str_replace('_', '-', $locale));
        if (isset($this->sourceTextLookups[$locale])) {
            return $this->sourceTextLookups[$locale];
        }

        $baseCatalogue = $this->loadTranslationCatalogue('sv');
        $targetCatalogue = $this->loadTranslationCatalogue($locale);
        $lookups = [];

        foreach ($baseCatalogue as $key => $sourceText) {
            if (!\is_string($key) || !\is_string($sourceText) || '' === trim($sourceText) || str_contains($sourceText, '%')) {
                continue;
            }

            $targetText = $targetCatalogue[$key] ?? null;
            if (!\is_string($targetText) || '' === trim($targetText) || $targetText === $sourceText) {
                continue;
            }

            $lookups[$this->normalizeSourceText($sourceText)] ??= $targetText;
        }

        return $this->sourceTextLookups[$locale] = $lookups;
    }

    /**
     * @return list<array{regex: string, target: string, parameters: list<string>}>
     */
    private function sourceTextPatterns(string $locale): array
    {
        $locale = strtolower(str_replace('_', '-', $locale));
        if (isset($this->sourceTextPatterns[$locale])) {
            return $this->sourceTextPatterns[$locale];
        }

        $baseCatalogue = $this->loadTranslationCatalogue('sv');
        $targetCatalogue = $this->loadTranslationCatalogue($locale);
        $patterns = [];

        foreach ($baseCatalogue as $key => $sourcePattern) {
            if (!\is_string($key) || !\is_string($sourcePattern) || !str_contains($sourcePattern, '%')) {
                continue;
            }

            $targetPattern = $targetCatalogue[$key] ?? null;
            if (!\is_string($targetPattern) || '' === trim($targetPattern) || $targetPattern === $sourcePattern) {
                continue;
            }

            $parameters = [];
            $regex = preg_replace_callback(
                '/%([a-zA-Z0-9_]+)%/',
                static function (array $matches) use (&$parameters): string {
                    $parameter = (string) $matches[1];
                    $parameters[] = $parameter;

                    return sprintf('(?P<%s>.+?)', $parameter);
                },
                preg_quote($sourcePattern, '/'),
            );

            if (!\is_string($regex) || [] === $parameters) {
                continue;
            }

            $patterns[] = [
                'regex' => '/^'.$regex.'$/u',
                'target' => $targetPattern,
                'parameters' => array_values(array_unique($parameters)),
            ];
        }

        return $this->sourceTextPatterns[$locale] = $patterns;
    }

    private function normalizeSourceText(string $text): string
    {
        return (string) preg_replace('/\s+/u', ' ', trim($text));
    }

    /**
     * @return list<string>
     */
    private function dynamicTranslationSourceTexts(): array
    {
        if (null !== $this->dynamicTranslationSourceTexts) {
            return $this->dynamicTranslationSourceTexts;
        }

        $texts = [];

        try {
            foreach ([
                $this->systemSettings->getCustomerLoginSettings(),
                $this->systemSettings->getHomeSupportWidgetSettings(),
                $this->systemSettings->getHomepageStatusSectionSettings(),
                $this->systemSettings->getSiteBrandingSettings(),
                $this->systemSettings->getPrivacyPolicySettings(),
                $this->systemSettings->getTermsPageSettings(),
                $this->systemSettings->getCookiePolicySettings(),
                $this->systemSettings->getPublicStatusSettings(),
                $this->systemSettings->getStatusMonitorSettings(),
                $this->systemSettings->getStatusPageSettings(),
                $this->systemSettings->getContactPageSettings(),
            ] as $settings) {
                $this->collectTranslationSourceValue($settings, $texts);
            }

            $this->collectEntityTranslationSourceTexts($texts);
        } catch (\Throwable) {
            return $this->dynamicTranslationSourceTexts = [];
        }

        $sourceTexts = array_keys($texts);
        sort($sourceTexts);

        return $this->dynamicTranslationSourceTexts = $sourceTexts;
    }

    /**
     * @param array<string, true> $texts
     */
    private function collectEntityTranslationSourceTexts(array &$texts): void
    {
        // Redaktionella artiklar i nyheter och kunskapsbas ska inte blandas in i UI-översättningar.

        /** @var list<TicketCategory> $ticketCategories */
        $ticketCategories = $this->entityManager->getRepository(TicketCategory::class)->findBy([], ['id' => 'ASC'], 250);
        foreach ($ticketCategories as $category) {
            $this->collectTranslationSourceValue($category->getName(), $texts);
            $this->collectTranslationSourceValue($category->getDescription(), $texts);
        }

        /** @var list<SlaPolicy> $slaPolicies */
        $slaPolicies = $this->entityManager->getRepository(SlaPolicy::class)->findBy([], ['id' => 'ASC'], 250);
        foreach ($slaPolicies as $policy) {
            $this->collectTranslationSourceValue($policy->getName(), $texts);
            $this->collectTranslationSourceValue($policy->getDescription(), $texts);
        }

        /** @var list<AddonModule> $addonModules */
        $addonModules = $this->entityManager->getRepository(AddonModule::class)->findBy([], ['id' => 'ASC'], 250);
        foreach ($addonModules as $addon) {
            $this->collectTranslationSourceValue($addon->getName(), $texts);
            $this->collectTranslationSourceValue($addon->getDescription(), $texts);
        }
    }

    /**
     * @param array<string, true> $texts
     */
    private function collectTranslationSourceValue(mixed $value, array &$texts): void
    {
        if (\is_array($value)) {
            foreach ($value as $item) {
                $this->collectTranslationSourceValue($item, $texts);
            }

            return;
        }

        if (!$value instanceof \Stringable && !\is_scalar($value)) {
            return;
        }

        $text = trim((string) $value);
        if ('' === $text) {
            return;
        }

        if (str_contains($text, "\n")) {
            foreach (preg_split('/\R+/u', $text) ?: [] as $line) {
                $this->collectTranslationSourceValue($line, $texts);
            }

            return;
        }

        if (str_contains($text, '|')) {
            foreach (explode('|', $text) as $part) {
                $this->collectTranslationSourceValue($part, $texts);
            }

            return;
        }

        $text = trim((string) preg_replace('/^\s*(?:#{1,6}|[-*]|\d+[.)])\s*/u', '', $text));
        if (!$this->isTranslatableSourceText($text)) {
            return;
        }

        $texts[$text] = true;
    }

    private function isTranslatableSourceText(string $text): bool
    {
        if (mb_strlen($text) < 2 || mb_strlen($text) > 400) {
            return false;
        }

        if (preg_match('/^[\d\s.,:+%()-]+$/u', $text) === 1) {
            return false;
        }

        if (preg_match('#^(?:https?:)?//#i', $text) === 1 || str_starts_with($text, '/')) {
            return false;
        }

        if (filter_var($text, \FILTER_VALIDATE_EMAIL)) {
            return false;
        }

        if (preg_match('/^[a-z0-9_.:-]+$/i', $text) === 1 && !str_contains($text, ' ')) {
            return false;
        }

        if (str_starts_with($text, '{') || str_starts_with($text, '[')) {
            return false;
        }

        return true;
    }

    /**
     * @return array<string, mixed>
     */
    private function loadTranslationFileCatalogue(string $locale): array
    {
        $locale = strtolower(str_replace('_', '-', $locale));

        if (isset($this->translationFileCatalogues[$locale])) {
            return $this->translationFileCatalogues[$locale];
        }

        $path = sprintf('%s/translations/messages.%s.yaml', $this->projectDir, $locale);
        if (!is_file($path)) {
            return $this->translationFileCatalogues[$locale] = [];
        }

        $data = Yaml::parseFile($path);
        if (!\is_array($data)) {
            return $this->translationFileCatalogues[$locale] = [];
        }

        return $this->translationFileCatalogues[$locale] = $data;
    }

    public function renderArticleBody(string $body): string
    {
        $body = str_replace(["\r\n", "\r"], "\n", trim($body));
        if ('' === $body) {
            return '';
        }

        $lines = explode("\n", $body);
        $html = [];
        $paragraph = [];
        $listItems = [];
        $listType = null;
        $checklistItems = [];
        $blockquote = [];
        $calloutType = null;
        $calloutTitle = null;
        $calloutLines = [];
        $faqQuestion = null;
        $faqLines = [];
        $tableLines = [];
        $tableHasSeparator = false;
        $codeFenceLines = [];
        $insideCodeFence = false;

        $flushParagraph = function () use (&$html, &$paragraph): void {
            if ([] === $paragraph) {
                return;
            }

            $html[] = sprintf('<p>%s</p>', implode('<br>', array_map([$this, 'renderInlineArticleMarkup'], $paragraph)));
            $paragraph = [];
        };

        $flushList = function () use (&$html, &$listItems, &$listType): void {
            if ([] === $listItems || null === $listType) {
                return;
            }

            $tag = 'ol' === $listType ? 'ol' : 'ul';
            $items = array_map(
                fn (string $item): string => sprintf('<li>%s</li>', $this->renderInlineArticleMarkup($item)),
                $listItems,
            );

            $html[] = sprintf('<%1$s>%2$s</%1$s>', $tag, implode('', $items));
            $listItems = [];
            $listType = null;
        };

        $flushChecklist = function () use (&$html, &$checklistItems): void {
            if ([] === $checklistItems) {
                return;
            }

            $items = array_map(
                fn (array $item): string => sprintf(
                    '<li class="%s"><span class="article-checklist-box" aria-hidden="true">%s</span><span>%s</span></li>',
                    $item['checked'] ? 'is-done' : 'is-pending',
                    $item['checked'] ? '✓' : '',
                    $this->renderInlineArticleMarkup($item['label']),
                ),
                $checklistItems,
            );

            $html[] = sprintf('<ul class="article-checklist">%s</ul>', implode('', $items));
            $checklistItems = [];
        };

        $flushBlockquote = function () use (&$html, &$blockquote): void {
            if ([] === $blockquote) {
                return;
            }

            $html[] = sprintf(
                '<blockquote><p>%s</p></blockquote>',
                implode('<br>', array_map([$this, 'renderInlineArticleMarkup'], $blockquote)),
            );
            $blockquote = [];
        };

        $flushCallout = function () use (&$html, &$calloutType, &$calloutTitle, &$calloutLines): void {
            if (null === $calloutType || [] === $calloutLines) {
                $calloutType = null;
                $calloutTitle = null;
                $calloutLines = [];

                return;
            }

            $bodyLines = array_values(array_filter(
                array_map(static fn (string $line): string => trim($line), $calloutLines),
                static fn (string $line): bool => '' !== $line,
            ));
            $title = null !== $calloutTitle && '' !== trim($calloutTitle)
                ? sprintf('<strong>%s</strong>', $this->renderInlineArticleMarkup($calloutTitle))
                : '';
            $bodyHtml = [] !== $bodyLines
                ? sprintf('<p>%s</p>', implode('<br>', array_map([$this, 'renderInlineArticleMarkup'], $bodyLines)))
                : '';

            $html[] = sprintf(
                '<div class="article-callout %s">%s%s</div>',
                $calloutType,
                $title,
                $bodyHtml,
            );

            $calloutType = null;
            $calloutTitle = null;
            $calloutLines = [];
        };

        $flushFaq = function () use (&$html, &$faqQuestion, &$faqLines): void {
            if (null === $faqQuestion || [] === $faqLines) {
                $faqQuestion = null;
                $faqLines = [];

                return;
            }

            $bodyLines = array_values(array_filter(
                array_map(static fn (string $line): string => trim($line), $faqLines),
                static fn (string $line): bool => '' !== $line,
            ));
            $bodyHtml = [] !== $bodyLines
                ? sprintf('<p>%s</p>', implode('<br>', array_map([$this, 'renderInlineArticleMarkup'], $bodyLines)))
                : '';

            $html[] = sprintf(
                '<details class="article-faq"><summary>%s</summary>%s</details>',
                $this->renderInlineArticleMarkup($faqQuestion),
                $bodyHtml,
            );

            $faqQuestion = null;
            $faqLines = [];
        };

        $flushTable = function () use (&$html, &$tableLines, &$tableHasSeparator): void {
            if ([] === $tableLines) {
                $tableHasSeparator = false;

                return;
            }

            if ($tableHasSeparator && \count($tableLines) >= 2) {
                $header = $tableLines[0];
                $rows = array_slice($tableLines, 1);
                $headerHtml = implode('', array_map(
                    fn (string $cell): string => sprintf('<th>%s</th>', $this->renderInlineArticleMarkup($cell)),
                    $header,
                ));
                $bodyHtml = implode('', array_map(
                    fn (array $row): string => sprintf(
                        '<tr>%s</tr>',
                        implode('', array_map(
                            fn (string $cell): string => sprintf('<td>%s</td>', $this->renderInlineArticleMarkup($cell)),
                            $row,
                        )),
                    ),
                    $rows,
                ));

                $html[] = sprintf(
                    '<div class="article-table-wrap"><table class="article-table"><thead><tr>%s</tr></thead><tbody>%s</tbody></table></div>',
                    $headerHtml,
                    $bodyHtml,
                );
            }

            $tableLines = [];
            $tableHasSeparator = false;
        };

        $flushCodeFence = function () use (&$html, &$codeFenceLines, &$insideCodeFence): void {
            if (!$insideCodeFence && [] === $codeFenceLines) {
                return;
            }

            $code = htmlspecialchars(implode("\n", $codeFenceLines), \ENT_QUOTES | \ENT_SUBSTITUTE, 'UTF-8');
            $html[] = sprintf('<pre class="article-code"><code>%s</code></pre>', $code);
            $codeFenceLines = [];
            $insideCodeFence = false;
        };

        foreach ($lines as $line) {
            $trimmed = trim($line);

            if ($insideCodeFence) {
                if ('```' === $trimmed) {
                    $flushCodeFence();
                    continue;
                }

                $codeFenceLines[] = rtrim($line, "\n");
                continue;
            }

            if (null !== $calloutType) {
                if (':::' === $trimmed) {
                    $flushCallout();
                    continue;
                }

                $calloutLines[] = $line;
                continue;
            }

            if (null !== $faqQuestion) {
                if ('???' === $trimmed) {
                    $flushFaq();
                    continue;
                }

                $faqLines[] = $line;
                continue;
            }

            if ('' === $trimmed) {
                $flushParagraph();
                $flushList();
                $flushChecklist();
                $flushBlockquote();
                $flushFaq();
                $flushTable();
                continue;
            }

            if ('```' === $trimmed) {
                $flushParagraph();
                $flushList();
                $flushChecklist();
                $flushBlockquote();
                $flushFaq();
                $flushTable();
                $insideCodeFence = true;
                $codeFenceLines = [];
                continue;
            }

            if (preg_match('/^:::(info|warning|success)(?:\s+(.+))?$/', $trimmed, $matches) === 1) {
                $flushParagraph();
                $flushList();
                $flushChecklist();
                $flushBlockquote();
                $flushFaq();
                $flushTable();
                $calloutType = $matches[1];
                $calloutTitle = $matches[2] ?? null;
                $calloutLines = [];
                continue;
            }

            if (preg_match('/^\?\?\?\s+(.+)$/', $trimmed, $matches) === 1) {
                $flushParagraph();
                $flushList();
                $flushChecklist();
                $flushBlockquote();
                $faqQuestion = $matches[1];
                $faqLines = [];
                continue;
            }

            if ('---' === $trimmed) {
                $flushParagraph();
                $flushList();
                $flushChecklist();
                $flushBlockquote();
                $flushFaq();
                $flushTable();
                $html[] = '<hr>';
                continue;
            }

            if (preg_match('/^\+\+\+\s+(.+?)(?:\s+\|\s+(.+))?$/', $trimmed, $matches) === 1) {
                $flushParagraph();
                $flushList();
                $flushChecklist();
                $flushBlockquote();
                $flushFaq();
                $flushTable();
                $version = $this->renderInlineArticleMarkup($matches[1]);
                $label = isset($matches[2]) && '' !== trim($matches[2])
                    ? sprintf('<span>%s</span>', $this->renderInlineArticleMarkup($matches[2]))
                    : '';
                $html[] = sprintf('<div class="article-version"><strong>%s</strong>%s</div>', $version, $label);
                continue;
            }

            if (preg_match('/^(#{2,3})\s+(.+)$/', $trimmed, $matches) === 1) {
                $flushParagraph();
                $flushList();
                $flushChecklist();
                $flushBlockquote();
                $flushFaq();
                $flushTable();
                $level = strlen($matches[1]);
                $html[] = sprintf('<h%d>%s</h%d>', $level, $this->renderInlineArticleMarkup($matches[2]), $level);
                continue;
            }

            if (preg_match('/^\|(.+)\|$/', $trimmed) === 1) {
                $flushParagraph();
                $flushList();
                $flushChecklist();
                $flushBlockquote();
                $flushFaq();

                if (preg_match('/^\|(?:\s*:?-{3,}:?\s*\|)+$/', $trimmed) === 1) {
                    if ([] !== $tableLines) {
                        $tableHasSeparator = true;
                    }
                    continue;
                }

                $cells = array_map(
                    static fn (string $cell): string => trim($cell),
                    explode('|', trim($trimmed, '|')),
                );
                $tableLines[] = $cells;
                continue;
            }

            $flushTable();

            if (preg_match('/^!\[(.*?)\]\((https?:\/\/[^\s)]+)\)$/', $trimmed, $matches) === 1) {
                $flushParagraph();
                $flushList();
                $flushChecklist();
                $flushBlockquote();
                $flushFaq();
                $alt = htmlspecialchars(trim($matches[1]), \ENT_QUOTES | \ENT_SUBSTITUTE, 'UTF-8');
                $url = htmlspecialchars($matches[2], \ENT_QUOTES | \ENT_SUBSTITUTE, 'UTF-8');
                $caption = '' !== trim($matches[1])
                    ? sprintf('<figcaption>%s</figcaption>', $this->renderInlineArticleMarkup($matches[1]))
                    : '';
                $html[] = sprintf(
                    '<figure class="article-media"><img src="%s" alt="%s" loading="lazy">%s</figure>',
                    $url,
                    $alt,
                    $caption,
                );
                continue;
            }

            if (preg_match('/^=>\s+(.+?)\s+\|\s+(https?:\/\/\S+)$/', $trimmed, $matches) === 1) {
                $flushParagraph();
                $flushList();
                $flushChecklist();
                $flushBlockquote();
                $flushFaq();
                $label = $this->renderInlineArticleMarkup($matches[1]);
                $url = htmlspecialchars($matches[2], \ENT_QUOTES | \ENT_SUBSTITUTE, 'UTF-8');
                $html[] = sprintf(
                    '<p><a class="article-cta" href="%s" target="_blank" rel="noopener noreferrer">%s</a></p>',
                    $url,
                    $label,
                );
                continue;
            }

            if (preg_match('/^>\s?(.*)$/', $trimmed, $matches) === 1) {
                $flushParagraph();
                $flushList();
                $flushChecklist();
                $blockquote[] = $matches[1];
                continue;
            }

            if (preg_match('/^- (.+)$/', $trimmed, $matches) === 1) {
                if (preg_match('/^\[( |x|X)\]\s+(.+)$/', $matches[1], $checklistMatches) === 1) {
                    $flushParagraph();
                    $flushList();
                    $flushBlockquote();
                    $checklistItems[] = [
                        'checked' => \in_array($checklistMatches[1], ['x', 'X'], true),
                        'label' => $checklistMatches[2],
                    ];
                    continue;
                }

                $flushParagraph();
                $flushChecklist();
                $flushBlockquote();
                if ('ul' !== $listType) {
                    $flushList();
                    $listType = 'ul';
                }
                $listItems[] = $matches[1];
                continue;
            }

            if (preg_match('/^\d+\. (.+)$/', $trimmed, $matches) === 1) {
                $flushParagraph();
                $flushChecklist();
                $flushBlockquote();
                if ('ol' !== $listType) {
                    $flushList();
                    $listType = 'ol';
                }
                $listItems[] = $matches[1];
                continue;
            }

            $flushList();
            $flushChecklist();
            $flushBlockquote();
            $paragraph[] = $trimmed;
        }

        $flushCallout();
        $flushFaq();
        $flushTable();
        $flushCodeFence();
        $flushParagraph();
        $flushList();
        $flushChecklist();
        $flushBlockquote();

        return implode("\n", $html);
    }

    private function renderInlineArticleMarkup(string $text): string
    {
        $text = htmlspecialchars($text, \ENT_QUOTES | \ENT_SUBSTITUTE, 'UTF-8');

        $patterns = [
            '/\[(.+?)\]\((https?:\/\/[^\s)]+)\)/' => '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>',
            '/\*\*(.+?)\*\*/' => '<strong>$1</strong>',
            '/(?<!\*)\*(?!\s)(.+?)(?<!\s)\*(?!\*)/' => '<em>$1</em>',
            '/`([^`]+)`/' => '<code>$1</code>',
        ];

        foreach ($patterns as $pattern => $replacement) {
            $text = preg_replace($pattern, $replacement, $text) ?? $text;
        }

        return $text;
    }
}
