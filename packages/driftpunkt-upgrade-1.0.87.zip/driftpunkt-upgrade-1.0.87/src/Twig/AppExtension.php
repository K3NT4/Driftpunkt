<?php

declare(strict_types=1);

namespace App\Twig;

use Twig\Extension\AbstractExtension;
use Twig\Extension\GlobalsInterface;
use Twig\TwigFilter;
use Twig\TwigFunction;

final class AppExtension extends AbstractExtension implements GlobalsInterface
{
    public function __construct(
        private readonly AppRuntime $runtime,
    ) {
    }

    public function getGlobals(): array
    {
        return [
            'maintenance_mode' => $this->runtime->maintenanceMode(),
            'site_branding' => $this->runtime->siteBranding(),
        ];
    }

    public function getFunctions(): array
    {
        return [
            new TwigFunction('maintenance_notice', [$this->runtime, 'maintenanceNotice']),
            new TwigFunction('t', [$this->runtime, 'translate']),
            new TwigFunction('available_locales', [$this->runtime, 'availableLocales']),
            new TwigFunction('app_timezone_label', [$this->runtime, 'timeZoneLabel']),
            new TwigFunction('inventory_list_enabled', [$this->runtime, 'inventoryListEnabled']),
            new TwigFunction('inventory_list_accessible', [$this->runtime, 'inventoryListAccessible']),
            new TwigFunction('inventory_any_enabled', [$this->runtime, 'inventoryAnyEnabled']),
            new TwigFunction('inventory_company_summary', [$this->runtime, 'inventoryCompanySummary']),
            new TwigFunction('inventory_item_value', [$this->runtime, 'inventoryItemValue']),
            new TwigFunction('inventory_customer_users', [$this->runtime, 'inventoryCustomerUsers']),
            new TwigFunction('customer_reports_accessible', [$this->runtime, 'customerReportsAccessible']),
            new TwigFunction('customer_company_ticket_access_summary', [$this->runtime, 'customerCompanyTicketAccessSummary']),
            new TwigFunction('customer_company_ticket_customer_users', [$this->runtime, 'customerCompanyTicketCustomerUsers']),
            new TwigFunction('customer_report_access_summary', [$this->runtime, 'customerReportAccessSummary']),
            new TwigFunction('customer_report_customer_users', [$this->runtime, 'customerReportCustomerUsers']),
            new TwigFunction('user_combobox_label', [$this->runtime, 'userComboboxLabel']),
            new TwigFunction('user_combobox_option_label', [$this->runtime, 'userComboboxOptionLabel']),
        ];
    }

    public function getFilters(): array
    {
        return [
            new TwigFilter('app_datetime', [$this->runtime, 'formatDateTime']),
            new TwigFilter('app_date', [$this->runtime, 'formatDate']),
            new TwigFilter('app_time', [$this->runtime, 'formatTime']),
            new TwigFilter('app_datetime_input', [$this->runtime, 'formatDateTimeInput']),
            new TwigFilter('article_body', [$this->runtime, 'renderArticleBody'], ['is_safe' => ['html']]),
            new TwigFilter('ticket_comment_body', [$this->runtime, 'renderTicketCommentBody'], ['is_safe' => ['html']]),
            new TwigFilter('ticket_comment_text', [$this->runtime, 'ticketCommentPlainText']),
            new TwigFilter('ticket_rich_text_body', [$this->runtime, 'renderTicketRichTextBody'], ['is_safe' => ['html']]),
            new TwigFilter('ticket_rich_text_text', [$this->runtime, 'ticketRichTextPlainText']),
        ];
    }
}
