<?php

declare(strict_types=1);

namespace App\Module\System\Service;

use Symfony\Component\Clock\ClockInterface;

final class SeasonalAppearance
{
    public const SURFACE_HOMEPAGE = 'homepage';
    public const SURFACE_CUSTOMER_PORTAL = 'customer_portal';

    public function __construct(
        private readonly SystemSettings $systemSettings,
        private readonly AppDateTimeFormatter $dateTimeFormatter,
        private readonly ClockInterface $clock,
    ) {
    }

    public function seasonFor(string $surface): ?string
    {
        if (!\in_array($surface, [self::SURFACE_HOMEPAGE, self::SURFACE_CUSTOMER_PORTAL], true)) {
            return null;
        }

        $settings = $this->systemSettings->getSeasonalAppearanceSettings();
        if (!$this->isVisibleOn($settings['visibility'], $surface)) {
            return null;
        }

        if (!\in_array($settings['mode'], ['auto', 'auto_holidays', 'holidays'], true)) {
            return $settings['mode'];
        }

        $now = $this->now();

        return match ($settings['mode']) {
            'holidays' => self::holidayForDate($now),
            'auto_holidays' => self::holidayOrSeasonForDate($now),
            default => self::seasonForMonth((int) $now->format('n')),
        };
    }

    /**
     * Current season in the installation's timezone, regardless of the admin's seasonal
     * decoration settings. Used by personal themes that follow the season.
     */
    public function currentSeason(): string
    {
        return self::seasonForMonth((int) $this->now()->format('n'));
    }

    /**
     * Decoration for staff who opted in on their own settings page: holidays first, then season.
     */
    public function personalDecoration(): string
    {
        return self::holidayOrSeasonForDate($this->now());
    }

    /**
     * Holidays take precedence; the rest of the year follows the season.
     */
    public static function holidayOrSeasonForDate(\DateTimeImmutable $date): string
    {
        return self::holidayForDate($date) ?? self::seasonForMonth((int) $date->format('n'));
    }

    public static function holidayForDate(\DateTimeImmutable $date): ?string
    {
        $day = $date->format('md');
        if ($day >= '1201' && $day <= '1226') {
            return 'christmas';
        }
        if ($day >= '1227' || $day <= '0106') {
            return 'new_year';
        }

        return null;
    }

    public static function seasonForMonth(int $month): string
    {
        return match (true) {
            \in_array($month, [12, 1, 2], true) => 'winter',
            $month >= 3 && $month <= 5 => 'spring',
            $month >= 6 && $month <= 8 => 'summer',
            default => 'autumn',
        };
    }

    private function now(): \DateTimeImmutable
    {
        return $this->clock->now()->setTimezone($this->dateTimeFormatter->timeZone());
    }

    private function isVisibleOn(string $visibility, string $surface): bool
    {
        return 'both' === $visibility || $visibility === $surface;
    }
}
