<?php

declare(strict_types=1);

namespace App\Module\Ticket\Service;

use App\Module\Identity\Entity\Company;
use App\Module\Identity\Entity\User;
use App\Module\Identity\Enum\UserType;
use App\Module\System\Service\SystemSettings;
use App\Module\Ticket\Entity\Ticket;
use App\Module\Ticket\Enum\TicketVisibility;

final class TicketAccessPolicy
{
    public function __construct(
        private readonly SystemSettings $systemSettings,
        private readonly ?CustomerCompanyTicketAccessService $customerCompanyTicketAccessService = null,
    ) {
    }

    public function customerCanAccessTicket(User $user, Ticket $ticket): bool
    {
        if (TicketVisibility::INTERNAL_ONLY === $ticket->getVisibility()) {
            return false;
        }

        if ($this->sameUser($ticket->getRequester(), $user)) {
            return true;
        }

        if (UserType::PRIVATE_CUSTOMER === $user->getType()) {
            return false;
        }

        if (!$user->getCompany() instanceof Company || !$ticket->getCompany() instanceof Company) {
            return false;
        }

        if (
            $this->customerCanAccessAllCompanyTickets($user)
            && $this->sameCompany($user->getCompany(), $ticket->getCompany())
        ) {
            return true;
        }

        return TicketVisibility::COMPANY_SHARED === $ticket->getVisibility()
            && $this->customerCompanyCanAccessCompanyTickets($user->getCompany(), $ticket->getCompany());
    }

    public function customerCanAccessAllCompanyTickets(User $user): bool
    {
        return $this->customerCompanyTicketAccessService?->canUserAccessAllCompanyTickets($user) ?? false;
    }

    public function customerCompanyCanAccessCompanyTickets(?Company $viewerCompany, ?Company $ticketCompany): bool
    {
        if (!$viewerCompany instanceof Company || !$ticketCompany instanceof Company) {
            return false;
        }

        if ($this->sameCompany($viewerCompany, $ticketCompany)) {
            return true;
        }

        $settings = $this->systemSettings->getCompanyHierarchyVisibilitySettings();

        if (
            $settings['parentCanSeeChildSharedTickets']
            && $ticketCompany->allowsParentCompanyAccessToSharedTickets()
            && $ticketCompany->isDescendantOf($viewerCompany)
        ) {
            return true;
        }

        return $settings['childCanSeeParentSharedTickets']
            && $viewerCompany->isDescendantOf($ticketCompany);
    }

    /**
     * @return list<TicketVisibility>
     */
    public function availableCustomerTicketVisibilities(User $user): array
    {
        $visibilities = [TicketVisibility::PRIVATE];

        if (UserType::PRIVATE_CUSTOMER !== $user->getType() && $user->getCompany() instanceof Company) {
            $visibilities[] = TicketVisibility::COMPANY_SHARED;
        }

        return $visibilities;
    }

    public function technicianCanReadTicket(User $user, Ticket $ticket): bool
    {
        if (\in_array($user->getType(), [UserType::SUPER_ADMIN, UserType::ADMIN], true)) {
            return true;
        }

        if (UserType::TECHNICIAN !== $user->getType()) {
            return false;
        }

        if ($this->systemSettings->getBool(SystemSettings::FEATURE_TECHNICIAN_CAN_READ_ALL_TICKETS, true)) {
            return true;
        }

        return $this->technicianCanCollaborateOnTicket($user, $ticket);
    }

    public function technicianCanCollaborateOnTicket(User $user, Ticket $ticket): bool
    {
        if (\in_array($user->getType(), [UserType::SUPER_ADMIN, UserType::ADMIN], true)) {
            return true;
        }

        if ($this->sameUser($ticket->getAssignee(), $user)) {
            return true;
        }

        if ($ticket->hasAdditionalTechnician($user)) {
            return true;
        }

        return $user->isMemberOfTechnicianTeam($ticket->getAssignedTeam());
    }

    public function technicianCanTakeOverTicket(User $user, Ticket $ticket): bool
    {
        if (\in_array($user->getType(), [UserType::SUPER_ADMIN, UserType::ADMIN], true)) {
            return !$this->sameUser($ticket->getAssignee(), $user);
        }

        return UserType::TECHNICIAN === $user->getType()
            && !$this->sameUser($ticket->getAssignee(), $user)
            && $this->technicianCanReadTicket($user, $ticket);
    }

    public function technicianCanEditTicketDetails(User $user, Ticket $ticket): bool
    {
        if (\in_array($user->getType(), [UserType::SUPER_ADMIN, UserType::ADMIN], true)) {
            return true;
        }

        return UserType::TECHNICIAN === $user->getType()
            && ($this->sameUser($ticket->getAssignee(), $user) || $ticket->hasAdditionalTechnician($user));
    }

    private function sameUser(?User $left, ?User $right): bool
    {
        if (!$left instanceof User || !$right instanceof User) {
            return false;
        }

        if ($left === $right) {
            return true;
        }

        return null !== $left->getId() && $left->getId() === $right->getId();
    }

    private function sameCompany(Company $left, Company $right): bool
    {
        if ($left === $right) {
            return true;
        }

        return null !== $left->getId() && $left->getId() === $right->getId();
    }

}
