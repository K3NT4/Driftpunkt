<?php

declare(strict_types=1);

namespace App\Module\Ticket\Service;

use App\Module\Identity\Entity\Company;
use App\Module\Identity\Entity\User;
use App\Module\Ticket\Entity\Ticket;
use App\Module\Ticket\Enum\TicketStatus;
use App\Module\Ticket\Enum\TicketVisibility;
use Doctrine\ORM\EntityManagerInterface;

final class CustomerTicketQuery
{
    public function __construct(
        private readonly EntityManagerInterface $entityManager,
        private readonly TicketAccessPolicy $ticketAccessPolicy,
    ) {
    }

    /**
     * @param list<TicketStatus>|null $statuses
     * @return list<Ticket>
     */
    public function findAccessibleTickets(User $user, ?array $statuses = null): array
    {
        if ([] === $statuses) {
            return [];
        }

        $queryBuilder = $this->baseCustomerTicketQueryBuilder();

        $accessibleCompanies = $this->accessibleCompanies($user);
        $viewerCompany = $user->getCompany();
        if ($viewerCompany instanceof Company && $this->ticketAccessPolicy->customerCanAccessAllCompanyTickets($user)) {
            if ([] !== $accessibleCompanies) {
                $queryBuilder
                    ->andWhere('(ticket.requester = :requester OR ticket.company = :viewerCompany OR (ticket.visibility = :companyShared AND ticket.company IN (:companies)))')
                    ->setParameter('requester', $user)
                    ->setParameter('viewerCompany', $viewerCompany)
                    ->setParameter('companyShared', TicketVisibility::COMPANY_SHARED)
                    ->setParameter('companies', $accessibleCompanies);
            } else {
                $queryBuilder
                    ->andWhere('(ticket.requester = :requester OR ticket.company = :viewerCompany)')
                    ->setParameter('requester', $user)
                    ->setParameter('viewerCompany', $viewerCompany);
            }
        } elseif ([] !== $accessibleCompanies) {
            $queryBuilder
                ->andWhere('(ticket.requester = :requester OR (ticket.visibility = :companyShared AND ticket.company IN (:companies)))')
                ->setParameter('requester', $user)
                ->setParameter('companyShared', TicketVisibility::COMPANY_SHARED)
                ->setParameter('companies', $accessibleCompanies);
        } else {
            $queryBuilder
                ->andWhere('ticket.requester = :requester')
                ->setParameter('requester', $user);
        }

        if (null !== $statuses) {
            $queryBuilder
                ->andWhere('ticket.status IN (:statuses)')
                ->setParameter('statuses', $statuses);
        }

        /** @var list<Ticket> $tickets */
        $tickets = $queryBuilder->getQuery()->getResult();

        return $tickets;
    }

    /**
     * @param list<TicketStatus>|null $statuses
     * @return list<Ticket>
     */
    public function findOwnTickets(User $user, ?array $statuses = null): array
    {
        if ([] === $statuses) {
            return [];
        }

        $queryBuilder = $this->baseCustomerTicketQueryBuilder()
            ->andWhere('ticket.requester = :requester')
            ->setParameter('requester', $user);

        if (null !== $statuses) {
            $queryBuilder
                ->andWhere('ticket.status IN (:statuses)')
                ->setParameter('statuses', $statuses);
        }

        /** @var list<Ticket> $tickets */
        $tickets = $queryBuilder->getQuery()->getResult();

        return $tickets;
    }

    /**
     * @param list<TicketStatus>|null $statuses
     * @return list<Ticket>
     */
    public function findCompanyTicketsForAllowedCustomer(User $user, ?array $statuses = null): array
    {
        if ([] === $statuses) {
            return [];
        }

        $viewerCompany = $user->getCompany();
        if (!$viewerCompany instanceof Company) {
            return [];
        }

        if ($this->ticketAccessPolicy->customerCanAccessAllCompanyTickets($user)) {
            $queryBuilder = $this->baseCustomerTicketQueryBuilder()
                ->andWhere('ticket.company = :viewerCompany')
                ->setParameter('viewerCompany', $viewerCompany);

            if (null !== $statuses) {
                $queryBuilder
                    ->andWhere('ticket.status IN (:statuses)')
                    ->setParameter('statuses', $statuses);
            }

            /** @var list<Ticket> $tickets */
            $tickets = $queryBuilder->getQuery()->getResult();

            return $tickets;
        }

        return array_values(array_filter(
            $this->findAccessibleTickets($user, $statuses),
            static fn (Ticket $ticket): bool => $ticket->getRequester()?->getId() !== $user->getId(),
        ));
    }

    private function baseCustomerTicketQueryBuilder(): \Doctrine\ORM\QueryBuilder
    {
        return $this->entityManager
            ->getRepository(Ticket::class)
            ->createQueryBuilder('ticket')
            ->leftJoin('ticket.company', 'company')->addSelect('company')
            ->leftJoin('ticket.requester', 'requester')->addSelect('requester')
            ->leftJoin('ticket.assignee', 'assignee')->addSelect('assignee')
            ->leftJoin('ticket.assignedTeam', 'assignedTeam')->addSelect('assignedTeam')
            ->andWhere('ticket.visibility != :internalOnly')
            ->setParameter('internalOnly', TicketVisibility::INTERNAL_ONLY)
            ->orderBy('ticket.updatedAt', 'DESC')
            ->addOrderBy('ticket.id', 'DESC');
    }

    /**
     * @return list<Company>
     */
    private function accessibleCompanies(User $user): array
    {
        $viewerCompany = $user->getCompany();
        if (!$viewerCompany instanceof Company) {
            return [];
        }

        /** @var list<Company> $companies */
        $companies = $this->entityManager->getRepository(Company::class)->findAll();

        return array_values(array_filter(
            $companies,
            fn (Company $company): bool => $this->ticketAccessPolicy->customerCompanyCanAccessCompanyTickets($viewerCompany, $company),
        ));
    }
}
