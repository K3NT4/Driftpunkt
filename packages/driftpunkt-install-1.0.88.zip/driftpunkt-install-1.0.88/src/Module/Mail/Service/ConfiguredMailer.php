<?php

declare(strict_types=1);

namespace App\Module\Mail\Service;

use App\Module\Identity\Entity\Company;
use App\Module\Mail\Entity\CompanyMailOverride;
use App\Module\Mail\Entity\MailServer;
use App\Module\Mail\Enum\MailEncryption;
use Doctrine\ORM\EntityManagerInterface;
use Psr\EventDispatcher\EventDispatcherInterface;
use Psr\Log\LoggerInterface;
use Symfony\Component\DependencyInjection\Attribute\Autowire;
use Symfony\Component\Mailer\Mailer;
use Symfony\Component\Mailer\MailerInterface;
use Symfony\Component\Mailer\Transport\Smtp\EsmtpTransport;
use Symfony\Component\Mime\Address;
use Symfony\Component\Mime\Email;

final class ConfiguredMailer
{
    public function __construct(
        private readonly EntityManagerInterface $entityManager,
        private readonly MailerInterface $fallbackMailer,
        private readonly MicrosoftOAuthTokenProvider $microsoftOAuthTokenProvider,
        private readonly MicrosoftOAuthSmtpClient $microsoftOAuthSmtpClient,
        #[Autowire('%env(MAILER_FROM)%')]
        private readonly string $fallbackFromAddress,
        #[Autowire('%env(MAILER_DSN)%')]
        private readonly string $fallbackMailerDsn,
        #[Autowire('%kernel.environment%')]
        private readonly string $environment,
        private readonly ?EventDispatcherInterface $eventDispatcher = null,
        private readonly ?LoggerInterface $logger = null,
    ) {
    }

    public function send(Email $email, ?Company $company = null, bool $requireConfiguredOutbound = false): void
    {
        $message = clone $email;
        $resolved = $this->resolveOutboundProfile($company);
        if (null === $resolved) {
            if ($requireConfiguredOutbound && $this->usesNullFallbackMailer()) {
                throw new \RuntimeException('Ingen aktiv primär utgående e-postserver är konfigurerad. Mailet skulle annars hamna i null-fallback och inte lämna systemet.');
            }

            $this->applyFallbackFromAddress($message);
            $this->fallbackMailer->send($message);

            return;
        }

        $this->applyFromAddress($message, $resolved['fromAddress'], $resolved['fromName']);

        if ($resolved['server']->usesMicrosoftOAuth()) {
            $this->microsoftOAuthSmtpClient->send(
                $resolved['server'],
                $message,
                $this->microsoftOAuthTokenProvider->accessTokenFor($resolved['server']),
            );

            return;
        }

        (new Mailer($this->buildTransport($resolved['server'])))->send($message);
    }

    public function testOutboundServer(MailServer $server): void
    {
        if ($server->usesMicrosoftOAuth()) {
            $this->microsoftOAuthSmtpClient->test($server, $this->microsoftOAuthTokenProvider->accessTokenFor($server));

            return;
        }

        $transport = $this->buildTransport($server);
        $transport->start();
        $transport->stop();
    }

    /**
     * @return array{server: MailServer, fromAddress: string, fromName: ?string}|null
     */
    private function resolveOutboundProfile(?Company $company): ?array
    {
        $override = $company instanceof Company ? $this->resolveCompanyMailOverride($company) : null;

        if ($override instanceof CompanyMailOverride) {
            $overrideServer = $override->getOutboundServer();
            if ($overrideServer instanceof MailServer && $overrideServer->isActive() && $overrideServer->supportsOutgoing()) {
                return [
                    'server' => $overrideServer,
                    'fromAddress' => $override->getFromAddress() ?? $overrideServer->getFromAddress() ?? $this->fallbackFromAddress,
                    'fromName' => $override->getFromName() ?? $overrideServer->getFromName(),
                ];
            }

            if (!$override->fallbackToPrimary()) {
                return null;
            }
        }

        $primaryServer = $this->entityManager->getRepository(MailServer::class)->findOneBy([
            'isPrimaryOutbound' => true,
            'isActive' => true,
        ]);

        if (!$primaryServer instanceof MailServer || !$primaryServer->supportsOutgoing()) {
            return null;
        }

        return [
            'server' => $primaryServer,
            'fromAddress' => $primaryServer->getFromAddress() ?? $this->fallbackFromAddress,
            'fromName' => $primaryServer->getFromName(),
        ];
    }

    private function resolveCompanyMailOverride(Company $company): ?CompanyMailOverride
    {
        $seenCompanies = [];
        $currentCompany = $company;

        while ($currentCompany instanceof Company) {
            $companyKey = null !== $currentCompany->getId() ? 'id:'.$currentCompany->getId() : 'object:'.spl_object_id($currentCompany);
            if (isset($seenCompanies[$companyKey])) {
                return null;
            }
            $seenCompanies[$companyKey] = true;

            $override = $this->entityManager->getRepository(CompanyMailOverride::class)->findOneBy([
                'company' => $currentCompany,
                'isActive' => true,
            ]);

            if ($override instanceof CompanyMailOverride) {
                return $override;
            }

            $currentCompany = $currentCompany->getParentCompany();
        }

        return null;
    }

    private function buildTransport(MailServer $server): EsmtpTransport
    {
        if ('smtp' !== $server->getTransportType()) {
            throw new \RuntimeException(sprintf('Utgående server "%s" måste använda SMTP-transport.', $server->getName()));
        }

        $tls = MailEncryption::SSL === $server->getEncryption();
        $transport = new EsmtpTransport($server->getHost(), $server->getPort(), $tls, $this->eventDispatcher, $this->logger);
        $transport->setAutoTls(\in_array($server->getEncryption(), [MailEncryption::TLS, MailEncryption::STARTTLS], true));
        $transport->setRequireTls(MailEncryption::NONE !== $server->getEncryption());

        $username = trim((string) $server->getUsername());

        if ($server->usesMicrosoftOAuth()) {
            if ('' === $username) {
                throw new \RuntimeException(sprintf('E-postservern "%s" kräver postlåda/UPN i användarnamnsfältet för Microsoft OAuth.', $server->getName()));
            }

            $transport
                ->setUsername($username)
                ->setPassword($this->microsoftOAuthTokenProvider->accessTokenFor($server));

            return $transport;
        }

        if ('' !== $username) {
            $transport->setUsername($username);
        }

        $password = $server->getPassword();
        if (null !== $password && '' !== trim($password)) {
            $transport->setPassword($password);
        }

        return $transport;
    }

    private function applyFromAddress(Email $email, string $fromAddress, ?string $fromName): void
    {
        $email->from(
            new Address(
                $fromAddress,
                trim((string) $fromName) !== '' ? (string) $fromName : '',
            ),
        );
    }

    private function applyFallbackFromAddress(Email $email): void
    {
        if ([] !== $email->getFrom()) {
            return;
        }

        $fallbackFromAddress = trim($this->fallbackFromAddress);
        if ('' === $fallbackFromAddress) {
            $fallbackFromAddress = 'notifications@localhost';
        }

        $this->applyFromAddress($email, $fallbackFromAddress, null);
    }

    private function usesNullFallbackMailer(): bool
    {
        if ('test' === $this->environment) {
            return false;
        }

        $dsn = mb_strtolower(trim($this->fallbackMailerDsn));

        return '' === $dsn || str_starts_with($dsn, 'null://');
    }
}
