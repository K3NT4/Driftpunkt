<?php

declare(strict_types=1);

namespace App\Module\Mail\Service;

use App\Module\Mail\Entity\MailServer;
use App\Module\Mail\Entity\SupportMailbox;
use App\Module\Mail\Enum\MailEncryption;

final class ImapMailboxFetcher
{
    private int $tagCounter = 0;

    public function __construct(
        private readonly MicrosoftOAuthTokenProvider $microsoftOAuthTokenProvider,
    ) {
    }

    public function supports(SupportMailbox $mailbox): bool
    {
        $server = $mailbox->getIncomingServer();

        return $server instanceof MailServer
            && $server->supportsIncoming()
            && 'imap' === $server->getTransportType()
            && null !== $server->getUsername()
            && (
                ($server->usesPasswordAuthentication() && null !== $server->getPassword())
                || $server->usesMicrosoftOAuth()
            );
    }

    /**
     * @return list<array{
     *     remote_id: string,
     *     raw_message: string
     * }>
     */
    public function fetchPendingMessages(SupportMailbox $mailbox): array
    {
        $server = $mailbox->getIncomingServer();
        if (!$server instanceof MailServer) {
            return [];
        }

        $stream = $this->openAuthenticatedStream($server);

        try {
            $this->execute($stream, 'SELECT INBOX');
            $search = $this->execute($stream, 'SEARCH UNSEEN');
            $messageIds = $this->parseSearchIds($search['lines']);
            $messages = [];

            foreach ($messageIds as $messageId) {
                $messageResponse = $this->execute($stream, sprintf('FETCH %s BODY.PEEK[]', $messageId));
                $rawMessage = $messageResponse['literals'][0] ?? '';

                if ('' === trim($rawMessage)) {
                    continue;
                }

                $messages[] = [
                    'remote_id' => $messageId,
                    'raw_message' => $rawMessage,
                ];
            }

            return $messages;
        } finally {
            $this->logout($stream);
        }
    }

    public function acknowledge(SupportMailbox $mailbox, string $remoteId): void
    {
        $server = $mailbox->getIncomingServer();
        if (!$server instanceof MailServer) {
            return;
        }

        $stream = $this->openAuthenticatedStream($server);

        try {
            $this->execute($stream, 'SELECT INBOX');
            $this->markMessageSeen($stream, $remoteId);
        } finally {
            $this->logout($stream);
        }
    }

    public function testIncomingServer(MailServer $server): void
    {
        if (!$server->supportsIncoming() || 'imap' !== $server->getTransportType()) {
            throw new \RuntimeException('Servern måste vara en inkommande IMAP-server för att kunna testas.');
        }

        $stream = $this->openAuthenticatedStream($server);

        try {
            $this->execute($stream, 'SELECT INBOX');
        } finally {
            $this->logout($stream);
        }
    }

    /**
     * @return resource
     */
    private function openAuthenticatedStream(MailServer $server)
    {
        $stream = $this->openStream($server);

        if (\in_array($server->getEncryption(), [MailEncryption::TLS, MailEncryption::STARTTLS], true)) {
            $this->execute($stream, 'STARTTLS');

            if (!stream_socket_enable_crypto($stream, true, \STREAM_CRYPTO_METHOD_TLS_CLIENT)) {
                throw new \RuntimeException('Kunde inte starta TLS mot IMAP-servern.');
            }
        }

        if ($server->usesMicrosoftOAuth()) {
            $this->authenticateWithMicrosoftOAuth($stream, $server);
        } else {
            $this->execute($stream, sprintf(
                'LOGIN "%s" "%s"',
                $this->escapeQuoted($server->getUsername() ?? ''),
                $this->escapeQuoted($server->getPassword() ?? ''),
            ));
        }

        return $stream;
    }

    /**
     * @return resource
     */
    private function openStream(MailServer $server)
    {
        $remote = match ($server->getEncryption()) {
            MailEncryption::SSL => sprintf('ssl://%s:%d', $server->getHost(), $server->getPort()),
            default => sprintf('tcp://%s:%d', $server->getHost(), $server->getPort()),
        };

        $context = stream_context_create([
            'ssl' => [
                'verify_peer' => false,
                'verify_peer_name' => false,
                'allow_self_signed' => true,
            ],
        ]);

        $stream = @stream_socket_client($remote, $errorCode, $errorMessage, 15, \STREAM_CLIENT_CONNECT, $context);
        if (!\is_resource($stream)) {
            throw new \RuntimeException(sprintf('Kunde inte ansluta till IMAP-servern: %s (%d).', $errorMessage, $errorCode));
        }

        stream_set_timeout($stream, 15);
        $this->tagCounter = 0;
        $this->readGreeting($stream);

        return $stream;
    }

    /**
     * @param resource $stream
     */
    private function readGreeting($stream): void
    {
        $line = fgets($stream);
        if (false === $line) {
            throw new \RuntimeException('IMAP-servern svarade inte med greeting.');
        }

        if (!str_starts_with(trim($line), '* OK')) {
            throw new \RuntimeException(sprintf('Ovantas greeting fran IMAP-servern: %s', trim($line)));
        }
    }

    /**
     * @param resource $stream
     * @return array{lines: list<string>, literals: list<string>}
     */
    private function execute($stream, string $command): array
    {
        $tag = sprintf('A%04d', ++$this->tagCounter);
        fwrite($stream, sprintf("%s %s\r\n", $tag, $command));

        $lines = [];
        $literals = [];

        while (($line = fgets($stream)) !== false) {
            $trimmed = rtrim($line, "\r\n");
            $lines[] = $trimmed;

            if (preg_match('/\{(\d+)\}$/', $trimmed, $matches)) {
                $length = (int) $matches[1];
                $literal = '';

                while (\strlen($literal) < $length) {
                    $chunk = fread($stream, $length - \strlen($literal));
                    if (false === $chunk || '' === $chunk) {
                        throw new \RuntimeException('Kunde inte läsa IMAP-literal fullt ut.');
                    }

                    $literal .= $chunk;
                }

                $literals[] = $literal;

                continue;
            }

            if (str_starts_with($trimmed, $tag.' ')) {
                if (!preg_match('/^'.preg_quote($tag, '/').'\s+OK\b/i', $trimmed)) {
                    throw new \RuntimeException(sprintf('IMAP-kommandot misslyckades: %s', $trimmed));
                }

                return [
                    'lines' => $lines,
                    'literals' => $literals,
                ];
            }
        }

        throw new \RuntimeException('IMAP-anslutningen stängdes innan kommandot blev klart.');
    }

    /**
     * @param resource $stream
     */
    private function logout($stream): void
    {
        try {
            $this->execute($stream, 'LOGOUT');
        } catch (\Throwable) {
        }

        fclose($stream);
    }

    /**
     * @param resource $stream
     */
    private function markMessageSeen($stream, string $messageId): void
    {
        $this->execute($stream, sprintf('STORE %s +FLAGS (\\Seen)', $messageId));
    }

    /**
     * @param list<string> $lines
     * @return list<string>
     */
    private function parseSearchIds(array $lines): array
    {
        foreach ($lines as $line) {
            if (!str_starts_with($line, '* SEARCH')) {
                continue;
            }

            $parts = preg_split('/\s+/', trim(substr($line, \strlen('* SEARCH')))) ?: [];

            return array_values(array_filter($parts, static fn (string $part): bool => '' !== trim($part)));
        }

        return [];
    }

    /**
     * @param resource $stream
     */
    private function authenticateWithMicrosoftOAuth($stream, MailServer $server): void
    {
        $mailboxUpn = trim((string) $server->getUsername());
        if ('' === $mailboxUpn) {
            throw new \RuntimeException('Microsoft OAuth för IMAP kräver postlåda/UPN i användarnamnsfältet.');
        }

        $accessToken = $this->microsoftOAuthTokenProvider->accessTokenFor($server);
        $payload = base64_encode(sprintf("user=%s\x01auth=Bearer %s\x01\x01", $mailboxUpn, $accessToken));
        $tag = sprintf('A%04d', ++$this->tagCounter);

        fwrite($stream, sprintf("%s AUTHENTICATE XOAUTH2 %s\r\n", $tag, $payload));

        while (($line = fgets($stream)) !== false) {
            $trimmed = rtrim($line, "\r\n");

            if ('+' === $trimmed) {
                fwrite($stream, "\r\n");
                continue;
            }

            if (str_starts_with($trimmed, $tag.' ')) {
                if (!preg_match('/^'.preg_quote($tag, '/').'\s+OK\b/i', $trimmed)) {
                    throw new \RuntimeException(sprintf('Microsoft OAuth-inloggning mot IMAP misslyckades: %s', $trimmed));
                }

                return;
            }
        }

        throw new \RuntimeException('IMAP-anslutningen stängdes innan Microsoft OAuth-autentisering blev klar.');
    }

    private function escapeQuoted(string $value): string
    {
        return str_replace(['\\', '"'], ['\\\\', '\\"'], $value);
    }
}
