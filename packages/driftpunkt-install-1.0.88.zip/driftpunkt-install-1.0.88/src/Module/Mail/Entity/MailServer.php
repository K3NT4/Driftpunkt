<?php

declare(strict_types=1);

namespace App\Module\Mail\Entity;

use App\Module\Mail\Enum\MailAuthenticationMode;
use App\Module\Mail\Enum\MailEncryption;
use App\Module\Mail\Enum\MailServerDirection;
use App\Module\Shared\Entity\TimestampableTrait;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity]
#[ORM\Table(name: 'mail_servers')]
#[ORM\HasLifecycleCallbacks]
class MailServer
{
    use TimestampableTrait;

    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 180, unique: true)]
    private string $name;

    #[ORM\Column(enumType: MailServerDirection::class)]
    private MailServerDirection $direction;

    #[ORM\Column(length: 40)]
    private string $transportType = 'smtp';

    #[ORM\Column(length: 255)]
    private string $host;

    #[ORM\Column]
    private int $port;

    #[ORM\Column(enumType: MailEncryption::class)]
    private MailEncryption $encryption = MailEncryption::TLS;

    #[ORM\Column(enumType: MailAuthenticationMode::class)]
    private MailAuthenticationMode $authenticationMode = MailAuthenticationMode::PASSWORD;

    #[ORM\Column(length: 180, nullable: true)]
    private ?string $username = null;

    #[ORM\Column(length: 255, nullable: true)]
    private ?string $password = null;

    #[ORM\Column(length: 120, nullable: true)]
    private ?string $oauthTenantId = null;

    #[ORM\Column(length: 180, nullable: true)]
    private ?string $oauthClientId = null;

    #[ORM\Column(length: 255, nullable: true)]
    private ?string $oauthClientSecret = null;

    #[ORM\Column(length: 180, nullable: true)]
    private ?string $fromAddress = null;

    #[ORM\Column(length: 180, nullable: true)]
    private ?string $fromName = null;

    #[ORM\Column(length: 255, nullable: true)]
    private ?string $description = null;

    #[ORM\Column]
    private bool $isActive = true;

    #[ORM\Column]
    private bool $isPrimaryOutbound = false;

    #[ORM\Column]
    private bool $fallbackToPrimary = true;

    public function __construct(string $name, MailServerDirection $direction, string $host, int $port)
    {
        $this->name = trim($name);
        $this->direction = $direction;
        $this->host = trim($host);
        $this->port = max(1, $port);
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getName(): string
    {
        return $this->name;
    }

    public function rename(string $name): self
    {
        $this->name = trim($name);

        return $this;
    }

    public function getDirection(): MailServerDirection
    {
        return $this->direction;
    }

    public function setDirection(MailServerDirection $direction): self
    {
        $this->direction = $direction;

        return $this;
    }

    public function supportsIncoming(): bool
    {
        return $this->direction->supportsIncoming();
    }

    public function supportsOutgoing(): bool
    {
        return $this->direction->supportsOutgoing();
    }

    public function getTransportType(): string
    {
        return $this->transportType;
    }

    public function setTransportType(string $transportType): self
    {
        $normalized = mb_strtolower(trim($transportType));
        $this->transportType = '' !== $normalized ? $normalized : 'smtp';

        return $this;
    }

    public function getHost(): string
    {
        return $this->host;
    }

    public function setHost(string $host): self
    {
        $this->host = trim($host);

        return $this;
    }

    public function getPort(): int
    {
        return $this->port;
    }

    public function setPort(int $port): self
    {
        $this->port = max(1, $port);

        return $this;
    }

    public function getEncryption(): MailEncryption
    {
        return $this->encryption;
    }

    public function setEncryption(MailEncryption $encryption): self
    {
        $this->encryption = $encryption;

        return $this;
    }

    public function getUsername(): ?string
    {
        return $this->username;
    }

    public function setUsername(?string $username): self
    {
        $this->username = self::normalizeNullable($username);

        return $this;
    }

    public function getAuthenticationMode(): MailAuthenticationMode
    {
        return $this->authenticationMode;
    }

    public function setAuthenticationMode(MailAuthenticationMode $authenticationMode): self
    {
        $this->authenticationMode = $authenticationMode;

        return $this;
    }

    public function usesPasswordAuthentication(): bool
    {
        return MailAuthenticationMode::PASSWORD === $this->authenticationMode;
    }

    public function usesMicrosoftOAuth(): bool
    {
        return MailAuthenticationMode::MICROSOFT_OAUTH === $this->authenticationMode;
    }

    public function getPassword(): ?string
    {
        return $this->password;
    }

    public function setPassword(?string $password): self
    {
        $this->password = self::normalizeNullable($password);

        return $this;
    }

    public function getOauthTenantId(): ?string
    {
        return $this->oauthTenantId;
    }

    public function setOauthTenantId(?string $oauthTenantId): self
    {
        $this->oauthTenantId = self::normalizeNullable($oauthTenantId);

        return $this;
    }

    public function getOauthClientId(): ?string
    {
        return $this->oauthClientId;
    }

    public function setOauthClientId(?string $oauthClientId): self
    {
        $this->oauthClientId = self::normalizeNullable($oauthClientId);

        return $this;
    }

    public function getOauthClientSecret(): ?string
    {
        return $this->oauthClientSecret;
    }

    public function setOauthClientSecret(?string $oauthClientSecret): self
    {
        $this->oauthClientSecret = self::normalizeNullable($oauthClientSecret);

        return $this;
    }

    public function getFromAddress(): ?string
    {
        return $this->fromAddress;
    }

    public function setFromAddress(?string $fromAddress): self
    {
        $normalized = self::normalizeNullable($fromAddress);
        $this->fromAddress = null !== $normalized ? mb_strtolower($normalized) : null;

        return $this;
    }

    public function getFromName(): ?string
    {
        return $this->fromName;
    }

    public function setFromName(?string $fromName): self
    {
        $this->fromName = self::normalizeNullable($fromName);

        return $this;
    }

    public function getDescription(): ?string
    {
        return $this->description;
    }

    public function setDescription(?string $description): self
    {
        $this->description = self::normalizeNullable($description);

        return $this;
    }

    public function isActive(): bool
    {
        return $this->isActive;
    }

    public function activate(): self
    {
        $this->isActive = true;

        return $this;
    }

    public function deactivate(): self
    {
        $this->isActive = false;

        return $this;
    }

    public function isPrimaryOutbound(): bool
    {
        return $this->isPrimaryOutbound;
    }

    public function setPrimaryOutbound(bool $primaryOutbound): self
    {
        $this->isPrimaryOutbound = $primaryOutbound;

        return $this;
    }

    public function fallbackToPrimary(): bool
    {
        return $this->fallbackToPrimary;
    }

    public function isFallbackToPrimary(): bool
    {
        return $this->fallbackToPrimary();
    }

    public function setFallbackToPrimary(bool $fallbackToPrimary): self
    {
        $this->fallbackToPrimary = $fallbackToPrimary;

        return $this;
    }

    private static function normalizeNullable(?string $value): ?string
    {
        if (null === $value) {
            return null;
        }

        $trimmed = trim($value);

        return '' !== $trimmed ? $trimmed : null;
    }
}
