<?php

declare(strict_types=1);

namespace App\Module\Mail\Entity;

use App\Module\Identity\Entity\Company;
use App\Module\Identity\Entity\User;
use App\Module\Mail\Enum\IncomingMailProcessingResult;
use App\Module\Shared\Entity\TimestampableTrait;
use App\Module\Ticket\Entity\Ticket;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity]
#[ORM\Table(name: 'incoming_mails')]
#[ORM\HasLifecycleCallbacks]
class IncomingMail
{
    use TimestampableTrait;

    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\ManyToOne]
    #[ORM\JoinColumn(onDelete: 'SET NULL', nullable: true)]
    private ?SupportMailbox $mailbox = null;

    #[ORM\Column(length: 180)]
    private string $fromEmail;

    #[ORM\Column(length: 180, nullable: true)]
    private ?string $fromName = null;

    #[ORM\Column(length: 255)]
    private string $subject;

    #[ORM\Column(type: 'text')]
    private string $body;

    /**
     * @var list<array{displayName: string, mimeType: ?string, fileSize: int, filePath: string, contentHash?: string}>
     */
    #[ORM\Column(type: 'json', options: ['default' => '[]'])]
    private array $attachmentMetadata = [];

    #[ORM\ManyToOne]
    #[ORM\JoinColumn(onDelete: 'SET NULL', nullable: true)]
    private ?User $matchedUser = null;

    #[ORM\ManyToOne]
    #[ORM\JoinColumn(onDelete: 'SET NULL', nullable: true)]
    private ?Company $matchedCompany = null;

    #[ORM\ManyToOne]
    #[ORM\JoinColumn(onDelete: 'SET NULL', nullable: true)]
    private ?Ticket $matchedTicket = null;

    #[ORM\Column(enumType: IncomingMailProcessingResult::class, nullable: true)]
    private ?IncomingMailProcessingResult $processingResult = null;

    #[ORM\Column(length: 255, nullable: true)]
    private ?string $processingNote = null;

    #[ORM\Column(nullable: true)]
    private ?\DateTimeImmutable $processedAt = null;

    public function __construct(string $fromEmail, string $subject, string $body)
    {
        $this->fromEmail = mb_strtolower(trim($fromEmail));
        $this->subject = trim($subject);
        $this->body = trim($body);
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getMailbox(): ?SupportMailbox
    {
        return $this->mailbox;
    }

    public function setMailbox(?SupportMailbox $mailbox): self
    {
        $this->mailbox = $mailbox;

        return $this;
    }

    public function getFromEmail(): string
    {
        return $this->fromEmail;
    }

    public function getFromName(): ?string
    {
        return $this->fromName;
    }

    public function setFromName(?string $fromName): self
    {
        if (null === $fromName) {
            $this->fromName = null;

            return $this;
        }

        $trimmed = trim($fromName);
        $this->fromName = '' !== $trimmed ? $trimmed : null;

        return $this;
    }

    public function getSubject(): string
    {
        return $this->subject;
    }

    public function getBody(): string
    {
        return $this->body;
    }

    /**
     * @return list<array{displayName: string, mimeType: ?string, fileSize: int, filePath: string, contentHash?: string}>
     */
    public function getAttachmentMetadata(): array
    {
        return $this->attachmentMetadata;
    }

    /**
     * @param list<array{displayName: string, mimeType: ?string, fileSize: int, filePath: string, contentHash?: string}> $attachmentMetadata
     */
    public function setAttachmentMetadata(array $attachmentMetadata): self
    {
        $this->attachmentMetadata = array_values($attachmentMetadata);

        return $this;
    }

    public function getMatchedUser(): ?User
    {
        return $this->matchedUser;
    }

    public function setMatchedUser(?User $matchedUser): self
    {
        $this->matchedUser = $matchedUser;

        return $this;
    }

    public function getMatchedCompany(): ?Company
    {
        return $this->matchedCompany;
    }

    public function setMatchedCompany(?Company $matchedCompany): self
    {
        $this->matchedCompany = $matchedCompany;

        return $this;
    }

    public function getMatchedTicket(): ?Ticket
    {
        return $this->matchedTicket;
    }

    public function setMatchedTicket(?Ticket $matchedTicket): self
    {
        $this->matchedTicket = $matchedTicket;

        return $this;
    }

    public function getProcessingResult(): ?IncomingMailProcessingResult
    {
        return $this->processingResult;
    }

    public function getProcessingNote(): ?string
    {
        return $this->processingNote;
    }

    public function getProcessedAt(): ?\DateTimeImmutable
    {
        return $this->processedAt;
    }

    public function markProcessed(IncomingMailProcessingResult $processingResult, string $processingNote): self
    {
        $this->processingResult = $processingResult;
        $this->processingNote = trim($processingNote);
        $this->processedAt = new \DateTimeImmutable();

        return $this;
    }
}
