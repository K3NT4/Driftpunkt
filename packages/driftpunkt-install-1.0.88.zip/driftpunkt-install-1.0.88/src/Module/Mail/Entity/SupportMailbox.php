<?php

declare(strict_types=1);

namespace App\Module\Mail\Entity;

use App\Module\Identity\Entity\Company;
use App\Module\Identity\Entity\TechnicianTeam;
use App\Module\Shared\Entity\TimestampableTrait;
use App\Module\Ticket\Entity\TicketCategory;
use App\Module\Ticket\Enum\TicketPriority;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity]
#[ORM\Table(name: 'support_mailboxes')]
#[ORM\HasLifecycleCallbacks]
class SupportMailbox
{
    use TimestampableTrait;

    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 180, unique: true)]
    private string $name;

    #[ORM\Column(length: 180, unique: true)]
    private string $emailAddress;

    #[ORM\ManyToOne]
    #[ORM\JoinColumn(onDelete: 'SET NULL', nullable: true)]
    private ?Company $company = null;

    #[ORM\ManyToOne]
    #[ORM\JoinColumn(onDelete: 'SET NULL', nullable: true)]
    private ?MailServer $incomingServer = null;

    #[ORM\ManyToOne]
    #[ORM\JoinColumn(onDelete: 'SET NULL', nullable: true)]
    private ?TicketCategory $defaultCategory = null;

    #[ORM\Column(enumType: TicketPriority::class, nullable: true)]
    private ?TicketPriority $defaultPriority = null;

    #[ORM\ManyToOne]
    #[ORM\JoinColumn(onDelete: 'SET NULL', nullable: true)]
    private ?TechnicianTeam $defaultTeam = null;

    #[ORM\Column]
    private int $pollingIntervalMinutes = 5;

    #[ORM\Column]
    private bool $allowUnknownSenders = true;

    #[ORM\Column]
    private bool $createDraftTicketsForUnknownSenders = true;

    #[ORM\Column]
    private bool $allowAttachments = true;

    #[ORM\Column]
    private bool $isActive = true;

    #[ORM\Column(nullable: true)]
    private ?\DateTimeImmutable $lastPolledAt = null;

    public function __construct(string $name, string $emailAddress)
    {
        $this->name = trim($name);
        $this->emailAddress = mb_strtolower(trim($emailAddress));
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getName(): string
    {
        return $this->name;
    }

    public function rename(string $name): self
    {
        $this->name = trim($name);

        return $this;
    }

    public function getEmailAddress(): string
    {
        return $this->emailAddress;
    }

    public function setEmailAddress(string $emailAddress): self
    {
        $this->emailAddress = mb_strtolower(trim($emailAddress));

        return $this;
    }

    public function getCompany(): ?Company
    {
        return $this->company;
    }

    public function setCompany(?Company $company): self
    {
        $this->company = $company;

        return $this;
    }

    public function getIncomingServer(): ?MailServer
    {
        return $this->incomingServer;
    }

    public function setIncomingServer(?MailServer $incomingServer): self
    {
        $this->incomingServer = $incomingServer;

        return $this;
    }

    public function getDefaultCategory(): ?TicketCategory
    {
        return $this->defaultCategory;
    }

    public function setDefaultCategory(?TicketCategory $defaultCategory): self
    {
        $this->defaultCategory = $defaultCategory;

        return $this;
    }

    public function getDefaultPriority(): ?TicketPriority
    {
        return $this->defaultPriority;
    }

    public function setDefaultPriority(?TicketPriority $defaultPriority): self
    {
        $this->defaultPriority = $defaultPriority;

        return $this;
    }

    public function getDefaultTeam(): ?TechnicianTeam
    {
        return $this->defaultTeam;
    }

    public function setDefaultTeam(?TechnicianTeam $defaultTeam): self
    {
        $this->defaultTeam = $defaultTeam;

        return $this;
    }

    public function getPollingIntervalMinutes(): int
    {
        return $this->pollingIntervalMinutes;
    }

    public function setPollingIntervalMinutes(int $pollingIntervalMinutes): self
    {
        $this->pollingIntervalMinutes = max(1, $pollingIntervalMinutes);

        return $this;
    }

    public function allowsUnknownSenders(): bool
    {
        return $this->allowUnknownSenders;
    }

    public function isAllowUnknownSenders(): bool
    {
        return $this->allowsUnknownSenders();
    }

    public function setAllowUnknownSenders(bool $allowUnknownSenders): self
    {
        $this->allowUnknownSenders = $allowUnknownSenders;

        return $this;
    }

    public function createsDraftTicketsForUnknownSenders(): bool
    {
        return $this->createDraftTicketsForUnknownSenders;
    }

    public function isCreateDraftTicketsForUnknownSenders(): bool
    {
        return $this->createsDraftTicketsForUnknownSenders();
    }

    public function setCreateDraftTicketsForUnknownSenders(bool $createDraftTicketsForUnknownSenders): self
    {
        $this->createDraftTicketsForUnknownSenders = $createDraftTicketsForUnknownSenders;

        return $this;
    }

    public function allowsAttachments(): bool
    {
        return $this->allowAttachments;
    }

    public function isAllowAttachments(): bool
    {
        return $this->allowsAttachments();
    }

    public function setAllowAttachments(bool $allowAttachments): self
    {
        $this->allowAttachments = $allowAttachments;

        return $this;
    }

    public function isActive(): bool
    {
        return $this->isActive;
    }

    public function activate(): self
    {
        $this->isActive = true;

        return $this;
    }

    public function deactivate(): self
    {
        $this->isActive = false;

        return $this;
    }

    public function getLastPolledAt(): ?\DateTimeImmutable
    {
        return $this->lastPolledAt;
    }

    public function markPolledNow(): self
    {
        $this->lastPolledAt = new \DateTimeImmutable();

        return $this;
    }
}
