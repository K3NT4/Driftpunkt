<?php

declare(strict_types=1);

namespace App\Module\Identity\Security;

use App\Module\Identity\Entity\User;
use App\Module\Identity\Service\MfaPolicyResolver;
use App\Module\Identity\Service\MfaSessionManager;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Generator\UrlGeneratorInterface;
use Symfony\Component\Security\Core\Authentication\Token\TokenInterface;
use Symfony\Component\Security\Http\Authentication\AuthenticationSuccessHandlerInterface;
use Symfony\Component\Security\Http\Util\TargetPathTrait;

final class LoginSuccessHandler implements AuthenticationSuccessHandlerInterface
{
    use TargetPathTrait;

    public function __construct(
        private readonly UrlGeneratorInterface $urlGenerator,
        private readonly MfaPolicyResolver $mfaPolicyResolver,
        private readonly MfaSessionManager $mfaSessionManager,
        private readonly LoginRoleTargetResolver $loginRoleTargetResolver,
    ) {
    }

    public function onAuthenticationSuccess(Request $request, TokenInterface $token): ?Response
    {
        $user = $token->getUser();
        if (!$user instanceof User) {
            return new RedirectResponse($this->urlGenerator->generate('app_portal_entry'));
        }

        $targetPath = null;
        if ($request->hasSession()) {
            $session = $request->getSession();
            $targetPath = $this->getTargetPath($session, 'main');
            $this->removeTargetPath($session, 'main');
            $this->mfaSessionManager->clear($session);
        }

        $targetPath = $this->targetPathAllowedForUser($targetPath, $user) ? $targetPath : null;
        $loginRoleTargetUrl = $this->loginRoleTargetResolver->resolveTargetUrl($user, $request->query->getString('role'));

        if ($this->mfaPolicyResolver->requiresMfa($user)) {
            if ($request->hasSession()) {
                $this->saveTargetPath($request->getSession(), 'main', $targetPath ?? $loginRoleTargetUrl ?? $this->urlGenerator->generate('app_portal_entry'));
            }

            return new RedirectResponse($this->urlGenerator->generate('app_mfa_challenge'));
        }

        if ($request->hasSession()) {
            $this->mfaSessionManager->markVerified($request->getSession(), $user);
        }

        if ($user->isPasswordChangeRequired()) {
            return new RedirectResponse($this->urlGenerator->generate('app_portal_security'));
        }

        return new RedirectResponse($targetPath ?? $loginRoleTargetUrl ?? $this->urlGenerator->generate('app_portal_entry'));
    }

    private function targetPathAllowedForUser(?string $targetPath, User $user): bool
    {
        if (null === $targetPath || '' === trim($targetPath)) {
            return false;
        }

        $path = (string) parse_url($targetPath, \PHP_URL_PATH);
        if ('' === $path) {
            return false;
        }

        $roles = $user->getRoles();

        return match (true) {
            str_starts_with($path, '/portal/admin') => \in_array('ROLE_ADMIN', $roles, true),
            str_starts_with($path, '/portal/koordinator') => \in_array('ROLE_TICKET_COORDINATOR', $roles, true),
            str_starts_with($path, '/portal/technician/inventarie') => \in_array('ROLE_TECHNICIAN', $roles, true) || \in_array('ROLE_TICKET_COORDINATOR', $roles, true),
            str_starts_with($path, '/portal/technician') => \in_array('ROLE_TECHNICIAN', $roles, true),
            str_starts_with($path, '/portal/customer') => \in_array('ROLE_CUSTOMER', $roles, true),
            str_starts_with($path, '/portal') => \in_array('ROLE_USER', $roles, true),
            default => true,
        };
    }
}
