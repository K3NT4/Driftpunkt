<?php

declare(strict_types=1);

namespace App\Command;

use App\Module\Mail\Entity\IncomingMail;
use App\Module\Mail\Entity\SupportMailbox;
use App\Module\Mail\Service\EmailMimeParser;
use App\Module\Mail\Service\ImapMailboxFetcher;
use App\Module\Mail\Service\IncomingMailAttachmentStorage;
use App\Module\Mail\Service\IncomingMailProcessor;
use App\Module\Mail\Service\IncomingMailSpoolReader;
use Doctrine\ORM\EntityManagerInterface;
use Psr\Log\LoggerInterface;
use Symfony\Component\Console\Attribute\AsCommand;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Style\SymfonyStyle;

#[AsCommand(
    name: 'app:mail:poll',
    description: 'Hämtar aktiva supportinkorgar från kömappar och importerar köade e-postmeddelanden.',
)]
final class PollSupportMailboxesCommand extends Command
{
    public function __construct(
        private readonly EntityManagerInterface $entityManager,
        private readonly IncomingMailSpoolReader $incomingMailSpoolReader,
        private readonly ImapMailboxFetcher $imapMailboxFetcher,
        private readonly EmailMimeParser $emailMimeParser,
        private readonly IncomingMailAttachmentStorage $incomingMailAttachmentStorage,
        private readonly IncomingMailProcessor $incomingMailProcessor,
        private readonly LoggerInterface $logger,
    ) {
        parent::__construct();
    }

    protected function configure(): void
    {
        $this->addOption('mailbox', null, InputOption::VALUE_REQUIRED, 'Begränsa hämtningen till en inkorg via e-postadress eller namn.');
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $io = new SymfonyStyle($input, $output);
        $mailboxFilter = trim((string) $input->getOption('mailbox'));

        /** @var list<SupportMailbox> $mailboxes */
        $mailboxes = $this->entityManager->getRepository(SupportMailbox::class)->findBy(['isActive' => true], ['id' => 'ASC']);
        if ('' !== $mailboxFilter) {
            $mailboxes = array_values(array_filter($mailboxes, static fn (SupportMailbox $mailbox): bool => $mailbox->getEmailAddress() === mb_strtolower($mailboxFilter) || $mailbox->getName() === $mailboxFilter));
        }

        $polledMailboxes = 0;
        $processedMessages = 0;
        $failedMailboxes = 0;

        foreach ($mailboxes as $mailbox) {
            ++$polledMailboxes;
            try {
                if ($this->imapMailboxFetcher->supports($mailbox)) {
                    foreach ($this->imapMailboxFetcher->fetchPendingMessages($mailbox) as $message) {
                        $incomingMail = $this->createIncomingMailFromPayload($mailbox, $message);
                        $this->incomingMailProcessor->process($incomingMail);
                        $this->imapMailboxFetcher->acknowledge($mailbox, $message['remote_id']);
                        ++$processedMessages;
                    }
                }

                foreach ($this->incomingMailSpoolReader->readPendingMessages($mailbox) as $message) {
                    $incomingMail = $this->createIncomingMailFromPayload($mailbox, $message);
                    $this->incomingMailProcessor->process($incomingMail);
                    $this->incomingMailSpoolReader->acknowledge($mailbox, $message['path']);
                    ++$processedMessages;
                }

                $mailbox->markPolledNow();
                $this->entityManager->flush();
            } catch (\Throwable $exception) {
                ++$failedMailboxes;
                $this->logger->error('E-posthämtning misslyckades för inkorg.', [
                    'mailbox_id' => $mailbox->getId(),
                    'mailbox_email' => $mailbox->getEmailAddress(),
                    'mailbox_name' => $mailbox->getName(),
                    'exception' => $exception,
                ]);
                $io->warning(sprintf('Hämtning misslyckades för "%s": %s', $mailbox->getEmailAddress(), $exception->getMessage()));
            }
        }

        $io->success(sprintf(
            'Hämtning klar för %d inkorgar. %d e-postmeddelanden importerades. %d inkorgar gav fel.',
            $polledMailboxes,
            $processedMessages,
            $failedMailboxes,
        ));

        return $failedMailboxes > 0 ? Command::FAILURE : Command::SUCCESS;
    }

    /**
     * @param array{
     *     from?: string,
     *     from_name?: ?string,
     *     subject?: string,
     *     body?: string,
     *     raw_message?: ?string,
     *     attachments?: list<array{displayName: string, mimeType: ?string, content: string}>
     * } $message
     */
    private function createIncomingMailFromPayload(SupportMailbox $mailbox, array $message): IncomingMail
    {
        $attachments = $message['attachments'] ?? [];
        $rawMessage = trim((string) ($message['raw_message'] ?? ''));

        if ('' !== $rawMessage) {
            $parsedMessage = $this->emailMimeParser->parse($rawMessage);
            $message['from'] = $parsedMessage['from'];
            $message['from_name'] = $parsedMessage['from_name'];
            $message['subject'] = $parsedMessage['subject'];
            $message['body'] = $parsedMessage['body'];
            $attachments = $parsedMessage['attachments'];
        }

        $incomingMail = new IncomingMail(
            trim((string) ($message['from'] ?? '')),
            trim((string) ($message['subject'] ?? '')),
            trim((string) ($message['body'] ?? '')),
        );
        $incomingMail
            ->setMailbox($mailbox)
            ->setFromName(\is_string($message['from_name'] ?? null) ? $message['from_name'] : null);

        $this->entityManager->persist($incomingMail);
        $this->entityManager->flush();

        if ($mailbox->allowsAttachments() && [] !== $attachments) {
            $incomingMail->setAttachmentMetadata(
                $this->incomingMailAttachmentStorage->storeIncomingMailAttachments($incomingMail, $attachments),
            );
            $this->entityManager->flush();
        }

        return $incomingMail;
    }
}
