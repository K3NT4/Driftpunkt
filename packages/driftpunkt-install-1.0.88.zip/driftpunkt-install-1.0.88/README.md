# Driftpunkt

<p align="center">
  <img src="docs/public-assets/branding/logo-wide.png" alt="Driftpunkt" width="520">
</p>

<p align="center">
  Symfony-baserat ticketsystem för drift, support och kunddialog.
</p>

Driftpunkt är ett Symfony-baserat support- och driftsystem med publik webb, kundportal, teknikerportal och adminyta i samma produkt.

README:n beskriver nuläget i koden i detta repo, version 1.0.88: fungerande MVP-flöden för ticketing, kunddialog, e-postingest, kundstyrda inventarielistor, SharePoint/CSV-import med skuggpersoner, driftstatus, kundanpassad rapportering, administration, loggcenter, språkstyrning, flerteam-stöd för intern personal, tekniker- och koordinatoranpassning och release/driftarbete. Miljöspecifika integrationer och viss intern driftsetup kan fortfarande leva utanför repo eller exportflöde.

## Nytt i 1.0.88

- Ärendebeskrivningar i teknikeröversikten, kundportalens ärendelista och ärendekoordinatorns utförliga ärendekort begränsas till en kort, enhetlig förhandsvisning.
- Förhandsvisningen normaliserar radbrytningar och överflödiga blanksteg, kapas vid ett helt ord när det är möjligt och avslutas med ellips.
- Den fullständiga ärendebeskrivningen visas fortfarande oförändrad inne i ärendets detaljvy.
- Inga nya databasmigrationer krävs jämfört med 1.0.87.
- Cache refresh och PHP/OPcache-reload rekommenderas efter applicerad uppdatering.

## Nytt i 1.0.87

- Ärendekoordinatorns aktiva ärendelistor sorteras konsekvent med senast skapade ärende först, även när äldre ärenden har högre riskpoäng eller prioritet.
- Riskmarkeringar, uppföljningspanel och riskfilter finns kvar utan att påverka den kronologiska listordningen.
- SLA-menyer, filtret `SLA-risk`, `Försenade` och tillhörande SLA-fält visas bara när SLA är aktiverat och faktiskt konfigurerat eller används av ett aktivt ärende.
- Filtret `Mina team` visas bara för ärendekoordinatorer som tillhör minst ett primärt eller extra team.
- Ärendekoordinatorn kan skicka kundsvar med mejl, lägga kundsynliga kommentarer utan mejl och skriva interna anteckningar före eller efter teknikertilldelning.
- Intern anteckning är fortsatt förvald, och kunddialog blockeras för avslutade, interna och kundlösa ärenden både i gränssnittet och server-side.
- Koordinatorflödet har regressionstest för sortering, paginering, kundmejl, statusändring, synlighet, auditlogg och manipulerade formuläranrop.
- Inga nya databasmigrationer krävs jämfört med 1.0.86.
- Cache refresh och PHP/OPcache-reload rekommenderas efter applicerad uppdatering.

## Nytt i 1.0.86

- Inkommande e-post rensar Outlook-signaturer och kampanjfotrar bättre innan ärendetexten sparas.
- Signaturloggor som ligger som inlinebilder i e-post importeras inte längre som ärendebilagor.
- Kund-, tekniker-, koordinator- och lösenordsåterställningsmail använder nu tabellbaserade HTML-mallar med Outlook-säkra knappar.
- Inga nya databasmigrationer krävs jämfört med 1.0.85.
- Cache refresh och PHP/OPcache-reload rekommenderas efter applicerad uppdatering.

## Nytt i 1.0.85

- Allmän triage-epost fungerar nu som aktivt huvudläge och inaktiverar mottagarlistan visuellt i admin.
- När allmän triage-epost sparas rensas personliga triagemottagare så nya notiser bara går till den delade inkorgen.
- Triage-notiser till den allmänna adressen fortsätter använda vanlig koordinatorlänk som kräver inloggning med eget ärendekoordinatorkonto.
- Inga nya databasmigrationer krävs jämfört med 1.0.84.
- Cache refresh och PHP/OPcache-reload rekommenderas efter applicerad uppdatering.

## Nytt i 1.0.84

- Admin kan ange en allmän triage-epost för delad koordinatorinkorg.
- När allmän triage-epost är ifylld inaktiveras den personliga mottagarlistan.
- Triage-notiser till den allmänna adressen innehåller en vanlig koordinatorlänk som kräver inloggning med eget ärendekoordinatorkonto.
- Personliga triagemottagare behåller personliga inloggningslänkar, medan fallback till aktiva ärendekoordinatorer bara används när varken mottagare eller allmän adress är vald.
- Notifieringsloggen visar utskick till den allmänna triage-adressen utan att knyta dem till en enskild användare.
- Inga nya databasmigrationer krävs jämfört med 1.0.83.
- Cache refresh och PHP/OPcache-reload rekommenderas efter applicerad uppdatering.

## Nytt i 1.0.83

- Koordinatorns formulär för nytt ärende visar `Nytt ärende` i stället för telefonärende-texter.
- Överflödiga hjälprader i koordinatorns nytt ärende-formulär är borttagna.
- Skapa-knappen i koordinatorns nytt ärende-formulär heter nu `Skapa och tilldela ärende`.
- Koordinatorns ärendedetalj visar kommentarer med senaste kommentaren överst.
- Inga nya databasmigrationer krävs jämfört med 1.0.82.
- Cache refresh och PHP/OPcache-reload rekommenderas efter applicerad uppdatering.

## Nytt i 1.0.82

- Företagsfiltret i koordinatorns öppna ärenden behåller aktuell kö när ett företag väljs.
- Företagsdropdownen i avslutade koordinatorärenden visas ovanpå sidopanelen i stället för bakom den.
- Startsidan och inloggningssidan har renare toppbar utan extra navigationsknappar.
- Inga nya databasmigrationer krävs jämfört med 1.0.81.
- Cache refresh och PHP/OPcache-reload rekommenderas efter applicerad uppdatering.

## Nytt i 1.0.81

- Ärendekoordinatorns topbar visar inte längre `Startsida` i koordinatorvyer.
- Ärendedetaljen för koordinatorn använder rubriken `Ärendebeskrivning`, mindre beskrivningstext och visar inte längre hjälpraden under rubriken.
- Koordinatorns ärendedetalj döljer ålders- och inaktivitetschippar som `Ingen aktivitet X dagar` och `Gammalt X dagar`.
- Företagsfiltret i öppna och avslutade koordinatorärenden använder samma sökbara företagsväljare som nytt ärende.
- Startsidan och inloggningssidan har renare toppbar utan extra navigationsknappar.
- Inga nya databasmigrationer krävs jämfört med 1.0.80.
- Cache refresh och PHP/OPcache-reload rekommenderas efter applicerad uppdatering.

## Nytt i 1.0.80

- Ärendekoordinatorns meny visar nu `Nytt ärende` i stället för `Nytt telefonärende`.
- Länken till nytt ärende finns kvar i koordinatorns sidomeny även från andra koordinatorvyer som guide, rapporter, företagsdata och inställningar.
- Formuläret för nytt telefonärende är renare: överflödiga hjälprader och knappen `Föreslå tekniker` är borttagna.
- Prioritet visas alltid direkt i formuläret i stället för att ligga under `Fler inställningar`.
- Kundsektionen använder tydligare rubriker: `Företag/Kund` och `Kundkontakt`.
- Inga nya databasmigrationer krävs jämfört med 1.0.79.
- Cache refresh och PHP/OPcache-reload rekommenderas efter applicerad uppdatering.

## Nytt i 1.0.79

- Superadmin kan styra om kundinloggningen ska visa rutan `Sök hjälp först`; den är avstängd som standard även när den publika kunskapsbasen är aktiv.
- Superadmin kan visa eller dölja startsidans `Behöver du hjälp?`-ruta utan att ändra hjälplänkarna som kontaktsidan använder.
- Superadmin kan visa eller dölja startsidans `Systemstatus`-ruta utan att påverka driftstatussidan eller monitorerna.
- Startsidan hanterar kombinationer där nyheter, hjälpruta och systemstatus visas eller döljs utan tomma layoutytor.
- Inga nya databasmigrationer krävs jämfört med 1.0.78.
- Cache refresh och PHP/OPcache-reload rekommenderas efter applicerad uppdatering.

## Nytt i 1.0.78

- Ärendekoordinatorns "Behöver åtgärd" är förenklat till samma arbetskö som ej tilldelade ärenden och visas som `Ej tilldelade ärenden`.
- Koordinatorns sidomeny är renare: `Översikt` visas inte längre och `Mina team` är borttaget från koordinatorns filterval.
- Signalraden under varje koordinatorärende är avstängd som standard och kan slås på i koordinatorns portalinställningar.
- `SLA-risk` och `Försenade` döljs konsekvent i koordinatorvyer när SLA inte används.
- Direkta gamla länkar till `scope=needs_attention`, `scope=sla_risk`, `scope=overdue` och `scope=my_teams` hanteras fortsatt utan att bredda startsidans standardkö.
- Inga nya databasmigrationer krävs jämfört med 1.0.77.
- Cache refresh och PHP/OPcache-reload rekommenderas efter applicerad uppdatering.

## Nytt i 1.0.77

- Ärendekoordinatorns startsida är förenklad och visar ej tilldelade ärenden som standard.
- Koordinatorsökningen söker i alla öppna ärenden när man söker utan explicit filter, samtidigt som ett valt filter fortfarande respekteras.
- Den dubblerande knappraden och den långa introduktionstexten är borttagna från koordinatorns vanliga startsida.
- Koordinatorns arbetsfilter visas som `Öppna ärenden` där knappen och menyn används, utan att ändra den interna statusen `Under arbete`.
- Inga nya databasmigrationer krävs jämfört med 1.0.76.
- Cache refresh och PHP/OPcache-reload rekommenderas efter applicerad uppdatering.

## Nytt i 1.0.76

- Releasepaketen är ombyggda från den verifierade 1.0.75-kodbasen med ny versionsmetadata för `1.0.76`.
- NAS/Docker-dokumentationen för adminuppdateringar är förtydligad: köade koduppdateringar måste plockas upp av en worker eller köras manuellt med `app:code-update:apply-run`.
- Driftstegen beskriver hur `var/` och loggfiler ägarrättas till `www-data` när en Docker-baserad testserver stoppar på skrivbehörighet i `var/log`.
- Adminytan, Composer-metadata, zip-filnamn och paketens `release-metadata.json` pekar på samma aktuella versionsnummer.
- Uppgraderingspaketet är fortsatt kumulativt och kan användas direkt från äldre Driftpunkt 1.x-installationer.
- Inga nya databasmigrationer krävs jämfört med 1.0.75.
- Cache refresh och PHP/OPcache-reload rekommenderas efter applicerad uppdatering.

## Nytt i 1.0.75

- Symfony-beroendena är uppgraderade från 8.0-serien till Symfony 8.1.
- Twig, Symfony Flex och relaterade Composer-beroenden är uppdaterade i låsfilen för den nya Symfony-versionen.
- Symfony-konfigurationsreferensen är uppdaterad för 8.1 så lokala config-kontroller matchar installerade paket.
- Testsviten är anpassad till Symfony 8.1:s aktuella testklient- och response-beteende.
- Inga nya databasmigrationer krävs jämfört med 1.0.74.
- Cache refresh och PHP/OPcache-reload rekommenderas efter applicerad uppdatering.

## Nytt i 1.0.74

- Kundunika utgående mailprofiler ärvs nu via företagshierarkin, så underbolag utan egen profil använder närmaste huvudbolags aktiva mailprofil.
- Inkommande inkorgar visar tydligare när valt företag fungerar som huvudbolag och hur många underbolag som omfattas av samma inkorgsstandard.
- Kända avsändare som mailar en huvudbolagsinkorg skapar fortsatt ärenden på avsändarens faktiska underbolag, medan okända avsändare får huvudbolaget som standard i utkastgranskningen.
- Mailadmin visar nu `Företag / huvudbolag` och `Gäller även X underbolag` för både inkorgar och utgående profiler.
- Inga nya databasmigrationer krävs jämfört med 1.0.73.
- Cache refresh och PHP/OPcache-reload rekommenderas efter applicerad uppdatering.

## Nytt i 1.0.73

- Releasepaketen är ombyggda från den verifierade 1.0.72-kodbasen med ny versionsmetadata för `1.0.73`.
- Adminytan, Composer-metadata, zip-filnamn och paketens `release-metadata.json` pekar nu på samma aktuella versionsnummer.
- Koordinatorns formulär för nytt telefonärende initierar nu kund- och företagssökningen efter att formuläret har renderats, så förslagslistorna visas precis som i teknikervyn.
- Uppgraderingspaketet är fortsatt kumulativt och kan användas direkt från äldre Driftpunkt 1.x-installationer.
- Inga nya databasmigrationer krävs jämfört med 1.0.72.
- Cache refresh och PHP/OPcache-reload rekommenderas efter applicerad uppdatering.

## Nytt i 1.0.72

- Kundväljare visar nu namn, e-post och företagskontext med moder-/dotterbolag där det behövs för att skilja liknande kundnamn åt.
- Samma tydligare etiketter används när tekniker skapar ärenden, admin byter beställare, koordinator skapar telefonärenden, mailutkast godkänns och skuggpersoner kopplas.
- Skuggpersoner kan fortsatt kopplas via den synliga kundetiketten och har regressionstest för kunder i dotterbolag.
- Adminytans användarformulär gör skillnaden tydligare mellan `Kund (företag krävs)` och `Privatkund (utan företag)`.
- Inga nya databasmigrationer krävs jämfört med 1.0.71.
- Cache refresh och PHP/OPcache-reload rekommenderas efter applicerad uppdatering.

## Nytt i 1.0.71

- Rich text-editorn har fått en tydlig `Normal text`-knapp som bryter ut ur rubriker, citat, listor, kodblock och färgmarkeringar utan att användaren behöver rensa hela kommentaren.
- När text är markerad kan `Normal text` rensa bara den markerade formateringen och återgå till vanliga stycken.
- Vanliga tekniker kan inte längre skriva över ärendesammanfattningen från snabbformulären när de uppdaterar status eller lösning.
- Tekniker ser sammanfattningen som läsbar rich text, medan admin fortsatt kan redigera sammanfattningen i samma vy.
- Symfony- och Twig-beroenden är uppdaterade till patchade versioner efter Composer audit för nya advisories i `symfony/http-foundation`, `symfony/routing`, `symfony/security-http` och `twig/twig`.
- Testskyddet täcker kundens rich text-editor, teknikers skyddade sammanfattning, adminredigering och berörda status-/bilageflöden.
- Inga nya databasmigrationer krävs jämfört med 1.0.70.

## Nytt i 1.0.70

- Releasepaketen är ombyggda från den verifierade 1.0.69-kodbasen med ny versionsmetadata för `1.0.70`.
- Adminytan och paketens `release-metadata.json` pekar nu på samma aktuella versionsnummer.
- `symfony/polyfill-intl-idn` är uppdaterad till patchad version efter Composer audit för CVE-2026-46644.
- SLA-reglaget i adminytan kan nu stängas av korrekt igen; avstängt läge bevaras i både formulärtext och checkbox efter sparning.
- Uppgraderingspaketet är fortsatt kumulativt och kan användas direkt från äldre Driftpunkt 1.x-installationer.
- Inga nya databasmigrationer krävs jämfört med 1.0.69.
- Cache refresh och PHP/OPcache-reload rekommenderas fortfarande efter applicerad uppdatering.

## Nytt i 1.0.69

- Teknikerns ärendedetalj visar nu ett fokuserat huvudformulär direkt med ämne, status, lösning, sammanfattning och primärknappen “Spara ärende”.
- Den konkurrerande “Spara status”-ytan är borttagen från detaljvyn; mer sällan använda fält finns kvar bakom “Visa fler fält”.
- Koordinatorns ärendevy prioriterar tilldelning, företag och påminn tekniker i sidokolumnen, medan historik och riskläge är dolda tills de behövs.
- Kommentarer ligger kvar synliga i koordinatorvyn, men historik/audit konkurrerar inte längre med den aktuella dialogen.
- Rich text-editorn ligger inte längre i ett label-element, så klick i kommentars- eller sammanfattningsfältet triggar inte Ångra av misstag.
- Citatformat i editorn går nu att stänga av igen, så användaren kan fortsätta skriva vanlig text efter ett citat.

## Nytt i 1.0.68

- Ärendesammanfattningar använder nu samma säkra rich text-flöde som kommentarer i kund-, tekniker- och adminflöden.
- Rich text-editorn har fått rubriker, checklistor, inline-kod, kodblock, ångra/gör om, tangentbordsgenvägar, statusmeddelanden och säkrare inklistring av ren text.
- Ärendelistor och dashboards visar sammanfattningar som ren text, medan detaljvyer visar tillåten formatering utan att läcka farlig HTML.
- Formatteringen sanerar nu rubriker, checklistor, kodblock, osäkra länkar, script/style och farliga attribut innan lagring.
- Testskyddet täcker formaterade ärendesammanfattningar från både kund- och teknikerflöden samt rich text-konvertering till plain text.

## Nytt i 1.0.67

- Inventarielistor validerar nu dubbletter tydligare: datorer per hostname och skrivare per IP-adress vid manuell registrering, uppdatering och CSV-import.
- Tekniker- och kundkommentarer har en rikare kommentarseditor med fet/kursiv text, listor, citat, länkar och säkra färgmarkeringar.
- Kommentarer saneras innan lagring och återges säkert i portal och e-post, samtidigt som textversioner av mail får läsbar plain text.
- Teknikeröversikten är lugnare som standard genom att avancerade snabbfilter, bulkåtgärder och sök/sort-paneler kan hållas dolda tills teknikern väljer dem.
- Symfony- och Twig-beroenden är uppdaterade till patchade versioner efter Composer audit.
- Testskyddet täcker inventariedubbletter, kommentarsanering och notifieringar med formaterade kommentarer.

## Nytt i 1.0.66

- Lösenordsåterställning använder nu användarens tilldelade företagsunika utgående mailprofil när en sådan finns.
- Användare utan tilldelad företagsprofil går vidare till global primär utgående e-postserver.
- Säkerhetsmail markeras inte längre som `Skickat` i produktion om systemet bara skulle använda `null://`-fallback; notifieringsloggen visar i stället ett tydligt konfigurationsfel.
- Testskyddet verifierar att produktionsläget stoppar null-fallback för kravställda säkerhetsmail.

## Nytt i 1.0.65

- Glömt lösenord-flödet skriver nu notifieringsloggar för `password_reset`, så det syns om säkerhetsmailet skickades, hoppades över eller misslyckades.
- Inaktiva och okända e-postadresser loggas utan att formuläret läcker om kontot finns.
- SMTP-/OAuth-fel vid lösenordsåterställning fångas i notifieringsloggen, vilket gör livefelsökning möjlig när ticket-mail fungerar men reset-mail saknas.
- Testskyddet verifierar både skickad lösenordsåterställning och okänd adress i notifieringsloggen.

## Nytt i 1.0.64

- Ärendekoordinatorer kan skapa telefonärenden från en fokuserad vy med rubrik, felbeskrivning, prioritet, kundnamn och ansvarig tekniker.
- Okända telefonkunder skapas som inaktiva ghost-kunder med intern `@no-mail.invalid`-adress, så ärendet får en riktig requester utan att kundmail skickas.
- Teknikerportalens “Att ta tag i nu”-kort radbryter långa sammanfattningar, kund-/företagsrader, taggar och knappar så korten håller sig inom sin panel.
- Testskyddet täcker telefonärenden med befintliga kunder, ghost-kunder, valideringsfel och teknikerportalens dashboardrendering.

## Nytt i 1.0.63

- Import / Export / Skuggpersoner byter nu ärendenummer på befintligt importerat ärende när en requester-skuggperson kopplas eller skapas mot ett företag som använder egen ärendeserie.
- Ärendet dupliceras inte vid flytten: ticket-id, historik, importerad person och kundkoppling bevaras, medan auditloggen visar gammalt och nytt ärendenummer.
- Företag utan egen ärendeserie behåller befintligt `DP-*`-nummer och tekniker-/ansvarigkopplingar påverkas inte.
- Avdelnings- och funktionskonton fortsätter att kunna skapas utan e-postadress; systemet genererar intern `@no-mail.invalid`-adress och stänger av kundnotiser.
- Offentlig export hoppar från 1.0.53 till 1.0.63 och inkluderar de samlade förbättringarna för interna ärendelänkar, kundåtkomst, inventarielistor, skuggpersoner, tekniker-/koordinatorvyer, statusmail och releasepaket.

## Nytt i 1.0.62

- Teknikeröversiktens valbara sidomoduler toppjusteras så statistik och andra paneler inte sträcks ut konstigt när de aktiveras.
- Statusen `Löst` skickar fortsatt kundens lösningsmail, medan `Stängd` nu är administrativ och skickar inget kundmail.
- Teknikerns ärendeåtgärder har en utfällbar förklaring av vad statusvalen betyder.
- Kundsynlig kommentar är nu standard i teknikerkommentarer; tekniker väljer aktivt `Kundsvar` när kommentaren ska mejlas till kunden.

## Nytt i 1.0.61

- Teknikerstartsidan är minimalare som standard med fyra klickbara nyckelrutor för aktiva ärenden, väntar på svar, försenade och totalt i teknikerns kö.
- Tekniker kan själva välja vilka extra moduler som visas på översikten, till exempel operativ cockpit, statistik, aktivitet, notifieringar, SLA-kö och uppföljningspanelen.
- Lösenordsåterställning är tydligt testskyddad som säkerhetsmail och skickas även om vanliga e-postnotiser är avstängda.
- Testskyddet för teknikerinställningar och teknikeröversikten har uppdaterats för de personliga dashboardvalen.

## Nytt i 1.0.60

- Löst/stängt-ärende-mail ber inte längre kunden att svara direkt, utan förklarar att svar inte krävs och att omdöme gärna får lämnas.
- Kundfeedback efter avslut har en konfigurerbar åldersgräns, standard 30 dagar, som döljer gamla omdömeslänkar och stoppar direkta formulärpostningar.
- Admin kan styra hur länge omdöme får lämnas efter avslut under ärendeinställningarna.
- Test- och driftflöden för loggcenter, lösenordsåterställning, skuggpersoner och teknikeröversikt ingår i samma releasepaket.

## Nytt i 1.0.59

- Kundmail för ärenden förklarar nu tydligare att kunden kan svara direkt på mailet och att svaret kopplas automatiskt till ärendet.
- Kundportalens öppna-knapp visar korrekt översatt knapptext i stället för rå översättningsnyckel.
- Import / Export / Skuggpersoner skiljer nu på avsändare och ansvarig: avsändare kopplas till kund/privatkund och ansvarig kopplas till tekniker.
- Skapa-flödet i Skuggpersoner skapar kund eller privatkund, med val för att stänga av e-postnotiser för avdelnings- eller funktionskonton.
- Skuggpersoner har tydligare kundfokuserade texter, radrankare och pagination som håller kvar rätt filtrerad sida efter sparning.
- Importerade ansvarig-namn auto-kopplas inte längre till tekniker och en reparationsmigration öppnar felaktigt länkade ansvarig-skuggpersoner igen utan att ändra ärendets tekniker.
- Ansvarig-skuggpersoner har ett separat fält för att välja ansvarig tekniker, där endast aktiva tekniker kan väljas.

## Nytt i 1.0.58

- Kundmail för ärenden förklarar nu tydligare att kunden kan svara direkt på mailet och att svaret kopplas automatiskt till ärendet.
- Kundportalens öppna-knapp visar korrekt översatt knapptext i stället för rå översättningsnyckel.
- Import / Export / Skuggpersoner är nu en ren kundkopplingskö: befintlig koppling söker bara kund/privatkund och ändrar aldrig tekniker/tilldelad ansvarig.
- Skapa-flödet i Skuggpersoner skapar kund eller privatkund, med val för att stänga av e-postnotiser för avdelnings- eller funktionskonton.
- Skuggpersoner har tydligare kundfokuserade texter, radrankare och pagination som håller kvar rätt filtrerad sida efter sparning.

## Nytt i 1.0.57

- Import / Export / Skuggpersoner kan nu hantera requester-skuggpersoner som egentligen är intern personal eller tekniker.
- För sådana fall finns valet "Koppla som intern skapare", som markerar skuggpersonen som hanterad utan att sätta teknikern som kund/requester på ärendet.
- Ärenden som skickats in av tekniker åt kund kan därmed behålla behovet av korrekt kund/företag separat, utan att tekniker felaktigt skapas eller kopplas som kund.
- Flödet har testskydd så intern skapare-koppling inte ändrar ärendets requester.

## Nytt i 1.0.56

- Kundportalen skiljer nu tydligare på "Mina ärenden" och "Företagets ärenden" för kundanvändare som har fått företagsvald ärendeåtkomst.
- "Mina ärenden" visar alltid bara kundens egna ärenden, medan den nya företagsvyn visar alla kundsynliga ärenden i samma företag för tillåtna användare.
- Sidomenyn visar separata antal för egna aktiva ärenden och företagets aktiva ärenden när företagsvyn är tillgänglig.
- Teknikerns snabbfilter kan nu begränsa ärendeöversikten till ett valt företag utan att behöva skriva företagsnamnet i fritextsökningen.
- Koppling av existerande användare i Import / Export / Skuggpersoner är mer robust: datalist-val sparar rätt användar-id och backend kan även tolka den synliga användaretiketten som fallback.
- Import-/exportflödet har regressionsskydd för skuggpersonkoppling där webbläsaren bara skickar den synliga komboboxtexten.

## Nytt i 1.0.55

- Företag kan nu ha en egen allowlist för vilka aktiva kundanvändare som får se alla kundsynliga ärenden i samma företag.
- Kundportalens ärendelistor, dashboard, sidomeny och detaljvy använder samma åtkomstregel: egna ärenden, företagsdelade ärenden och särskilt tilldelad företagsåtkomst, men aldrig interna ärenden.
- Inventarielistor för datorer och skrivare är nu alltid allowlist-styrda. Äldre "alla kundanvändare"-lägen ger inte längre kundåtkomst förrän användare bockas i.
- Adminvyn för inventarielistor visar sparade checkboxar och tydligare sammanfattning för valda användare.
- Ärendekoordinatorer får personliga inställningar för att själva slå på statkort, uppföljningspanel, avancerade filter och detaljerade ärendekort. Standardvyn är minimal.
- Koordinatorns risköversikt är renare som standard och kan visa mer detaljer när användaren själv väljer det.
- Ärendestatusen `On hold` hanteras i aktiv ärenderäkning, SLA-risk och koordinatoröversikt utan att dra onödiga åtgärdssignaler.

## Nytt i 1.0.54

- Ärendekoordinatorer och tekniker kan nu öppna interna ärendemejl via säkra engångsknappar som loggar in och skickar vidare till rätt ärende.
- Engångslänkarna lagras bara som hash, gäller i två timmar, kan användas en gång och behåller MFA-krav när kontot har MFA aktiverat.
- Textversioner av interna ärendemejl skriver inte längre ut engångstoken-länkar, utan hänvisar till HTML-knappen eller vanlig portalinloggning.
- Automatisk IMAP-hämtning markerar nu meddelanden som lästa direkt när de har hämtats in till Driftpunkt.
- Inkommande mail får försiktigare signaturrensning så tydliga signaturblock kapas utan att telefonnummer eller länkar i felbeskrivningen tas bort.
- Begärd av-fältet kan nu söka eller ta ett manuellt kundnamn som skuggperson, Företag kan sökas utan att nya företag skapas, och admin kan koppla inkommande mailadresser till kund/företag.
- Mailkonfigurationen har fått de senaste förbättringarna för tydligare OAuth/SMTP-hantering och tillhörande tester.

## Nytt i 1.0.53

- Lägger till en reparationsmigration som skapar `technician_team_memberships` om en liveinstallation redan fått 1.0.52-kod men saknar tabellen efter en avbruten migration.
- Reparationsmigrationen använder MariaDB-kompatibel SQL för främmande nycklar och backfillar medlemskap från `users.technician_team_id` med `NOT EXISTS`.
- Fixen tar sikte på 500-felet i adminvyer som identitet/företag där Doctrine försökte läsa teknikerteammedlemskap innan tabellen fanns.
- Releasepaketen för 1.0.53 ska kunna lyfta installationer som fastnat i mellanläget efter 1.0.52.

## Nytt i 1.0.52

- Intern personal kan nu ha ett primärt teknikerteam och valfritt antal extra teammedlemskap.
- `users.technician_team_id` finns kvar som primärt team för standardval, auto-routing, "koppla till mitt team" och delade teamköer.
- En ny medlemskapstabell `technician_team_memberships` backfillas från befintliga primära team vid migration.
- 1.0.52-paketen är ombyggda med MariaDB-kompatibel migrations-SQL för främmande nycklar i medlemskapstabellen.
- Admin-identitet har stöd för extra team på superadmin, admin, ärendekoordinator och tekniker, med validering mot saknat primärt team och inaktiva team.
- Teknikers läs- och samarbetsåtkomst, dashboard, stängda ärenden, "Mina team"-filter och koordinatorns teamvy räknar nu alla teammedlemskap.
- Tickets behåller fortsatt exakt ett ansvarigt team via `Ticket.assignedTeam`.
- Teamradering rensar både primär teamkoppling och extra medlemskap utan att ta bort andra team från användaren.
- Ärendekoordinatorn har en fast guide på `/portal/koordinator/guide` med arbetsflöde för inkommande kanal, triage, tilldelning, uppföljning, mailhantering, rapporter och eskalering.
- Koordinatorns meny visar `Guide` på översikt, ärendedetalj, rapporter och koordinatorläget i teknikerportalen.
- Guidesidan har visuella sektioner, flödeskartor, checklistor och sökfunktion för snabbare stöd i vardagsflödet.
- Guide, menytext, sökfält och hjälptexter är översatta på svenska, engelska och norska.
- Uppladdad webbplatslogga och favicon får versionsstyrda filnamn med innehållsfingeravtryck så gammal branding inte ligger kvar i webbläsarcache.
- 1.0.51-förbättringarna ingår fortsatt: tystare importflöden, enkel kundinloggning, dolbara startsidenyheter, minimal koordinatorvy och mer konsekventa teknikerärenderäknare.

## Översikt

Driftpunkt innehåller bland annat:

- publik webb med startsida, driftstatus, nyheter, sök, kontakt och policy-sidor
- kundkonto med självregistrering, lösenordsåterställning och kundportal för ticketdialog
- teknikerportal för ticketkö, prioritering, kommentarer, SLA och kunskapsbasarbete
- adminyta för identitet, paginerad företagshantering, team, mail, innehåll, driftstatus, databas, jobb och uppdateringar
- e-postflöden med spool-ingest, mailbox-polling och draftgranskning för osäkra fall
- kunskapsbas med publik/kundintern vy, fällbara guider, paginering per innehållstyp, nyhetsmodul och statuskommunikation i samma produkt
- underhållsläge, bilagearkivering, bakgrundsjobb och release-/uppgraderingspaket
- publikt ticket-formulär för att skapa nya tickets utan inloggning
- rapporter och BI-light-översikter för ärenden, SLA, backlog och företag
- tokenbaserat read-only API för enkel ticketexport till integrationer
- månadsrapporter för företag med automatisk e-postsändning
- systemaudit, applikationsloggning, loggcenter med export/rensning för superadmin och Debian-logrotate för enklare felsökning

## Vad man kan göra

### Publik webb

- visa startsida med statusöversikt och senaste nyheter
- läsa nyheter, publik kunskapsbas och publika policy-sidor
- använda sök och kontaktsida utan separat frontend
- visa driftstatus och underhållsinformation publikt
- skapa nya supporttickets via publikt formulär utan inloggning

### Kundflöden

- registrera privatkundskonto när funktionen är aktiverad
- logga in, återställa lösenord och följa egna eller företagsdelade tickets
- kommentera tickets kunden har access till
- lämna omdöme på lösta/stängda ärenden och få en valfri påminnelse om feedbackfunktionen är aktiverad
- läsa kundsynlig kunskapsbas och statusinformation
- se kundanpassade rapporter, datorer och skrivare under `Mina resurser` när företaget och användaren har fått åtkomst
- byta språk mellan svenska, engelska och norska i portalen

### Tekniker- och adminflöden

- skapa, ta över, uppdatera och kommentera tickets
- välja personligt standardspråk i tekniker-, koordinator- och adminytan så nästa inloggning öppnar med rätt språk
- tillhöra flera teknikerteam samtidigt via ett primärt team och extra teammedlemskap
- styra visibility, prioritet, påverkan, request type, routing och SLA
- hantera användare, primärt teknikerteam, extra teammedlemskap och identitet separat från en egen företagssida
- skydda admin- och superadminbehörighet så bara superadmin kan skapa eller tilldela privilegierade roller
- låta superadmin styra globalt standardspråk och vilka språk som ska visas som valbara i gränssnittet
- hantera företag i en paginerad koncernvy där dotterbolag följer med sitt moderbolag
- skapa och publicera nyheter och kunskapsbasinnehåll med typflikar och bevarade filter i admin- och teknikerläge
- rensa testärenden per företag som superadmin med preview, säkerhetsfrågor och borttagning av tillhörande bilagor
- arbeta med telefonstödsdata i admin
- importera ärenden från SharePoint/CSV och behålla kund- och teknikernamn som skuggpersoner tills riktiga konton skapas eller kopplas
- ta bort felimporterade ärenden direkt från importgranskningen när de ännu inte har tilldelats tekniker eller team
- konfigurera fjärrsupportgenvägar för AnyDesk och TeamViewer när SupportDesk-addonet är färdiginstallerat och släppt
- konfigurera mail, supportinkorgar, driftstatus, inställningar och underhåll
- följa BI-light-rapporter för inflöde, backlog, SLA-hälsa, risker, företag och intern arbetslast
- konfigurera och skicka månadsrapporter för företag
- låta ärendekoordinatorer läsa företagsdata och inventarielistor utan att ge full adminåtkomst
- koppla flera teknikeransvariga till ärenden när arbetsflödet kräver delat ansvar
- följa notifieringar, grupperade systemloggar, driftåtgärder och jobbfel i ett loggcenter med export och kontrollerad superadmin-rensning
- importera, registrera och växla installerade addon-paket när moduler följer Driftpunkts paketstruktur

### Drift och automation

- läsa in inkommande mail via spool eller polling av supportinkorgar
- lägga osäkra mail i draftgranskning innan de blir kundsynliga tickets
- köra mailpolling, SLA-kontroll, bilagearkivering och månadsrapporter via appens interna fallback eller externa schemaläggare
- köra engångspåminnelser för kundomdömen efter avslutade ärenden när funktionen är aktiverad
- köra databasjobb och post-update tasks via CLI eller adminens bakgrundsjobb
- använda `PHP_CLI_BINARY` för säkra bakgrundsstarter i Apache/mod_php- och webbhotellmiljöer
- bygga installations- och uppgraderingspaket
- stagea och applicera koduppdateringsflöden i admin/drift
- exportera en publik repo-kopia med privata moduler, driftkod och interna docs bortfiltrerade
- felsöka via `var/log/*.log`, systemd-loggar, release-metadata och checksummor för paket

## Begränsningar i nuläget

- API:t är read-only och avsett för kontrollerad ticketexport, inte som full integrationshub
- ingen full fristående BI-motor med sparade egna rapportmallar eller externa BI-integrationer
- produktion behöver fortfarande egen serverhardening, backup/restore och extern scheduler för förutsägbara bakgrundsjobb

## Installationskrav

Driftpunkt är en serverrenderad Symfony 8-applikation. Det finns ingen separat Node-, npm- eller frontend-build som krävs för att köra sidan i nuläget.

Minimikrav för lokal utveckling och serverdrift:

- PHP 8.4 eller senare
- Composer 2
- MariaDB 10.11 eller senare, rekommenderat MariaDB 11 för lokal Docker-miljö
- `DATABASE_URL` måste peka på MariaDB utanför `APP_ENV=test`; `mysql://` ska ange `serverVersion` som innehåller `mariadb`
- PHP-tilläggen `ctype`, `curl`, `iconv`, `intl`, `mbstring`, `pdo`, `pdo_mysql`, `xml`, `zip` och gärna `opcache`
- en webbserver som kan köra PHP och peka dokumentroten mot `htdocs/`, till exempel Symfony CLI, PHP:s inbyggda server, Apache eller appcontainern i Docker
- skrivbar `var/`-katalog för cache, loggar, uppladdningar och delade driftfiler
- skrivbar `htdocs/assets/branding` om logotyp, flikikon och branding ska kunna ändras från adminytan; uppladdade `custom-site-*`-filer är runtime-data och ska bevaras vid koduppdateringar
- om adminytans webbaserade uppdateringsflöde ska användas måste den faktiska PHP/webbserver-användaren, normalt `www-data` men på Apache med `mpm-itk`/`AssignUserID` ofta vhost-användaren, även kunna skriva till kodfilerna som uppdateras: `bin/`, `config/`, `htdocs/`, `migrations/`, `public/`, `src/`, `templates/`, `composer.json`, `composer.lock` och `symfony.lock`

Rekommenderat för produktion:

- HTTPS/TLS framför applikationen
- ett unikt `APP_SECRET` i `.env.local` eller riktiga miljovariabler
- låt `DRIFTPUNKT_SESSION_IDLE_TIMEOUT=1800` eller ett kortare driftanpassat värde vara satt så inloggade sessioner stängs efter inaktivitet
- lämna `DRIFTPUNKT_ENABLE_DEMO_DATA=0` i produktion om du inte uttryckligen vill skapa demoärenden i en tom databas
- sätt `DRIFTPUNKT_API_TOKEN` bara om read-only API:t `/api/v1/tickets` ska aktiveras
- en riktig `DATABASE_URL` mot MariaDB
- SMTP-konfiguration via `MAILER_DSN` om appen ska skicka e-post
- schemalagda jobb för mailpolling, SLA-kontroll, månadsrapporter och bilagearkivering via systemd, cron eller Docker-scheduler rekommenderas för förutsägbar produktion, men appen har en intern fallback som köar samma återkommande jobb från webbflödet om extern scheduler saknas
- regelbunden backup av MariaDB och `var/share`
- välj driftmodell för kodägarskap: webbaserad uppdatering kräver skrivbar applikationskod för samma användare som Apache/PHP kör webbplatsen med, medan en hårdare låst server kan låta `root` äga kodfilerna och i stället uppdateras via SSH/deploy-script

Valfria verktyg:

- Symfony CLI för smidig lokal serverstart
- Docker och Docker Compose för lokal MariaDB eller komplett NAS-/serverdrift
- PHPUnit för testkörning via `php bin/phpunit`

## Skärmbilder

### Startsida

![Driftpunkt startsida](docs/public-assets/screenshots/homepage.png)

### Inloggning

| Admin | Tekniker |
| --- | --- |
| ![Admin login](docs/public-assets/screenshots/login-admin.png) | ![Tekniker login](docs/public-assets/screenshots/login-technician.png) |

| Kund |
| --- |
| ![Kund login](docs/public-assets/screenshots/login-customer.png) |

### Portaler

| Kundportal | Teknikerportal |
| --- | --- |
| ![Kundportal](docs/public-assets/screenshots/customer-portal.png) | ![Teknikerportal](docs/public-assets/screenshots/technician-portal.png) |

### Adminvy

![Admin dashboard](docs/public-assets/screenshots/admin-dashboard.png)

## Snabbstart

1. Installera PHP-beroenden

   ```bash
   composer install
   ```

2. Konfigurera miljö

   Standardvärdena i `.env` fungerar för lokal utveckling mot MariaDB från `compose.yaml`. Skapa `.env.local` om du vill ändra till exempel `DATABASE_URL`, `APP_SECRET`, `MAILER_DSN`, `DEFAULT_URI` eller `DRIFTPUNKT_SESSION_IDLE_TIMEOUT`.

3. Starta MariaDB om du använder lokal Docker-miljö

   ```bash
   docker compose up -d database
   ```

   Om du inte använder Docker, skapa en MariaDB-databas och uppdatera `DATABASE_URL`.

4. Initialisera databasen

   För en helt ny MariaDB-installation:

   ```bash
   php bin/console app:install:fresh
   ```

   Det kommandot säkerställer alltid standardkonton för superadmin och admin. Det skapar också standardkonton för tekniker och kund om du inte uttryckligen hoppar över dem med `--skip-test-accounts`.

   Om du arbetar mot en befintlig databas med migrationshistorik:

   ```bash
   php bin/console doctrine:migrations:migrate -n
   ```

5. Skapa testkonton eller en första admin

   ```bash
   php bin/console app:create-test-accounts
   ```

   eller

   ```bash
   php bin/console app:create-admin dinmail@example.com DittLösenord123 Förnamn Efternamn super_admin
   ```

6. Starta sidan

   ```bash
   symfony server:start
   ```

   Om Symfony CLI saknas:

   ```bash
   php -S 127.0.0.1:8000 -t htdocs
   ```

7. Öppna `http://127.0.0.1:8000`

## Snabbstart med Docker Compose

Rootens `compose.yaml` startar MariaDB på port `33060` och mailtestning för lokal utveckling. NAS-/serverdrift med appcontainer finns i `deploy/nas/compose.yaml`.

1. Starta hjälptjänsterna

   ```bash
   docker compose up -d
   ```

2. Installera beroenden och initiera MariaDB

   ```bash
   composer install
   php bin/console app:install:fresh
   ```

3. (Valfritt) skapa testkonton

   ```bash
   php bin/console app:create-test-accounts
   ```

4. Öppna `http://127.0.0.1:8000`

## NAS med Docker Compose

För en NAS eller annan Docker-baserad server finns en komplett compose-setup med app, MariaDB, persistenta volymer och scheduler:

- [NAS-installation med Docker Compose](docs/nas_docker_setup.md)
- `deploy/nas/compose.yaml`
- `deploy/nas/.env.example`

Kort version:

```bash
cp deploy/nas/.env.example deploy/nas/.env
nano deploy/nas/.env
mkdir -p deploy/nas/data/var deploy/nas/data/mariadb
docker compose -f deploy/nas/compose.yaml --env-file deploy/nas/.env up -d --build
docker compose -f deploy/nas/compose.yaml --env-file deploy/nas/.env exec app php bin/console app:install:fresh --env=prod
```

## Debian-server

För en vanlig Debian-server utan Docker finns en konkret runbook och färdiga mallar:

- [Debian-server: krav och installation](docs/debian_server_setup.md)
- `deploy/debian/app.env.example` för `.env.local`
- `deploy/debian/apache-driftpunkt.conf` för Apache
- `deploy/debian/setup.sh` för basinstallation av paket, Composer, Apache-site och systemd-timers

Kort version:

```bash
sudo mkdir -p /var/www/driftpunkt
sudo chown "$USER":www-data /var/www/driftpunkt
git clone <repo-url> /var/www/driftpunkt
cd /var/www/driftpunkt
DOMAIN=driftpunkt.example.com sudo -E bash deploy/debian/setup.sh
sudo nano /var/www/driftpunkt/.env.local
sudo -u www-data php bin/console app:install:fresh --env=prod
```

## Testkonton

Om du kör `app:create-test-accounts` skapas:

| Roll | E-post | Lösenord |
| --- | --- | --- |
| Super admin | `super@test.local` | `AdminPassword123` |
| Admin | `admin@test.local` | `AdminPassword123` |
| Tekniker | `tech@test.local` | `TechPassword123` |
| Kund | `customer@test.local` | `CustomerPassword123` |

`app:install:fresh` säkerställer alltid superadmin- och admin-kontot. Tekniker- och kundkontot skapas automatiskt om du inte anger `--skip-test-accounts`.
Alla standardkonton markeras för lösenordsbyte vid första inloggningen.

## Viktiga Kommandon

```bash
php bin/console app:create-test-accounts
php bin/console app:system-accounts:ensure
php bin/console app:install:fresh
php bin/console app:create-admin <email> <lösenord> <förnamn> <efternamn> <admin|super_admin>
php bin/console app:mail:ingest <spoolfil>
php bin/console app:mail:poll
php bin/console app:check-ticket-sla
php bin/console app:reports:send-monthly --dry-run
php bin/console app:archive-ticket-attachments
php bin/console app:send-ticket-feedback-reminders --dry-run
php bin/console app:operations:run-due
php bin/console app:database-maintenance:run <job-id>
php bin/console app:post-update:run <run-id>
php bin/console app:code-update:apply-run <run-id>
php bin/console app:maintenance status
php bin/console app:i18n:audit --strict
php bin/console app:release:build-packages
composer export:public-repo
php bin/phpunit
```

För att köra testsviten mot MariaDB i testmiljön, starta databasen och override:a `DATABASE_URL` för själva testkommandot:

```bash
docker compose up -d database
docker compose exec -T database mariadb -uroot -pdriftpunkt-root -e "CREATE DATABASE IF NOT EXISTS driftpunkt_test CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci; GRANT ALL PRIVILEGES ON driftpunkt_test.* TO 'driftpunkt'@'%'; FLUSH PRIVILEGES;"
DATABASE_URL='mysql://driftpunkt:driftpunkt@127.0.0.1:33060/driftpunkt?serverVersion=mariadb-11.8.6&charset=utf8mb4' APP_ENV=test php bin/phpunit
```

`phpunit.dist.xml` tvingar `APP_ENV=test` och Doctrine lägger på suffixet `_test`, så basdatabasen `driftpunkt` i URL:en används som `driftpunkt_test` under testkörningen.

## Språk och översättningar

Svenska är bas-språket i `translations/messages.sv.yaml`. Engelska och norska ska ha samma nycklar i `translations/messages.en.yaml` och `translations/messages.no.yaml`, även för äldre vyer som fortfarande skickar direkt svensk källtext till `t('...')`.

Användare med admin-, superadmin-, tekniker- eller koordinatorroll kan spara ett personligt standardspråk. Superadmin kan dessutom välja globalt standardspråk och begränsa vilka installerade språk som visas som valbara; om ett sparat språk inte längre är aktivt används det globala standardspråket.

Kör språkgranskningen innan release eller när nya UI-texter läggs till:

```bash
php bin/console app:i18n:audit --strict
```

Kommandot kontrollerar alla språkfiler mot svenska, visar saknade översättningar och varnar om en översättning finns i engelska/norska men saknas i svenska basfilen. Adminytan under Språk & översättningar kan sedan användas för att hitta och fylla saknade texter per språk.

## Intern schemaläggningsfallback

Driftpunkt har en appstyrd fallback för återkommande driftjobb. När en webbförfrågan avslutas kontrollerar appen om mailpolling, SLA-kontroll, bilagearkivering eller månadsrapporter är förfallna och köar då:

```bash
php bin/console app:operations:run-due
```

Fallbacken använder låsning och state i `var/operational_tasks.lock` och `var/operational_tasks.json`, så den inte ska starta samma körning vid varje sidladdning. Extern schemaläggning via systemd, cron eller Docker-scheduler är fortfarande rekommenderad i produktion för mer förutsägbara körtider, men appen slutar inte fungera om det saknas.

## Releasepaket

Releaseversionen hämtas normalt från `version` i `composer.json`. Höj den inför varje släpp, till exempel från `1.0.0` till `1.0.1`, så får både adminytan och zip-filerna samma versionsnummer.

Aktuell release i detta arbetsläge är `1.0.88`. Motsvarande paket heter `driftpunkt-install-1.0.88.zip` och `driftpunkt-upgrade-1.0.88.zip`.

### Viktigt vid avbruten 1.0.45-uppdatering

Version `1.0.46` och senare innehåller hotfixen för migrationen `DoctrineMigrations\Version20260514100000`. Om en uppdatering till `1.0.45` stoppade med felet `Call to undefined method Doctrine\DBAL\Schema\Table::changeColumn()` ska du använda senaste `driftpunkt-upgrade-<version>.zip` och köra uppdateringsflödet igen.

Om koden redan är uppackad manuellt kan migrationen köras om från applikationskatalogen efter att `1.0.46` eller senare ligger på plats:

```bash
php bin/console doctrine:migrations:migrate --no-interaction --allow-no-migration --all-or-nothing --env=prod
```

Felet sker innan Doctrine markerar migrationen som slutförd, så samma migration kan normalt köras igen utan manuell databasändring. Kontrollera ändå alltid backup innan du fortsätter en avbruten driftuppdatering.

Bygg båda paketen:

```bash
composer build:packages
```

Om globalt `composer` saknas men projektets lokala Composer-PHAR finns i repo-roten kan samma kommando köras med:

```bash
php composer build:packages
```

Bygg bara uppgraderingspaketet:

```bash
composer build:upgrade-package
```

Om Composer-kommandot inte är tillgängligt i driftmiljön kan samma uppgraderingsbygge köras direkt via Symfony-kommandot:

```bash
php bin/console app:release:build-packages --type=upgrade
```

Bygg bara installationspaketet:

```bash
composer build:install-package
```

Både installations- och uppgraderingspaket innehåller `vendor/`, så en NAS eller Debian-server slipper hämta Composer-paket från internet under själva uppdateringen.

Uppgraderingspaket är kumulativa från Driftpunkt 1.x: senaste `driftpunkt-upgrade-<version>.zip` innehåller hela aktuella kodbasen och ska normalt kunna lyfta en installation som ligger flera versioner efter direkt till aktuell version. Själva adminuppdateraren jämför paketet mot installerad kod och skriver bara nya eller ändrade filer, tar bort gamla hanterade filer och bevarar runtime-data som `.env*`, `var/` och uppladdad branding.

Paketens webbrot är `htdocs/`. Apache, Docker eller NAS-webbserver ska därför peka mot `<appkatalog>/htdocs`. `public/` kan finnas kvar för kompatibilitet i äldre miljöer, men nya installationer ska inte kräva `/public`.

Om webbhotellet har en fast publik katalog som heter `/htdocs` kan hela installationspaketet packas upp direkt där. Paketets root-`.htaccess` och root-`index.php` gör då att appen startar från yttre `/htdocs`, samtidigt som känsliga mappar som `config/`, `src/`, `vendor/` och `var/` blockeras. Det kräver Apache med `mod_rewrite` och fungerande `.htaccess`.

Paketbygget tar bara med installations- och uppdateringsnära dokumentation från `docs/`. Interna produktplaner, systemspecar, skärmbilder, designunderlag och superpowers-planer följer inte med i zip-filerna.

Lägg releaseinformation i `release-notes/<version>.md` innan paketet byggs, till exempel `release-notes/1.0.9.md`. Paketbyggaren läser filen automatiskt, lägger den i zippen och bäddar in nyheter, driftkrav och efterkontroller i `release-metadata.json`. Om filen saknas kan paketet fortfarande laddas upp, men adminytan visar en varning så versionen granskas extra noggrant.

Uppdateringar från adminytan kör förkontroll mot MariaDB, stoppar parallella uppdateringar, tar kodbackup, kör diff-medveten kodsynk, kör obligatoriska eftersteg och markerar inte versionen som klar förrän migrationer och cache-rensning har lyckats.

## Publik Export

Den publika repot ska inte längre få en rensad kodkopia. Exporten bygger i stället aktuella releasepaket och skriver en separat engelsk README för öppna repot.

Exporten innehåller:

- senaste installationspaketet: `packages/driftpunkt-install-<version>.zip`
- senaste kumulativa uppgraderingspaketet samt upp till tre senaste uppgraderingspaket som fallback och versionshistorik: `packages/driftpunkt-upgrade-<version>.zip`
- en `.sha256`-fil bredvid varje paket
- `README.md` på engelska med produktbeskrivning, bilder, installationsflöde, uppgraderingsflöde och engelska release notes för aktuell publik release
- utvalda publika README-assets under `assets/`, hämtade från `docs/public-assets/`
- `PUBLIC_EXPORT_MANIFEST.md` med exporterade och överhoppade paket

Skapa eller uppdatera den publika arbetskopian från den privata repot:

```bash
composer export:public-repo
```

Kommandot kör paketbygget först, så aktuell version i `composer.json` får både install- och upgradepaket innan filerna kopieras. Peka exporten direkt mot en lokal klon av den publika GitHub-repot:

```bash
php bin/console app:repo:export-public --output-dir=/path/to/Driftpunkt
```

För den lokala publika arbetskopian som används här:

```bash
php bin/console app:repo:export-public --output-dir=/home/kenta/REPO/Driftpunkt-public
```

Rekommenderat arbetsflöde:

1. Utveckla i `Driftpunkt-privat`
2. Höj versionen och lägg releaseinformation i `release-notes/<version>.md`; skriv den på engelska om den ska synas i publika repots README
3. Kör publik export mot den lokala klonen av öppna repot
4. Granska att diffen bara innehåller README, manifest och paketfiler
5. Commit:a och pusha när exporten ser ren ut

## Dokumentation

Dokumentationen i `docs/` beskriver nuläget i koden, inte en framtida målbild. De drift- och publikt återanvändbara dokumenten är:

- `docs/driftpunkt_ticket_system_spec.md`
- `docs/installation_and_deployment.md`
- `docs/debian_server_setup.md`
- `docs/nas_docker_setup.md`
- `docs/mail_configuration_guide.md`
- `docs/mail_processing_rules.md`
- `docs/mail_polling_operations.md`
- `docs/ticket_attachment_archiving_operations.md`
- `docs/security_requirements.md`
- `docs/known_limitations.md`

Det privata repot kan dessutom innehålla interna produkt-, roll-, datamodell-, test- och planeringsdokument som inte behöver följa med i den publika exporten.

Bra startpunkter beroende på vad du vill göra:

- produktomfång och nuläge: `docs/driftpunkt_ticket_system_spec.md`
- installation och drift: `docs/installation_and_deployment.md`
- mailflöden: `docs/mail_processing_rules.md`
- Debian-server: `docs/debian_server_setup.md`
- NAS/Docker: `docs/nas_docker_setup.md`
- säkerhetskrav: `docs/security_requirements.md`
