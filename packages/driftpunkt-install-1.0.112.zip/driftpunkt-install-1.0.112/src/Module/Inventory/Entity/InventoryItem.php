<?php

declare(strict_types=1);

namespace App\Module\Inventory\Entity;

use App\Module\Identity\Entity\Company;
use App\Module\Inventory\Enum\InventoryListType;
use App\Module\Shared\Entity\TimestampableTrait;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity]
#[ORM\Table(name: 'inventory_items')]
#[ORM\Index(name: 'idx_inventory_item_company_type', columns: ['company_id', 'type'])]
#[ORM\HasLifecycleCallbacks]
class InventoryItem
{
    use TimestampableTrait;

    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\ManyToOne(targetEntity: Company::class)]
    #[ORM\JoinColumn(nullable: false, onDelete: 'CASCADE')]
    private Company $company;

    #[ORM\Column(enumType: InventoryListType::class)]
    private InventoryListType $type;

    #[ORM\Column(length: 255, nullable: true)]
    private ?string $hostname = null;

    #[ORM\Column(name: 'assigned_to', length: 255, nullable: true)]
    private ?string $assignedTo = null;

    #[ORM\Column(length: 255, nullable: true)]
    private ?string $manufacturer = null;

    #[ORM\Column(length: 255, nullable: true)]
    private ?string $model = null;

    #[ORM\Column(length: 255, nullable: true)]
    private ?string $serialNumber = null;

    #[ORM\Column(name: 'operating_system', length: 255, nullable: true)]
    private ?string $operatingSystem = null;

    #[ORM\Column(length: 255, nullable: true)]
    private ?string $processor = null;

    #[ORM\Column(length: 255, nullable: true)]
    private ?string $memory = null;

    #[ORM\Column(length: 255, nullable: true)]
    private ?string $storage = null;

    #[ORM\Column(nullable: true)]
    private ?\DateTimeImmutable $purchaseDate = null;

    #[ORM\Column(nullable: true)]
    private ?\DateTimeImmutable $warrantyEndsAt = null;

    #[ORM\Column(options: ['default' => false])]
    private bool $broken = false;

    #[ORM\Column(type: 'text', nullable: true)]
    private ?string $comment = null;

    #[ORM\Column(length: 64, nullable: true)]
    private ?string $ipAddress = null;

    #[ORM\Column(length: 255, nullable: true)]
    private ?string $printerKind = null;

    #[ORM\Column(length: 255, nullable: true)]
    private ?string $printerName = null;

    #[ORM\Column(length: 255, nullable: true)]
    private ?string $area = null;

    #[ORM\Column(length: 64, nullable: true)]
    private ?string $color = null;

    #[ORM\Column(options: ['default' => false])]
    private bool $available = false;

    #[ORM\Column(nullable: true)]
    private ?\DateTimeImmutable $installationDate = null;

    #[ORM\Column(length: 80, nullable: true)]
    private ?string $pin = null;

    #[ORM\Column(length: 80, nullable: true)]
    private ?string $screenSize = null;

    #[ORM\Column(length: 80, nullable: true)]
    private ?string $resolution = null;

    #[ORM\Column(length: 120, nullable: true)]
    private ?string $connectionType = null;

    #[ORM\Column(length: 255, nullable: true)]
    private ?string $terminalId = null;

    #[ORM\Column(length: 255, nullable: true)]
    private ?string $provider = null;

    #[ORM\Column(options: ['default' => false])]
    private bool $payAtTable = false;

    public function __construct(Company $company, InventoryListType $type)
    {
        $this->company = $company;
        $this->type = $type;
    }

    public function getId(): ?int { return $this->id; }
    public function getCompany(): Company { return $this->company; }
    public function getType(): InventoryListType { return $this->type; }
    public function getHostname(): ?string { return $this->hostname; }
    public function getAssignedTo(): ?string { return $this->assignedTo; }
    public function getManufacturer(): ?string { return $this->manufacturer; }
    public function getModel(): ?string { return $this->model; }
    public function getSerialNumber(): ?string { return $this->serialNumber; }
    public function getOperatingSystem(): ?string { return $this->operatingSystem; }
    public function getProcessor(): ?string { return $this->processor; }
    public function getMemory(): ?string { return $this->memory; }
    public function getStorage(): ?string { return $this->storage; }
    public function getPurchaseDate(): ?\DateTimeImmutable { return $this->purchaseDate; }
    public function getWarrantyEndsAt(): ?\DateTimeImmutable { return $this->warrantyEndsAt; }
    public function isBroken(): bool { return $this->broken; }
    public function getComment(): ?string { return $this->comment; }
    public function getIpAddress(): ?string { return $this->ipAddress; }
    public function getPrinterKind(): ?string { return $this->printerKind; }
    public function getPrinterName(): ?string { return $this->printerName; }
    public function getArea(): ?string { return $this->area; }
    public function getColor(): ?string { return $this->color; }
    public function isAvailable(): bool { return $this->available; }
    public function getInstallationDate(): ?\DateTimeImmutable { return $this->installationDate; }
    public function getPin(): ?string { return $this->pin; }
    public function getScreenSize(): ?string { return $this->screenSize; }
    public function getResolution(): ?string { return $this->resolution; }
    public function getConnectionType(): ?string { return $this->connectionType; }
    public function getTerminalId(): ?string { return $this->terminalId; }
    public function getProvider(): ?string { return $this->provider; }
    public function isPayAtTable(): bool { return $this->payAtTable; }

    /**
     * @param array<string, mixed> $data
     */
    public function applyData(array $data): self
    {
        foreach ($data as $field => $value) {
            $value = \is_string($value) ? trim($value) : $value;
            $value = '' === $value ? null : $value;

            match ($field) {
                'hostname' => $this->hostname = self::shortText($value),
                'assignedTo' => $this->assignedTo = self::shortText($value),
                'manufacturer' => $this->manufacturer = self::shortText($value),
                'model' => $this->model = self::shortText($value),
                'serialNumber' => $this->serialNumber = self::shortText($value),
                'operatingSystem' => $this->operatingSystem = self::shortText($value),
                'processor' => $this->processor = self::shortText($value),
                'memory' => $this->memory = self::shortText($value),
                'storage' => $this->storage = self::shortText($value),
                'purchaseDate' => $this->purchaseDate = $value instanceof \DateTimeImmutable ? $value : null,
                'warrantyEndsAt' => $this->warrantyEndsAt = $value instanceof \DateTimeImmutable ? $value : null,
                'broken' => $this->broken = (bool) $value,
                'comment' => $this->comment = null !== $value ? (string) $value : null,
                'ipAddress' => $this->ipAddress = self::shortText($value, 64),
                'printerKind' => $this->printerKind = self::shortText($value),
                'printerName' => $this->printerName = self::shortText($value),
                'area' => $this->area = self::shortText($value),
                'color' => $this->color = self::shortText($value, 64),
                'available' => $this->available = (bool) $value,
                'installationDate' => $this->installationDate = $value instanceof \DateTimeImmutable ? $value : null,
                'pin' => $this->pin = self::shortText($value, 80),
                'screenSize' => $this->screenSize = self::shortText($value, 80),
                'resolution' => $this->resolution = self::shortText($value, 80),
                'connectionType' => $this->connectionType = self::shortText($value, 120),
                'terminalId' => $this->terminalId = self::shortText($value),
                'provider' => $this->provider = self::shortText($value),
                'payAtTable' => $this->payAtTable = (bool) $value,
                default => null,
            };
        }

        return $this;
    }

    /**
     * @return array<string, mixed>
     */
    public function snapshot(): array
    {
        return [
            'hostname' => $this->hostname,
            'assignedTo' => $this->assignedTo,
            'manufacturer' => $this->manufacturer,
            'model' => $this->model,
            'serialNumber' => $this->serialNumber,
            'operatingSystem' => $this->operatingSystem,
            'processor' => $this->processor,
            'memory' => $this->memory,
            'storage' => $this->storage,
            'purchaseDate' => $this->purchaseDate?->format('Y-m-d'),
            'warrantyEndsAt' => $this->warrantyEndsAt?->format('Y-m-d'),
            'broken' => $this->broken,
            'comment' => $this->comment,
            'ipAddress' => $this->ipAddress,
            'printerKind' => $this->printerKind,
            'printerName' => $this->printerName,
            'area' => $this->area,
            'color' => $this->color,
            'available' => $this->available,
            'installationDate' => $this->installationDate?->format('Y-m-d'),
            'pin' => $this->pin,
            'screenSize' => $this->screenSize,
            'resolution' => $this->resolution,
            'connectionType' => $this->connectionType,
            'terminalId' => $this->terminalId,
            'provider' => $this->provider,
            'payAtTable' => $this->payAtTable,
        ];
    }

    private static function shortText(mixed $value, int $length = 255): ?string
    {
        if (null === $value) {
            return null;
        }

        return mb_substr(trim((string) $value), 0, $length) ?: null;
    }
}
