<?php

declare(strict_types=1);

namespace App\Module\Inventory\Controller;

use App\Module\Identity\Entity\Company;
use App\Module\Identity\Entity\User;
use App\Module\Inventory\Entity\InventoryItem;
use App\Module\Inventory\Entity\InventoryListSetting;
use App\Module\Inventory\Enum\InventoryListType;
use App\Module\Inventory\Service\InventoryService;
use App\Module\Identity\Service\MfaPolicyResolver;
use App\Module\System\Service\SystemSettings;
use App\Module\Ticket\Entity\Ticket;
use App\Module\Ticket\Enum\TicketStatus;
use App\Module\Ticket\Service\CustomerTicketQuery;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\StreamedResponse;
use Symfony\Component\HttpFoundation\File\UploadedFile;
use Symfony\Component\Routing\Attribute\Route;
use Symfony\Component\Security\Http\Attribute\IsGranted;

final class InventoryController extends AbstractController
{
    public function __construct(
        private readonly EntityManagerInterface $entityManager,
        private readonly InventoryService $inventoryService,
        private readonly CustomerTicketQuery $customerTicketQuery,
        private readonly MfaPolicyResolver $mfaPolicyResolver,
        private readonly SystemSettings $systemSettings,
    ) {
    }

    #[Route('/portal/customer/inventarie/datorer', name: 'app_inventory_customer_computers', methods: ['GET'])]
    #[IsGranted('ROLE_CUSTOMER')]
    public function customerComputers(Request $request): Response
    {
        return $this->customerList($request, InventoryListType::COMPUTER);
    }

    #[Route('/portal/customer/inventarie/skrivare', name: 'app_inventory_customer_printers', methods: ['GET'])]
    #[IsGranted('ROLE_CUSTOMER')]
    public function customerPrinters(Request $request): Response
    {
        return $this->customerList($request, InventoryListType::PRINTER);
    }

    #[Route('/portal/customer/inventarie/skarmar', name: 'app_inventory_customer_monitors', methods: ['GET'])]
    #[IsGranted('ROLE_CUSTOMER')]
    public function customerMonitors(Request $request): Response
    {
        return $this->customerList($request, InventoryListType::MONITOR);
    }

    #[Route('/portal/customer/inventarie/kortterminaler', name: 'app_inventory_customer_payment_terminals', methods: ['GET'])]
    #[IsGranted('ROLE_CUSTOMER')]
    public function customerPaymentTerminals(Request $request): Response
    {
        return $this->customerList($request, InventoryListType::PAYMENT_TERMINAL);
    }

    #[Route('/portal/technician/inventarie', name: 'app_inventory_technician_index', methods: ['GET'])]
    #[IsGranted('ROLE_USER')]
    public function technicianIndex(Request $request): Response
    {
        $this->denyUnlessInventoryStaff();

        $query = trim((string) $request->query->get('q'));
        $normalizedQuery = mb_strtolower($query);
        $settings = $this->entityManager->getRepository(InventoryListSetting::class)->findBy(['enabled' => true], ['updatedAt' => 'DESC']);
        $companies = [];
        foreach ($settings as $setting) {
            $company = $setting->getCompany();
            if ('' !== $normalizedQuery && !str_contains(mb_strtolower($company->getName()), $normalizedQuery)) {
                continue;
            }

            $companyId = $company->getId() ?? 0;
            $companies[$companyId] ??= [
                'company' => $company,
                'lists' => [],
                'totalCount' => 0,
            ];

            $count = $this->inventoryService->countItems($company, $setting->getType());
            $companies[$companyId]['lists'][$setting->getType()->value] = [
                'type' => $setting->getType(),
                'count' => $count,
            ];
            $companies[$companyId]['totalCount'] += $count;
        }

        $companies = array_values($companies);
        usort(
            $companies,
            static fn (array $left, array $right): int => $left['company']->getName() <=> $right['company']->getName(),
        );

        return $this->render('inventory/technician_index.html.twig', [
            'companies' => $companies,
            'query' => $query,
        ]);
    }

    #[Route('/portal/technician/inventarie/{companyId}/{type}', name: 'app_inventory_technician_list', methods: ['GET'], requirements: ['companyId' => '\d+', 'type' => 'computer|printer|monitor|payment_terminal'])]
    #[IsGranted('ROLE_USER')]
    public function technicianList(Request $request, int $companyId, string $type): Response
    {
        $this->denyUnlessInventoryStaff();

        $company = $this->company($companyId);
        $listType = InventoryListType::from($type);
        $this->denyUnlessEnabled($company, $listType);

        $query = trim((string) $request->query->get('q'));
        $sort = trim((string) $request->query->get('sort'));
        $direction = 'desc' === strtolower((string) $request->query->get('direction')) ? 'desc' : 'asc';
        $items = $this->inventoryService->items($company, $listType, $query, $sort, $direction);

        if ('csv' === $request->query->get('export')) {
            return $this->csvResponse($company, $listType, $items);
        }

        if ('excel' === $request->query->get('export')) {
            return $this->excelResponse($company, $listType, $items);
        }

        return $this->render('inventory/technician_list.html.twig', [
            'company' => $company,
            'type' => $listType,
            'columns' => $this->inventoryService->columns($listType),
            'items' => $items,
            'query' => $query,
            'sort' => $sort,
            'direction' => $direction,
            'inventoryEditable' => $this->isGranted('ROLE_TECHNICIAN'),
        ]);
    }

    #[Route('/portal/technician/inventarie/{companyId}/{type}/rader', name: 'app_inventory_technician_item_create', methods: ['POST'], requirements: ['companyId' => '\d+', 'type' => 'computer|printer|monitor|payment_terminal'])]
    #[IsGranted('ROLE_TECHNICIAN')]
    public function createTechnicianItem(Request $request, int $companyId, string $type): RedirectResponse
    {
        $company = $this->company($companyId);
        $listType = InventoryListType::from($type);
        $this->denyUnlessEnabled($company, $listType);
        $this->validateCsrf('inventory_create_'.$company->getId().'_'.$listType->value, $request);
        $actor = $this->currentUser();
        try {
            $this->inventoryService->createItem($company, $listType, $request->request->all(), $actor);
            $this->addFlash('success', 'Raden skapades.');
        } catch (\InvalidArgumentException $exception) {
            $this->addFlash('error', $exception->getMessage());
        }

        return $this->redirectToRoute('app_inventory_technician_list', ['companyId' => $companyId, 'type' => $type]);
    }

    #[Route('/portal/technician/inventarie/rader/{id}', name: 'app_inventory_technician_item_update', methods: ['POST'], requirements: ['id' => '\d+'])]
    #[IsGranted('ROLE_TECHNICIAN')]
    public function updateTechnicianItem(Request $request, InventoryItem $item): RedirectResponse
    {
        $this->denyUnlessEnabled($item->getCompany(), $item->getType());
        $this->validateCsrf('inventory_update_'.$item->getId(), $request);
        try {
            $this->inventoryService->updateItem($item, $request->request->all(), $this->currentUser());
            $this->addFlash('success', 'Raden uppdaterades.');
        } catch (\InvalidArgumentException $exception) {
            $this->addFlash('error', $exception->getMessage());
        }

        return $this->redirectToRoute('app_inventory_technician_list', ['companyId' => $item->getCompany()->getId(), 'type' => $item->getType()->value]);
    }

    #[Route('/portal/technician/inventarie/rader/{id}/delete', name: 'app_inventory_technician_item_delete', methods: ['POST'], requirements: ['id' => '\d+'])]
    #[IsGranted('ROLE_TECHNICIAN')]
    public function deleteTechnicianItem(Request $request, InventoryItem $item): RedirectResponse
    {
        $companyId = $item->getCompany()->getId();
        $type = $item->getType()->value;
        $this->denyUnlessEnabled($item->getCompany(), $item->getType());
        $this->validateCsrf('inventory_delete_'.$item->getId(), $request);
        $this->inventoryService->deleteItem($item, $this->currentUser());
        $this->addFlash('success', 'Raden togs bort.');

        return $this->redirectToRoute('app_inventory_technician_list', ['companyId' => $companyId, 'type' => $type]);
    }

    #[Route('/portal/admin/companies/{id}/inventory/{type}/toggle', name: 'app_inventory_admin_toggle', methods: ['POST'], requirements: ['id' => '\d+', 'type' => 'computer|printer|monitor|payment_terminal'])]
    #[IsGranted('ROLE_SUPER_ADMIN')]
    public function toggleAdmin(Request $request, Company $company, string $type): RedirectResponse
    {
        $listType = InventoryListType::from($type);
        $this->validateCsrf('inventory_toggle_'.$company->getId().'_'.$listType->value, $request);
        $enabled = $request->request->getBoolean('enabled');
        $this->inventoryService->setEnabled($company, $listType, $enabled, $this->currentUser());
        $this->addFlash('success', sprintf('%s %s för %s.', $listType->label(), $enabled ? 'aktiverades' : 'inaktiverades', $company->getName()));

        return $this->redirectToRoute('app_portal_admin_companies_index');
    }

    #[Route('/portal/admin/companies/{id}/inventory/{type}/import', name: 'app_inventory_admin_import', methods: ['POST'], requirements: ['id' => '\d+', 'type' => 'computer|printer|monitor|payment_terminal'])]
    #[IsGranted('ROLE_SUPER_ADMIN')]
    public function importAdmin(Request $request, Company $company, string $type): RedirectResponse
    {
        $listType = InventoryListType::from($type);
        $this->validateCsrf('inventory_import_'.$company->getId().'_'.$listType->value, $request);
        $file = $request->files->get('inventory_csv');
        if (!$file instanceof UploadedFile) {
            $this->addFlash('error', 'Välj en CSV-fil att importera.');

            return $this->redirectToRoute('app_portal_admin_companies_index');
        }

        try {
            $result = $this->inventoryService->importCsv($company, $listType, $file, $this->currentUser());
            $this->addFlash('success', sprintf('%s importerades för %s: %d rader skapades och %d gamla rader ersattes.', $listType->label(), $company->getName(), $result['imported'], $result['removed']));
        } catch (\Throwable $exception) {
            $this->addFlash('error', sprintf('Importen misslyckades: %s', $exception->getMessage()));
        }

        return $this->redirectToRoute('app_portal_admin_companies_index');
    }

    #[Route('/portal/admin/companies/{id}/inventory/{type}/delete', name: 'app_inventory_admin_delete', methods: ['POST'], requirements: ['id' => '\d+', 'type' => 'computer|printer|monitor|payment_terminal'])]
    #[IsGranted('ROLE_SUPER_ADMIN')]
    public function deleteAdmin(Request $request, Company $company, string $type): RedirectResponse
    {
        $listType = InventoryListType::from($type);
        $this->validateCsrf('inventory_delete_list_'.$company->getId().'_'.$listType->value, $request);

        if (!$request->request->getBoolean('confirm_delete') || 'TA BORT LISTA' !== trim((string) $request->request->get('confirm_phrase'))) {
            $this->addFlash('error', 'Listan togs inte bort. Bekräfta raderingen och skriv TA BORT LISTA exakt.');

            return $this->redirectToRoute('app_portal_admin_companies_index');
        }

        $deleted = $this->inventoryService->deleteList($company, $listType, $this->currentUser());
        $this->addFlash('success', sprintf('%s för %s togs bort permanent. %d rader raderades.', $listType->label(), $company->getName(), $deleted));

        return $this->redirectToRoute('app_portal_admin_companies_index');
    }

    #[Route('/portal/admin/companies/{id}/inventory/{type}/access', name: 'app_inventory_admin_access', methods: ['POST'], requirements: ['id' => '\d+', 'type' => 'computer|printer|monitor|payment_terminal'])]
    #[IsGranted('ROLE_SUPER_ADMIN')]
    public function accessAdmin(Request $request, Company $company, string $type): RedirectResponse
    {
        $listType = InventoryListType::from($type);
        $this->validateCsrf('inventory_access_'.$company->getId().'_'.$listType->value, $request);

        $restricted = 'restricted' === (string) $request->request->get('access_mode');
        $allowedUserIds = $this->allowedUserIdsFromRequest($request);
        $this->inventoryService->setAccess($company, $listType, $restricted, $allowedUserIds, $this->currentUser());

        $this->addFlash('success', sprintf(
            'Synligheten för %s hos %s sparades.',
            mb_strtolower($listType->label()),
            $company->getName(),
        ));

        return $this->redirectToRoute('app_portal_admin_companies_index');
    }

    private function customerList(Request $request, InventoryListType $type): Response
    {
        $user = $this->currentUser();
        $company = $user->getCompany();
        if (!$company instanceof Company || !$this->inventoryService->canUserAccessList($user, $type)) {
            throw $this->createNotFoundException('Listan är inte aktiverad för kunden.');
        }

        $query = trim((string) $request->query->get('q'));
        $sort = trim((string) $request->query->get('sort'));
        $direction = 'desc' === strtolower((string) $request->query->get('direction')) ? 'desc' : 'asc';
        $items = $this->inventoryService->items($company, $type, $query, $sort, $direction);

        if ('csv' === $request->query->get('export')) {
            return $this->csvResponse($company, $type, $items);
        }

        if ('excel' === $request->query->get('export')) {
            return $this->excelResponse($company, $type, $items);
        }

        return $this->render('inventory/customer_list.html.twig', [
            'company' => $company,
            'type' => $type,
            'columns' => $this->inventoryService->columns($type),
            'items' => $items,
            'query' => $query,
            'sort' => $sort,
            'direction' => $direction,
            'customerSidebar' => $this->buildCustomerSidebarViewData($user, match ($type) {
                InventoryListType::COMPUTER => 'inventory-computers',
                InventoryListType::PRINTER => 'inventory-printers',
                InventoryListType::MONITOR => 'inventory-monitors',
                InventoryListType::PAYMENT_TERMINAL => 'inventory-payment-terminals',
            }),
            'knowledgeBaseSettings' => $this->systemSettings->getKnowledgeBaseSettings(),
        ]);
    }

    private function company(int $companyId): Company
    {
        $company = $this->entityManager->getRepository(Company::class)->find($companyId);
        if (!$company instanceof Company) {
            throw $this->createNotFoundException('Företaget kunde inte hittas.');
        }

        return $company;
    }

    private function denyUnlessEnabled(Company $company, InventoryListType $type): void
    {
        if (!$this->inventoryService->isEnabled($company, $type)) {
            throw $this->createNotFoundException('Listan är inte aktiverad.');
        }
    }

    private function denyUnlessInventoryStaff(): void
    {
        if (!$this->isGranted('ROLE_TECHNICIAN') && !$this->isGranted('ROLE_TICKET_COORDINATOR')) {
            throw $this->createAccessDeniedException('Du har inte åtkomst till inventarielistor.');
        }
    }

    private function currentUser(): User
    {
        $user = $this->getUser();
        \assert($user instanceof User);

        return $user;
    }

    private function validateCsrf(string $id, Request $request): void
    {
        if (!$this->isCsrfTokenValid($id, (string) $request->request->get('_token'))) {
            throw $this->createAccessDeniedException('Formuläret kunde inte verifieras.');
        }
    }

    /**
     * @return list<int>
     */
    private function allowedUserIdsFromRequest(Request $request): array
    {
        $submitted = $request->request->all('allowed_user_ids');
        $ids = [];
        foreach ($submitted as $key => $value) {
            $candidate = \is_int($key) || ctype_digit((string) $key) ? (string) $key : (string) $value;
            if (ctype_digit($candidate)) {
                $ids[] = (int) $candidate;
            }
        }

        return array_values(array_unique($ids));
    }

    /**
     * @return array<string, mixed>
     */
    private function buildCustomerSidebarViewData(User $user, string $activePage): array
    {
        $visibleTickets = $this->customerTicketQuery->findAccessibleTickets($user);
        $ownTickets = $this->customerTicketQuery->findOwnTickets($user);
        $companyTickets = $this->customerTicketQuery->findCompanyTicketsForAllowedCustomer($user);
        $openCount = \count(array_filter($ownTickets, fn (Ticket $ticket): bool => $this->isTicketOpenForCustomer($ticket)));
        $closedCount = \count(array_filter($ownTickets, fn (Ticket $ticket): bool => $this->isTicketClosedForCustomer($ticket)));

        return [
            'activePage' => $activePage,
            'knowledgeBaseEnabled' => $this->systemSettings->getKnowledgeBaseSettings()['customerEnabled'],
            'mfaAvailable' => $this->mfaPolicyResolver->isMfaAvailable($user),
            'mfaEnabled' => $user->isMfaEnabled(),
            'reportsEnabled' => $this->systemSettings->getReportSettings()['customerEnabled'],
            'ticketSummary' => [
                'total' => \count($ownTickets),
                'open' => $openCount,
                'resolved' => $closedCount,
            ],
            'ownTicketSummary' => [
                'total' => \count($ownTickets),
                'open' => $openCount,
                'resolved' => $closedCount,
            ],
            'companyTicketsEnabled' => \count($companyTickets) > \count($ownTickets) || \count($visibleTickets) > \count($ownTickets),
            'companyTicketSummary' => [
                'total' => \count($companyTickets),
                'open' => \count(array_filter($companyTickets, fn (Ticket $ticket): bool => $this->isTicketOpenForCustomer($ticket))),
                'resolved' => \count(array_filter($companyTickets, fn (Ticket $ticket): bool => $this->isTicketClosedForCustomer($ticket))),
            ],
            'waitingOnCustomer' => \count(array_filter($ownTickets, static fn (Ticket $ticket): bool => TicketStatus::PENDING_CUSTOMER === $ticket->getStatus())),
            'viewLabel' => 'Inventarie',
            'viewNote' => 'Du visar inventarielistor för ditt företag.',
            'actionItems' => [],
        ];
    }

    private function isTicketOpenForCustomer(Ticket $ticket): bool
    {
        return \in_array($ticket->getStatus(), [TicketStatus::NEW, TicketStatus::OPEN, TicketStatus::IN_PROGRESS, TicketStatus::PENDING_CUSTOMER, TicketStatus::ON_HOLD], true);
    }

    private function isTicketClosedForCustomer(Ticket $ticket): bool
    {
        return \in_array($ticket->getStatus(), [TicketStatus::RESOLVED, TicketStatus::CLOSED], true);
    }

    /**
     * @param list<InventoryItem> $items
     */
    private function csvResponse(Company $company, InventoryListType $type, array $items): StreamedResponse
    {
        $filename = $this->filename($company, $type, 'csv');
        $columns = $this->inventoryService->columns($type);

        return new StreamedResponse(function () use ($columns, $items): void {
            $handle = fopen('php://output', 'w');
            \assert(false !== $handle);
            fwrite($handle, "\xEF\xBB\xBF");
            fputcsv($handle, array_column($columns, 'label'), ',', '"', '');
            foreach ($items as $item) {
                fputcsv($handle, array_map(fn (array $column): string => $this->inventoryService->value($item, $column['key']), $columns), ',', '"', '');
            }
            fclose($handle);
        }, Response::HTTP_OK, [
            'Content-Type' => 'text/csv; charset=UTF-8',
            'Content-Disposition' => sprintf('attachment; filename="%s"', $filename),
        ]);
    }

    /**
     * @param list<InventoryItem> $items
     */
    private function excelResponse(Company $company, InventoryListType $type, array $items): Response
    {
        return $this->render('inventory/export_excel.html.twig', [
            'company' => $company,
            'type' => $type,
            'columns' => $this->inventoryService->columns($type),
            'items' => $items,
            'filename' => $this->filename($company, $type, 'xls'),
        ], new Response('', Response::HTTP_OK, [
            'Content-Type' => 'application/vnd.ms-excel; charset=UTF-8',
            'Content-Disposition' => sprintf('attachment; filename="%s"', $this->filename($company, $type, 'xls')),
        ]));
    }

    private function filename(Company $company, InventoryListType $type, string $extension): string
    {
        $companyName = preg_replace('/[^a-z0-9]+/i', '-', strtolower($company->getName())) ?: 'kund';

        return sprintf('%s-%s.%s', trim($companyName, '-'), $type->value, $extension);
    }
}
