<?php

declare(strict_types=1);

namespace App\Module\Mail\Service;

use App\Module\Identity\Entity\User;
use App\Module\Identity\Enum\UserType;
use App\Module\Mail\Entity\DraftTicketReview;
use App\Module\Mail\Entity\IncomingMail;
use App\Module\Mail\Entity\IncomingMailAlias;
use App\Module\Mail\Entity\SupportMailbox;
use App\Module\Mail\Enum\IncomingMailProcessingResult;
use App\Module\Mail\Enum\DraftTicketReviewKind;
use App\Module\Ticket\Entity\Ticket;
use App\Module\Ticket\Entity\TicketComment;
use App\Module\Ticket\Entity\ImportedTicketPerson;
use App\Module\Ticket\Enum\ImportedTicketPersonRole;
use App\Module\Ticket\Enum\TicketEscalationLevel;
use App\Module\Ticket\Enum\TicketImpactLevel;
use App\Module\Ticket\Enum\TicketPriority;
use App\Module\Ticket\Enum\TicketRequestType;
use App\Module\Ticket\Enum\TicketStatus;
use App\Module\Ticket\Enum\TicketVisibility;
use App\Module\Ticket\Service\AttachmentCopyResult;
use App\Module\Ticket\Service\TicketAccessPolicy;
use App\Module\Ticket\Service\TicketAuditLogger;
use App\Module\Ticket\Service\TicketLifecycleService;
use App\Module\Ticket\Service\TicketMergeService;
use App\Module\Ticket\Service\TicketReferenceGenerator;
use App\Module\Ticket\Service\TicketResponseNotifier;
use App\Module\System\Service\SystemSettings;
use App\Module\System\Service\InternalReportNotifier;
use App\Module\System\Service\SystemAuditLogger;
use App\Module\System\Entity\InternalReport;
use App\Module\System\Entity\InternalReportResponse;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\Lock\LockFactory;

final class IncomingMailProcessor
{
    public function __construct(
        private readonly EntityManagerInterface $entityManager,
        private readonly TicketAuditLogger $ticketAuditLogger,
        private readonly TicketLifecycleService $ticketLifecycleService,
        private readonly TicketMergeService $ticketMergeService,
        private readonly TicketReferenceGenerator $ticketReferenceGenerator,
        private readonly TicketResponseNotifier $ticketResponseNotifier,
        private readonly SystemSettings $systemSettings,
        private readonly IncomingMailAttachmentStorage $incomingMailAttachmentStorage,
        private readonly InternalReportNotifier $internalReportNotifier,
        private readonly SystemAuditLogger $systemAuditLogger,
        private readonly AutomaticCustomerRegistration $automaticCustomerRegistration,
        private readonly LockFactory $lockFactory,
        private readonly TicketAccessPolicy $ticketAccessPolicy,
        private readonly CompanySenderDomainResolver $companySenderDomainResolver,
    ) {
    }

    public function process(IncomingMail $incomingMail): IncomingMail
    {
        // Alla inkorgar delar låset eftersom kundadresser och standardärendeserien är globala.
        $lock = $this->lockFactory->createLock('incoming-mail-processing', 300.0);
        if (!$lock->acquire(true)) {
            throw new \RuntimeException('Kunde inte låsa inkommande mejlbehandling. Försök igen.');
        }
        try {
            if (null !== $incomingMail->getId() && $this->entityManager->contains($incomingMail)) {
                $this->entityManager->refresh($incomingMail);
            }

            return $this->processLocked($incomingMail);
        } finally {
            $lock->release();
        }
    }

    private function processLocked(IncomingMail $incomingMail): IncomingMail
    {
        if (null !== $incomingMail->getProcessingResult()) {
            return $incomingMail;
        }

        $matchedInternalReport = $this->findInternalReportReply($incomingMail);
        if ($matchedInternalReport instanceof InternalReport && '' !== trim($incomingMail->getBody())) {
            $this->appendResponseToInternalReport($matchedInternalReport, $incomingMail);

            return $incomingMail;
        }

        $matchedUser = $this->entityManager->getRepository(User::class)->findOneBy([
            'email' => $incomingMail->getFromEmail(),
        ]);
        $matchedAlias = null;
        if (!$matchedUser instanceof User) {
            $matchedAlias = $this->entityManager->getRepository(IncomingMailAlias::class)->findOneBy([
                'email' => IncomingMailAlias::normalizeEmail($incomingMail->getFromEmail()),
            ]);
            if ($matchedAlias instanceof IncomingMailAlias) {
                $aliasUser = $matchedAlias->getUser();
                $matchedUser = $aliasUser instanceof User && \in_array($aliasUser->getType(), [UserType::CUSTOMER, UserType::PRIVATE_CUSTOMER], true)
                    ? $aliasUser
                    : null;
            }
        }
        if ($this->automaticCustomerRegistration->applies($incomingMail->getMailbox())) {
            $matchedAlias ??= $this->entityManager->getRepository(IncomingMailAlias::class)->findOneBy([
                'email' => IncomingMailAlias::normalizeEmail($incomingMail->getFromEmail()),
            ]);
            $reason = $this->automaticCustomerRegistration->reviewReason($incomingMail, $matchedUser, $matchedAlias);
            if (null !== $reason) {
                $incomingMail->setMatchedUser($matchedUser)->setMatchedCompany($matchedUser?->getCompany() ?? $this->senderDomainCompany($incomingMail, $matchedUser));
                $this->createDraftReview($incomingMail, $reason, null, $matchedUser, null !== $matchedAlias);

                return $incomingMail;
            }
        }
        $matchedCompany = $matchedUser?->getCompany() ?? ($matchedAlias instanceof IncomingMailAlias ? $matchedAlias->getCompany() : null);
        $matchedTicket = $this->findTicketForIncomingMail($incomingMail, $matchedCompany);
        $matchedSourceReference = $matchedTicket?->getReference();
        if ($matchedTicket instanceof Ticket) {
            $matchedTicket = $this->ticketMergeService->effectiveTicket($matchedTicket);
        }
        // Domänkopplingen styr bara vilket bolag utkast och nya kunder hamnar på, inte ärendematchningen ovan.
        $routingCompany = $matchedCompany ?? $this->senderDomainCompany($incomingMail, $matchedUser);
        $incomingMail
            ->setMatchedUser($matchedUser instanceof User ? $matchedUser : null)
            ->setMatchedCompany($routingCompany)
            ->setMatchedTicket($matchedTicket);

        if ($this->mailboxRejectsUnknownSender($incomingMail, $matchedUser, $routingCompany)
            && ($matchedTicket instanceof Ticket || $this->isReplyOrForwardSubject($incomingMail->getSubject()))) {
            return $this->rejectUnknownSender($incomingMail);
        }

        if ($matchedTicket instanceof Ticket) {
            if ($matchedUser instanceof User && $this->userCanReplyToTicket($matchedUser, $matchedTicket)) {
                $this->appendCommentToTicket($matchedTicket, $matchedUser, $incomingMail, $matchedSourceReference);

                return $incomingMail;
            }

            $reason = $matchedUser instanceof User
                ? 'Avsändaren matchade inte någon behörig person på ärendet.'
                : 'Okänd avsändare försökte svara på ett befintligt ärende.';

            $this->createDraftReview($incomingMail, $reason, $matchedTicket, $matchedUser, $matchedAlias instanceof IncomingMailAlias);

            return $incomingMail;
        }

        if ($this->isReplyOrForwardSubject($incomingMail->getSubject())) {
            $this->createDraftReview(
                $incomingMail,
                'Mejlet ser ut som ett svar eller en vidarebefordran men kunde inte entydigt kopplas till ett aktivt ärende.',
                null,
                $matchedUser instanceof User ? $matchedUser : null,
                $matchedAlias instanceof IncomingMailAlias,
            );

            return $incomingMail;
        }

        if (!$matchedUser instanceof User && $this->automaticCustomerRegistration->canRegister($incomingMail)) {
            $requester = $this->entityManager->wrapInTransaction(function () use ($incomingMail): User {
                $requester = $this->automaticCustomerRegistration->createCustomer($incomingMail);
                $this->entityManager->persist($requester);
                $incomingMail->setMatchedUser($requester)->setMatchedCompany($requester->getCompany());
                $this->createTicketFromKnownSender($incomingMail, $requester, false);
                $this->systemAuditLogger->log(
                    null,
                    'incoming_mail.customer_registered',
                    'Kundperson skapad automatiskt från e-post',
                    sprintf('Kund %s, företag %s, inkorg %s, mejl %d, ärende %s. Portalåtkomst är avstängd.',
                        $requester->getEmail(), $requester->getCompany()->getName(),
                        $incomingMail->getMailbox()->getEmailAddress(), $incomingMail->getId(),
                        $incomingMail->getMatchedTicket()->getReference()),
                );

                return $requester;
            });
            $this->notifyNewTicket($incomingMail, $requester);

            return $incomingMail;
        }

        if ($matchedUser instanceof User) {
            if ($this->automaticCustomerRegistration->applies($incomingMail->getMailbox())) {
                $this->entityManager->wrapInTransaction(function () use ($incomingMail, $matchedUser): void {
                    $this->createTicketFromKnownSender($incomingMail, $matchedUser, false);
                });
                $this->notifyNewTicket($incomingMail, $matchedUser);
            } else {
                $this->createTicketFromKnownSender($incomingMail, $matchedUser);
            }

            return $incomingMail;
        }

        if (!$incomingMail->getMailbox() instanceof SupportMailbox || $this->mailboxRejectsUnknownSender($incomingMail, null, $routingCompany)) {
            return $this->rejectUnknownSender($incomingMail);
        }

        $reason = $routingCompany instanceof \App\Module\Identity\Entity\Company
            ? 'Avsändaren matchade ett företag men ingen kundperson och kräver manuell granskning.'
            : 'Okänd avsändare kräver manuell granskning innan ärendet kan kopplas.';
        $this->createDraftReview($incomingMail, $reason, null, null, $matchedAlias instanceof IncomingMailAlias);

        return $incomingMail;
    }

    /**
     * Inkorgens regel för okända avsändare gäller även svar och vidarebefordringar,
     * annars kan vem som helst skapa utkast och koordinatornotiser med ett "Re:"-ämne.
     */
    private function mailboxRejectsUnknownSender(IncomingMail $incomingMail, ?User $matchedUser, ?\App\Module\Identity\Entity\Company $matchedCompany): bool
    {
        $mailbox = $incomingMail->getMailbox();

        return $mailbox instanceof SupportMailbox
            && !$mailbox->allowsUnknownSenders()
            && !$matchedUser instanceof User
            && !$matchedCompany instanceof \App\Module\Identity\Entity\Company;
    }

    private function senderDomainCompany(IncomingMail $incomingMail, ?User $matchedUser): ?\App\Module\Identity\Entity\Company
    {
        if ($matchedUser instanceof User) {
            return null;
        }

        return $this->companySenderDomainResolver->resolve($incomingMail->getMailbox(), $incomingMail->getFromEmail());
    }

    private function rejectUnknownSender(IncomingMail $incomingMail): IncomingMail
    {
        $incomingMail->markProcessed(IncomingMailProcessingResult::REJECTED, 'Avsändaren är okänd och inkorgen tillåter inte okända avsändare.');
        $this->entityManager->persist($incomingMail);
        $this->entityManager->flush();

        return $incomingMail;
    }

    private function findInternalReportReply(IncomingMail $incomingMail): ?InternalReport
    {
        $authorizedSender = $this->systemSettings->getInternalReportSettings()['recipient'];
        if ('' === $authorizedSender || mb_strtolower(trim($incomingMail->getFromEmail())) !== $authorizedSender) {
            return null;
        }

        if (1 !== preg_match('/\[DRIFTPUNKT-RAPPORT\s+([0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12})\]/i', $incomingMail->getSubject(), $matches)) {
            return null;
        }

        $report = $this->entityManager->getRepository(InternalReport::class)->findOneBy([
            'publicReference' => mb_strtolower($matches[1]),
        ]);

        return $report instanceof InternalReport ? $report : null;
    }

    private function appendResponseToInternalReport(InternalReport $report, IncomingMail $incomingMail): void
    {
        $originalBody = trim($incomingMail->getBody());
        $responseBody = mb_substr($originalBody, 0, 20000);
        $wasTruncated = mb_strlen($originalBody) > 20000;
        $contentHash = InternalReportResponse::buildContentHash($report, $incomingMail->getFromEmail(), $responseBody);
        $existingResponse = null !== $incomingMail->getMessageId()
            ? $this->entityManager->getRepository(InternalReportResponse::class)->findOneBy(['incomingMail' => $incomingMail])
            : $this->entityManager->getRepository(InternalReportResponse::class)->findOneBy(['contentHash' => $contentHash]);

        if ($existingResponse instanceof InternalReportResponse) {
            $incomingMail->markProcessed(
                IncomingMailProcessingResult::INTERNAL_REPORT_RESPONSE_ADDED,
                sprintf('Dubblett av svar till intern rapport %s ignorerades.', $report->getPublicReference()),
            );
            $this->entityManager->flush();

            return;
        }

        $response = new InternalReportResponse(
            $report,
            $incomingMail,
            $incomingMail->getFromEmail(),
            $responseBody,
        );
        $report->markInProgressFromResponse();
        $attachmentNote = [] !== $incomingMail->getAttachmentMetadata()
            ? ' Bilagor ignorerades för rapportsvaret.'
            : '';
        $truncationNote = $wasTruncated ? ' Svaret kortades till 20 000 tecken; originalet finns kvar i inkommande e-post.' : '';
        $incomingMail->markProcessed(
            IncomingMailProcessingResult::INTERNAL_REPORT_RESPONSE_ADDED,
            sprintf('Svar lades till i intern rapport %s.%s%s', $report->getPublicReference(), $attachmentNote, $truncationNote),
        );

        $this->entityManager->persist($response);
        $this->entityManager->flush();
        $this->systemAuditLogger->log(
            null,
            'internal_report.response_imported',
            'E-postsvar kopplat till intern rapport',
            sprintf('Svar från %s kopplades till rapport %s.', $incomingMail->getFromEmail(), $report->getPublicReference()),
        );
        $this->internalReportNotifier->notifyReporterOfResponse($report, $response);
    }

    private function createTicketFromKnownSender(IncomingMail $incomingMail, User $requester, bool $notify = true): void
    {
        $mailbox = $incomingMail->getMailbox();
        $resolvedCompany = $requester->getCompany() ?? $mailbox?->getCompany();

        $ticket = new Ticket(
            $this->ticketReferenceGenerator->nextReference($resolvedCompany),
            $incomingMail->getSubject(),
            $incomingMail->getBody(),
            TicketStatus::NEW,
            TicketVisibility::PRIVATE,
            $mailbox?->getDefaultPriority() ?? TicketPriority::NORMAL,
            TicketRequestType::INCIDENT,
            TicketImpactLevel::SINGLE_USER,
            TicketEscalationLevel::NONE,
        );
        $ticket
            ->setRequester($requester)
            ->setCompany($resolvedCompany)
            ->setCategory($mailbox?->getDefaultCategory())
            ->setAssignedTeam($mailbox?->getDefaultTeam());
        $automaticStatusChange = $this->markTicketOpenWhenRouted($ticket, 'inkommande e-post routades');

        $this->entityManager->persist($ticket);
        $this->entityManager->persist($incomingMail);
        $this->entityManager->flush();

        $attachmentResult = AttachmentCopyResult::empty();
        if ([] !== $incomingMail->getAttachmentMetadata()) {
            $comment = new TicketComment($ticket, $requester, $incomingMail->getBody(), false);
            $ticket->addComment($comment);
            $this->entityManager->persist($comment);
            $attachmentResult = $this->attachIncomingMailAttachmentsToComment($incomingMail, $ticket, $comment);
        }

        $incomingMail
            ->setMatchedTicket($ticket)
            ->markProcessed(
                IncomingMailProcessingResult::TICKET_CREATED,
                sprintf(
                    'Nytt ärende %s skapades från känd avsändare%s.',
                    $ticket->getReference(),
                    $this->formatAttachmentProcessingSuffix($attachmentResult),
                ),
            );

        $this->entityManager->flush();
        $this->ticketAuditLogger->log(
            $ticket,
            'incoming_mail_ticket_created',
            sprintf(
                'Ärende skapades från inkommande e-post via %s%s.',
                $mailbox?->getEmailAddress() ?? 'okänd inkorg',
                $this->formatAttachmentAuditSuffix($attachmentResult),
            ),
            $requester,
        );
        if (null !== $automaticStatusChange) {
            $this->ticketAuditLogger->log($ticket, 'ticket_updated', $automaticStatusChange.'.', $requester);
        }

        if ($notify) {
            $this->notifyNewTicket($incomingMail, $requester);
        }
    }

    private function notifyNewTicket(IncomingMail $incomingMail, User $requester): void
    {
        $ticket = $incomingMail->getMatchedTicket();
        $this->ticketResponseNotifier->notifyIncomingMailTicketReceived(
            $ticket,
            $incomingMail->getFromEmail(),
            $requester->getDisplayName(),
            $requester,
        );
        try {
            $this->ticketResponseNotifier->notifyTicketCreatedForTriage($ticket);
        } catch (\Throwable) {
            // Ärendet och kundbekräftelsen ska inte påverkas om triage-notisen misslyckas.
        }
    }

    private function appendCommentToTicket(Ticket $ticket, User $author, IncomingMail $incomingMail, ?string $matchedSourceReference = null): void
    {
        $comment = new TicketComment($ticket, $author, $incomingMail->getBody(), false);
        $ticket->addComment($comment);
        $ticket->setStatus(TicketStatus::OPEN);

        $this->entityManager->persist($comment);
        $attachmentResult = $this->attachIncomingMailAttachmentsToComment($incomingMail, $ticket, $comment);
        $this->entityManager->persist($incomingMail);
        $this->entityManager->flush();

        $incomingMail->markProcessed(
            IncomingMailProcessingResult::COMMENT_ADDED,
            sprintf(
                'Svar lades till i ärende %s%s.',
                $ticket->getReference(),
                $this->formatAttachmentProcessingSuffix($attachmentResult),
            ),
        );
        $this->entityManager->flush();

        $this->ticketAuditLogger->log(
            $ticket,
            'incoming_mail_comment_added',
            sprintf(
                'Inkommande e-post från %s lades till som kundsvar%s%s.',
                $incomingMail->getFromEmail(),
                null !== $matchedSourceReference && $matchedSourceReference !== $ticket->getReference()
                    ? sprintf(' via sammanslaget ärende %s', $matchedSourceReference)
                    : '',
                $this->formatAttachmentAuditSuffix($attachmentResult),
            ),
            $author,
        );

        if ($ticket->getAssignee() instanceof User && $ticket->getAssignee()->getId() !== $author->getId()) {
            $this->ticketResponseNotifier->notifyTechnicianWaitingForReply($ticket, $comment);
        }
    }

    private function createDraftReview(IncomingMail $incomingMail, string $reason, ?Ticket $matchedTicket, ?User $matchedUser, bool $knownAlias = false): void
    {
        $mailbox = $incomingMail->getMailbox();
        $draftTicket = null;
        $reviewKind = $matchedUser instanceof User
            ? DraftTicketReviewKind::UNAUTHORIZED_REPLY
            : DraftTicketReviewKind::UNKNOWN_SENDER;

        if ($mailbox instanceof SupportMailbox && (DraftTicketReviewKind::UNKNOWN_SENDER === $reviewKind || $mailbox->createsDraftTicketsForUnknownSenders())) {
            $draftCompany = $matchedUser?->getCompany() ?? $incomingMail->getMatchedCompany() ?? $mailbox->getCompany();
            $draftTicket = new Ticket(
                $this->ticketReferenceGenerator->nextReference($draftCompany),
                sprintf('[Utkast] %s', $incomingMail->getSubject()),
                $incomingMail->getBody(),
                TicketStatus::NEW,
                TicketVisibility::INTERNAL_ONLY,
                $mailbox->getDefaultPriority() ?? TicketPriority::NORMAL,
                TicketRequestType::INCIDENT,
                TicketImpactLevel::SINGLE_USER,
                TicketEscalationLevel::NONE,
            );
            $draftTicket
                ->setCompany($draftCompany)
                ->setCategory($mailbox->getDefaultCategory())
                ->setAssignedTeam($mailbox->getDefaultTeam());

            if (DraftTicketReviewKind::UNKNOWN_SENDER === $reviewKind && !$knownAlias) {
                $senderEmail = mb_strtolower(trim($incomingMail->getFromEmail()));
                $senderName = trim((string) $incomingMail->getFromName());
                $draftTicket->addImportedPerson(new ImportedTicketPerson(
                    $draftTicket,
                    ImportedTicketPersonRole::REQUESTER,
                    '' !== $senderName ? $senderName : $senderEmail,
                    'incoming_mail',
                    $senderEmail,
                ));
            }

            $this->entityManager->persist($draftTicket);
        }

        $review = new DraftTicketReview($incomingMail, $reason, $reviewKind);
        $review
            ->setMailbox($mailbox)
            ->setDraftTicket($draftTicket)
            ->setMatchedTicket($matchedTicket)
            ->setMatchedCompany($matchedUser?->getCompany() ?? $incomingMail->getMatchedCompany() ?? $mailbox?->getCompany());

        $incomingMail->markProcessed(
            IncomingMailProcessingResult::DRAFT_REVIEW_CREATED,
            $draftTicket instanceof Ticket
                ? sprintf('Utkastgranskning skapades tillsammans med internt ärende %s.', $draftTicket->getReference())
                : 'Utkastgranskning skapades utan automatiskt ärende.',
        );

        $this->entityManager->persist($incomingMail);
        $this->entityManager->persist($review);
        $this->entityManager->flush();

        $this->systemAuditLogger->log(
            null,
            'incoming_mail.review_created',
            'Inkommande mejl kräver granskning',
            sprintf('Mejl %d, inkorg %s, företag %s: %s', $incomingMail->getId(),
                $mailbox?->getEmailAddress() ?? 'saknas',
                $incomingMail->getMailbox()?->getCompany()?->getName() ?? 'saknas', $reason),
        );

        if ($draftTicket instanceof Ticket) {
            $this->ticketAuditLogger->log(
                $draftTicket,
                'incoming_mail_draft_review_created',
                sprintf('Utkastärende skapades för manuell granskning: %s', $reason),
            );
        }

        $this->ticketResponseNotifier->notifyUnknownSenderReviewCreated($review);
    }

    private function findTicketForIncomingMail(IncomingMail $incomingMail, ?\App\Module\Identity\Entity\Company $company): ?Ticket
    {
        foreach ([$incomingMail->getSubject(), $incomingMail->getBody()] as $content) {
            if (!preg_match($this->ticketReferenceGenerator->ticketReferenceRegex(), $content, $matches)) {
                continue;
            }

            $ticket = $this->entityManager->getRepository(Ticket::class)->findOneBy([
                'reference' => strtoupper($matches[1]),
            ]);
            if ($ticket instanceof Ticket) {
                return $ticket;
            }
        }

        if (!$company instanceof \App\Module\Identity\Entity\Company) {
            return null;
        }

        $normalizedSubject = $this->normalizeReplySubject($incomingMail->getSubject());
        if ('' === $normalizedSubject) {
            return null;
        }

        $candidates = $this->entityManager->getRepository(Ticket::class)->createQueryBuilder('ticket')
            ->andWhere('ticket.company = :company')
            ->andWhere('ticket.status NOT IN (:closedStatuses)')
            ->setParameter('company', $company)
            ->setParameter('closedStatuses', $this->ticketLifecycleService->closedStatuses())
            ->orderBy('ticket.createdAt', 'DESC')
            ->setMaxResults(25)
            ->getQuery()
            ->getResult();

        $matches = array_values(array_filter(
            $candidates,
            fn (mixed $ticket): bool => $ticket instanceof Ticket
                && $this->normalizeReplySubject($ticket->getSubject()) === $normalizedSubject,
        ));

        return 1 === \count($matches) ? $matches[0] : null;
    }

    private function normalizeReplySubject(string $subject): string
    {
        $normalized = trim($subject);
        do {
            $previous = $normalized;
            $normalized = trim((string) preg_replace('/^(?:re|sv|fw|fwd|vb)\s*:\s*/iu', '', $normalized));
        } while ($normalized !== $previous);

        $normalized = trim((string) preg_replace('/\[[A-Z0-9]+(?:-[A-Z0-9]+)+\]\s*/iu', '', $normalized));

        return mb_strtolower((string) preg_replace('/\s+/u', ' ', $normalized));
    }

    private function isReplyOrForwardSubject(string $subject): bool
    {
        return 1 === preg_match('/^\s*(?:re|sv|fw|fwd|vb)\s*:/iu', $subject);
    }

    private function userCanReplyToTicket(User $user, Ticket $ticket): bool
    {
        // Samma regler som i portalen, så att mejl inte ger bredare åtkomst än webben.
        if (\in_array($user->getType(), [UserType::SUPER_ADMIN, UserType::ADMIN, UserType::TECHNICIAN], true)) {
            return $this->ticketAccessPolicy->technicianCanReadTicket($user, $ticket);
        }

        return $this->ticketAccessPolicy->customerCanAccessTicket($user, $ticket);
    }

    /**
     */
    private function attachIncomingMailAttachmentsToComment(IncomingMail $incomingMail, Ticket $ticket, TicketComment $comment): AttachmentCopyResult
    {
        if ([] === $incomingMail->getAttachmentMetadata()) {
            return AttachmentCopyResult::empty();
        }

        $result = $this->incomingMailAttachmentStorage->copyIncomingMailAttachmentsToTicketComment(
            $incomingMail,
            $ticket,
            $comment,
            $this->systemSettings->getTicketAttachmentSettings(),
        );

        foreach ($result->getCreatedAttachments() as $attachment) {
            $comment->addAttachment($attachment);
            $this->entityManager->persist($attachment);
        }

        return $result;
    }

    private function formatAttachmentProcessingSuffix(AttachmentCopyResult $result): string
    {
        $parts = [];
        $createdCount = $result->getCreatedAttachmentCount();
        if ($createdCount > 0) {
            $parts[] = sprintf('med %d bilag%s', $createdCount, 1 === $createdCount ? 'a' : 'or');
        }

        if ($result->hasSkippedDuplicates()) {
            $parts[] = sprintf(
                '%s%d dubblettbilag%s hoppades över',
                0 === $createdCount ? 'och ' : '',
                $result->getSkippedDuplicateCount(),
                1 === $result->getSkippedDuplicateCount() ? 'a' : 'or',
            );
        }

        return [] !== $parts ? ' '.implode(' och ', $parts) : '';
    }

    private function formatAttachmentAuditSuffix(AttachmentCopyResult $result): string
    {
        $parts = [];
        $createdCount = $result->getCreatedAttachmentCount();
        if ($createdCount > 0) {
            $parts[] = sprintf('%d bilag%s kopierades in', $createdCount, 1 === $createdCount ? 'a' : 'or');
        }

        if ($result->hasSkippedDuplicates()) {
            $parts[] = sprintf('%d dubblettbilag%s hoppades över', $result->getSkippedDuplicateCount(), 1 === $result->getSkippedDuplicateCount() ? 'a' : 'or');
        }

        return [] !== $parts ? ' och '.implode(' och ', $parts) : '';
    }

    private function markTicketOpenWhenRouted(Ticket $ticket, string $reason): ?string
    {
        $previousStatus = $this->ticketLifecycleService->markOpenWhenRouted($ticket);
        if (!$previousStatus instanceof TicketStatus) {
            return null;
        }

        return sprintf('status %s -> %s, %s', $previousStatus->label(), $ticket->getStatus()->label(), $reason);
    }
}
