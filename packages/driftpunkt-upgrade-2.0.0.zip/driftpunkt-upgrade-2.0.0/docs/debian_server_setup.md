# Debian-server: krav och installation

Den här guiden är den kortaste vägen till en vanlig Debian-installation utan Docker. Den utgår från att appen ligger i `/var/www/driftpunkt`, körs av `www-data` och exponeras via Apache. Om Apache kör vhosten med `mpm-itk` eller `AssignUserID` ska du använda den faktiska vhost-användaren i kommandon och rättigheter i stället för `www-data`.

För en nyinstallation: läs först den korta [startguiden](../INSTALL.md). Debian 13 stöds med distributionspaketen och aktuella säkerhetsuppdateringar. `setup.sh --help` beskriver alternativen och `--check` gör endast en lokal förkontroll.

## Krav

Minimikrav:

- Debian-server med shell-access och `sudo`
- PHP 8.4.27 eller senare inom 8.4-serien, alternativt PHP 8.5.12 eller senare inom 8.5-serien
- Composer 2
- Apache 2 med `mod_rewrite`
- MariaDB 10.11 eller senare
- Skrivbar `var/`-mapp för cache, loggar, bilagor och delade filer
- `PHP_CLI_BINARY=/usr/bin/php` i miljöfilen, eller motsvarande PHP CLI-binär på servern
- Apache DocumentRoot mot `/var/www/driftpunkt/htdocs`
- systemd timers eller cron för bakgrundsjobb
- systemd timer för köade koduppdateringar om adminytans uppdateringsflöde används

Krav för webbaserade uppdateringar från adminytan:

- PHP/webbserver-användaren, normalt `www-data`, måste kunna skriva till applikationskoden som uppdateringspaketet hanterar: `bin/`, `config/`, `htdocs/`, `migrations/`, `public/`, `src/`, `templates/`, `composer.json`, `composer.lock` och `symfony.lock`
- På Apache med `mpm-itk` eller `AssignUserID` är användaren ofta vhost-användaren, inte `www-data`. Kontrollera vhosten eller en PHP-diagnos och använd samma användare för ägarskap, `composer install`, migrations och cache-warmup.
- Om servern ska vara hårdare låst med kodfiler ägda av `root` ska adminytans uppdateringsflöde inte användas för kodbyte. Uppdatera då i stället via SSH/deploy-script och låt bara `var/` vara skrivbar för `www-data`.

För en installation där adminytan ska kunna applicera uppdateringspaket:

```bash
WEB_USER=www-data
sudo chown -R "$WEB_USER:$WEB_USER" /var/www/driftpunkt
sudo chmod -R u+rwX /var/www/driftpunkt
```

För en mer låst server:

```bash
sudo chown -R root:www-data /var/www/driftpunkt
sudo chown -R www-data:www-data /var/www/driftpunkt/var /var/www/driftpunkt/htdocs/assets
sudo find /var/www/driftpunkt -type d -exec chmod 755 {} \;
sudo find /var/www/driftpunkt -type f -exec chmod 644 {} \;
sudo chmod 600 /var/www/driftpunkt/.env.local
```

I den låsta modellen ska koduppdateringar göras via SSH/deploy-script, inte via adminytans kodapplicering.

PHP-motorn måste innehålla rättningarna för CVE-2026-109618 och CVE-2026-109619. Composer och appens uppgraderingspaket uppdaterar inte motorn. Uppdatera och verifiera PHP innan nya app-/vendor-paket appliceras. Följ [PHP-uppdatering och verifiering](installation_and_deployment.md#säkerhetsuppdatera-php-motorn) för paketkontroll, omstart av FPM eller Apache/mod_php samt separat verifiering av webbserverns PHP och CLI.

Rekommenderade PHP-tillägg:

- `gd` med JPEG, PNG och FreeType
- `fileinfo`
- `ctype`
- `curl`
- `iconv`
- `intl`
- `mbstring`
- `pdo`
- `pdo_mysql`
- `xml`
- `zip`
- `opcache`

Databasval:

- MariaDB är standard för drift, Docker/NAS och Debian.
- SQLite används bara när `APP_ENV=test`; live-, Docker- och Debian-miljöer ska köra MariaDB.

## Snabb installation

1. Packa upp **installationspaketet** under `/var/www/driftpunkt` och gå in i katalogen som innehåller `composer.json`. Behåll dolda filer. Du behöver inte Git eller åtkomst till ett privat repo för att installera ett releasepaket.

   ```bash
   cd /var/www/driftpunkt
   test -f composer.json && test -f deploy/debian/setup.sh
   ```

2. Kör Debian-hjälpscriptet:

   ```bash
   sudo env DOMAIN=support.dindoman.se bash deploy/debian/setup.sh
   ```

   Scriptet installerar Apache, PHP-paket, MariaDB, Composer, Apache-vhost, logrotate samt systemd-timers för mailpolling och bilagearkivering. Timers installeras men startas först efter att databasen och kontot har skapats. Scriptet skapar också `.env.local` om den saknas, med en slumpad `APP_SECRET` och rätt adress. Det stannar före app-/webbkonfiguration när databaslösenordet fortfarande är en platshållare. Konfigurera databas och miljö, och kör sedan samma kommando igen. Befintliga hemligheter ändras aldrig automatiskt. För ett IP-baserat test kan `DOMAIN=DIN-SERVER-IP PUBLIC_URL=http://DIN-SERVER-IP` anges; verklig kunddrift behöver HTTPS.

3. Redigera produktionsmiljön:

   ```bash
   sudo nano /var/www/driftpunkt/.env.local
   ```

   Byt minst:

   - bevara den redan slumpade `APP_SECRET`; säkerhetskopiera den skyddat
   - `DEFAULT_URI`
   - `DATABASE_URL` med MariaDB och `serverVersion` som innehåller `mariadb`
   - `PHP_CLI_BINARY` om PHP CLI inte finns på `/usr/bin/php`
   - `MAILER_DSN` och `MAILER_FROM` när mail ska skickas

4. Skapa MariaDB-databas:

   ```bash
   sudo mariadb
   ```

   ```sql
   CREATE DATABASE driftpunkt CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
   CREATE USER 'driftpunkt'@'localhost' IDENTIFIED BY 'byt-databaslösenord';
   GRANT ALL PRIVILEGES ON driftpunkt.* TO 'driftpunkt'@'localhost';
   FLUSH PRIVILEGES;
   EXIT;
   ```

5. Kör samma setup-kommando igen efter databas-/miljökonfigurationen. Skriptet använder den medföljande Composer-filen när den finns och installerar produktionsberoenden från låsfilen. Manuell motsvarighet:

   ```bash
   cd /var/www/driftpunkt
   sudo -u www-data php composer install --no-dev --no-interaction --optimize-autoloader
   ```

6. Initiera en helt ny databas:

   ```bash
   sudo -u www-data php bin/console app:install:fresh --env=prod
   ```

   Kommandot skapar schema och basdata men aldrig användarkonton. Skapa första superadmin separat med dold lösenordsinmatning:

   ```bash
   sudo -u www-data php bin/console app:create-admin admin@example.com \
     --first-name=Förnamn \
     --last-name=Efternamn \
     --type=super_admin \
     --env=prod
   ```

   Logga därefter in och öppna **Inställningar → Åtkomst → MFA-policy**. Skapa eller importera MFA-krypteringsnyckeln, välj roller där MFA ska vara tillgängligt, välj frivilligt eventuella obligatoriska roller och välj period för betrodd enhet. Standard är 14 dagar. Ingen roll får obligatorisk MFA automatiskt.

7. Sätt rättigheter:

   ```bash
   sudo chown -R www-data:www-data /var/www/driftpunkt/var /var/www/driftpunkt/htdocs/assets
   sudo find /var/www/driftpunkt -type d -exec chmod 755 {} \;
   sudo find /var/www/driftpunkt -type f -exec chmod 644 {} \;
sudo chmod 600 /var/www/driftpunkt/.env.local
   ```

8. Ladda om Apache:

   ```bash
   sudo apache2ctl configtest
   sudo systemctl reload apache2
   ```

   Aktivera därefter schemalagda jobb när miljö, databas och första konto är verifierade:

   ```bash
   sudo systemctl enable --now driftpunkt-mail-poll.timer driftpunkt-attachment-archive.timer
   ```

9. Lägg på HTTPS, till exempel med Certbot:

   ```bash
   sudo apt-get install certbot python3-certbot-apache
   sudo certbot --apache -d driftpunkt.example.com
   ```

10. Aktivera update-worker om adminytans uppdateringsflöde ska användas. Se avsnittet `Automatiska uppdateringar med systemd timer` nedan.

## Viktiga produktionsfiler

- Appkatalog: `/var/www/driftpunkt`
- Miljö: `/var/www/driftpunkt/.env.local`
- Apache-vhost: `/etc/apache2/sites-available/driftpunkt.conf`
- Webbrot: `/var/www/driftpunkt/htdocs`
- Bakåtkompatibel äldre webbrot: `/var/www/driftpunkt/public`
- Cache/loggar/uploads: `/var/www/driftpunkt/var`
- Loggrotation: `/etc/logrotate.d/driftpunkt`
- Köade koduppdateringar: `/var/www/driftpunkt/var/code_update_runs`
- Mailpolling timer: `driftpunkt-mail-poll.timer`
- Bilagearkivering timer: `driftpunkt-attachment-archive.timer`
- Update-worker timer: `driftpunkt-update-worker.timer`

## Bakgrundsjobb

Systemd-timers installeras av hjälpscriptet. Kontrollera dem med:

```bash
systemctl list-timers 'driftpunkt-*'
systemctl status driftpunkt-mail-poll.timer
systemctl status driftpunkt-attachment-archive.timer
```

Hjälpscriptet installerar de färdiga timerfilerna som finns i `deploy/debian/`. SLA-kontroll, månadsrapporter och update-worker ska antingen hanteras av appens interna fallback eller sättas upp som egna cron/systemd-jobb efter samma mönster.

Köra jobben manuellt:

```bash
sudo -u www-data php /var/www/driftpunkt/bin/console app:mail:poll --env=prod
sudo -u www-data php /var/www/driftpunkt/bin/console app:internal-reports:retry-notifications --env=prod
sudo -u www-data php /var/www/driftpunkt/bin/console app:archive-ticket-attachments --env=prod
sudo -u www-data php /var/www/driftpunkt/bin/console app:check-ticket-sla --env=prod
```

## Automatiska uppdateringar med systemd timer

Adminytans uppdateringsflöde kan skapa en köad update-run i `var/code_update_runs`. För att den inte ska bli liggande som `queued` ska Debian-servern ha en separat worker som körs av systemd.

Flödet är:

```text
Adminyta köar uppdatering
        ↓
systemd timer startar worker
        ↓
workern hittar första queued JSON-fil
        ↓
workern kör app:code-update:apply-run
        ↓
status blir completed eller failed
```

### 1. Skapa worker-script

```bash
sudo nano /usr/local/bin/driftpunkt-run-pending-updates
```

Innehåll:

```bash
#!/bin/bash
set -euo pipefail

APP_DIR="/var/www/driftpunkt"
cd "$APP_DIR"

RUN_ID=$(sudo -u www-data php -r '
$dir = "var/code_update_runs";
if (!is_dir($dir)) { exit; }

$files = glob($dir . "/*.json");
rsort($files);

foreach ($files as $file) {
    $data = json_decode(file_get_contents($file), true);
    if (($data["status"] ?? "") === "queued") {
        echo basename($file, ".json");
        exit;
    }
}
')

if [ -n "$RUN_ID" ]; then
    echo "Kör Driftpunkt-uppdatering: $RUN_ID"
    sudo -u www-data php bin/console app:code-update:apply-run "$RUN_ID" --env=prod
else
    echo "Ingen köad Driftpunkt-uppdatering hittades."
fi
```

Gör scriptet körbart:

```bash
sudo chmod +x /usr/local/bin/driftpunkt-run-pending-updates
```

Testa manuellt:

```bash
sudo /usr/local/bin/driftpunkt-run-pending-updates
```

### 2. Skapa systemd-service

```bash
sudo nano /etc/systemd/system/driftpunkt-update-worker.service
```

Innehåll:

```ini
[Unit]
Description=Driftpunkt pending update worker
After=network.target mariadb.service apache2.service
Wants=mariadb.service

[Service]
Type=oneshot
ExecStart=/usr/local/bin/driftpunkt-run-pending-updates
WorkingDirectory=/var/www/driftpunkt
User=root
Nice=5
```

### 3. Skapa systemd-timer

```bash
sudo nano /etc/systemd/system/driftpunkt-update-worker.timer
```

Innehåll:

```ini
[Unit]
Description=Run Driftpunkt pending update worker every minute

[Timer]
OnBootSec=1min
OnUnitActiveSec=1min
Unit=driftpunkt-update-worker.service

[Install]
WantedBy=timers.target
```

### 4. Aktivera och kontrollera

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now driftpunkt-update-worker.timer
systemctl status driftpunkt-update-worker.timer
```

Visa loggar:

```bash
journalctl -u driftpunkt-update-worker.service -n 100 --no-pager
```

Kör workern direkt vid felsökning:

```bash
sudo systemctl start driftpunkt-update-worker.service
journalctl -u driftpunkt-update-worker.service -n 50 --no-pager
```

Om ingen uppdatering väntar ska loggen visa:

```text
Ingen köad Driftpunkt-uppdatering hittades.
```

## Uppgradering

Rekommenderad ordning när ett paketerat uppgraderingsflöde inte används:

```bash
cd /var/www/driftpunkt
sudo -u www-data php bin/console app:maintenance on --message="Uppgradering pågår" --env=prod
sudo -u www-data composer install --no-dev --optimize-autoloader
sudo -u www-data php bin/console doctrine:migrations:migrate -n --env=prod
sudo -u www-data php -d memory_limit=512M bin/console cache:clear --env=prod
sudo -u www-data php bin/console app:maintenance off --env=prod
```

Ta alltid backup på databas och `var/` innan uppgradering.

Uppgraderingspaket som byggs av Driftpunkt är kumulativa inom Driftpunkt 1.x och innehåller `vendor/`, så Debian-servern ska kunna uppdateras med senaste paketet utan att hämta Composer-paket från internet under själva driftfönstret. Adminflödet jämför paketet mot installerad kod, skriver bara nya eller ändrade filer och bevarar runtime-data som `.env*`, `var/` och uppladdad branding.

Om adminytans uppdateringsflöde används ska `driftpunkt-update-worker.timer` vara aktiv innan uppdateringen köas. Annars kan körningen bli liggande som `queued` tills den körs manuellt. Kontrollera också att Apache-vhosten pekar på `/var/www/driftpunkt/htdocs` innan första htdocs-baserade releasepaketet appliceras.

Manuell körning av en köad update-run:

```bash
cd /var/www/driftpunkt
sudo -u www-data php bin/console app:code-update:apply-run RUN_ID --env=prod
```

Kontrollera status:

```bash
cat /var/www/driftpunkt/var/code_update_runs/RUN_ID.json
```

## Rekommenderad release-struktur för mer kontrollerad produktion

För kundmiljöer där rollback är viktigt bör Driftpunkt på sikt driftsättas med release-mappar och symlink:

```text
/var/www/driftpunkt/
├── current -> releases/1.0.9
├── releases/
│   ├── 1.0.6
│   └── 1.0.9
└── shared/
    ├── .env.local
    ├── var/
    └── public/uploads/
```

Ett sådant flöde gör det enklare att byta tillbaka till föregående version om en release behöver rullas tillbaka.

## Felsökning

Kontrollera PHP och tillägg:

```bash
php -v
php -m
composer check-platform-reqs
```

Kontrollera loggar:

```bash
sudo journalctl -u apache2 -n 100 --no-pager
sudo tail -n 100 /var/www/driftpunkt/var/log/prod.log
sudo tail -n 100 /var/www/driftpunkt/var/log/mail-poll.log
sudo tail -n 100 /var/www/driftpunkt/var/log/ticket-attachment-archive.log
sudo journalctl -u driftpunkt-mail-poll.service -n 100 --no-pager
sudo journalctl -u driftpunkt-update-worker.service -n 100 --no-pager
```

Kontrollera timers:

```bash
systemctl list-timers 'driftpunkt-*'
systemctl status driftpunkt-update-worker.timer
```

Vanliga fel:

- `Composer detected issues in your platform`: PHP-version eller PHP-tillägg saknas.
- HTTP 500 efter deploy: kontrollera `var/log/prod.log`, `.env.local` och databasanslutningen.
- 404 på alla routes: Apache-vhost pekar inte på `htdocs/` eller `mod_rewrite`/`FallbackResource` saknas.
- Inga mail skickas: `MAILER_DSN` är fortfarande `null://null` eller SMTP-uppgifter saknas.
- Rapporter sparas men skickas inte centralt: kontrollera superadmins rapportinställningar, att svarsadressen exakt matchar en aktiv IMAP-inkorg och att mailpolling körs.
- Uppdatering ligger kvar som `queued`: kontrollera `driftpunkt-update-worker.timer`, kör `sudo systemctl start driftpunkt-update-worker.service` och läs `journalctl -u driftpunkt-update-worker.service`.
- `Permission denied` vid uppdatering: kontrollera ägarskap på kodfiler och `var/`, särskilt om adminytans uppdateringsflöde används.
