<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

final class Version20260828190000 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Adds optional MFA policy deadlines and expands encrypted MFA secret storage';
    }

    public function up(Schema $schema): void
    {
        if (!$schema->hasTable('users')) {
            return;
        }

        $table = $schema->getTable('users');
        if ($table->hasColumn('mfa_secret')) {
            $table->modifyColumn('mfa_secret', ['length' => 255, 'notnull' => false]);
        }
        if (!$table->hasColumn('mfa_requirement_assigned_at')) {
            $table->addColumn('mfa_requirement_assigned_at', 'datetime_immutable', ['notnull' => false]);
        }
        if (!$table->hasColumn('mfa_enrollment_deadline')) {
            $table->addColumn('mfa_enrollment_deadline', 'datetime_immutable', ['notnull' => false]);
        }

        if ($schema->hasTable('system_settings')) {
            $defaults = [
                'mfa.role.super_admin.required' => '0',
                'mfa.role.admin.required' => '0',
                'mfa.role.ticket_coordinator.required' => '0',
                'mfa.role.technician.required' => '0',
                'mfa.role.customer.required' => '0',
                'mfa.role.private_customer.required' => '0',
                'mfa.trusted_device_duration_days' => '14',
                'mfa.trusted_device_policy_version' => '1',
            ];
            foreach ($defaults as $key => $value) {
                $this->addSql(
                    'INSERT INTO system_settings (setting_key, setting_value, created_at, updated_at) '
                    .'SELECT :setting_key, :setting_value, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP '
                    .'WHERE NOT EXISTS (SELECT 1 FROM system_settings WHERE setting_key = :setting_key)',
                    ['setting_key' => $key, 'setting_value' => $value],
                );
            }
        }
    }

    public function down(Schema $schema): void
    {
        if (!$schema->hasTable('users')) {
            return;
        }

        $table = $schema->getTable('users');
        foreach (['mfa_requirement_assigned_at', 'mfa_enrollment_deadline'] as $column) {
            if ($table->hasColumn($column)) {
                $table->dropColumn($column);
            }
        }
    }
}
