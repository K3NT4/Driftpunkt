<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

final class Version20260824120000 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Adds monitor and payment terminal inventory fields';
    }

    public function up(Schema $schema): void
    {
        if (!$schema->hasTable('inventory_items')) {
            return;
        }

        $table = $schema->getTable('inventory_items');
        foreach ([
            'screen_size' => 80,
            'resolution' => 80,
            'connection_type' => 120,
            'terminal_id' => 255,
            'provider' => 255,
        ] as $name => $length) {
            if (!$table->hasColumn($name)) {
                $table->addColumn($name, 'string', ['length' => $length, 'notnull' => false]);
            }
        }

        if (!$table->hasColumn('pay_at_table')) {
            $table->addColumn('pay_at_table', 'boolean', ['default' => false]);
        }
    }

    public function down(Schema $schema): void
    {
        if (!$schema->hasTable('inventory_items')) {
            return;
        }

        $table = $schema->getTable('inventory_items');
        foreach (['screen_size', 'resolution', 'connection_type', 'terminal_id', 'provider', 'pay_at_table'] as $name) {
            if ($table->hasColumn($name)) {
                $table->dropColumn($name);
            }
        }
    }
}
