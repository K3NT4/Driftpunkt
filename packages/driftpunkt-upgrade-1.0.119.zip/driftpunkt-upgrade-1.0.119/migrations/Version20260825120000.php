<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

final class Version20260825120000 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Adds structured payment-terminal and base-station inventory fields';
    }

    public function up(Schema $schema): void
    {
        if (!$schema->hasTable('inventory_items')) {
            return;
        }

        $table = $schema->getTable('inventory_items');
        foreach ([
            'device_type' => 40,
            'device_status' => 40,
            'login_name' => 255,
            'consumables' => 255,
            'terminal_name' => 255,
            'admin_card' => 255,
            'base_station_name' => 255,
            'base_station_model' => 255,
            'base_station_serial_number' => 255,
        ] as $name => $length) {
            if (!$table->hasColumn($name)) {
                $table->addColumn($name, 'string', ['length' => $length, 'notnull' => false]);
            }
        }

        if (!$table->hasColumn('has_base_station')) {
            $table->addColumn('has_base_station', 'boolean', ['notnull' => false]);
        }
        if ($table->hasColumn('pay_at_table')) {
            $table->getColumn('pay_at_table')->setNotnull(false)->setDefault(null);
        }
    }

    public function down(Schema $schema): void
    {
        if (!$schema->hasTable('inventory_items')) {
            return;
        }

        $table = $schema->getTable('inventory_items');
        foreach (['device_type', 'device_status', 'login_name', 'consumables', 'terminal_name', 'admin_card', 'has_base_station', 'base_station_name', 'base_station_model', 'base_station_serial_number'] as $name) {
            if ($table->hasColumn($name)) {
                $table->dropColumn($name);
            }
        }
        if ($table->hasColumn('pay_at_table')) {
            $table->getColumn('pay_at_table')->setNotnull(true)->setDefault(false);
        }
    }
}
