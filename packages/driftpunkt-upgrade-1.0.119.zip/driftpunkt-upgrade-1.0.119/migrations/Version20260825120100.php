<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

final class Version20260825120100 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Maps existing inventory flags to lifecycle statuses';
    }

    public function up(Schema $schema): void
    {
        if (!$schema->hasTable('inventory_items') || !$schema->getTable('inventory_items')->hasColumn('device_status')) {
            return;
        }

        $this->addSql("UPDATE inventory_items SET device_status = CASE WHEN broken = 1 THEN 'Trasig' ELSE 'I drift' END WHERE type IN ('computer', 'monitor') AND device_status IS NULL");
        $this->addSql("UPDATE inventory_items SET device_status = CASE WHEN available = 1 THEN 'I drift' ELSE 'Ur drift' END WHERE type = 'printer' AND device_status IS NULL");
    }

    public function down(Schema $schema): void
    {
        // The legacy boolean columns remain synchronized by the application.
        // No data rollback is needed before the preceding schema migration runs down.
    }
}
