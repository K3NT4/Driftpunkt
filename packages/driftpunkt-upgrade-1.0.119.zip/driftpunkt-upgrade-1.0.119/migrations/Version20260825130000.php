<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

final class Version20260825130000 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Adds an optional order number to computer and monitor inventory items';
    }

    public function up(Schema $schema): void
    {
        if (!$schema->hasTable('inventory_items')) {
            return;
        }

        $table = $schema->getTable('inventory_items');
        if (!$table->hasColumn('order_number')) {
            $table->addColumn('order_number', 'string', ['length' => 255, 'notnull' => false]);
        }
    }

    public function down(Schema $schema): void
    {
        if ($schema->hasTable('inventory_items') && $schema->getTable('inventory_items')->hasColumn('order_number')) {
            $schema->getTable('inventory_items')->dropColumn('order_number');
        }
    }
}
