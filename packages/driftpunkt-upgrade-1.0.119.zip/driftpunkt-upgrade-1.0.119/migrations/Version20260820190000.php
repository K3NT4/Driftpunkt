<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Platforms\AbstractMySQLPlatform;
use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

final class Version20260820190000 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Classifies draft ticket reviews for safe coordinator access';
    }

    public function up(Schema $schema): void
    {
        if (!$schema->hasTable('draft_ticket_reviews')) {
            return;
        }

        $table = $schema->getTable('draft_ticket_reviews');
        if (!$table->hasColumn('kind')) {
            $this->addSql("ALTER TABLE draft_ticket_reviews ADD kind VARCHAR(255) DEFAULT 'manual_correction' NOT NULL");
        }
        if (!$table->hasIndex('idx_draft_review_kind_status')) {
            $this->addSql('CREATE INDEX idx_draft_review_kind_status ON draft_ticket_reviews (kind, status)');
        }

        $this->addSql("UPDATE draft_ticket_reviews SET kind = 'unknown_sender' WHERE reason LIKE 'Okänd avsändare%' OR reason LIKE 'Avsändaren matchade ett företag%'");
        $this->addSql("UPDATE draft_ticket_reviews SET kind = 'unauthorized_reply' WHERE reason LIKE 'Avsändaren matchade inte någon behörig person%'");
    }

    public function down(Schema $schema): void
    {
        if (!$schema->hasTable('draft_ticket_reviews')) {
            return;
        }

        $table = $schema->getTable('draft_ticket_reviews');
        if ($table->hasIndex('idx_draft_review_kind_status')) {
            if ($this->connection->getDatabasePlatform() instanceof AbstractMySQLPlatform) {
                $this->addSql('DROP INDEX idx_draft_review_kind_status ON draft_ticket_reviews');
            } else {
                $this->addSql('DROP INDEX idx_draft_review_kind_status');
            }
        }
        if ($table->hasColumn('kind')) {
            $this->addSql('ALTER TABLE draft_ticket_reviews DROP COLUMN kind');
        }
    }
}
