<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

final class Version20260820210000 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Adds per-user customer portal appearance preferences';
    }

    public function up(Schema $schema): void
    {
        if (!$schema->hasTable('users')) {
            return;
        }

        $table = $schema->getTable('users');
        if (!$table->hasColumn('customer_portal_preferences')) {
            $table->addColumn('customer_portal_preferences', 'json', ['notnull' => false]);
        }
    }

    public function down(Schema $schema): void
    {
        if (!$schema->hasTable('users')) {
            return;
        }

        $table = $schema->getTable('users');
        if ($table->hasColumn('customer_portal_preferences')) {
            $table->dropColumn('customer_portal_preferences');
        }
    }
}
