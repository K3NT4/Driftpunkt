const CACHE_PREFIX = 'driftpunkt-static-';
const CACHE = `${CACHE_PREFIX}v1.0.115`;
const STATIC_ASSETS = ['/assets/branding/driftpunkt-logo-icon.png'];
self.addEventListener('install', event => event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(STATIC_ASSETS)).then(() => self.skipWaiting())));
self.addEventListener('activate', event => event.waitUntil(caches.keys()
    .then(keys => Promise.all(keys.filter(key => key.startsWith(CACHE_PREFIX) && key !== CACHE).map(key => caches.delete(key))))
    .then(() => self.clients.claim())));
self.addEventListener('fetch', event => {
    const requestUrl = new URL(event.request.url);
    if (event.request.method !== 'GET'
        || event.request.mode === 'navigate'
        || requestUrl.origin !== self.location.origin
        || !STATIC_ASSETS.includes(requestUrl.pathname)) return;
    event.respondWith(caches.match(event.request).then(cached => cached || fetch(event.request)));
});
