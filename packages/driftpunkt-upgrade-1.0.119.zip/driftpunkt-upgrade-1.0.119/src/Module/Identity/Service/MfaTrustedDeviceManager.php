<?php

declare(strict_types=1);

namespace App\Module\Identity\Service;

use App\Module\Identity\Entity\User;
use App\Module\Identity\Enum\UserType;
use Symfony\Component\Clock\ClockInterface;
use Symfony\Component\DependencyInjection\Attribute\Autowire;
use Symfony\Component\HttpFoundation\Cookie;
use Symfony\Component\HttpFoundation\Request;
use App\Module\System\Service\SystemSettings;

final class MfaTrustedDeviceManager
{
    public const COOKIE_NAME = 'driftpunkt_mfa_trusted_device';
    /** @deprecated Use configured duration. Kept for legacy callers/tests. */
    public const TRUST_DURATION_SECONDS = 1209600;

    public function __construct(
        private readonly ClockInterface $clock,
        #[Autowire('%kernel.secret%')]
        private readonly string $appSecret,
        private readonly ?SystemSettings $systemSettings = null,
        private readonly ?MfaKeyManager $mfaKeyManager = null,
    ) {
    }

    public function supports(User $user): bool
    {
        return \in_array($user->getType(), [
            UserType::TECHNICIAN,
            UserType::TICKET_COORDINATOR,
        ], true);
    }

    public function isTrusted(Request $request, User $user): bool
    {
        if (!$this->supports($user) || !$user->isMfaEnabled() || !$user->isMfaSetupCompleted()) {
            return false;
        }

        $token = $request->cookies->get(self::COOKIE_NAME);
        if (!\is_string($token) || '' === $token) {
            return false;
        }

        $parts = explode('.', $token, 2);
        if (2 !== \count($parts)) {
            return false;
        }

        [$encodedPayload, $providedSignature] = $parts;
        $expectedSignature = $this->sign($encodedPayload);
        if (!hash_equals($expectedSignature, $providedSignature)) {
            return false;
        }

        $payloadJson = $this->base64UrlDecode($encodedPayload);
        if (null === $payloadJson) {
            return false;
        }

        try {
            $payload = json_decode($payloadJson, true, 8, \JSON_THROW_ON_ERROR);
        } catch (\JsonException) {
            return false;
        }

        if (!\is_array($payload)) {
            return false;
        }

        $expiresAt = $payload['exp'] ?? null;
        if (!\is_int($expiresAt) || $expiresAt <= $this->clock->now()->getTimestamp()) {
            return false;
        }

        $policyVersion = $this->policyVersion();
        $tokenPolicyVersion = $payload['pv'] ?? null;
        if (null !== $tokenPolicyVersion && $tokenPolicyVersion !== $policyVersion) {
            return false;
        }
        if (null === $tokenPolicyVersion && 1 !== $policyVersion) {
            return false;
        }

        $expectedFingerprint = null === $tokenPolicyVersion
            ? $this->userSecurityFingerprint($user, false)
            : $this->userSecurityFingerprint($user, true);

        return 0 < $this->durationDays()
            && ($payload['sub'] ?? null) === (string) $user->getPublicId()
            && ($payload['key'] ?? null) === $expectedFingerprint;
    }

    public function createCookie(User $user): Cookie
    {
        if (!$this->supports($user) || !$user->isMfaEnabled() || !$user->isMfaSetupCompleted()) {
            throw new \LogicException('Betrodd MFA-enhet kan bara skapas för tekniker och ärendekoordinatorer med aktiv MFA.');
        }

        $durationDays = $this->durationDays();
        if (0 === $durationDays) {
            throw new \LogicException('Betrodda MFA-enheter är avstängda.');
        }
        $expiresAt = $this->clock->now()->modify(sprintf('+%d days', $durationDays));
        $payload = json_encode([
            'sub' => (string) $user->getPublicId(),
            'exp' => $expiresAt->getTimestamp(),
            'key' => $this->userSecurityFingerprint($user),
            'pv' => $this->policyVersion(),
        ], \JSON_THROW_ON_ERROR);
        $encodedPayload = $this->base64UrlEncode($payload);
        $token = $encodedPayload.'.'.$this->sign($encodedPayload);

        return Cookie::create(
            name: self::COOKIE_NAME,
            value: $token,
            expire: $expiresAt,
            path: '/',
            secure: true,
            httpOnly: true,
            sameSite: Cookie::SAMESITE_STRICT,
        );
    }

    private function userSecurityFingerprint(User $user, bool $includePolicyVersion = true): string
    {
        $storedSecret = (string) $user->getMfaSecret();
        try {
            $secret = null !== $this->mfaKeyManager && '' !== $storedSecret
                ? $this->mfaKeyManager->decryptSecret($storedSecret)
                : $storedSecret;
        } catch (\Throwable) {
            // A damaged/unavailable key must make the cookie untrusted, never break login.
            return '';
        }
        $parts = [
            (string) $user->getPublicId(),
            $user->getPassword(),
            $secret,
            $user->getType()->value,
        ];
        if ($includePolicyVersion) {
            $parts[] = (string) $this->policyVersion();
        }

        return hash_hmac('sha256', implode("\0", $parts), $this->appSecret);
    }

    public function durationDays(): int
    {
        return $this->systemSettings?->getMfaSettings()['trustedDeviceDurationDays'] ?? 14;
    }

    private function policyVersion(): int
    {
        return $this->systemSettings?->getMfaSettings()['trustedDevicePolicyVersion'] ?? 1;
    }

    private function sign(string $encodedPayload): string
    {
        return $this->base64UrlEncode(hash_hmac('sha256', $encodedPayload, $this->appSecret, true));
    }

    private function base64UrlEncode(string $value): string
    {
        return rtrim(strtr(base64_encode($value), '+/', '-_'), '=');
    }

    private function base64UrlDecode(string $value): ?string
    {
        if ('' === $value || 1 === \strlen($value) % 4) {
            return null;
        }

        $padding = (4 - \strlen($value) % 4) % 4;
        $decoded = base64_decode(strtr($value, '-_', '+/').str_repeat('=', $padding), true);

        return false === $decoded ? null : $decoded;
    }
}
