<?php

declare(strict_types=1);

namespace App\Module\Identity\Service;

use App\Module\Identity\Entity\User;
use App\Module\Identity\Enum\UserType;
use App\Module\System\Service\SystemSettings;

final class MfaPolicyResolver
{
    public function __construct(
        private readonly SystemSettings $systemSettings,
    ) {
    }

    public function isMfaAvailable(User $user): bool
    {
        $settings = $this->systemSettings->getMfaSettings();
        $role = $user->getType()->value;

        return ($settings['enabledByRole'][$role] ?? false) || ($settings['requiredByRole'][$role] ?? false);
    }

    public function isMfaRequiredByPolicy(User $user): bool
    {
        $settings = $this->systemSettings->getMfaSettings();

        return (bool) ($settings['requiredByRole'][$user->getType()->value] ?? false);
    }

    public function isEnrollmentOverdue(User $user, ?\DateTimeImmutable $now = null): bool
    {
        return $this->isMfaRequiredByPolicy($user)
            && (!$user->isMfaEnabled() || !$user->isMfaSetupCompleted())
            && $user->getMfaEnrollmentDeadline() instanceof \DateTimeImmutable
            && $user->getMfaEnrollmentDeadline() <= ($now ?? new \DateTimeImmutable());
    }

    public function requiresMfa(User $user): bool
    {
        return $user->isMfaEnabled()
            && $user->isMfaSetupCompleted()
            && $this->isMfaAvailable($user);
    }
}
