<?php

declare(strict_types=1);

namespace App\Module\Identity\Service;

use App\Module\System\Service\SystemSettings;
use Symfony\Component\DependencyInjection\Attribute\Autowire;
use Doctrine\ORM\EntityManagerInterface;

final class MfaKeyManager
{
    private const CIPHER = 'aes-256-gcm';
    private const KEY_BYTES = 32;
    private const NONCE_BYTES = 12;
    private const TAG_BYTES = 16;
    private const UNSAFE_APP_SECRETS = [
        'change-me-in-production',
        'driftpunkt-dev-secret-change-me',
        'byt-till-en-lang-slumpad-hemlighet',
    ];

    public function __construct(
        private readonly SystemSettings $settings,
        #[Autowire('%env(APP_SECRET)%')]
        private readonly string $appSecret,
        private readonly EntityManagerInterface $entityManager,
    ) {
    }

    public function isConfigured(): bool
    {
        try {
            return null !== $this->activeKey();
        } catch (\Throwable) {
            return false;
        }
    }

    /** @return array{configured: bool, version: int, fingerprint: string, createdAt: string, rotationPending: bool} */
    public function status(): array
    {
        $key = $this->activeKey();

        return [
            'configured' => null !== $key,
            'version' => $this->settings->getNonNegativeInt(SystemSettings::MFA_KEY_VERSION, 0),
            'fingerprint' => null === $key ? '' : substr(hash('sha256', $key), 0, 16),
            'createdAt' => $this->settings->getString(SystemSettings::MFA_KEY_CREATED_AT, ''),
            'rotationPending' => '' !== $this->settings->getString(SystemSettings::MFA_KEY_PREVIOUS_ENCRYPTED, ''),
        ];
    }

    public function generate(bool $rotate = false): string
    {
        $encoded = base64_encode(random_bytes(self::KEY_BYTES));
        $this->install($encoded, $rotate);

        return $encoded;
    }

    public function install(string $encodedKey, bool $rotate = false): void
    {
        $normalizedKey = trim($encodedKey);
        $key = base64_decode($normalizedKey, true);
        if (!\is_string($key) || self::KEY_BYTES !== \strlen($key) || base64_encode($key) !== $normalizedKey) {
            throw new \InvalidArgumentException('MFA-nyckeln måste vara en base64-kodad 32-bytesnyckel.');
        }
        $current = $this->settings->getString(SystemSettings::MFA_KEY_ENCRYPTED, '');
        if ('' !== $current) {
            // Verify that APP_SECRET can open the current key before changing any state.
            $this->activeKey();
        }
        if ($rotate && '' !== $this->settings->getString(SystemSettings::MFA_KEY_PREVIOUS_ENCRYPTED, '')) {
            throw new \LogicException('Slutför pågående MFA-nyckelmigration innan en ny rotation startas.');
        }
        if ('' !== $current && !$rotate) {
            throw new \LogicException('En MFA-nyckel är redan konfigurerad. Använd rotation.');
        }
        $wrappedKey = $this->wrap($key);
        $nextVersion = max(1, $this->settings->getNonNegativeInt(SystemSettings::MFA_KEY_VERSION, 0) + 1);
        $createdAt = (new \DateTimeImmutable())->format(DATE_ATOM);
        $this->entityManager->wrapInTransaction(function () use ($rotate, $current, $wrappedKey, $nextVersion, $createdAt): void {
            if ($rotate && '' !== $current) {
                $this->settings->setString(SystemSettings::MFA_KEY_PREVIOUS_ENCRYPTED, $current);
            }
            $this->settings->setString(SystemSettings::MFA_KEY_ENCRYPTED, $wrappedKey);
            $this->settings->setInt(SystemSettings::MFA_KEY_VERSION, $nextVersion);
            $this->settings->setString(SystemSettings::MFA_KEY_CREATED_AT, $createdAt);
        });
    }

    public function encryptSecret(string $plaintext): string
    {
        $key = $this->activeKey();
        if (null === $key) {
            throw new \RuntimeException('MFA-krypteringsnyckeln är inte konfigurerad.');
        }
        $nonce = random_bytes(self::NONCE_BYTES);
        $tag = '';
        $ciphertext = openssl_encrypt($plaintext, self::CIPHER, $key, \OPENSSL_RAW_DATA, $nonce, $tag);
        if (false === $ciphertext || self::TAG_BYTES !== \strlen($tag)) {
            throw new \RuntimeException('MFA-hemligheten kunde inte krypteras.');
        }
        $version = $this->settings->getNonNegativeInt(SystemSettings::MFA_KEY_VERSION, 1);

        return 'enc:v'.$version.':'.base64_encode($nonce.$tag.$ciphertext);
    }

    public function decryptSecret(string $stored): string
    {
        if (!str_starts_with($stored, 'enc:v')) {
            return $stored;
        }
        $separator = strpos($stored, ':', 5);
        if (false === $separator) {
            throw new \RuntimeException('Den lagrade MFA-hemligheten har ogiltigt format.');
        }
        $payload = base64_decode(substr($stored, $separator + 1), true);
        if (!\is_string($payload) || \strlen($payload) <= self::NONCE_BYTES + self::TAG_BYTES) {
            throw new \RuntimeException('Den lagrade MFA-hemligheten är skadad.');
        }
        foreach (array_filter([$this->activeKey(), $this->previousKey()]) as $key) {
            $plaintext = openssl_decrypt(
                substr($payload, self::NONCE_BYTES + self::TAG_BYTES),
                self::CIPHER,
                $key,
                \OPENSSL_RAW_DATA,
                substr($payload, 0, self::NONCE_BYTES),
                substr($payload, self::NONCE_BYTES, self::TAG_BYTES),
            );
            if (false !== $plaintext) {
                return $plaintext;
            }
        }
        throw new \RuntimeException('MFA-hemligheten kunde inte dekrypteras.');
    }

    public function isEncrypted(string $value): bool
    {
        return str_starts_with($value, 'enc:v');
    }

    public function needsEncryptionWithActiveKey(string $value): bool
    {
        if (!$this->isEncrypted($value)) {
            return true;
        }

        return !str_starts_with($value, 'enc:v'.$this->currentVersion().':');
    }

    public function completeRotation(): void
    {
        $this->settings->setString(SystemSettings::MFA_KEY_PREVIOUS_ENCRYPTED, '');
    }

    public function currentVersion(): int
    {
        return max(1, $this->settings->getNonNegativeInt(SystemSettings::MFA_KEY_VERSION, 1));
    }

    private function activeKey(): ?string
    {
        return $this->unwrapSetting(SystemSettings::MFA_KEY_ENCRYPTED);
    }

    private function previousKey(): ?string
    {
        return $this->unwrapSetting(SystemSettings::MFA_KEY_PREVIOUS_ENCRYPTED);
    }

    private function unwrapSetting(string $setting): ?string
    {
        $wrapped = $this->settings->getString($setting, '');
        if ('' === $wrapped) {
            return null;
        }
        if (!str_starts_with($wrapped, 'wrap:v1:')) {
            throw new \RuntimeException('Den omslutna MFA-nyckeln har okänt format.');
        }
        $payload = base64_decode(substr($wrapped, 8), true);
        if (!\is_string($payload) || \strlen($payload) <= self::NONCE_BYTES + self::TAG_BYTES) {
            throw new \RuntimeException('Den omslutna MFA-nyckeln är skadad.');
        }
        $key = openssl_decrypt(
            substr($payload, self::NONCE_BYTES + self::TAG_BYTES), self::CIPHER, $this->wrappingKey(),
            \OPENSSL_RAW_DATA, substr($payload, 0, self::NONCE_BYTES), substr($payload, self::NONCE_BYTES, self::TAG_BYTES),
        );
        if (false === $key || self::KEY_BYTES !== \strlen($key)) {
            throw new \RuntimeException('MFA-nyckeln kunde inte öppnas med installationens APP_SECRET.');
        }

        return $key;
    }

    private function wrap(string $key): string
    {
        $nonce = random_bytes(self::NONCE_BYTES);
        $tag = '';
        $ciphertext = openssl_encrypt($key, self::CIPHER, $this->wrappingKey(), \OPENSSL_RAW_DATA, $nonce, $tag);
        if (false === $ciphertext) {
            throw new \RuntimeException('MFA-nyckeln kunde inte omslutas.');
        }

        return 'wrap:v1:'.base64_encode($nonce.$tag.$ciphertext);
    }

    private function wrappingKey(): string
    {
        $secret = trim($this->appSecret);
        if (\strlen($secret) < 32 || \in_array($secret, self::UNSAFE_APP_SECRETS, true)) {
            throw new \RuntimeException('Ett säkert APP_SECRET krävs för MFA-nyckelhantering.');
        }

        return hash_hkdf('sha256', $secret, self::KEY_BYTES, 'driftpunkt-mfa-key-wrap-v1');
    }
}
