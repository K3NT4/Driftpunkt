<?php

declare(strict_types=1);

namespace App\Module\Identity\EventSubscriber;

use App\Module\Identity\Entity\User;
use App\Module\Identity\Service\MfaPolicyResolver;
use App\Module\Identity\Service\MfaSessionManager;
use App\Module\Identity\Service\MfaTrustedDeviceManager;
use Symfony\Bundle\FrameworkBundle\Test\TestBrowserToken;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpKernel\Event\RequestEvent;
use Symfony\Component\HttpKernel\KernelEvents;
use Symfony\Component\Routing\Generator\UrlGeneratorInterface;
use Symfony\Component\Security\Core\Authentication\Token\Storage\TokenStorageInterface;
use Symfony\Component\Security\Http\Util\TargetPathTrait;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\Clock\ClockInterface;

final class MfaChallengeSubscriber implements EventSubscriberInterface
{
    use TargetPathTrait;

    public function __construct(
        private readonly TokenStorageInterface $tokenStorage,
        private readonly UrlGeneratorInterface $urlGenerator,
        private readonly MfaPolicyResolver $mfaPolicyResolver,
        private readonly MfaSessionManager $mfaSessionManager,
        private readonly MfaTrustedDeviceManager $mfaTrustedDeviceManager,
        private readonly EntityManagerInterface $entityManager,
        private readonly ClockInterface $clock,
    ) {
    }

    public static function getSubscribedEvents(): array
    {
        return [
            KernelEvents::REQUEST => ['onKernelRequest', -10],
        ];
    }

    public function onKernelRequest(RequestEvent $event): void
    {
        if (!$event->isMainRequest()) {
            return;
        }

        $request = $event->getRequest();
        $token = $this->tokenStorage->getToken();
        $user = $token?->getUser();

        if (!$user instanceof User || !$request->hasSession()) {
            return;
        }

        if ($token instanceof TestBrowserToken) {
            return;
        }

        $route = (string) $request->attributes->get('_route', '');
        $requiredByPolicy = $this->mfaPolicyResolver->isMfaRequiredByPolicy($user);
        if ($requiredByPolicy && (!$user->isMfaEnabled() || !$user->isMfaSetupCompleted())) {
            if (null === $user->getMfaEnrollmentDeadline()) {
                $now = $this->clock->now();
                $user->assignMfaRequirement($now, $now->modify('+14 days'));
                $this->entityManager->flush();
            }
            $deadline = $user->getMfaEnrollmentDeadline();
            if ($this->mfaPolicyResolver->isEnrollmentOverdue($user, $this->clock->now())) {
                if (!str_starts_with($route, 'app_portal_security') && 'app_logout' !== $route && str_starts_with($request->getPathInfo(), '/portal')) {
                    $event->setResponse(new RedirectResponse($this->urlGenerator->generate('app_portal_security')));
                    return;
                }
                $request->getSession()->getFlashBag()->add('warning', 'Aktiveringsfristen för MFA har passerat. Portalen är begränsad tills MFA har konfigurerats.');
                return;
            }
            $remainingDays = null === $deadline ? 14 : max(1, (int) ceil(($deadline->getTimestamp() - $this->clock->now()->getTimestamp()) / 86400));
            $request->getSession()->getFlashBag()->add('warning', sprintf('MFA är obligatoriskt för din roll. %d dagar återstår – aktivera MFA under Säker inloggning.', $remainingDays));
        } elseif (!$requiredByPolicy && null !== $user->getMfaEnrollmentDeadline()) {
            $user->clearMfaRequirement();
            $this->entityManager->flush();
        }
        if (
            $this->mfaPolicyResolver->isMfaAvailable($user)
            && $user->isMfaEnabled()
            && !$user->isMfaSetupCompleted()
        ) {
            if (str_starts_with($route, 'app_portal_security')) {
                return;
            }

            if (str_starts_with($request->getPathInfo(), '/portal')) {
                $event->setResponse(new RedirectResponse($this->urlGenerator->generate('app_portal_security')));
            }

            return;
        }

        if (!$this->mfaPolicyResolver->requiresMfa($user) || $this->mfaSessionManager->isVerified($request->getSession(), $user)) {
            return;
        }

        if ($this->mfaTrustedDeviceManager->isTrusted($request, $user)) {
            $this->mfaSessionManager->markVerified($request->getSession(), $user);

            return;
        }

        if ($this->shouldBypass($request->getPathInfo(), $route)) {
            return;
        }

        if (str_starts_with($request->getPathInfo(), '/portal')) {
            $this->saveTargetPath($request->getSession(), 'main', $request->getUri());
        }

        $event->setResponse(new RedirectResponse($this->urlGenerator->generate('app_mfa_challenge')));
    }

    private function shouldBypass(string $path, string $route): bool
    {
        if (str_starts_with($path, '/_wdt') || str_starts_with($path, '/_profiler')) {
            return true;
        }

        if (\in_array($route, [
            'app_mfa_challenge',
            'app_logout',
            'app_home',
            'app_news_index',
            'app_news_index_en',
            'app_news_show',
            'app_news_show_en',
            'app_public_search',
            'app_public_search_en',
            'app_contact',
            'app_contact_en',
            'app_status_page',
            'app_status_page_en',
            'app_knowledge_base_public',
            'app_knowledge_base_public_en',
            'app_cookie_policy',
            'app_cookie_policy_en',
            'app_privacy_policy',
            'app_privacy_policy_en',
            'app_terms_page',
            'app_terms_page_en',
            'app_locale_switch',
        ], true)) {
            return true;
        }

        return \in_array($path, [
            '/',
            '/nyheter',
            '/news',
            '/sok',
            '/search',
            '/kontakta-oss',
            '/contact',
            '/driftstatus',
            '/status',
            '/kunskapsbas',
            '/knowledge-base',
            '/cookiepolicy',
            '/cookie-policy',
            '/integritetspolicy',
            '/privacy-policy',
            '/anvandarvillkor',
            '/terms',
            '/mfa',
            '/logout',
        ], true) || str_starts_with($path, '/nyheter/') || str_starts_with($path, '/news/');
    }
}
