<?php

declare(strict_types=1);

namespace App\Module\Identity\Entity;

use App\Module\Identity\Enum\UserType;
use App\Module\Shared\Entity\TimestampableTrait;
use App\Module\System\Locale\AppLocale;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Security\Core\User\PasswordAuthenticatedUserInterface;
use Symfony\Component\Security\Core\User\UserInterface;
use Symfony\Component\Uid\Uuid;

#[ORM\Entity]
#[ORM\Table(name: 'users')]
#[ORM\HasLifecycleCallbacks]
class User implements UserInterface, PasswordAuthenticatedUserInterface
{
    use TimestampableTrait;

    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(type: 'uuid', unique: true)]
    private Uuid $publicId;

    #[ORM\Column(length: 180, unique: true)]
    private string $email;

    /**
     * @var list<string>
     */
    #[ORM\Column]
    private array $roles = [];

    #[ORM\Column]
    private string $password;

    #[ORM\Column(length: 80)]
    private string $firstName;

    #[ORM\Column(length: 80)]
    private string $lastName;

    #[ORM\Column(enumType: UserType::class)]
    private UserType $type;

    #[ORM\Column]
    private bool $isActive = true;

    #[ORM\Column]
    private bool $mfaEnabled = false;

    #[ORM\Column(length: 255, nullable: true)]
    private ?string $mfaSecret = null;

    #[ORM\Column(nullable: true)]
    private ?bool $mfaSetupCompleted = null;

    #[ORM\Column(nullable: true)]
    private ?\DateTimeImmutable $mfaRequirementAssignedAt = null;

    #[ORM\Column(nullable: true)]
    private ?\DateTimeImmutable $mfaEnrollmentDeadline = null;

    #[ORM\Column]
    private bool $emailNotificationsEnabled = true;

    #[ORM\Column]
    private bool $passwordChangeRequired = false;

    #[ORM\Column(length: 16, nullable: true)]
    private ?string $preferredLocale = null;

    /**
     * @var array<string, mixed>|null
     */
    #[ORM\Column(nullable: true)]
    private ?array $technicianPortalPreferences = null;

    /**
     * @var array<string, mixed>|null
     */
    #[ORM\Column(nullable: true)]
    private ?array $customerPortalPreferences = null;

    #[ORM\ManyToOne(targetEntity: Company::class, inversedBy: 'users')]
    #[ORM\JoinColumn(onDelete: 'SET NULL', nullable: true)]
    private ?Company $company = null;

    #[ORM\ManyToOne(targetEntity: TechnicianTeam::class)]
    #[ORM\JoinColumn(onDelete: 'SET NULL', nullable: true)]
    private ?TechnicianTeam $technicianTeam = null;

    /**
     * @var Collection<int, TechnicianTeam>
     */
    #[ORM\ManyToMany(targetEntity: TechnicianTeam::class, inversedBy: 'members')]
    #[ORM\JoinTable(name: 'technician_team_memberships')]
    #[ORM\JoinColumn(name: 'user_id', referencedColumnName: 'id', onDelete: 'CASCADE')]
    #[ORM\InverseJoinColumn(name: 'technician_team_id', referencedColumnName: 'id', onDelete: 'CASCADE')]
    #[ORM\OrderBy(['name' => 'ASC'])]
    private Collection $technicianTeams;

    public function __construct(
        string $email,
        string $firstName,
        string $lastName,
        UserType $type,
    ) {
        $this->publicId = Uuid::v7();
        $this->email = mb_strtolower(trim($email));
        $this->firstName = trim($firstName);
        $this->lastName = trim($lastName);
        $this->type = $type;
        $this->password = '';
        $this->technicianTeams = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getPublicId(): Uuid
    {
        return $this->publicId;
    }

    public function getEmail(): string
    {
        return $this->email;
    }

    public function setEmail(string $email): self
    {
        $this->email = mb_strtolower(trim($email));

        return $this;
    }

    public function getUserIdentifier(): string
    {
        return $this->email;
    }

    /**
     * @return list<string>
     */
    public function getRoles(): array
    {
        if ($this->isArchivedPlaceholder()) {
            return ['ROLE_USER'];
        }

        $roles = [...$this->roles, ...$this->type->defaultRoles()];
        $roles[] = 'ROLE_USER';

        $roles = array_values(array_unique($roles));
        sort($roles);

        return $roles;
    }

    /**
     * @param list<string> $roles
     */
    public function setRoles(array $roles): self
    {
        $this->roles = array_values(array_unique($roles));

        return $this;
    }

    public function getPassword(): string
    {
        return $this->password;
    }

    public function setPassword(string $password): self
    {
        $this->password = $password;

        return $this;
    }

    public function eraseCredentials(): void
    {
    }

    public function getFirstName(): string
    {
        return $this->firstName;
    }

    public function setFirstName(string $firstName): self
    {
        $this->firstName = trim($firstName);

        return $this;
    }

    public function getLastName(): string
    {
        return $this->lastName;
    }

    public function setLastName(string $lastName): self
    {
        $this->lastName = trim($lastName);

        return $this;
    }

    public function getDisplayName(): string
    {
        return trim(sprintf('%s %s', $this->firstName, $this->lastName));
    }

    public function getType(): UserType
    {
        return $this->type;
    }

    public function isArchivedPlaceholder(): bool
    {
        return !$this->isActive && str_ends_with($this->email, '@deleted.local');
    }

    public function setType(UserType $type): self
    {
        $this->type = $type;

        return $this;
    }

    public function isActive(): bool
    {
        return $this->isActive;
    }

    public function activate(): self
    {
        $this->isActive = true;

        return $this;
    }

    public function deactivate(): self
    {
        $this->isActive = false;

        return $this;
    }

    public function isMfaEnabled(): bool
    {
        return $this->mfaEnabled;
    }

    public function enableMfa(): self
    {
        $this->mfaEnabled = true;

        return $this;
    }

    public function disableMfa(): self
    {
        $this->mfaEnabled = false;
        $this->mfaSetupCompleted = false;

        return $this;
    }

    public function getMfaSecret(): ?string
    {
        return $this->mfaSecret;
    }

    public function setMfaSecret(?string $mfaSecret): self
    {
        $normalizedSecret = null !== $mfaSecret ? trim($mfaSecret) : null;
        if (null !== $normalizedSecret && !str_starts_with($normalizedSecret, 'enc:v')) {
            $normalizedSecret = strtoupper($normalizedSecret);
        }
        $this->mfaSecret = '' !== (string) $normalizedSecret ? $normalizedSecret : null;

        return $this;
    }

    public function clearMfaSecret(): self
    {
        $this->mfaSecret = null;
        $this->mfaSetupCompleted = false;

        return $this;
    }

    public function getMfaRequirementAssignedAt(): ?\DateTimeImmutable
    {
        return $this->mfaRequirementAssignedAt;
    }

    public function getMfaEnrollmentDeadline(): ?\DateTimeImmutable
    {
        return $this->mfaEnrollmentDeadline;
    }

    public function assignMfaRequirement(\DateTimeImmutable $assignedAt, \DateTimeImmutable $deadline): self
    {
        $this->mfaRequirementAssignedAt = $assignedAt;
        $this->mfaEnrollmentDeadline = $deadline;

        return $this;
    }

    public function clearMfaRequirement(): self
    {
        $this->mfaRequirementAssignedAt = null;
        $this->mfaEnrollmentDeadline = null;

        return $this;
    }

    public function isMfaSetupCompleted(): bool
    {
        if (null !== $this->mfaSetupCompleted) {
            return $this->mfaSetupCompleted;
        }

        return $this->mfaEnabled && null !== $this->mfaSecret && '' !== $this->mfaSecret;
    }

    public function markMfaSetupPending(): self
    {
        $this->mfaSetupCompleted = false;

        return $this;
    }

    public function markMfaSetupCompleted(): self
    {
        $this->mfaSetupCompleted = true;

        return $this;
    }

    public function isEmailNotificationsEnabled(): bool
    {
        return $this->emailNotificationsEnabled;
    }

    public function enableEmailNotifications(): self
    {
        $this->emailNotificationsEnabled = true;

        return $this;
    }

    public function disableEmailNotifications(): self
    {
        $this->emailNotificationsEnabled = false;

        return $this;
    }

    public function isPasswordChangeRequired(): bool
    {
        return $this->passwordChangeRequired;
    }

    public function requirePasswordChange(): self
    {
        $this->passwordChangeRequired = true;

        return $this;
    }

    public function clearPasswordChangeRequired(): self
    {
        $this->passwordChangeRequired = false;

        return $this;
    }

    public function getPreferredLocale(): ?string
    {
        return $this->preferredLocale;
    }

    public function setPreferredLocale(?string $preferredLocale): self
    {
        $preferredLocale = null !== $preferredLocale ? trim($preferredLocale) : null;
        $this->preferredLocale = '' !== (string) $preferredLocale ? AppLocale::normalize($preferredLocale) : null;

        return $this;
    }

    /**
     * @return array<string, mixed>
     */
    public function getTechnicianPortalPreferences(): array
    {
        return $this->technicianPortalPreferences ?? [];
    }

    /**
     * @param array<string, mixed> $technicianPortalPreferences
     */
    public function setTechnicianPortalPreferences(array $technicianPortalPreferences): self
    {
        $this->technicianPortalPreferences = [] !== $technicianPortalPreferences ? $technicianPortalPreferences : null;

        return $this;
    }

    /**
     * @return array<string, mixed>
     */
    public function getCustomerPortalPreferences(): array
    {
        return $this->customerPortalPreferences ?? [];
    }

    /**
     * @param array<string, mixed> $customerPortalPreferences
     */
    public function setCustomerPortalPreferences(array $customerPortalPreferences): self
    {
        $this->customerPortalPreferences = [] !== $customerPortalPreferences ? $customerPortalPreferences : null;

        return $this;
    }

    public function getCustomerPortalTheme(): string
    {
        $theme = (string) ($this->getCustomerPortalPreferences()['theme'] ?? 'system');

        return \in_array($theme, ['system', 'light', 'dark', 'contrast'], true) ? $theme : 'system';
    }

    public function setCustomerPortalTheme(string $theme): self
    {
        $preferences = $this->getCustomerPortalPreferences();
        $preferences['theme'] = \in_array($theme, ['system', 'light', 'dark', 'contrast'], true) ? $theme : 'system';
        $this->setCustomerPortalPreferences($preferences);

        return $this;
    }

    public function isVisibleInTechnicianLists(): bool
    {
        $preferences = $this->getTechnicianPortalPreferences();
        if (\array_key_exists('visibleInTechnicianLists', $preferences)) {
            return true === $preferences['visibleInTechnicianLists'];
        }

        return UserType::TECHNICIAN === $this->type;
    }

    public function setVisibleInTechnicianLists(bool $visible): self
    {
        $preferences = $this->getTechnicianPortalPreferences();
        $preferences['visibleInTechnicianLists'] = $visible;
        $this->setTechnicianPortalPreferences($preferences);

        return $this;
    }

    public function getEffectiveLocale(): string
    {
        return $this->preferredLocale
            ?? $this->company?->getPreferredLocale()
            ?? AppLocale::DEFAULT;
    }

    public function getCompany(): ?Company
    {
        return $this->company;
    }

    public function setCompany(?Company $company): self
    {
        $this->company = $company;

        return $this;
    }

    public function getTechnicianTeam(): ?TechnicianTeam
    {
        return $this->technicianTeam;
    }

    public function setTechnicianTeam(?TechnicianTeam $technicianTeam): self
    {
        $this->technicianTeam = $technicianTeam;
        if ($technicianTeam instanceof TechnicianTeam) {
            $this->addTechnicianTeam($technicianTeam);
        }

        return $this;
    }

    /**
     * @return Collection<int, TechnicianTeam>
     */
    public function getTechnicianTeams(): Collection
    {
        return $this->technicianTeams;
    }

    /**
     * @param iterable<TechnicianTeam> $technicianTeams
     */
    public function setTechnicianTeams(iterable $technicianTeams): self
    {
        $this->technicianTeams->clear();

        foreach ($technicianTeams as $technicianTeam) {
            if ($technicianTeam instanceof TechnicianTeam) {
                $this->addTechnicianTeam($technicianTeam);
            }
        }

        if ($this->technicianTeam instanceof TechnicianTeam) {
            $this->addTechnicianTeam($this->technicianTeam);
        }

        return $this;
    }

    public function addTechnicianTeam(TechnicianTeam $technicianTeam): self
    {
        if (!$this->technicianTeams->contains($technicianTeam)) {
            $this->technicianTeams->add($technicianTeam);
        }

        return $this;
    }

    public function removeTechnicianTeam(TechnicianTeam $technicianTeam): self
    {
        $this->technicianTeams->removeElement($technicianTeam);
        if ($this->sameTechnicianTeam($this->technicianTeam, $technicianTeam)) {
            $this->technicianTeam = null;
        }

        return $this;
    }

    public function isMemberOfTechnicianTeam(?TechnicianTeam $technicianTeam): bool
    {
        if (!$technicianTeam instanceof TechnicianTeam) {
            return false;
        }

        foreach ($this->technicianTeams as $memberTeam) {
            if ($this->sameTechnicianTeam($memberTeam, $technicianTeam)) {
                return true;
            }
        }

        return false;
    }

    private function sameTechnicianTeam(?TechnicianTeam $left, ?TechnicianTeam $right): bool
    {
        if (!$left instanceof TechnicianTeam || !$right instanceof TechnicianTeam) {
            return false;
        }

        if ($left === $right) {
            return true;
        }

        return null !== $left->getId() && $left->getId() === $right->getId();
    }
}
