<?php

declare(strict_types=1);

namespace App\Module\Mail\Enum;

enum DraftTicketReviewKind: string
{
    case UNKNOWN_SENDER = 'unknown_sender';
    case UNAUTHORIZED_REPLY = 'unauthorized_reply';
    case MANUAL_CORRECTION = 'manual_correction';
}
