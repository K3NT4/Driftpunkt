<?php

declare(strict_types=1);

namespace App\Module\Inventory\Service;

use App\Module\Identity\Entity\Company;
use App\Module\Identity\Entity\User;
use App\Module\Identity\Enum\UserType;
use App\Module\Inventory\Entity\InventoryAuditLog;
use App\Module\Inventory\Entity\InventoryItem;
use App\Module\Inventory\Entity\InventoryListSetting;
use App\Module\Inventory\Enum\InventoryListType;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\HttpFoundation\File\UploadedFile;

final class InventoryService
{
    public function __construct(
        private readonly EntityManagerInterface $entityManager,
    ) {
    }

    public function setting(Company $company, InventoryListType $type, bool $create = false): ?InventoryListSetting
    {
        $setting = $this->entityManager->getRepository(InventoryListSetting::class)->findOneBy([
            'company' => $company,
            'type' => $type,
        ]);

        if (!$setting instanceof InventoryListSetting && $create) {
            $setting = new InventoryListSetting($company, $type);
            $this->entityManager->persist($setting);
        }

        return $setting instanceof InventoryListSetting ? $setting : null;
    }

    public function isEnabled(?Company $company, InventoryListType|string $type): bool
    {
        if (!$company instanceof Company) {
            return false;
        }

        $type = \is_string($type) ? InventoryListType::tryFrom($type) : $type;
        if (!$type instanceof InventoryListType) {
            return false;
        }

        return true === $this->setting($company, $type)?->isEnabled();
    }

    public function hasAnyEnabledList(): bool
    {
        return $this->entityManager->getRepository(InventoryListSetting::class)->count(['enabled' => true]) > 0;
    }

    /**
     * @return array<string, array{enabled: bool, count: int, lastImportedAt: ?\DateTimeImmutable, lastImportFilename: ?string, accessRestricted: bool, allowedUserIds: list<int>, allowedUsers: list<User>}>
     */
    public function companySummary(Company $company): array
    {
        $summary = [];
        foreach (InventoryListType::cases() as $type) {
            $setting = $this->setting($company, $type);
            $allowedUsers = $setting instanceof InventoryListSetting
                ? $this->sortUsers($setting->getAllowedUsers()->toArray())
                : [];
            $summary[$type->value] = [
                'enabled' => $setting?->isEnabled() ?? false,
                'count' => $this->countItems($company, $type),
                'lastImportedAt' => $setting?->getLastImportedAt(),
                'lastImportFilename' => $setting?->getLastImportFilename(),
                'accessRestricted' => $setting?->isAccessRestricted() ?? false,
                'allowedUserIds' => array_values(array_filter(array_map(static fn (User $user): ?int => $user->getId(), $allowedUsers))),
                'allowedUsers' => $allowedUsers,
            ];
        }

        return $summary;
    }

    public function canUserAccessList(?User $user, InventoryListType|string $type): bool
    {
        if (!$user instanceof User || !$user->isActive() || UserType::CUSTOMER !== $user->getType()) {
            return false;
        }

        $company = $user->getCompany();
        if (!$company instanceof Company) {
            return false;
        }

        $type = \is_string($type) ? InventoryListType::tryFrom($type) : $type;
        if (!$type instanceof InventoryListType) {
            return false;
        }

        $setting = $this->setting($company, $type);
        if (!$setting instanceof InventoryListSetting || !$setting->isEnabled()) {
            return false;
        }

        $userId = $user->getId();
        if (null === $userId) {
            return false;
        }

        foreach ($setting->getAllowedUsers() as $allowedUser) {
            if ($allowedUser->isActive() && $allowedUser->getId() === $userId && $this->isEligibleCustomerUser($company, $allowedUser)) {
                return true;
            }
        }

        return false;
    }

    /**
     * @return list<User>
     */
    public function customerUsers(Company $company): array
    {
        return $this->sortUsers(array_values(array_filter(
            $company->getUsers()->toArray(),
            fn (User $user): bool => $this->isEligibleCustomerUser($company, $user),
        )));
    }

    public function countItems(Company $company, InventoryListType $type): int
    {
        return $this->entityManager->getRepository(InventoryItem::class)->count([
            'company' => $company,
            'type' => $type,
        ]);
    }

    /**
     * @return list<InventoryItem>
     */
    public function items(Company $company, InventoryListType $type, string $query = '', ?string $sort = null, string $direction = 'asc'): array
    {
        $sort = $this->validSortColumn($type, $sort);
        $direction = 'desc' === mb_strtolower($direction) ? 'DESC' : 'ASC';

        $qb = $this->entityManager->getRepository(InventoryItem::class)->createQueryBuilder('item')
            ->andWhere('item.company = :company')
            ->andWhere('item.type = :type')
            ->setParameter('company', $company)
            ->setParameter('type', $type)
            ->orderBy('item.'.$sort, $direction)
            ->addOrderBy('item.updatedAt', 'DESC')
            ->addOrderBy('item.id', 'ASC');

        $query = mb_strtolower(trim($query));
        if ('' !== $query) {
            $qb
                ->andWhere('LOWER(CONCAT(COALESCE(item.hostname, \'\'), \' \', COALESCE(item.assignedTo, \'\'), \' \', COALESCE(item.loginName, \'\'), \' \', COALESCE(item.manufacturer, \'\'), \' \', COALESCE(item.model, \'\'), \' \', COALESCE(item.serialNumber, \'\'), \' \', COALESCE(item.orderNumber, \'\'), \' \', COALESCE(item.ipAddress, \'\'), \' \', COALESCE(item.printerName, \'\'), \' \', COALESCE(item.area, \'\'), \' \', COALESCE(item.terminalId, \'\'), \' \', COALESCE(item.provider, \'\'), \' \', COALESCE(item.deviceType, \'\'), \' \', COALESCE(item.terminalName, \'\'), \' \', COALESCE(item.adminCard, \'\'), \' \', COALESCE(item.baseStationName, \'\'), \' \', COALESCE(item.baseStationModel, \'\'), \' \', COALESCE(item.baseStationSerialNumber, \'\'), \' \', COALESCE(item.screenSize, \'\'), \' \', COALESCE(item.resolution, \'\'), \' \', COALESCE(item.connectionType, \'\'))) LIKE :query')
                ->setParameter('query', '%'.$query.'%');
        }

        return $qb->getQuery()->getResult();
    }

    /**
     * @return array{imported: int, removed: int}
     */
    public function importCsv(Company $company, InventoryListType $type, UploadedFile $file, User $actor): array
    {
        $rows = $this->parseCsv($file);
        $this->validateCsvHeaders($type, array_keys($rows[0] ?? []));
        $items = [];
        $seenUniqueValues = [];
        foreach ($rows as $row) {
            $item = new InventoryItem($company, $type);
            $data = $this->dataFromCsvRow($type, $row);
            $uniqueField = $this->uniqueField($type);
            $normalizedUniqueValue = null === $uniqueField ? '' : $this->normalizedUniqueValue($data[$uniqueField] ?? null);
            if ('' !== $normalizedUniqueValue) {
                if (isset($seenUniqueValues[$normalizedUniqueValue])) {
                    throw new \InvalidArgumentException($this->duplicateMessage($type));
                }
                $seenUniqueValues[$normalizedUniqueValue] = true;
            }

            $item->applyData($data);
            $items[] = $item;
        }

        $removed = $this->deleteItems($company, $type);
        foreach ($items as $item) {
            $this->entityManager->persist($item);
        }

        $setting = $this->setting($company, $type, true);
        \assert($setting instanceof InventoryListSetting);
        $setting->markImported($file->getClientOriginalName());
        $this->log($company, $type, $actor, 'import', [
            'filename' => $file->getClientOriginalName(),
            'imported' => \count($items),
            'removed' => $removed,
        ]);
        $this->entityManager->flush();

        return ['imported' => \count($items), 'removed' => $removed];
    }

    /**
     * @param array<string, mixed> $data
     */
    public function createItem(Company $company, InventoryListType $type, array $data, User $actor): InventoryItem
    {
        $item = new InventoryItem($company, $type);
        $normalizedData = $this->normalizeFormData($type, $data);
        $this->assertUniqueValueAvailable($company, $type, $normalizedData);
        $item->applyData($normalizedData);
        $this->entityManager->persist($item);
        $this->log($company, $type, $actor, 'item_created', ['item' => $item->snapshot()]);
        $this->entityManager->flush();

        return $item;
    }

    /**
     * @param array<string, mixed> $data
     */
    public function updateItem(InventoryItem $item, array $data, User $actor): void
    {
        $before = $item->snapshot();
        $normalizedData = $this->normalizeFormData($item->getType(), $data);
        $this->assertUniqueValueAvailable($item->getCompany(), $item->getType(), $normalizedData, $item);
        $item->applyData($normalizedData);
        $after = $item->snapshot();
        $this->log($item->getCompany(), $item->getType(), $actor, 'item_updated', [
            'itemId' => $item->getId(),
            'before' => $before,
            'after' => $after,
        ]);
        $this->entityManager->flush();
    }

    public function deleteItem(InventoryItem $item, User $actor): void
    {
        $this->log($item->getCompany(), $item->getType(), $actor, 'item_deleted', [
            'itemId' => $item->getId(),
            'item' => $item->snapshot(),
        ]);
        $this->entityManager->remove($item);
        $this->entityManager->flush();
    }

    public function setEnabled(Company $company, InventoryListType $type, bool $enabled, User $actor): void
    {
        $setting = $this->setting($company, $type, true);
        \assert($setting instanceof InventoryListSetting);
        $setting->setEnabled($enabled);
        $this->log($company, $type, $actor, $enabled ? 'enabled' : 'disabled', ['rowCount' => $this->countItems($company, $type)]);
        $this->entityManager->flush();
    }

    /**
     * @param list<int> $allowedUserIds
     */
    public function setAccess(Company $company, InventoryListType $type, bool $restricted, array $allowedUserIds, User $actor): void
    {
        $setting = $this->setting($company, $type, true);
        \assert($setting instanceof InventoryListSetting);

        $setting->setAccessRestricted(true);
        $setting->clearAllowedUsers();

        if ([] !== $allowedUserIds) {
            $users = $this->entityManager->getRepository(User::class)->findBy(['id' => array_values(array_unique($allowedUserIds))]);
            foreach ($users as $user) {
                if ($this->isEligibleCustomerUser($company, $user)) {
                    $setting->addAllowedUser($user);
                }
            }
        }

        $this->log($company, $type, $actor, 'access_updated', [
            'restricted' => $setting->isAccessRestricted(),
            'allowedUserIds' => array_values(array_filter(array_map(
                static fn (User $user): ?int => $user->getId(),
                $setting->getAllowedUsers()->toArray(),
            ))),
        ]);
        $this->entityManager->flush();
    }

    public function deleteList(Company $company, InventoryListType $type, User $actor): int
    {
        $rowCount = $this->countItems($company, $type);
        $this->deleteItems($company, $type);
        $setting = $this->setting($company, $type);
        if ($setting instanceof InventoryListSetting) {
            $this->entityManager->remove($setting);
        }

        $this->log($company, $type, $actor, 'list_deleted', ['rowCount' => $rowCount]);
        $this->entityManager->flush();

        return $rowCount;
    }

    /**
     * @return list<array{key: string, label: string}>
     */
    public function columns(InventoryListType $type): array
    {
        return match ($type) {
            InventoryListType::COMPUTER => [
                ['key' => 'hostname', 'label' => 'Hostname'],
                ['key' => 'deviceType', 'label' => 'Enhetstyp'],
                ['key' => 'assignedTo', 'label' => 'Användare / Avdelning'],
                ['key' => 'loginName', 'label' => 'Inloggningsnamn'],
                ['key' => 'area', 'label' => 'Placering'],
                ['key' => 'manufacturer', 'label' => 'Fabrikat'],
                ['key' => 'model', 'label' => 'Modell'],
                ['key' => 'serialNumber', 'label' => 'SN:'],
                ['key' => 'orderNumber', 'label' => 'Ordernummer'],
                ['key' => 'operatingSystem', 'label' => 'OS'],
                ['key' => 'processor', 'label' => 'Processor'],
                ['key' => 'memory', 'label' => 'Minne'],
                ['key' => 'storage', 'label' => 'HD'],
                ['key' => 'purchaseDate', 'label' => 'Inköpsdatum'],
                ['key' => 'warrantyEndsAt', 'label' => 'Sluttid för garantin'],
                ['key' => 'deviceStatus', 'label' => 'Status'],
                ['key' => 'comment', 'label' => 'Kommentar'],
            ],
            InventoryListType::PRINTER => [
                ['key' => 'printerName', 'label' => 'Skrivarens Namn'],
                ['key' => 'printerKind', 'label' => 'Skrivartyp'],
                ['key' => 'area', 'label' => 'Område'],
                ['key' => 'manufacturer', 'label' => 'Fabrikat'],
                ['key' => 'model', 'label' => 'Modell'],
                ['key' => 'serialNumber', 'label' => 'Serienummer'],
                ['key' => 'color', 'label' => 'Utskrift'],
                ['key' => 'connectionType', 'label' => 'Primär anslutning'],
                ['key' => 'ipAddress', 'label' => 'IP-adress'],
                ['key' => 'deviceStatus', 'label' => 'Status'],
                ['key' => 'consumables', 'label' => 'Toner/bläckmodell'],
                ['key' => 'installationDate', 'label' => 'Installation'],
                ['key' => 'pin', 'label' => 'Utskrifts-PIN'],
            ],
            InventoryListType::MONITOR => [
                ['key' => 'assignedTo', 'label' => 'Användare / Avdelning'],
                ['key' => 'area', 'label' => 'Placering'],
                ['key' => 'manufacturer', 'label' => 'Fabrikat'],
                ['key' => 'model', 'label' => 'Modell'],
                ['key' => 'serialNumber', 'label' => 'Serienummer'],
                ['key' => 'orderNumber', 'label' => 'Ordernummer'],
                ['key' => 'screenSize', 'label' => 'Storlek i tum'],
                ['key' => 'resolution', 'label' => 'Upplösning'],
                ['key' => 'connectionType', 'label' => 'Primär anslutning'],
                ['key' => 'deviceStatus', 'label' => 'Status'],
                ['key' => 'comment', 'label' => 'Kommentar'],
            ],
            InventoryListType::PAYMENT_TERMINAL => [
                ['key' => 'terminalId', 'label' => 'Terminal-ID'],
                ['key' => 'deviceType', 'label' => 'Enhetstyp'],
                ['key' => 'terminalName', 'label' => 'Namn'],
                ['key' => 'area', 'label' => 'Område'],
                ['key' => 'hasBaseStation', 'label' => 'Har basstation'],
                ['key' => 'baseStationName', 'label' => 'Basstationens namn'],
                ['key' => 'baseStationModel', 'label' => 'Basstationens modell'],
                ['key' => 'baseStationSerialNumber', 'label' => 'Basstationens serienummer'],
                ['key' => 'provider', 'label' => 'Leverantör'],
                ['key' => 'model', 'label' => 'Modell'],
                ['key' => 'serialNumber', 'label' => 'Serienummer'],
                ['key' => 'connectionType', 'label' => 'Anslutning'],
                ['key' => 'available', 'label' => 'I drift'],
                ['key' => 'payAtTable', 'label' => 'Pay@Table (bordsbetalning)'],
                ['key' => 'adminCard', 'label' => 'Administratörskort'],
                ['key' => 'comment', 'label' => 'Kommentar'],
            ],
        };
    }

    public function value(InventoryItem $item, string $key): string
    {
        $snapshot = $item->snapshot();
        $value = $snapshot[$key] ?? null;
        if (null === $value && \in_array($key, ['payAtTable', 'hasBaseStation'], true)) {
            return 'Ej angivet';
        }
        if (\is_bool($value)) {
            return $value ? 'Ja' : 'Nej';
        }

        return (string) $value;
    }

    private function validSortColumn(InventoryListType $type, ?string $sort): string
    {
        $columnKeys = array_column($this->columns($type), 'key');
        if (\is_string($sort) && \in_array($sort, $columnKeys, true)) {
            return $sort;
        }

        return match ($type) {
            InventoryListType::COMPUTER => 'hostname',
            InventoryListType::PRINTER => 'printerName',
            InventoryListType::MONITOR => 'serialNumber',
            InventoryListType::PAYMENT_TERMINAL => 'terminalId',
        };
    }

    /**
     * @param array<string, mixed> $data
     */
    private function assertUniqueValueAvailable(Company $company, InventoryListType $type, array $data, ?InventoryItem $currentItem = null): void
    {
        $field = $this->uniqueField($type);
        if (null === $field) {
            return;
        }

        $value = $this->normalizedUniqueValue($data[$field] ?? null);
        if ('' === $value) {
            return;
        }

        $items = $this->entityManager->getRepository(InventoryItem::class)->findBy([
            'company' => $company,
            'type' => $type,
        ]);

        foreach ($items as $item) {
            if ($currentItem instanceof InventoryItem && $item->getId() === $currentItem->getId()) {
                continue;
            }

            $candidate = match ($type) {
                InventoryListType::COMPUTER => $item->getHostname(),
                InventoryListType::PRINTER => $item->getIpAddress(),
                InventoryListType::MONITOR => null,
                InventoryListType::PAYMENT_TERMINAL => $item->getTerminalId(),
            };
            if ($value === $this->normalizedUniqueValue($candidate)) {
                throw new \InvalidArgumentException($this->duplicateMessage($type));
            }
        }
    }

    private function uniqueField(InventoryListType $type): ?string
    {
        return match ($type) {
            InventoryListType::COMPUTER => 'hostname',
            InventoryListType::PRINTER => 'ipAddress',
            InventoryListType::MONITOR => null,
            InventoryListType::PAYMENT_TERMINAL => 'terminalId',
        };
    }

    private function duplicateMessage(InventoryListType $type): string
    {
        return match ($type) {
            InventoryListType::COMPUTER => 'Hostname finns redan i den här datorlistan.',
            InventoryListType::PRINTER => 'IP finns redan i den här skrivarlistan.',
            InventoryListType::MONITOR => '',
            InventoryListType::PAYMENT_TERMINAL => 'Terminal-ID finns redan i den här kortterminallistan.',
        };
    }

    private function normalizedUniqueValue(mixed $value): string
    {
        return mb_strtolower(trim((string) $value));
    }

    private function deleteItems(Company $company, InventoryListType $type): int
    {
        $items = $this->entityManager->getRepository(InventoryItem::class)->findBy([
            'company' => $company,
            'type' => $type,
        ]);
        foreach ($items as $item) {
            $this->entityManager->remove($item);
        }

        return \count($items);
    }

    /**
     * @return list<array<string, string>>
     */
    private function parseCsv(UploadedFile $file): array
    {
        if (!$file->isValid()) {
            throw new \InvalidArgumentException('CSV-filen kunde inte läsas.');
        }

        $sample = (string) file_get_contents($file->getPathname(), false, null, 0, 4096);
        $delimiter = $this->detectDelimiter($sample);
        $csv = new \SplFileObject($file->getPathname(), 'r');
        $csv->setCsvControl($delimiter, '"', '');
        $csv->setFlags(\SplFileObject::READ_CSV | \SplFileObject::SKIP_EMPTY);

        $headers = [];
        $rows = [];
        foreach ($csv as $cells) {
            if (!\is_array($cells) || [null] === $cells) {
                continue;
            }

            $values = array_map(static fn (mixed $value): string => trim((string) $value), $cells);
            if ([] === array_filter($values, static fn (string $value): bool => '' !== $value)) {
                continue;
            }

            if ([] === $headers) {
                $headers = array_map(fn (string $header): string => $this->cleanHeader($header), $values);
                continue;
            }

            $row = [];
            foreach ($headers as $index => $header) {
                $row[$header] = $values[$index] ?? '';
            }
            $rows[] = $row;
        }

        if ([] === $headers || [] === $rows) {
            throw new \InvalidArgumentException('CSV-filen behöver minst en rubrikrad och en datarad.');
        }

        return $rows;
    }

    /**
     * @param array<string, string> $row
     * @return array<string, mixed>
     */
    private function dataFromCsvRow(InventoryListType $type, array $row): array
    {
        $lookup = [];
        foreach ($row as $header => $value) {
            $lookup[$this->normalizeHeader($header)] = $value;
        }

        $get = fn (string ...$headers): string => $this->firstHeaderValue($lookup, $headers);

        return match ($type) {
            InventoryListType::COMPUTER => [
                'hostname' => $get('Hostname', 'Datornamn'),
                'deviceType' => $get('Enhetstyp', 'Datortyp', 'Typ'),
                'assignedTo' => $get('Användare / Avdelning', 'Anvandare / Avdelning', 'Användare', 'Anvandare'),
                'loginName' => $get('Inloggningsnamn', 'Inloggnings namn', 'Login'),
                'area' => $get('Placering', 'Område', 'Omrade'),
                'manufacturer' => $get('Fabrikat'),
                'model' => $get('Modell'),
                'serialNumber' => $get('SN:', 'SN', 'Serienummer', 'Serinummer', 'Serier'),
                'orderNumber' => $get('Ordernummer', 'Order nr', 'Order-nr', 'Order Number'),
                'operatingSystem' => $get('OS'),
                'processor' => $get('Processor'),
                'memory' => $get('Minne', 'Minne (GB)'),
                'storage' => $get('HD'),
                'purchaseDate' => $this->parseDate($get('Inköpsdatum', 'Inkopsdatum', 'Inköpt', 'Inkopt')),
                'warrantyEndsAt' => $this->parseDate($get('Sluttid för garantin', 'Sluttid for garantin', 'Utökad Garanti', 'Utökad garanti')),
                'deviceStatus' => $this->computerStatusFromCsv($get('Status'), $get('Trasig')),
                'comment' => $get('Kommentar'),
            ],
            InventoryListType::PRINTER => [
                'ipAddress' => $get('IP-adress/hostname', 'IP-adress', 'IP', 'Hostname'),
                'printerKind' => $get('Skrivartyp', 'Vad för skrivare', 'Vad for skrivare'),
                'printerName' => $get('Skrivarens Namn', 'Skrivarens namn'),
                'area' => $get('Område', 'Omrade'),
                'serialNumber' => $get('Serinummer', 'Serienummer'),
                'color' => $get('Utskrift', 'Färg', 'Farg'),
                'manufacturer' => $get('Fabrikat', 'Tillverkare'),
                'model' => $get('Modell'),
                'connectionType' => $get('Primär anslutning', 'Anslutning'),
                'deviceStatus' => $this->printerStatusFromCsv($get('Status'), $get('Tillgänglig', 'Tillganglig')),
                'consumables' => $get('Toner/bläckmodell', 'Toner/blackmodell', 'Toner', 'Bläckmodell'),
                'installationDate' => $this->parseDate($get('Installation')),
                'pin' => $get('Utskrifts-PIN', 'PIN'),
            ],
            InventoryListType::MONITOR => [
                'assignedTo' => $get('Användare / Avdelning', 'Anvandare / Avdelning'),
                'area' => $get('Placering'),
                'manufacturer' => $get('Fabrikat'),
                'model' => $get('Modell'),
                'serialNumber' => $get('Serienummer', 'Serinummer'),
                'orderNumber' => $get('Ordernummer', 'Order nr', 'Order-nr', 'Order Number'),
                'screenSize' => $get('Storlek i tum'),
                'resolution' => $get('Upplösning', 'Upplosning'),
                'connectionType' => $get('Primär anslutning', 'Anslutning'),
                'deviceStatus' => $this->computerStatusFromCsv($get('Status'), $get('Trasig')),
                'comment' => $get('Kommentar'),
            ],
            InventoryListType::PAYMENT_TERMINAL => [
                'terminalId' => $get('Terminal-ID', 'Terminal ID', 'S/N', 'SN'),
                'deviceType' => $get('Enhetstyp', 'Typ'),
                'terminalName' => $get('Namn'),
                'area' => $get('Område', 'Omrade', 'Placering'),
                'hasBaseStation' => $this->parseNullableBool($get('Har basstation', 'Basstation')),
                'baseStationName' => $get('Basstationens namn', 'Basstation namn'),
                'baseStationModel' => $get('Basstationens modell', 'Basstation modell'),
                'baseStationSerialNumber' => $get('Basstationens serienummer', 'Basstation serienummer', 'Basstation S/N'),
                'provider' => $get('Leverantör', 'Leverantor'),
                'model' => $get('Modell'),
                'serialNumber' => $get('Serienummer', 'Serinummer'),
                'connectionType' => $get('Anslutning'),
                'available' => $this->parseBool($get('I drift')),
                'payAtTable' => $this->parseNullableBool($get('Pay@Table (bordsbetalning)', 'Pay@Table', 'Pay at table')),
                'adminCard' => $get('Administratörskort', 'Admin kort', 'Adminkort'),
                'comment' => $get('Kommentar'),
            ],
        };
    }

    /**
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    private function normalizeFormData(InventoryListType $type, array $data): array
    {
        $normalized = [];
        foreach ($this->columns($type) as $column) {
            $key = $column['key'];
            $value = $data[$key] ?? null;
            if (\in_array($key, ['purchaseDate', 'warrantyEndsAt', 'installationDate'], true)) {
                $value = $this->parseDate((string) $value);
            } elseif (\in_array($key, ['payAtTable', 'hasBaseStation'], true)) {
                $value = $this->parseNullableBool((string) $value);
            } elseif (\in_array($key, ['broken', 'available'], true)) {
                $value = filter_var($value, \FILTER_VALIDATE_BOOL);
            }
            $normalized[$key] = $value;
        }

        return $normalized;
    }

    private function cleanHeader(string $header): string
    {
        return trim(preg_replace('/^\xEF\xBB\xBF/', '', $header) ?? $header);
    }

    private function normalizeHeader(string $header): string
    {
        $ascii = iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $header);
        $normalized = strtolower((string) ($ascii ?: $header));

        return preg_replace('/[^a-z0-9]+/', '', $normalized) ?? '';
    }

    /**
     * @param array<string, string> $lookup
     * @param list<string> $headers
     */
    private function firstHeaderValue(array $lookup, array $headers): string
    {
        foreach ($headers as $header) {
            $key = $this->normalizeHeader($header);
            if (array_key_exists($key, $lookup)) {
                return trim($lookup[$key]);
            }
        }

        return '';
    }

    private function parseDate(string $value): ?\DateTimeImmutable
    {
        $value = trim($value);
        if ('' === $value) {
            return null;
        }

        foreach (['Y-m-d', 'Y/m/d', 'd/m/Y', 'd.m.Y'] as $format) {
            $date = \DateTimeImmutable::createFromFormat('!'.$format, $value);
            $errors = \DateTimeImmutable::getLastErrors();
            if ($date instanceof \DateTimeImmutable && (false === $errors || (0 === $errors['warning_count'] && 0 === $errors['error_count']))) {
                return $date;
            }
        }

        throw new \InvalidArgumentException(sprintf('Datumet "%s" är ogiltigt. Använd exempelvis ÅÅÅÅ-MM-DD.', $value));
    }

    private function parseBool(string $value): bool
    {
        return \in_array(mb_strtolower(trim($value)), ['1', 'ja', 'yes', 'true', 'på', 'pa', 'x'], true);
    }

    private function parseNullableBool(string $value): ?bool
    {
        $value = mb_strtolower(trim($value));
        if ('' === $value || \in_array($value, ['-', 'ej relevant', 'inte tillämpligt', 'okänt'], true)) {
            return null;
        }

        return $this->parseBool($value);
    }

    private function computerStatusFromCsv(string $status, string $broken): string
    {
        $status = trim($status);
        if ('' !== $status) {
            return $status;
        }

        return $this->parseBool($broken) ? 'Trasig' : 'I drift';
    }

    private function printerStatusFromCsv(string $status, string $available): string
    {
        $status = trim($status);
        if ('' !== $status) {
            return $status;
        }

        return $this->parseBool($available) ? 'I drift' : 'Ur drift';
    }

    private function isEligibleCustomerUser(Company $company, User $user): bool
    {
        return $user->isActive()
            && UserType::CUSTOMER === $user->getType()
            && $user->getCompany()?->getId() === $company->getId();
    }

    /**
     * @param list<User> $users
     * @return list<User>
     */
    private function sortUsers(array $users): array
    {
        usort(
            $users,
            static fn (User $left, User $right): int => [$left->getDisplayName(), $left->getEmail(), $left->getId() ?? 0]
                <=> [$right->getDisplayName(), $right->getEmail(), $right->getId() ?? 0],
        );

        return $users;
    }

    /**
     * @param list<string> $headers
     */
    private function validateCsvHeaders(InventoryListType $type, array $headers): void
    {
        $present = array_fill_keys(array_map(fn (string $header): string => $this->normalizeHeader($header), $headers), true);

        if (InventoryListType::COMPUTER === $type) {
            $identityHeaders = array_map(fn (string $header): string => $this->normalizeHeader($header), ['Hostname', 'Datornamn', 'SN', 'SN:', 'Serienummer', 'Serier']);
            if ([] === array_intersect(array_keys($present), $identityHeaders)) {
                throw new \InvalidArgumentException('CSV-filen behöver innehålla Hostname/Datornamn eller Serienummer/SN.');
            }

            return;
        }

        if (InventoryListType::MONITOR === $type) {
            $serialHeaders = array_map(fn (string $header): string => $this->normalizeHeader($header), ['Serienummer', 'Serinummer', 'SN', 'SN:']);
            if ([] === array_intersect(array_keys($present), $serialHeaders)) {
                throw new \InvalidArgumentException('CSV-filen behöver innehålla Serienummer/SN.');
            }

            return;
        }

        if (InventoryListType::PRINTER === $type) {
            $identityHeaders = array_map(fn (string $header): string => $this->normalizeHeader($header), ['Skrivarens Namn', 'Skrivarens namn', 'IP', 'IP-adress', 'IP-adress/hostname', 'Serienummer', 'Serinummer']);
            if ([] === array_intersect(array_keys($present), $identityHeaders)) {
                throw new \InvalidArgumentException('CSV-filen behöver innehålla skrivarnamn, IP-adress eller serienummer.');
            }

            return;
        }

        $optionalKeys = InventoryListType::PAYMENT_TERMINAL === $type
            ? ['deviceType', 'terminalName', 'hasBaseStation', 'baseStationName', 'baseStationModel', 'baseStationSerialNumber', 'adminCard']
            : [];
        $missing = [];
        foreach ($this->columns($type) as $column) {
            if (\in_array($column['key'], $optionalKeys, true)) {
                continue;
            }
            $normalized = $this->normalizeHeader($column['label']);
            if (!isset($present[$normalized])) {
                $missing[] = $column['label'];
            }
        }

        if ([] !== $missing) {
            throw new \InvalidArgumentException(sprintf('CSV-filen saknar kolumner: %s.', implode(', ', $missing)));
        }
    }

    private function detectDelimiter(string $sample): string
    {
        $line = strtok($sample, "\r\n") ?: '';
        $best = ',';
        $bestCount = -1;
        foreach ([',', ';', "\t"] as $delimiter) {
            $count = substr_count($line, $delimiter);
            if ($count > $bestCount) {
                $best = $delimiter;
                $bestCount = $count;
            }
        }

        return $best;
    }

    /**
     * @param array<string, mixed> $details
     */
    private function log(Company $company, InventoryListType $type, ?User $actor, string $action, array $details): void
    {
        $this->entityManager->persist(new InventoryAuditLog($company, $type, $actor, $action, $details));
    }
}
