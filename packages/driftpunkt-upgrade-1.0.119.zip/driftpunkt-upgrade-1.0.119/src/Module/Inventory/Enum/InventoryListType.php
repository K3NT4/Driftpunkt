<?php

declare(strict_types=1);

namespace App\Module\Inventory\Enum;

enum InventoryListType: string
{
    case COMPUTER = 'computer';
    case PRINTER = 'printer';
    case MONITOR = 'monitor';
    case PAYMENT_TERMINAL = 'payment_terminal';

    public function label(): string
    {
        return match ($this) {
            self::COMPUTER => 'Datorlista',
            self::PRINTER => 'Skrivarlista',
            self::MONITOR => 'Skärmlista',
            self::PAYMENT_TERMINAL => 'Kortterminallista',
        };
    }

    public function pluralLabel(): string
    {
        return match ($this) {
            self::COMPUTER => 'Datorer',
            self::PRINTER => 'Skrivare',
            self::MONITOR => 'Skärmar',
            self::PAYMENT_TERMINAL => 'Kortterminaler',
        };
    }

    public function customerRoute(): string
    {
        return match ($this) {
            self::COMPUTER => 'app_inventory_customer_computers',
            self::PRINTER => 'app_inventory_customer_printers',
            self::MONITOR => 'app_inventory_customer_monitors',
            self::PAYMENT_TERMINAL => 'app_inventory_customer_payment_terminals',
        };
    }
}
