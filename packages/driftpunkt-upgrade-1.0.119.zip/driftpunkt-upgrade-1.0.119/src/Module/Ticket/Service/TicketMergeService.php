<?php

declare(strict_types=1);

namespace App\Module\Ticket\Service;

use App\Module\Identity\Entity\Company;
use App\Module\Identity\Entity\User;
use App\Module\Identity\Enum\UserType;
use App\Module\Ticket\Entity\Ticket;
use App\Module\Ticket\Entity\TicketMerge;
use App\Module\Ticket\Entity\TicketParticipant;
use App\Module\Ticket\Enum\TicketParticipantRole;
use App\Module\Ticket\Enum\TicketStatus;
use App\Module\Ticket\Enum\TicketVisibility;
use Doctrine\ORM\EntityManagerInterface;

final class TicketMergeService
{
    public function __construct(
        private readonly EntityManagerInterface $entityManager,
        private readonly TicketLifecycleService $ticketLifecycleService,
        private readonly TicketAuditLogger $ticketAuditLogger,
    ) {
    }

    public function merge(Ticket $source, Ticket $target, User $actor): TicketMerge
    {
        $this->assertCanMerge($source, $target);

        return $this->entityManager->wrapInTransaction(function () use ($source, $target, $actor): TicketMerge {
            $this->assertCanMerge($source, $target);

            $previousStatus = $source->getStatus();
            $participantAdded = $this->addSourceRequesterAsParticipant($source, $target, $actor);
            $merge = new TicketMerge($source, $target, $actor);
            $source
                ->setStatus(TicketStatus::CLOSED)
                ->setStatusReason(sprintf('Sammanslaget med %s.', $target->getReference()));

            $this->entityManager->persist($merge);
            $this->entityManager->flush();

            $details = [
                'sourceReference' => $source->getReference(),
                'sourceSubject' => $source->getSubject(),
                'sourceSummary' => $source->getSummary(),
                'sourceRequester' => $source->getRequesterDisplayName(),
                'sourceRequesterAddedAsParticipant' => $participantAdded,
                'targetReference' => $target->getReference(),
                'previousSourceStatus' => $previousStatus->value,
            ];
            $this->ticketAuditLogger->log(
                $source,
                'ticket_merged',
                sprintf('Ärendet slogs samman med huvudärende %s.', $target->getReference()),
                $actor,
                $details,
            );
            $this->ticketAuditLogger->log(
                $target,
                'ticket_merge_received',
                sprintf('Ärende %s slogs samman med detta huvudärende.', $source->getReference()),
                $actor,
                $details,
            );

            return $merge;
        });
    }

    private function addSourceRequesterAsParticipant(Ticket $source, Ticket $target, User $actor): bool
    {
        $requester = $source->getRequester();
        if (!$requester instanceof User || $this->sameUser($requester, $target->getRequester())) {
            return false;
        }

        $email = TicketParticipant::normalizeEmail($requester->getEmail());
        foreach ($target->getParticipants() as $participant) {
            if (
                $participant instanceof TicketParticipant
                && TicketParticipantRole::CUSTOMER_CC === $participant->getRole()
                && $participant->getEmail() === $email
            ) {
                return false;
            }
        }

        $participant = new TicketParticipant(
            $target,
            $email,
            $requester->getDisplayName(),
            TicketParticipantRole::CUSTOMER_CC,
            $requester,
            $actor,
        );
        $target->addParticipant($participant);
        $this->entityManager->persist($participant);

        return true;
    }

    public function assertCanMerge(Ticket $source, Ticket $target): void
    {
        if ($this->sameTicket($source, $target)) {
            throw new \DomainException('Ett ärende kan inte slås samman med sig självt.');
        }

        if (!$this->ticketLifecycleService->isActive($source) || !$this->ticketLifecycleService->isActive($target)) {
            throw new \DomainException('Både källärendet och huvudärendet måste vara aktiva.');
        }

        if ($source->isMerged()) {
            throw new \DomainException('Källärendet är redan sammanslaget med ett annat ärende.');
        }

        if ($target->isMerged()) {
            throw new \DomainException('Huvudärendet är redan sammanslaget med ett annat ärende.');
        }

        $sourceCompany = $source->getCompany();
        $targetCompany = $target->getCompany();
        if (!$this->sameCompany($sourceCompany, $targetCompany)) {
            throw new \DomainException('Ärendena måste tillhöra samma företag.');
        }

        if (
            (TicketVisibility::INTERNAL_ONLY === $source->getVisibility())
            !== (TicketVisibility::INTERNAL_ONLY === $target->getVisibility())
        ) {
            throw new \DomainException('Interna ärenden kan bara slås samman med andra interna ärenden.');
        }

        if (
            !$sourceCompany instanceof Company
            || TicketVisibility::PRIVATE === $source->getVisibility()
            || TicketVisibility::PRIVATE === $target->getVisibility()
            || UserType::PRIVATE_CUSTOMER === $source->getRequester()?->getType()
            || UserType::PRIVATE_CUSTOMER === $target->getRequester()?->getType()
        ) {
            if (!$this->sameUser($source->getRequester(), $target->getRequester())) {
                throw new \DomainException('Privata ärenden och ärenden utan företag måste ha samma beställare.');
            }
        }
    }

    public function effectiveTicket(Ticket $ticket): Ticket
    {
        $visited = [];
        while ($ticket->isMerged()) {
            $id = $ticket->getId();
            $key = null !== $id ? (string) $id : sprintf('object:%d', spl_object_id($ticket));
            if (isset($visited[$key])) {
                throw new \LogicException('En cirkulär ärendesammanslagning upptäcktes.');
            }

            $visited[$key] = true;
            $target = $ticket->getMergedInto();
            if (!$target instanceof Ticket) {
                break;
            }
            $ticket = $target;
        }

        return $ticket;
    }

    private function sameTicket(Ticket $left, Ticket $right): bool
    {
        return $left === $right
            || (null !== $left->getId() && $left->getId() === $right->getId());
    }

    private function sameCompany(?Company $left, ?Company $right): bool
    {
        if (!$left instanceof Company || !$right instanceof Company) {
            return null === $left && null === $right;
        }

        return $left === $right
            || (null !== $left->getId() && $left->getId() === $right->getId());
    }

    private function sameUser(?User $left, ?User $right): bool
    {
        if (!$left instanceof User || !$right instanceof User) {
            return false;
        }

        return $left === $right
            || (null !== $left->getId() && $left->getId() === $right->getId());
    }
}
