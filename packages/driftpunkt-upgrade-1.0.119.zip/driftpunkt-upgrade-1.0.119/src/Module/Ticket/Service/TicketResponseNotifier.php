<?php

declare(strict_types=1);

namespace App\Module\Ticket\Service;

use App\Module\Identity\Entity\User;
use App\Module\Identity\Enum\UserType;
use App\Module\Identity\Service\PortalLoginLinkService;
use App\Module\Mail\Service\ConfiguredMailer;
use App\Module\Notification\Entity\NotificationLog;
use App\Module\System\Service\LocalePreferenceResolver;
use App\Module\System\Service\LocalizedTemplateRenderer;
use App\Module\System\Service\SystemSettings;
use App\Module\Ticket\Entity\Ticket;
use App\Module\Ticket\Entity\TicketComment;
use App\Module\Ticket\Enum\TicketStatus;
use App\Twig\AppRuntime;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\Mime\Email;
use Symfony\Component\Routing\Generator\UrlGeneratorInterface;

final class TicketResponseNotifier
{
    public function __construct(
        private readonly ConfiguredMailer $mailer,
        private readonly EntityManagerInterface $entityManager,
        private readonly LocalizedTemplateRenderer $templateRenderer,
        private readonly LocalePreferenceResolver $localePreferenceResolver,
        private readonly AppRuntime $appRuntime,
        private readonly UrlGeneratorInterface $urlGenerator,
        private readonly SystemSettings $systemSettings,
        private readonly PortalLoginLinkService $portalLoginLinkService,
    ) {
    }

    public function notifyCustomerWaitingForReply(Ticket $ticket, TicketComment $comment): void
    {
        $recipient = $ticket->getRequester();
        $subject = sprintf('[%s] Ärendet väntar på ditt svar', $ticket->getReference());
        $deliveredEmails = [];

        if (!$recipient instanceof User) {
            $this->logNotification('customer_waiting_reply', $ticket, null, '', $subject, false, 'Ingen kundmottagare satt på ärendet.');
        } elseif ($this->isNoMailRecipient($recipient)) {
            $this->logNotification('customer_waiting_reply', $ticket, $recipient, $recipient->getEmail(), $subject, false, 'Avdelningskonto utan e-post.');
        } elseif (!$recipient->isEmailNotificationsEnabled()) {
            $this->logNotification('customer_waiting_reply', $ticket, $recipient, $recipient->getEmail(), $subject, false, 'E-postnotiser är avstängda för mottagaren.');
        } else {
            $this->sendTicketEmail(
                eventType: 'customer_waiting_reply',
                recipient: $recipient,
                ticket: $ticket,
                subject: $subject,
                intro: 'En tekniker har svarat och ärendet väntar nu på ditt svar.',
                comment: $comment,
                badge: 'email.ticket.badge.customer_waiting_reply',
            );
            $deliveredEmails[$recipient->getEmail()] = true;
        }

        $this->notifyTicketParticipants(
            eventType: 'customer_waiting_reply',
            ticket: $ticket,
            subject: $subject,
            intro: 'En tekniker har svarat och ärendet väntar nu på ditt svar.',
            comment: $comment,
            badge: 'email.ticket.badge.customer_waiting_reply',
            deliveredEmails: $deliveredEmails,
        );
    }

    public function notifyTechnicianWaitingForReply(Ticket $ticket, TicketComment $comment): void
    {
        $subject = sprintf('[%s] Ärendet väntar på teknikersvar', $ticket->getReference());
        $recipients = $this->technicianNotificationRecipients($ticket);

        if ([] === $recipients) {
            $this->logNotification('technician_waiting_reply', $ticket, null, '', $subject, false, 'Ingen tekniker är tilldelad ärendet.');
            return;
        }

        foreach ($recipients as $recipient) {
            if (!$recipient->isEmailNotificationsEnabled()) {
                $this->logNotification('technician_waiting_reply', $ticket, $recipient, $recipient->getEmail(), $subject, false, 'E-postnotiser är avstängda för mottagaren.');
                continue;
            }

            $this->sendTicketEmail(
                eventType: 'technician_waiting_reply',
                recipient: $recipient,
                ticket: $ticket,
                subject: $subject,
                intro: 'Kunden har svarat och ärendet väntar nu på teknikersvar.',
                comment: $comment,
                badge: 'email.ticket.badge.waiting_technician',
            );
        }
    }

    public function notifyAssignedTechnician(Ticket $ticket, User $recipient, string $intro): void
    {
        $subject = sprintf('[%s] Ärendet har tilldelats dig', $ticket->getReference());

        if (!$recipient->isEmailNotificationsEnabled()) {
            $this->logNotification('ticket_assigned', $ticket, $recipient, $recipient->getEmail(), $subject, false, 'E-postnotiser är avstängda för mottagaren.');
            return;
        }

        $this->sendTicketEmail(
            eventType: 'ticket_assigned',
            recipient: $recipient,
            ticket: $ticket,
            subject: $subject,
            intro: $intro,
            comment: null,
            badge: 'email.ticket.badge.assigned',
        );
    }

    public function notifyTechniciansOfMergedTicket(Ticket $ticket, Ticket $mergedSource): void
    {
        $eventType = 'ticket_merge_received';
        $subject = sprintf('[%s] Ett ärende har slagits ihop med ditt ärende', $ticket->getReference());
        $recipients = $this->technicianNotificationRecipients($ticket);

        if ([] === $recipients) {
            $this->logNotification($eventType, $ticket, null, '', $subject, false, 'Ingen tekniker är tilldelad huvudärendet.');

            return;
        }

        foreach ($recipients as $recipient) {
            if (!$recipient->isEmailNotificationsEnabled()) {
                $this->logNotification($eventType, $ticket, $recipient, $recipient->getEmail(), $subject, false, 'E-postnotiser är avstängda för mottagaren.');
                continue;
            }

            $this->sendTicketEmail(
                eventType: $eventType,
                recipient: $recipient,
                ticket: $ticket,
                subject: $subject,
                intro: sprintf(
                    'Ärende %s (%s) har slagits ihop med detta huvudärende. Kundens ursprungliga text finns nu i ärendets historik.',
                    $mergedSource->getReference(),
                    $mergedSource->getSubject(),
                ),
                comment: null,
                badge: 'email.ticket.badge.update',
            );
        }
    }

    /**
     * @param list<User> $fallbackRecipients
     * @return array{sent: int, skipped: int}
     */
    public function notifyTechnicianFollowUpReminder(Ticket $ticket, User $coordinator, string $message = '', array $fallbackRecipients = []): array
    {
        $eventType = 'technician_followup_reminder';
        $subject = sprintf('[%s] Påminnelse: följ upp ärendet snarast', $ticket->getReference());
        $recipients = $this->technicianNotificationRecipients($ticket);

        if ([] === $recipients) {
            $recipients = $this->uniqueActiveUsers($fallbackRecipients);
        }

        if ([] === $recipients) {
            $this->logNotification($eventType, $ticket, null, '', $subject, false, 'Ingen tekniker kunde påminnas.');

            return ['sent' => 0, 'skipped' => 1];
        }

        $sent = 0;
        $skipped = 0;
        $intro = sprintf(
            '%s vill att du följer upp ärendet snarast.%s',
            $coordinator->getDisplayName(),
            '' !== $message ? "\n\n".$message : '',
        );

        foreach ($recipients as $recipient) {
            if (!$recipient->isEmailNotificationsEnabled()) {
                $this->logNotification($eventType, $ticket, $recipient, $recipient->getEmail(), $subject, false, 'E-postnotiser är avstängda för mottagaren.');
                ++$skipped;
                continue;
            }

            try {
                $this->sendTicketEmail(
                    eventType: $eventType,
                    recipient: $recipient,
                    ticket: $ticket,
                    subject: $subject,
                    intro: $intro,
                    comment: null,
                    badge: 'email.ticket.badge.reminder',
                );
                ++$sent;
            } catch (\Throwable) {
                $this->logNotification($eventType, $ticket, $recipient, $recipient->getEmail(), $subject, false, 'Påminnelsen kunde inte skickas.');
                ++$skipped;
            }
        }

        return ['sent' => $sent, 'skipped' => $skipped];
    }

    public function notifyTicketCreatedForTriage(Ticket $ticket): void
    {
        $settings = $this->systemSettings->getTicketTriageSettings();
        $hasAssignee = $ticket->getAssignee() instanceof User;
        if ('unassigned_only' === $settings['notificationMode'] && $hasAssignee) {
            return;
        }

        $eventType = $hasAssignee ? 'ticket_created_for_triage' : 'ticket_needs_assignment';
        $subject = sprintf('[%s] Nytt ärende%s', $ticket->getReference(), $hasAssignee ? '' : ' behöver tilldelas');
        $generalRecipientEmail = trim($settings['generalRecipientEmail']);
        $recipients = $this->triageNotificationRecipients($settings['recipientIds'], '' === $generalRecipientEmail);

        if ([] === $recipients && '' === $generalRecipientEmail) {
            $this->logNotification($eventType, $ticket, null, '', $subject, false, 'Ingen ärendekoordinator eller triagemottagare kunde notifieras.');

            return;
        }

        foreach ($recipients as $recipient) {
            if (!$recipient->isEmailNotificationsEnabled()) {
                $this->logNotification($eventType, $ticket, $recipient, $recipient->getEmail(), $subject, false, 'E-postnotiser är avstängda för mottagaren.');
                continue;
            }

            $this->sendTriageEmail($eventType, $recipient, $ticket, $subject);
        }

        if ('' !== $generalRecipientEmail) {
            $this->sendGeneralTriageEmail($eventType, $generalRecipientEmail, $ticket, $subject);
        }
    }

    /**
     * @return list<User>
     */
    private function technicianNotificationRecipients(Ticket $ticket): array
    {
        $recipients = [];
        $assignee = $ticket->getAssignee();

        if ($assignee instanceof User) {
            $recipients[$this->notificationRecipientKey($assignee)] = $assignee;
        }

        foreach ($ticket->getAdditionalTechnicians() as $technician) {
            $recipients[$this->notificationRecipientKey($technician)] = $technician;
        }

        return array_values($recipients);
    }

    /**
     * @param list<int> $configuredRecipientIds
     * @return list<User>
     */
    private function triageNotificationRecipients(array $configuredRecipientIds, bool $useFallback): array
    {
        $recipients = [];
        if ([] !== $configuredRecipientIds) {
            $users = $this->entityManager->getRepository(User::class)->findBy(['id' => $configuredRecipientIds]);
            foreach ($users as $user) {
                if ($user instanceof User && $this->isTriageRecipientCandidate($user)) {
                    $recipients[$this->notificationRecipientKey($user)] = $user;
                }
            }
        }

        if ($useFallback && [] === $recipients) {
            $users = $this->entityManager->getRepository(User::class)->findBy(['type' => UserType::TICKET_COORDINATOR]);
            foreach ($users as $user) {
                if ($user instanceof User && $this->isTriageRecipientCandidate($user)) {
                    $recipients[$this->notificationRecipientKey($user)] = $user;
                }
            }
        }

        return array_values($recipients);
    }

    /**
     * @param list<User> $users
     * @return list<User>
     */
    private function uniqueActiveUsers(array $users): array
    {
        $recipients = [];
        foreach ($users as $user) {
            if ($user->isActive()) {
                $recipients[$this->notificationRecipientKey($user)] = $user;
            }
        }

        return array_values($recipients);
    }

    private function isTriageRecipientCandidate(User $user): bool
    {
        return $user->isActive()
            && \in_array($user->getType(), [UserType::SUPER_ADMIN, UserType::ADMIN, UserType::TICKET_COORDINATOR, UserType::TECHNICIAN], true);
    }

    private function notificationRecipientKey(User $user): string
    {
        $id = $user->getId();

        if (null !== $id) {
            return 'id:'.$id;
        }

        return 'object:'.spl_object_id($user);
    }

    private function isNoMailRecipient(User $recipient): bool
    {
        return $this->isNoMailAddress($recipient->getEmail());
    }

    private function isNoMailAddress(string $email): bool
    {
        return str_ends_with(mb_strtolower(trim($email)), '@no-mail.invalid');
    }

    public function notifyCustomerTicketUpdate(Ticket $ticket, TicketComment $comment): void
    {
        $recipient = $ticket->getRequester();
        $subject = sprintf('[%s] Ärendet har uppdaterats', $ticket->getReference());
        $deliveredEmails = [];

        if (!$recipient instanceof User) {
            $this->logNotification('customer_ticket_update', $ticket, null, '', $subject, false, 'Ingen kundmottagare satt på ärendet.');
        } elseif ($this->isNoMailRecipient($recipient)) {
            $this->logNotification('customer_ticket_update', $ticket, $recipient, $recipient->getEmail(), $subject, false, 'Avdelningskonto utan e-post.');
        } elseif (!$recipient->isEmailNotificationsEnabled()) {
            $this->logNotification('customer_ticket_update', $ticket, $recipient, $recipient->getEmail(), $subject, false, 'E-postnotiser är avstängda för mottagaren.');
        } else {
            $this->sendTicketEmail(
                eventType: 'customer_ticket_update',
                recipient: $recipient,
                ticket: $ticket,
                subject: $subject,
                intro: 'En tekniker har uppdaterat ditt ärende med ny information.',
                comment: $comment,
                badge: 'Uppdatering',
            );
            $deliveredEmails[$recipient->getEmail()] = true;
        }

        $this->notifyTicketParticipants(
            eventType: 'customer_ticket_update',
            ticket: $ticket,
            subject: $subject,
            intro: 'En tekniker har uppdaterat ditt ärende med ny information.',
            comment: $comment,
            badge: 'Uppdatering',
            deliveredEmails: $deliveredEmails,
        );
    }

    public function notifyCustomerTicketResolved(Ticket $ticket): void
    {
        $recipient = $ticket->getRequester();
        $subject = sprintf('[%s] Ärendet är %s', $ticket->getReference(), mb_strtolower($ticket->getStatus()->label()));
        $deliveredEmails = [];

        if (!$recipient instanceof User) {
            $this->logNotification('customer_ticket_resolved', $ticket, null, '', $subject, false, 'Ingen kundmottagare satt på ärendet.');
        } elseif ($this->isNoMailRecipient($recipient)) {
            $this->logNotification('customer_ticket_resolved', $ticket, $recipient, $recipient->getEmail(), $subject, false, 'Avdelningskonto utan e-post.');
        } elseif (!$recipient->isEmailNotificationsEnabled()) {
            $this->logNotification('customer_ticket_resolved', $ticket, $recipient, $recipient->getEmail(), $subject, false, 'E-postnotiser är avstängda för mottagaren.');
        } else {
            $this->sendTicketEmail(
                eventType: 'customer_ticket_resolved',
                recipient: $recipient,
                ticket: $ticket,
                subject: $subject,
                intro: 'Ärendet har markerats som löst eller stängt. Lösningen finns nedan och syns även i ärendet.',
                comment: null,
                badge: 'Lösning klar',
                resolutionSummary: $ticket->getResolutionSummary(),
            );
            $deliveredEmails[$recipient->getEmail()] = true;
        }

        $this->notifyTicketParticipants(
            eventType: 'customer_ticket_resolved',
            ticket: $ticket,
            subject: $subject,
            intro: 'Ärendet har markerats som löst eller stängt. Lösningen finns nedan och syns även i ärendet.',
            comment: null,
            badge: 'Lösning klar',
            resolutionSummary: $ticket->getResolutionSummary(),
            deliveredEmails: $deliveredEmails,
        );
    }

    public function notifySlaReminder(Ticket $ticket, string $eventType, string $subject, string $intro, string $badge): bool
    {
        $recipient = $ticket->getAssignee();

        if ($this->hasExistingNotification($eventType, $ticket, $recipient)) {
            return false;
        }

        if (!$recipient instanceof User) {
            $this->logNotification($eventType, $ticket, null, '', $subject, false, 'Ingen tekniker är tilldelad ärendet.');

            return true;
        }

        if (!$recipient->isEmailNotificationsEnabled()) {
            $this->logNotification($eventType, $ticket, $recipient, $recipient->getEmail(), $subject, false, 'E-postnotiser är avstängda för mottagaren.');

            return true;
        }

        $this->sendTicketEmail(
            eventType: $eventType,
            recipient: $recipient,
            ticket: $ticket,
            subject: $subject,
            intro: $intro,
            comment: null,
            badge: $badge,
        );

        return true;
    }

    public function notifyCustomerFeedbackReminder(Ticket $ticket, bool $dryRun = false): bool
    {
        $eventType = 'customer_feedback_reminder';
        $recipient = $ticket->getRequester();
        $subject = sprintf('[%s] Lämna gärna omdöme på ditt ärende', $ticket->getReference());

        if ($this->hasExistingTicketNotification($eventType, $ticket)) {
            return false;
        }

        if (!$recipient instanceof User) {
            if (!$dryRun) {
                $this->logNotification($eventType, $ticket, null, '', $subject, false, 'Ingen kundmottagare satt på ärendet.');
            }

            return true;
        }

        if ($this->isNoMailRecipient($recipient)) {
            if (!$dryRun) {
                $this->logNotification($eventType, $ticket, $recipient, $recipient->getEmail(), $subject, false, 'Avdelningskonto utan e-post.');
            }

            return true;
        }

        if (!$recipient->isEmailNotificationsEnabled()) {
            if (!$dryRun) {
                $this->logNotification($eventType, $ticket, $recipient, $recipient->getEmail(), $subject, false, 'E-postnotiser är avstängda för mottagaren.');
            }

            return true;
        }

        if ($dryRun) {
            return true;
        }

        $this->sendCustomerFeedbackReminderEmail(
            recipient: $recipient,
            ticket: $ticket,
            subject: $subject,
            ticketUrl: $this->customerTicketFeedbackUrl($ticket),
            logNotification: true,
        );

        return true;
    }

    public function sendCustomerFeedbackReminderPreview(User $recipient): void
    {
        $ticket = new Ticket(
            'EXEMPEL-001',
            'Exempelärende för omdöme',
            'Ett exempel på hur kunden ser påminnelsen efter avslut.',
            TicketStatus::RESOLVED,
        );
        $ticket->setResolutionSummary('Vi uppdaterade VPN-profilen och verifierade att anslutningen fungerar igen.');

        $this->sendCustomerFeedbackReminderEmail(
            recipient: $recipient,
            ticket: $ticket,
            subject: '[EXEMPEL-001] Omdöme på avslutat ärende',
            ticketUrl: $this->urlGenerator->generate('app_portal_admin', ['section' => 'automation'], UrlGeneratorInterface::ABSOLUTE_URL),
            logNotification: false,
        );
    }

    public function notifyIncomingMailTicketReceived(
        Ticket $ticket,
        string $recipientEmail,
        ?string $recipientName = null,
        ?User $recipient = null,
    ): void {
        $normalizedEmail = mb_strtolower(trim($recipientEmail));
        $locale = $this->localePreferenceResolver->forRecipient($recipient, $ticket->getCompany());
        $subject = $this->appRuntime->translate('email.incoming.subject', [
            '%reference%' => $ticket->getReference(),
        ], $locale);

        if (false === filter_var($normalizedEmail, FILTER_VALIDATE_EMAIL)) {
            $this->logNotification('incoming_mail_ticket_received', $ticket, $recipient, $normalizedEmail, $subject, false, 'Ogiltig mottagaradress för inkommande bekräftelse.');

            return;
        }

        if ($this->isNoMailAddress($normalizedEmail)) {
            $this->logNotification('incoming_mail_ticket_received', $ticket, $recipient, $normalizedEmail, $subject, false, 'Avdelningskonto utan e-post.');

            return;
        }

        $context = [
            'recipientName' => $recipientName ?: $normalizedEmail,
            'ticket' => $ticket,
            'ticketUrl' => $this->customerTicketUrl($ticket),
        ];

        $this->mailer->send(
            (new Email())
                ->to($normalizedEmail)
                ->subject($subject)
                ->text($this->templateRenderer->render('emails/incoming_mail_ticket_received.txt.twig', $context, $locale))
                ->html($this->templateRenderer->render('emails/incoming_mail_ticket_received.html.twig', $context, $locale)),
            $ticket->getCompany(),
        );

        $this->logNotification('incoming_mail_ticket_received', $ticket, $recipient, $normalizedEmail, $subject, true, 'Inkommande bekräftelse skickad.');
    }

    private function sendTicketEmail(
        string $eventType,
        User $recipient,
        Ticket $ticket,
        string $subject,
        string $intro,
        ?TicketComment $comment,
        string $badge,
        ?string $resolutionSummary = null,
    ): void {
        if ($this->isNoMailRecipient($recipient)) {
            $this->logNotification($eventType, $ticket, $recipient, $recipient->getEmail(), $subject, false, 'Avdelningskonto utan e-post.');

            return;
        }

        $locale = $this->localePreferenceResolver->forUser($recipient);
        $localizedSubject = $this->localizeTicketSubject($eventType, $ticket, $subject, $locale);
        $context = [
            'recipient' => $recipient,
            'recipientName' => $recipient->getDisplayName(),
            'ticket' => $ticket,
            'intro' => $this->translateEmailText($intro, $locale),
            'comment' => $comment,
            'badge' => $this->translateEmailText($badge, $locale),
            'statusLabel' => $this->resolveEmailStatusLabel($eventType, $ticket, $locale),
            'ticketUrl' => $this->resolveTicketUrl($eventType, $ticket, $recipient),
            'ticketActionLabel' => $this->resolveTicketActionLabel($eventType, $locale),
            'ticketActionHelp' => $this->resolveTicketActionHelp($eventType, $locale),
            'customerCanReplyByEmail' => $this->customerCanReplyByEmail($eventType),
            'showPlainTicketUrl' => !$this->usesPortalLoginLink($eventType),
            'resolutionSummary' => $resolutionSummary,
            'noCommentMessage' => $this->resolveNoCommentMessage($eventType, $locale),
        ];

        $this->mailer->send(
            (new Email())
                ->to($recipient->getEmail())
                ->subject($localizedSubject)
                ->text($this->templateRenderer->render('emails/ticket_notification.txt.twig', $context, $locale))
                ->html($this->templateRenderer->render('emails/ticket_notification.html.twig', $context, $locale)),
            $ticket->getCompany(),
        );

        $this->logNotification($eventType, $ticket, $recipient, $recipient->getEmail(), $localizedSubject, true, 'E-post skickad.');
    }

    private function sendTriageEmail(string $eventType, User $recipient, Ticket $ticket, string $subject): void
    {
        $locale = $this->localePreferenceResolver->forUser($recipient);
        $ticketUrl = $this->coordinatorTicketUrl($ticket, $recipient);
        $context = [
            'recipient' => $recipient,
            'recipientName' => $recipient->getDisplayName(),
            'ticket' => $ticket,
            'ticketUrl' => $ticketUrl,
            'showPlainTicketUrl' => false,
            'assignmentLabel' => $ticket->getAssignee() instanceof User
                ? sprintf('Tilldelad till %s', $ticket->getAssignee()->getDisplayName())
                : 'Saknar ansvarig tekniker',
        ];

        $this->mailer->send(
            (new Email())
                ->to($recipient->getEmail())
                ->subject($subject)
                ->text($this->templateRenderer->render('emails/ticket_triage_notification.txt.twig', $context, $locale))
                ->html($this->templateRenderer->render('emails/ticket_triage_notification.html.twig', $context, $locale)),
            $ticket->getCompany(),
        );

        $this->logNotification($eventType, $ticket, $recipient, $recipient->getEmail(), $subject, true, 'Triage-notis skickad.');
    }

    private function sendGeneralTriageEmail(string $eventType, string $recipientEmail, Ticket $ticket, string $subject): void
    {
        $ticketUrl = $this->genericCoordinatorTicketUrl($ticket);
        $context = [
            'recipient' => null,
            'recipientName' => 'Ärendekoordinator',
            'ticket' => $ticket,
            'ticketUrl' => $ticketUrl,
            'showPlainTicketUrl' => true,
            'assignmentLabel' => $ticket->getAssignee() instanceof User
                ? sprintf('Tilldelad till %s', $ticket->getAssignee()->getDisplayName())
                : 'Saknar ansvarig tekniker',
        ];

        $this->mailer->send(
            (new Email())
                ->to($recipientEmail)
                ->subject($subject)
                ->text($this->templateRenderer->render('emails/ticket_triage_notification.txt.twig', $context, 'sv'))
                ->html($this->templateRenderer->render('emails/ticket_triage_notification.html.twig', $context, 'sv')),
            $ticket->getCompany(),
        );

        $this->logNotification($eventType, $ticket, null, $recipientEmail, $subject, true, 'Triage-notis skickad till allmän adress.');
    }

    /**
     * @param array<string, bool> $deliveredEmails
     */
    private function notifyTicketParticipants(
        string $eventType,
        Ticket $ticket,
        string $subject,
        string $intro,
        ?TicketComment $comment,
        string $badge,
        ?string $resolutionSummary = null,
        array $deliveredEmails = [],
    ): void {
        foreach ($ticket->getNotifiableCustomerParticipants() as $participant) {
            $recipientEmail = $participant->getEmail();
            if (isset($deliveredEmails[$recipientEmail])) {
                $this->logNotification($eventType, $ticket, $participant->getUser(), $recipientEmail, $subject, false, 'Mottagaren är redan notifierad via ärendets huvudmottagare.');
                continue;
            }

            if (false === filter_var($recipientEmail, FILTER_VALIDATE_EMAIL)) {
                $this->logNotification($eventType, $ticket, $participant->getUser(), $recipientEmail, $subject, false, 'Ogiltig deltagaradress.');
                continue;
            }

            if ($this->isNoMailAddress($recipientEmail)) {
                $this->logNotification($eventType, $ticket, $participant->getUser(), $recipientEmail, $subject, false, 'Avdelningskonto utan e-post.');
                continue;
            }

            $this->sendTicketEmailToAddress(
                eventType: $eventType,
                recipientEmail: $recipientEmail,
                recipientName: $participant->getDisplayName() ?? $recipientEmail,
                ticket: $ticket,
                subject: $subject,
                intro: $intro,
                comment: $comment,
                badge: $badge,
                resolutionSummary: $resolutionSummary,
                recipient: $participant->getUser(),
            );
            $deliveredEmails[$recipientEmail] = true;
        }
    }

    private function sendTicketEmailToAddress(
        string $eventType,
        string $recipientEmail,
        string $recipientName,
        Ticket $ticket,
        string $subject,
        string $intro,
        ?TicketComment $comment,
        string $badge,
        ?string $resolutionSummary = null,
        ?User $recipient = null,
    ): void {
        if ($this->isNoMailAddress($recipientEmail)) {
            $this->logNotification($eventType, $ticket, $recipient, $recipientEmail, $subject, false, 'Avdelningskonto utan e-post.');

            return;
        }

        $locale = $this->localePreferenceResolver->forRecipient($recipient, $ticket->getCompany());
        $localizedSubject = $this->localizeTicketSubject($eventType, $ticket, $subject, $locale);
        $context = [
            'recipient' => $recipient,
            'recipientName' => $recipientName,
            'ticket' => $ticket,
            'intro' => $this->translateEmailText($intro, $locale),
            'comment' => $comment,
            'badge' => $this->translateEmailText($badge, $locale),
            'statusLabel' => $this->resolveEmailStatusLabel($eventType, $ticket, $locale),
            'ticketUrl' => $this->resolveTicketUrl($eventType, $ticket, $recipient),
            'ticketActionLabel' => $this->resolveTicketActionLabel($eventType, $locale),
            'ticketActionHelp' => $this->resolveTicketActionHelp($eventType, $locale),
            'customerCanReplyByEmail' => $this->customerCanReplyByEmail($eventType),
            'showPlainTicketUrl' => !$this->usesPortalLoginLink($eventType),
            'resolutionSummary' => $resolutionSummary,
            'noCommentMessage' => $this->resolveNoCommentMessage($eventType, $locale),
        ];

        $this->mailer->send(
            (new Email())
                ->to($recipientEmail)
                ->subject($localizedSubject)
                ->text($this->templateRenderer->render('emails/ticket_notification.txt.twig', $context, $locale))
                ->html($this->templateRenderer->render('emails/ticket_notification.html.twig', $context, $locale)),
            $ticket->getCompany(),
        );

        $this->logNotification($eventType, $ticket, $recipient, $recipientEmail, $localizedSubject, true, 'E-post skickad till ärendedeltagare.');
    }

    private function localizeTicketSubject(string $eventType, Ticket $ticket, string $subject, string $locale): string
    {
        $parameters = ['%reference%' => $ticket->getReference()];
        $key = match ($eventType) {
            'customer_waiting_reply' => 'email.ticket.subject.customer_waiting_reply',
            'technician_waiting_reply' => 'email.ticket.subject.technician_waiting_reply',
            'ticket_assigned' => 'email.ticket.subject.ticket_assigned',
            'customer_ticket_update' => 'email.ticket.subject.customer_ticket_update',
            'sla_first_response_breached' => 'email.ticket.subject.sla_first_response_breached',
            'sla_first_response_due_soon' => 'email.ticket.subject.sla_first_response_due_soon',
            'sla_resolution_breached' => 'email.ticket.subject.sla_resolution_breached',
            'sla_resolution_due_soon' => 'email.ticket.subject.sla_resolution_due_soon',
            'technician_followup_reminder' => 'email.ticket.subject.technician_followup_reminder',
            default => null,
        };

        if ('customer_ticket_resolved' === $eventType) {
            $parameters['%status%'] = mb_strtolower($this->translateEmailText($ticket->getStatus()->label(), $locale));

            return $this->appRuntime->translate('email.ticket.subject.customer_ticket_resolved', $parameters, $locale);
        }

        if (\is_string($key)) {
            return $this->appRuntime->translate($key, $parameters, $locale);
        }

        return $this->translateEmailText($subject, $locale);
    }

    private function translateEmailText(string $text, string $locale): string
    {
        return $this->appRuntime->translate($text, [], $locale);
    }

    private function resolveEmailStatusLabel(string $eventType, Ticket $ticket, string $locale): string
    {
        if ('customer_waiting_reply' === $eventType && TicketStatus::PENDING_CUSTOMER === $ticket->getStatus()) {
            return $this->appRuntime->translate('email.ticket.status.customer_waiting_reply', [], $locale);
        }

        return $this->translateEmailText($ticket->getStatus()->label(), $locale);
    }

    private function resolveTicketUrl(string $eventType, Ticket $ticket, ?User $recipient = null): ?string
    {
        if ($this->isTechnicianTicketEvent($eventType)) {
            if ($recipient instanceof User) {
                return $this->technicianTicketUrl($ticket, $recipient);
            }

            return null;
        }

        if (!\in_array($eventType, ['customer_waiting_reply', 'customer_ticket_update', 'customer_ticket_resolved'], true)) {
            return null;
        }

        if ('customer_ticket_resolved' === $eventType) {
            return $this->customerTicketFeedbackUrl($ticket);
        }

        return $this->customerTicketUrl($ticket);
    }

    private function resolveTicketActionLabel(string $eventType, string $locale): string
    {
        if ($this->isTechnicianTicketEvent($eventType)) {
            return $this->appRuntime->translate('email.ticket.action.open_technician_ticket', [], $locale);
        }

        return match ($eventType) {
            'customer_ticket_resolved' => $this->appRuntime->translate('email.ticket.action.leave_feedback', [], $locale),
            default => $this->appRuntime->translate('email.ticket.action.open_customer_ticket', [], $locale),
        };
    }

    private function resolveTicketActionHelp(string $eventType, string $locale): string
    {
        if ($this->isTechnicianTicketEvent($eventType)) {
            return $this->appRuntime->translate('email.ticket.action.technician_login_required', [], $locale);
        }

        return match ($eventType) {
            'customer_ticket_resolved' => $this->appRuntime->translate('email.ticket.action.feedback_login_required', [], $locale),
            default => $this->appRuntime->translate('email.ticket.action.login_required', [], $locale),
        };
    }

    private function isTechnicianTicketEvent(string $eventType): bool
    {
        return \in_array($eventType, [
            'technician_waiting_reply',
            'ticket_assigned',
            'technician_followup_reminder',
            'sla_first_response_breached',
            'sla_first_response_due_soon',
            'sla_resolution_breached',
            'sla_resolution_due_soon',
        ], true);
    }

    private function customerTicketFeedbackUrl(Ticket $ticket): ?string
    {
        $ticketUrl = $this->customerTicketUrl($ticket);
        if (null === $ticketUrl) {
            return null;
        }

        return $ticketUrl.'#customer-feedback';
    }

    private function customerTicketUrl(Ticket $ticket): ?string
    {
        $ticketId = $ticket->getId();
        if (null === $ticketId) {
            return null;
        }

        return $this->urlGenerator->generate(
            'app_portal_customer_ticket_show',
            ['id' => $ticketId],
            UrlGeneratorInterface::ABSOLUTE_URL,
        );
    }

    private function usesPortalLoginLink(string $eventType): bool
    {
        return $this->isTechnicianTicketEvent($eventType);
    }

    private function customerCanReplyByEmail(string $eventType): bool
    {
        return \in_array($eventType, ['customer_waiting_reply', 'customer_ticket_update'], true);
    }

    private function resolveNoCommentMessage(string $eventType, string $locale): string
    {
        if ('customer_ticket_resolved' === $eventType) {
            return $this->appRuntime->translate('email.ticket.no_comment.resolved', [], $locale);
        }

        return $this->appRuntime->translate('email.ticket.no_comment', [], $locale);
    }

    private function coordinatorTicketUrl(Ticket $ticket, User $recipient): ?string
    {
        $ticketId = $ticket->getId();
        if (null === $ticketId) {
            return null;
        }

        $targetPath = $this->urlGenerator->generate('app_portal_coordinator_ticket_show', ['id' => $ticketId], UrlGeneratorInterface::ABSOLUTE_PATH);

        return $this->portalLoginLinkService->createLoginUrl($recipient, $ticket, $targetPath, 'ROLE_TICKET_COORDINATOR')
            ?? $this->urlGenerator->generate('app_portal_coordinator_ticket_show', ['id' => $ticketId], UrlGeneratorInterface::ABSOLUTE_URL);
    }

    private function genericCoordinatorTicketUrl(Ticket $ticket): ?string
    {
        $ticketId = $ticket->getId();
        if (null === $ticketId) {
            return null;
        }

        return $this->urlGenerator->generate('app_portal_coordinator_ticket_show', ['id' => $ticketId], UrlGeneratorInterface::ABSOLUTE_URL);
    }

    private function technicianTicketUrl(Ticket $ticket, User $recipient): ?string
    {
        $ticketId = $ticket->getId();
        if (null === $ticketId) {
            return null;
        }

        $targetPath = $this->urlGenerator->generate('app_portal_technician_ticket_show', ['id' => $ticketId], UrlGeneratorInterface::ABSOLUTE_PATH);

        return $this->portalLoginLinkService->createLoginUrl($recipient, $ticket, $targetPath, 'ROLE_TECHNICIAN')
            ?? $this->urlGenerator->generate('app_portal_technician_ticket_show', ['id' => $ticketId], UrlGeneratorInterface::ABSOLUTE_URL);
    }

    private function logNotification(
        string $eventType,
        Ticket $ticket,
        ?User $recipient,
        string $recipientEmail,
        string $subject,
        bool $sent,
        string $statusMessage,
    ): void {
        $log = new NotificationLog(
            $eventType,
            '' !== $recipientEmail ? $recipientEmail : 'unknown@local',
            $subject,
            $sent,
            $statusMessage,
        );
        $log->setTicket($ticket);
        $log->setRecipient($recipient);

        $this->entityManager->persist($log);
        $this->entityManager->flush();
    }

    private function hasExistingNotification(string $eventType, Ticket $ticket, ?User $recipient): bool
    {
        return null !== $this->entityManager->getRepository(NotificationLog::class)->findOneBy([
            'eventType' => $eventType,
            'ticket' => $ticket,
            'recipient' => $recipient,
        ]);
    }

    private function hasExistingTicketNotification(string $eventType, Ticket $ticket): bool
    {
        return null !== $this->entityManager->getRepository(NotificationLog::class)->findOneBy([
            'eventType' => $eventType,
            'ticket' => $ticket,
        ]);
    }

    private function sendCustomerFeedbackReminderEmail(
        User $recipient,
        Ticket $ticket,
        string $subject,
        ?string $ticketUrl,
        bool $logNotification,
    ): void {
        $locale = $this->localePreferenceResolver->forUser($recipient);
        $context = [
            'recipient' => $recipient,
            'recipientName' => $recipient->getDisplayName(),
            'ticket' => $ticket,
            'ticketUrl' => $ticketUrl,
            'resolutionSummary' => $ticket->getResolutionSummary(),
        ];

        $this->mailer->send(
            (new Email())
                ->to($recipient->getEmail())
                ->subject($subject)
                ->text($this->templateRenderer->render('emails/ticket_feedback_reminder.txt.twig', $context, $locale))
                ->html($this->templateRenderer->render('emails/ticket_feedback_reminder.html.twig', $context, $locale)),
            $ticket->getCompany(),
        );

        if ($logNotification) {
            $this->logNotification('customer_feedback_reminder', $ticket, $recipient, $recipient->getEmail(), $subject, true, 'Omdömespåminnelse skickad.');
        }
    }
}
