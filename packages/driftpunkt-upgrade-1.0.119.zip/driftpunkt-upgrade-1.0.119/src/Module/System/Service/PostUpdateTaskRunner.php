<?php

declare(strict_types=1);

namespace App\Module\System\Service;

use Symfony\Component\DependencyInjection\Attribute\Autowire;

final class PostUpdateTaskRunner
{
    private const RUNS_DIRECTORY = 'post_update_runs';
    private const LEGACY_RUNS_DIRECTORY = 'code_update_runs';

    public function __construct(
        #[Autowire('%kernel.project_dir%')]
        private readonly string $projectDir,
        private readonly ProjectCommandExecutor $commandExecutor,
        private readonly BackgroundConsoleLauncher $backgroundConsoleLauncher,
    ) {
    }

    /**
     * @return list<array{id: string, label: string, description: string, commandPreview: string, recommended: bool}>
     */
    public function describeAvailableTasks(): array
    {
        return array_values(array_map(
            static fn (array $task): array => [
                'id' => $task['id'],
                'label' => $task['label'],
                'description' => $task['description'],
                'commandPreview' => implode(' ', $task['command']),
                'recommended' => $task['recommended'],
            ],
            $this->taskMap(),
        ));
    }

    /**
     * @return list<array{
     *     id: string,
     *     queuedAt: \DateTimeImmutable,
     *     startedAt: ?\DateTimeImmutable,
     *     finishedAt: ?\DateTimeImmutable,
     *     status: string,
     *     succeeded: ?bool,
     *     selectedTasks: list<string>,
     *     taskResults: list<array{
     *         id: string,
     *         label: string,
     *         exitCode: int,
     *         succeeded: bool,
     *         output: string
     *     }>
     * }>
     */
    public function listRecentRuns(): array
    {
        $runs = [];

        foreach ($this->runFiles() as $path) {
            try {
                /** @var array<string, mixed> $raw */
                $raw = json_decode((string) file_get_contents($path), true, 512, \JSON_THROW_ON_ERROR);
            } catch (\JsonException) {
                continue;
            }

            if (!isset($raw['id'], $raw['queuedAt'], $raw['selectedTasks'], $raw['taskResults'], $raw['status'])) {
                continue;
            }

            $normalized = $this->normalizeRun($raw);
            if (null !== $normalized) {
                $runs[] = $normalized;
            }
        }

        usort(
            $runs,
            static fn (array $left, array $right): int => $right['queuedAt']->getTimestamp() <=> $left['queuedAt']->getTimestamp(),
        );

        return array_slice($runs, 0, 8);
    }

    /**
     * @param list<string> $taskIds
     *
     * @return array{
     *     id: string,
     *     queuedAt: \DateTimeImmutable,
     *     startedAt: ?\DateTimeImmutable,
     *     finishedAt: ?\DateTimeImmutable,
     *     status: string,
     *     succeeded: ?bool,
     *     selectedTasks: list<string>,
     *     taskResults: list<array{
     *         id: string,
     *         label: string,
     *         exitCode: int,
     *         succeeded: bool,
     *         output: string
     *     }>
     * }
     */
    public function queueTasks(array $taskIds): array
    {
        $selectedTasks = [];
        $taskMap = $this->taskMap();

        foreach ($taskIds as $taskId) {
            $normalizedTaskId = trim($taskId);
            if ('' === $normalizedTaskId || !isset($taskMap[$normalizedTaskId])) {
                continue;
            }

            $selectedTasks[$normalizedTaskId] = $taskMap[$normalizedTaskId];
        }

        if ([] === $selectedTasks) {
            throw new \RuntimeException('Välj minst ett efter-uppdateringssteg att köra.');
        }

        $runId = sprintf('%s_%s', (new \DateTimeImmutable())->format('Ymd_His'), bin2hex(random_bytes(4)));
        $queuedAt = new \DateTimeImmutable();
        $run = [
            'id' => $runId,
            'queuedAt' => $queuedAt->format(DATE_ATOM),
            'startedAt' => null,
            'finishedAt' => null,
            'status' => 'queued',
            'succeeded' => null,
            'selectedTasks' => array_values(array_keys($selectedTasks)),
            'taskResults' => [],
        ];

        $this->persistRun($run);
        $this->backgroundConsoleLauncher->launch(
            [\PHP_BINARY, 'bin/console', 'app:post-update:run', $runId],
            $this->projectDir,
        );

        $normalized = $this->normalizeRun($run);
        if (null === $normalized) {
            throw new \RuntimeException('Kunde inte läsa tillbaka den köade uppdateringskörningen.');
        }

        return $normalized;
    }

    /**
     * @return array{
     *     id: string,
     *     queuedAt: \DateTimeImmutable,
     *     startedAt: ?\DateTimeImmutable,
     *     finishedAt: ?\DateTimeImmutable,
     *     status: string,
     *     succeeded: ?bool,
     *     selectedTasks: list<string>,
     *     taskResults: list<array{
     *         id: string,
     *         label: string,
     *         exitCode: int,
     *         succeeded: bool,
     *         output: string
     *     }>
     * }
     */
    public function retryRun(string $runId): array
    {
        $run = $this->readRawRun($runId);
        if (null === $run) {
            throw new \RuntimeException('Den valda efter-uppdateringskörningen kunde inte hittas.');
        }

        /** @var list<string> $selectedTaskIds */
        $selectedTaskIds = array_values(array_map('strval', \is_array($run['selectedTasks'] ?? null) ? $run['selectedTasks'] : []));

        return $this->queueTasks($selectedTaskIds);
    }

    /**
     * @return array{
     *     id: string,
     *     queuedAt: \DateTimeImmutable,
     *     startedAt: ?\DateTimeImmutable,
     *     finishedAt: ?\DateTimeImmutable,
     *     status: string,
     *     succeeded: ?bool,
     *     selectedTasks: list<string>,
     *     taskResults: list<array{
     *         id: string,
     *         label: string,
     *         exitCode: int,
     *         succeeded: bool,
     *         output: string
     *     }>
     * }|null
     */
    public function getRunById(string $runId): ?array
    {
        $run = $this->readRawRun($runId);
        if (null === $run) {
            return null;
        }

        return $this->normalizeRun($run);
    }

    public function purgeFinishedRuns(): int
    {
        $deleted = 0;

        foreach ($this->runFiles() as $path) {
            $rawRun = $this->readRawRun(pathinfo($path, \PATHINFO_FILENAME));
            if (null === $rawRun) {
                continue;
            }

            if (isset($rawRun['packageId'])) {
                continue;
            }

            $status = (string) ($rawRun['status'] ?? '');
            if (!\in_array($status, ['completed', 'failed'], true)) {
                continue;
            }

            if (@unlink($path)) {
                ++$deleted;
            }
        }

        return $deleted;
    }

    public function failStaleQueuedRuns(\DateTimeImmutable $queuedBefore, string $reason): int
    {
        $failed = 0;

        foreach ($this->runFiles() as $path) {
            $rawRun = $this->readRawRun(pathinfo($path, \PATHINFO_FILENAME));
            if (null === $rawRun || isset($rawRun['packageId']) || 'queued' !== (string) ($rawRun['status'] ?? '')) {
                continue;
            }

            try {
                $queuedAt = new \DateTimeImmutable((string) ($rawRun['queuedAt'] ?? ''));
            } catch (\Throwable) {
                continue;
            }

            if ($queuedAt > $queuedBefore) {
                continue;
            }

            $taskResults = \is_array($rawRun['taskResults'] ?? null) ? $rawRun['taskResults'] : [];
            $taskResults[] = [
                'id' => 'stale_queued_cleanup',
                'label' => 'Rensad kö',
                'exitCode' => 1,
                'succeeded' => false,
                'output' => $reason,
            ];

            $rawRun['status'] = 'failed';
            $rawRun['succeeded'] = false;
            $rawRun['finishedAt'] = (new \DateTimeImmutable())->format(DATE_ATOM);
            $rawRun['taskResults'] = $taskResults;
            $this->persistRun($rawRun);
            ++$failed;
        }

        return $failed;
    }

    public function failStaleRunningRuns(\DateTimeImmutable $startedBefore, string $reason): int
    {
        $failed = 0;

        foreach ($this->runFiles() as $path) {
            $rawRun = $this->readRawRun(pathinfo($path, \PATHINFO_FILENAME));
            if (null === $rawRun || isset($rawRun['packageId']) || 'running' !== (string) ($rawRun['status'] ?? '')) {
                continue;
            }

            try {
                $startedAt = new \DateTimeImmutable((string) ($rawRun['startedAt'] ?? ''));
            } catch (\Throwable) {
                continue;
            }

            if ($startedAt > $startedBefore) {
                continue;
            }

            $taskResults = \is_array($rawRun['taskResults'] ?? null) ? $rawRun['taskResults'] : [];
            $taskResults[] = [
                'id' => 'stale_running_cleanup',
                'label' => 'Rensad pågående körning',
                'exitCode' => 1,
                'succeeded' => false,
                'output' => $reason,
            ];

            $rawRun['status'] = 'failed';
            $rawRun['succeeded'] = false;
            $rawRun['finishedAt'] = (new \DateTimeImmutable())->format(DATE_ATOM);
            $rawRun['taskResults'] = $taskResults;
            unset($rawRun['currentTaskId']);
            $this->persistRun($rawRun);
            ++$failed;
        }

        return $failed;
    }

    public function purgeOldFinishedRuns(\DateTimeImmutable $completedBefore, \DateTimeImmutable $failedBefore): int
    {
        $deleted = 0;

        foreach ($this->runFiles() as $path) {
            $rawRun = $this->readRawRun(pathinfo($path, \PATHINFO_FILENAME));
            if (null === $rawRun || isset($rawRun['packageId'])) {
                continue;
            }

            if (!$this->isOldFinishedRecord($rawRun, $completedBefore, $failedBefore)) {
                continue;
            }

            if (@unlink($path)) {
                ++$deleted;
            }
        }

        return $deleted;
    }

    /**
     * @return array{
     *     id: string,
     *     queuedAt: \DateTimeImmutable,
     *     startedAt: ?\DateTimeImmutable,
     *     finishedAt: ?\DateTimeImmutable,
     *     status: string,
     *     succeeded: ?bool,
     *     selectedTasks: list<string>,
     *     taskResults: list<array{
     *         id: string,
     *         label: string,
     *         exitCode: int,
     *         succeeded: bool,
     *         output: string
     *     }>
     * }
     */
    public function processQueuedRun(string $runId): array
    {
        $run = $this->readRawRun($runId);
        if (null === $run) {
            throw new \RuntimeException('Den köade efter-uppdateringskörningen kunde inte hittas.');
        }

        if (\in_array((string) ($run['status'] ?? ''), ['completed', 'failed'], true)) {
            $normalizedExistingRun = $this->normalizeRun($run);
            if (null === $normalizedExistingRun) {
                throw new \RuntimeException('Kunde inte läsa körloggen för efter-uppdateringen.');
            }

            return $normalizedExistingRun;
        }

        $taskMap = $this->taskMap();
        /** @var list<string> $selectedTaskIds */
        $selectedTaskIds = array_values(array_map('strval', \is_array($run['selectedTasks'] ?? null) ? $run['selectedTasks'] : []));
        $selectedTasks = [];
        foreach ($selectedTaskIds as $taskId) {
            if (isset($taskMap[$taskId])) {
                $selectedTasks[] = $taskMap[$taskId];
            }
        }

        if ([] === $selectedTasks) {
            throw new \RuntimeException('Körningen saknar giltiga efter-uppdateringssteg.');
        }

        $run['status'] = 'running';
        $run['startedAt'] = (new \DateTimeImmutable())->format(DATE_ATOM);
        $run['finishedAt'] = null;
        $run['succeeded'] = null;
        $run['taskResults'] = [];
        $this->persistRun($run);

        $succeeded = true;
        foreach ($selectedTasks as $task) {
            if ($task['deferred'] ?? false) {
                $this->backgroundConsoleLauncher->launch($task['command'], $this->projectDir);
                $execution = [
                    'exitCode' => 0,
                    'output' => 'Cache-refresh köades som fristående bakgrundssteg så den inte kan avbryta den aktiva Symfony-processen.',
                ];
            } else {
                $execution = $this->commandExecutor->execute($task['command'], $this->projectDir);
            }

            $taskSucceeded = 0 === $execution['exitCode'];
            $run['taskResults'][] = [
                'id' => $task['id'],
                'label' => $task['label'],
                'exitCode' => $execution['exitCode'],
                'succeeded' => $taskSucceeded,
                'output' => $execution['output'],
            ];
            $run['currentTaskId'] = $task['id'];
            $this->persistRun($run);

            if (!$taskSucceeded) {
                $succeeded = false;
                break;
            }
        }

        $run['status'] = $succeeded ? 'completed' : 'failed';
        $run['succeeded'] = $succeeded;
        $run['finishedAt'] = (new \DateTimeImmutable())->format(DATE_ATOM);
        unset($run['currentTaskId']);
        $this->persistRun($run);

        $normalizedRun = $this->normalizeRun($run);
        if (null === $normalizedRun) {
            throw new \RuntimeException('Kunde inte läsa körloggen för efter-uppdateringen.');
        }

        return $normalizedRun;
    }

    private function runsDirectory(): string
    {
        $directory = $this->projectDir.\DIRECTORY_SEPARATOR.'var'.\DIRECTORY_SEPARATOR.self::RUNS_DIRECTORY;
        if (!is_dir($directory) && !mkdir($directory, 0775, true) && !is_dir($directory)) {
            throw new \RuntimeException('Kunde inte skapa loggmappen för efter-uppdateringssteg.');
        }

        return $directory;
    }

    private function legacyRunsDirectory(): string
    {
        return $this->projectDir.\DIRECTORY_SEPARATOR.'var'.\DIRECTORY_SEPARATOR.self::LEGACY_RUNS_DIRECTORY;
    }

    /**
     * @return list<string>
     */
    private function runFiles(): array
    {
        $files = array_merge(
            glob($this->runsDirectory().\DIRECTORY_SEPARATOR.'*.json') ?: [],
            glob($this->legacyRunsDirectory().\DIRECTORY_SEPARATOR.'*.json') ?: [],
        );

        return array_values(array_unique($files));
    }

    /**
     * @param array<string, mixed> $run
     *
     * @return array{
     *     id: string,
     *     queuedAt: \DateTimeImmutable,
     *     startedAt: ?\DateTimeImmutable,
     *     finishedAt: ?\DateTimeImmutable,
     *     status: string,
     *     succeeded: ?bool,
     *     selectedTasks: list<string>,
     *     taskResults: list<array{
     *         id: string,
     *         label: string,
     *         exitCode: int,
     *         succeeded: bool,
     *         output: string
     *     }>
     * }|null
     */
    private function normalizeRun(array $run): ?array
    {
        if (!isset($run['id'], $run['queuedAt'], $run['selectedTasks'], $run['taskResults'], $run['status'])) {
            return null;
        }

        return [
            'id' => (string) $run['id'],
            'queuedAt' => new \DateTimeImmutable((string) $run['queuedAt']),
            'startedAt' => isset($run['startedAt']) && \is_string($run['startedAt']) ? new \DateTimeImmutable($run['startedAt']) : null,
            'finishedAt' => isset($run['finishedAt']) && \is_string($run['finishedAt']) ? new \DateTimeImmutable($run['finishedAt']) : null,
            'status' => (string) $run['status'],
            'succeeded' => isset($run['succeeded']) && \is_bool($run['succeeded']) ? $run['succeeded'] : null,
            'selectedTasks' => array_values(array_map('strval', \is_array($run['selectedTasks']) ? $run['selectedTasks'] : [])),
            'taskResults' => array_values(array_map(
                static fn (array $result): array => [
                    'id' => (string) ($result['id'] ?? ''),
                    'label' => (string) ($result['label'] ?? ''),
                    'exitCode' => (int) ($result['exitCode'] ?? 1),
                    'succeeded' => (bool) ($result['succeeded'] ?? false),
                    'output' => (string) ($result['output'] ?? ''),
                ],
                \is_array($run['taskResults']) ? $run['taskResults'] : [],
            )),
        ];
    }

    /**
     * @param array<string, mixed> $record
     */
    private function isOldFinishedRecord(array $record, \DateTimeImmutable $completedBefore, \DateTimeImmutable $failedBefore): bool
    {
        $status = (string) ($record['status'] ?? '');
        if (!\in_array($status, ['completed', 'failed'], true)) {
            return false;
        }

        try {
            $finishedAt = new \DateTimeImmutable((string) ($record['finishedAt'] ?? ''));
        } catch (\Throwable) {
            return false;
        }

        return 'completed' === $status
            ? $finishedAt <= $completedBefore
            : $finishedAt <= $failedBefore;
    }

    /**
     * @param array<string, mixed> $run
     */
    private function persistRun(array $run): void
    {
        file_put_contents(
            $this->runPathForWrite((string) $run['id']),
            json_encode($run, \JSON_PRETTY_PRINT | \JSON_THROW_ON_ERROR),
        );
    }

    private function runPathForWrite(string $runId): string
    {
        $newPath = $this->runsDirectory().\DIRECTORY_SEPARATOR.basename($runId).'.json';
        if (is_file($newPath)) {
            return $newPath;
        }

        $legacyPath = $this->legacyRunsDirectory().\DIRECTORY_SEPARATOR.basename($runId).'.json';
        if (is_file($legacyPath)) {
            return $legacyPath;
        }

        return $newPath;
    }

    /**
     * @return array<string, mixed>|null
     */
    private function readRawRun(string $runId): ?array
    {
        $paths = [
            $this->runsDirectory().\DIRECTORY_SEPARATOR.basename($runId).'.json',
            $this->legacyRunsDirectory().\DIRECTORY_SEPARATOR.basename($runId).'.json',
        ];

        $path = null;
        foreach ($paths as $candidatePath) {
            if (is_file($candidatePath)) {
                $path = $candidatePath;
                break;
            }
        }

        if (null === $path) {
            return null;
        }

        try {
            /** @var array<string, mixed> $run */
            $run = json_decode((string) file_get_contents($path), true, 512, \JSON_THROW_ON_ERROR);

            return $run;
        } catch (\JsonException) {
            return null;
        }
    }

    /**
     * @return array<string, array{id: string, label: string, description: string, command: list<string>, recommended: bool, deferred?: bool}>
     */
    private function taskMap(): array
    {
        $phpBinary = \PHP_BINARY;
        $localComposer = $this->projectDir.\DIRECTORY_SEPARATOR.'composer';
        $composerCommand = is_file($localComposer)
            ? [$phpBinary, $localComposer]
            : ['composer'];
        $cacheRefresh = 'rm -rf var/cache/prod var/cache/prod_* && '.$phpBinary.' bin/console cache:warmup --env=prod';

        return [
            'composer_install' => [
                'id' => 'composer_install',
                'label' => 'Composer install',
                'description' => 'Installerar eller uppdaterar beroenden och bygger autoloadern för den nya kodversionen.',
                'command' => [...$composerCommand, 'install', '--no-dev', '--no-interaction', '--prefer-dist', '--optimize-autoloader'],
                'recommended' => true,
            ],
            'doctrine_migrate' => [
                'id' => 'doctrine_migrate',
                'label' => 'Kör migreringar',
                'description' => 'Applicerar nya Doctrine-migrationer transaktionellt och tolererar att det inte finns några nya steg.',
                'command' => [$phpBinary, 'bin/console', 'doctrine:migrations:migrate', '--no-interaction', '--allow-no-migration', '--all-or-nothing', '--env=prod'],
                'recommended' => true,
            ],
            'cache_clear' => [
                'id' => 'cache_clear',
                'label' => 'Refresh prod-cache',
                'description' => 'Rensar prod-cache och bygger ny Symfony-cache innan uppdateringen markeras klar.',
                'command' => ['bash', '-lc', $cacheRefresh],
                'recommended' => true,
            ],
        ];
    }
}
