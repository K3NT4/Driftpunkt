<?php

declare(strict_types=1);

namespace App\Module\System\Service;

use Symfony\Component\Clock\ClockInterface;

final class SeasonalAppearance
{
    public const SURFACE_HOMEPAGE = 'homepage';
    public const SURFACE_CUSTOMER_PORTAL = 'customer_portal';

    public function __construct(
        private readonly SystemSettings $systemSettings,
        private readonly AppDateTimeFormatter $dateTimeFormatter,
        private readonly ClockInterface $clock,
    ) {
    }

    public function seasonFor(string $surface): ?string
    {
        if (!\in_array($surface, [self::SURFACE_HOMEPAGE, self::SURFACE_CUSTOMER_PORTAL], true)) {
            return null;
        }

        $settings = $this->systemSettings->getSeasonalAppearanceSettings();
        if (!$this->isVisibleOn($settings['visibility'], $surface)) {
            return null;
        }

        if ('auto' !== $settings['mode']) {
            return $settings['mode'];
        }

        $now = $this->clock->now()->setTimezone($this->dateTimeFormatter->timeZone());

        return self::seasonForMonth((int) $now->format('n'));
    }

    public static function seasonForMonth(int $month): string
    {
        return match (true) {
            \in_array($month, [12, 1, 2], true) => 'winter',
            $month >= 3 && $month <= 5 => 'spring',
            $month >= 6 && $month <= 8 => 'summer',
            default => 'autumn',
        };
    }

    private function isVisibleOn(string $visibility, string $surface): bool
    {
        return 'both' === $visibility || $visibility === $surface;
    }
}
