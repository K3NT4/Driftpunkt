<?php

declare(strict_types=1);

namespace App\Module\System\Service;

use Symfony\Component\Process\Process;

class ProjectCommandExecutor
{
    public function __construct(
        private readonly float $timeoutSeconds = 900.0,
        private readonly float $idleTimeoutSeconds = 300.0,
    ) {
        if ($this->timeoutSeconds <= 0 || $this->idleTimeoutSeconds <= 0) {
            throw new \InvalidArgumentException('Processens timeoutvärden måste vara större än noll.');
        }
    }

    /**
     * @param list<string> $command
     *
     * @return array{exitCode: int, output: string}
     */
    public function execute(array $command, string $workingDirectory): array
    {
        if ([] === $command) {
            throw new \InvalidArgumentException('Processkommandot får inte vara tomt.');
        }

        $process = new Process($command, $workingDirectory, $this->processEnvironment($workingDirectory), null, $this->timeoutSeconds);
        $process->setIdleTimeout($this->idleTimeoutSeconds);
        $process->run();

        return [
            'exitCode' => $process->getExitCode() ?? 1,
            'output' => trim($process->getOutput()."\n".$process->getErrorOutput()),
        ];
    }

    /**
     * @return array<string, string>
     */
    private function processEnvironment(string $workingDirectory): array
    {
        $environment = getenv();
        if (!\is_array($environment)) {
            $environment = [];
        }

        $composerHome = $workingDirectory.'/var/composer-home';
        if (!is_dir($composerHome) && !mkdir($composerHome, 0775, true) && !is_dir($composerHome)) {
            throw new \RuntimeException('Kunde inte skapa Composer HOME för efteruppdatering.');
        }

        if (!isset($environment['HOME']) || '' === trim((string) $environment['HOME'])) {
            $environment['HOME'] = $composerHome;
        }

        if (!isset($environment['COMPOSER_HOME']) || '' === trim((string) $environment['COMPOSER_HOME'])) {
            $environment['COMPOSER_HOME'] = $composerHome;
        }

        /** @var array<string, string> $environment */
        return $environment;
    }
}
