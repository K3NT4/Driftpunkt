<?php

declare(strict_types=1);

namespace App\Module\System\Service;

use Psr\Cache\CacheItemPoolInterface;
use Symfony\Component\DependencyInjection\Attribute\Autowire;
use Symfony\Component\HttpFoundation\Request;
use Psr\Log\LoggerInterface;
use Symfony\Component\Lock\LockFactory;
use Symfony\Component\RateLimiter\LimiterInterface;
use Symfony\Component\RateLimiter\RateLimiterFactory;
use Symfony\Component\RateLimiter\Storage\CacheStorage;

final class FormRateLimiter
{
    public function __construct(
        #[Autowire(service: 'cache.app')]
        private readonly CacheItemPoolInterface $cache,
        private readonly LockFactory $lockFactory,
        private readonly LoggerInterface $logger,
    ) {
    }

    public function isBlocked(Request $request, string $scope, int $limit, int $windowSeconds, ?string $identity = null): bool
    {
        try {
            return $this->limiter($request, $scope, $limit, $windowSeconds, $identity)
                ->consume(0)
                ->getRemainingTokens() <= 0;
        } catch (\Throwable $exception) {
            $this->logFailure($scope, $exception);
            return $this->isCriticalScope($scope);
        }
    }

    public function hasAttempts(Request $request, string $scope, int $windowSeconds, ?string $identity = null): bool
    {
        try {
            $state = $this->limiter($request, $scope, PHP_INT_MAX, $windowSeconds, $identity)->consume(0);

            return $state->getRemainingTokens() < $state->getLimit();
        } catch (\Throwable) {
            return false;
        }
    }

    public function retryAfter(Request $request, string $scope, int $windowSeconds, ?string $identity = null): int
    {
        try {
            $state = $this->limiter($request, $scope, PHP_INT_MAX, $windowSeconds, $identity)->consume(0);

            return max(0, $state->getRetryAfter()->getTimestamp() - time());
        } catch (\Throwable) {
            return 0;
        }
    }

    public function consume(Request $request, string $scope, int $limit, int $windowSeconds, ?string $identity = null): bool
    {
        try {
            return $this->limiter($request, $scope, $limit, $windowSeconds, $identity)->consume()->isAccepted();
        } catch (\Throwable $exception) {
            $this->logFailure($scope, $exception);
            return !$this->isCriticalScope($scope);
        }
    }

    public function reset(Request $request, string $scope, ?string $identity = null): void
    {
        try {
            $this->limiter($request, $scope, 1, 60, $identity)->reset();
        } catch (\Throwable) {
        }
    }

    public function forceBlock(Request $request, string $scope, int $limit, int $windowSeconds, ?string $identity = null): void
    {
        try {
            $this->limiter($request, $scope, $limit, $windowSeconds, $identity)->consume(max(1, $limit));
        } catch (\Throwable) {
        }
    }

    private function limiter(Request $request, string $scope, int $limit, int $windowSeconds, ?string $identity): LimiterInterface
    {
        $factory = new RateLimiterFactory([
            'id' => 'driftpunkt.form.'.sha1($scope),
            'policy' => 'fixed_window',
            'limit' => max(1, $limit),
            'interval' => max(1, $windowSeconds).' seconds',
        ], new CacheStorage($this->cache), $this->lockFactory);

        return $factory->create($this->cacheKey($request, $scope, $identity));
    }

    private function cacheKey(Request $request, string $scope, ?string $identity): string
    {
        $clientIp = $request->getClientIp() ?? 'unknown-ip';
        $normalizedIdentity = mb_strtolower(trim((string) $identity));

        return 'form_rate_limit.'.sha1($scope.'|'.$clientIp.'|'.$normalizedIdentity);
    }

    private function isCriticalScope(string $scope): bool
    {
        return str_starts_with($scope, 'login') || str_starts_with($scope, 'mfa') || str_contains($scope, 'password');
    }

    private function logFailure(string $scope, \Throwable $exception): void
    {
        $this->logger->error('Rate limiter backend failed.', ['scope' => $scope, 'exception' => $exception]);
    }
}
