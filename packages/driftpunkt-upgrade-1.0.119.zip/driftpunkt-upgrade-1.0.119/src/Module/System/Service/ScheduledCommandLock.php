<?php

declare(strict_types=1);

namespace App\Module\System\Service;

use Psr\Log\LoggerInterface;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Style\SymfonyStyle;
use Symfony\Component\Lock\LockFactory;

final class ScheduledCommandLock
{
    private const LOCK_PREFIX = 'driftpunkt.scheduled-command.';
    private const LOCK_TTL_SECONDS = 21600.0;

    public function __construct(
        private readonly LockFactory $lockFactory,
        private readonly LoggerInterface $logger,
    ) {
    }

    /**
     * @param callable(): int $task
     */
    public function run(string $taskId, SymfonyStyle $io, callable $task): int
    {
        $lock = $this->lockFactory->createLock(self::LOCK_PREFIX.$taskId, self::LOCK_TTL_SECONDS);
        if (!$lock->acquire()) {
            $this->logger->notice('Schemalagt kommando hoppades över eftersom en annan instans redan körs.', [
                'task_id' => $taskId,
            ]);
            $io->note('Jobbet körs redan i en annan process. Den här körningen hoppades över säkert.');

            return Command::SUCCESS;
        }

        try {
            return $task();
        } finally {
            $lock->release();
        }
    }
}
