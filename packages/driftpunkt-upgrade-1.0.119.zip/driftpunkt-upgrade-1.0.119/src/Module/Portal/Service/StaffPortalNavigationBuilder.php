<?php

declare(strict_types=1);

namespace App\Module\Portal\Service;

use App\Module\Identity\Entity\User;
use App\Module\Identity\Enum\UserType;
use App\Module\Mail\Entity\DraftTicketReview;
use App\Module\Mail\Enum\DraftTicketReviewKind;
use App\Module\Mail\Enum\DraftTicketReviewStatus;
use App\Module\System\Service\SystemSettings;
use App\Module\Ticket\Entity\Ticket;
use App\Module\Ticket\Enum\TicketStatus;
use Doctrine\ORM\EntityManagerInterface;
use Doctrine\ORM\QueryBuilder;

final class StaffPortalNavigationBuilder
{
    public function __construct(
        private readonly EntityManagerInterface $entityManager,
        private readonly SystemSettings $systemSettings,
    ) {
    }

    /**
     * Supplies the shared technician/coordinator layout with the same menu data
     * when it is rendered by controllers outside the portal module.
     *
     * @return array<string, mixed>
     */
    public function build(User $user): array
    {
        $activeCount = $this->countTickets($user, false);
        $closedCount = $this->countTickets($user, true);

        $viewData = [
            'ticketSummary' => [
                'total' => $activeCount,
                'open' => $activeCount,
                'resolved' => $closedCount,
            ],
            'ticketQuickFilters' => [
                'scopes' => [
                    ['value' => 'all', 'count' => $activeCount],
                    ['value' => 'mine', 'count' => $this->countTickets($user, false, 'mine')],
                    ['value' => 'additional', 'count' => $this->countTickets($user, false, 'additional')],
                    ['value' => 'my_team', 'count' => $this->countTickets($user, false, 'my_team')],
                    ['value' => 'unassigned', 'count' => $this->countTickets($user, false, 'unassigned')],
                ],
            ],
            'knowledgeBaseSettings' => $this->systemSettings->getKnowledgeBaseSettings(),
            'newsSettings' => $this->systemSettings->getNewsSettings(),
        ];

        if (UserType::TICKET_COORDINATOR === $user->getType()) {
            $viewData['coordinatorNavigationCounts'] = [
                'unassigned' => $this->countCoordinatorTickets('unassigned'),
                'assigned' => $this->countCoordinatorTickets('assigned'),
                'inProgress' => $this->countCoordinatorTickets('in_progress'),
                'unknownReviews' => $this->entityManager->getRepository(DraftTicketReview::class)->count([
                    'kind' => DraftTicketReviewKind::UNKNOWN_SENDER,
                    'status' => DraftTicketReviewStatus::PENDING,
                ]),
                'resolved' => $closedCount,
            ];
        }

        return $viewData;
    }

    private function countTickets(User $user, bool $closed, string $scope = 'all'): int
    {
        $queryBuilder = $this->baseTicketCountQuery();
        $closedStatuses = [TicketStatus::RESOLVED, TicketStatus::CLOSED];
        $queryBuilder
            ->andWhere($closed ? 'ticket.status IN (:closedStatuses)' : 'ticket.status NOT IN (:closedStatuses)')
            ->setParameter('closedStatuses', $closedStatuses);

        $teamIds = $this->technicianTeamIds($user);
        if (UserType::TECHNICIAN === $user->getType()) {
            if ($closed) {
                $queryBuilder
                    ->leftJoin('ticket.comments', 'involvementComment')
                    ->leftJoin('ticket.auditLogs', 'involvementAuditLog');
                $involvement = '(assignee = :user OR additionalTechnician = :user OR involvementComment.author = :user OR involvementAuditLog.actor = :user';
                $involvement .= [] !== $teamIds ? ' OR assignedTeam.id IN (:teamIds))' : ')';
                $queryBuilder->andWhere($involvement)->setParameter('user', $user);
                if ([] !== $teamIds) {
                    $queryBuilder->setParameter('teamIds', $teamIds);
                }
            } elseif (!$this->systemSettings->getBool(SystemSettings::FEATURE_TECHNICIAN_CAN_READ_ALL_TICKETS, true)) {
                $readScope = '(assignee = :user OR additionalTechnician = :user';
                $readScope .= [] !== $teamIds ? ' OR assignedTeam.id IN (:teamIds))' : ')';
                $queryBuilder->andWhere($readScope)->setParameter('user', $user);
                if ([] !== $teamIds) {
                    $queryBuilder->setParameter('teamIds', $teamIds);
                }
            }
        }

        if ('mine' === $scope) {
            $queryBuilder->andWhere('assignee = :scopeUser')->setParameter('scopeUser', $user);
        } elseif ('additional' === $scope) {
            $queryBuilder
                ->andWhere('additionalTechnician = :scopeUser')
                ->setParameter('scopeUser', $user);
        } elseif ('my_team' === $scope) {
            if ([] === $teamIds) {
                $queryBuilder->andWhere('1 = 0');
            } else {
                $queryBuilder->andWhere('assignedTeam.id IN (:scopeTeamIds)')->setParameter('scopeTeamIds', $teamIds);
            }
        } elseif ('unassigned' === $scope) {
            $queryBuilder->andWhere('ticket.assignee IS NULL AND technicianAssignment.id IS NULL');
        }

        return (int) $queryBuilder->getQuery()->getSingleScalarResult();
    }

    private function countCoordinatorTickets(string $scope): int
    {
        $queryBuilder = $this->baseTicketCountQuery()
            ->andWhere('ticket.status NOT IN (:closedStatuses)')
            ->setParameter('closedStatuses', [TicketStatus::RESOLVED, TicketStatus::CLOSED]);

        if ('unassigned' === $scope) {
            $queryBuilder->andWhere('ticket.assignee IS NULL');
        } elseif ('assigned' === $scope) {
            $queryBuilder->andWhere('ticket.assignee IS NOT NULL');
        } elseif ('in_progress' === $scope) {
            $queryBuilder->andWhere('ticket.status = :inProgress')->setParameter('inProgress', TicketStatus::IN_PROGRESS);
        }

        return (int) $queryBuilder->getQuery()->getSingleScalarResult();
    }

    private function baseTicketCountQuery(): QueryBuilder
    {
        return $this->entityManager->getRepository(Ticket::class)->createQueryBuilder('ticket')
            ->select('COUNT(DISTINCT ticket.id)')
            ->leftJoin('ticket.assignee', 'assignee')
            ->leftJoin('ticket.assignedTeam', 'assignedTeam')
            ->leftJoin('ticket.technicianAssignments', 'technicianAssignment')
            ->leftJoin('technicianAssignment.technician', 'additionalTechnician');
    }

    /** @return list<int> */
    private function technicianTeamIds(User $user): array
    {
        $teamIds = [];
        foreach ($user->getTechnicianTeams() as $team) {
            if (null !== $team->getId()) {
                $teamIds[$team->getId()] = $team->getId();
            }
        }

        if (null !== $user->getTechnicianTeam()?->getId()) {
            $teamIds[$user->getTechnicianTeam()->getId()] = $user->getTechnicianTeam()->getId();
        }

        return array_values($teamIds);
    }
}
