<?php

declare(strict_types=1);

namespace App\Command;

use App\Module\Identity\Entity\User;
use App\Module\Identity\Enum\UserType;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\Console\Attribute\AsCommand;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Style\SymfonyStyle;
use Symfony\Component\PasswordHasher\Hasher\UserPasswordHasherInterface;

#[AsCommand(
    name: 'app:create-admin',
    description: 'Skapar det första administratörs- eller superadministratörskontot för en ny installation.',
)]
final class CreateInitialAdminCommand extends Command
{
    public function __construct(
        private readonly EntityManagerInterface $entityManager,
        private readonly UserPasswordHasherInterface $passwordHasher,
    ) {
        parent::__construct();
    }

    protected function configure(): void
    {
        $this
            ->addArgument('email', InputArgument::REQUIRED, 'E-postadress')
            ->addArgument('password', InputArgument::OPTIONAL, 'Utfasat: lösenord i klartext. Utelämna för dold inmatning.')
            ->addArgument('first-name', InputArgument::OPTIONAL, 'Förnamn', 'System')
            ->addArgument('last-name', InputArgument::OPTIONAL, 'Efternamn', 'Admin')
            ->addArgument('type', InputArgument::OPTIONAL, 'admin eller super_admin', UserType::SUPER_ADMIN->value)
            ->addOption('first-name', null, InputOption::VALUE_REQUIRED, 'Förnamn')
            ->addOption('last-name', null, InputOption::VALUE_REQUIRED, 'Efternamn')
            ->addOption('type', null, InputOption::VALUE_REQUIRED, 'admin eller super_admin')
            ->addOption('password-file', null, InputOption::VALUE_REQUIRED, 'Läs lösenordet från en skyddad fil');
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $io = new SymfonyStyle($input, $output);

        $email = mb_strtolower(trim((string) $input->getArgument('email')));
        $legacyPassword = (string) ($input->getArgument('password') ?? '');
        $passwordFile = trim((string) ($input->getOption('password-file') ?? ''));
        if ('' !== $passwordFile) {
            if (!is_file($passwordFile) || !is_readable($passwordFile)) {
                $io->error('Lösenordsfilen saknas eller kan inte läsas.');
                return Command::INVALID;
            }
            $password = rtrim((string) file_get_contents($passwordFile), "\r\n");
        } elseif ('' !== $legacyPassword) {
            $password = $legacyPassword;
            $io->warning('Lösenord som positionsargument är utfasat eftersom det kan synas i shellhistorik och processlista.');
        } elseif ($input->isInteractive()) {
            $password = (string) $io->askHidden('Lösenord (minst 12 tecken)');
            $confirmation = (string) $io->askHidden('Bekräfta lösenordet');
            if (!hash_equals($password, $confirmation)) {
                $io->error('Lösenorden matchar inte.');
                return Command::INVALID;
            }
        } else {
            $io->error('Ange lösenord via dold interaktiv inmatning eller --password-file.');
            return Command::INVALID;
        }
        if (\strlen($password) < 12) {
            $io->error('Lösenordet måste vara minst 12 tecken långt.');
            return Command::INVALID;
        }
        $firstName = (string) ($input->getOption('first-name') ?: $input->getArgument('first-name'));
        $lastName = (string) ($input->getOption('last-name') ?: $input->getArgument('last-name'));
        $type = UserType::tryFrom((string) ($input->getOption('type') ?: $input->getArgument('type')));

        if (!$type instanceof UserType || !\in_array($type, [UserType::ADMIN, UserType::SUPER_ADMIN], true)) {
            $io->error('Den första kontotypen måste vara admin eller super_admin.');

            return Command::INVALID;
        }

        $existingUser = $this->entityManager
            ->getRepository(User::class)
            ->findOneBy(['email' => $email]);

        if (null !== $existingUser) {
            $io->error(sprintf('En användare med e-postadressen "%s" finns redan.', $email));

            return Command::FAILURE;
        }

        $user = new User($email, $firstName, $lastName, $type);
        $user->setPassword($this->passwordHasher->hashPassword($user, $password));

        $this->entityManager->persist($user);
        $this->entityManager->flush();

        $io->success(sprintf(
            'Skapade %s-konto för %s. Logga in och aktivera MFA från säkerhetsvarningen i administratörsytan så snart som möjligt.',
            $type->label(),
            $user->getEmail(),
        ));

        return Command::SUCCESS;
    }
}
