<?php

declare(strict_types=1);

namespace App\Command;

use App\Module\Mail\Entity\DraftTicketReview;
use App\Module\Mail\Enum\DraftTicketReviewStatus;
use App\Module\Ticket\Entity\Ticket;
use App\Module\Ticket\Service\TicketAuditLogger;
use App\Module\Ticket\Service\TicketLifecycleService;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\Console\Attribute\AsCommand;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Style\SymfonyStyle;

#[AsCommand(
    name: 'app:tickets:normalize-legacy-draft-subjects',
    description: 'Tar bort gamla utkastprefix från avslutade ärenden som inte väntar på granskning.',
)]
final class NormalizeLegacyDraftTicketSubjectsCommand extends Command
{
    public function __construct(
        private readonly EntityManagerInterface $entityManager,
        private readonly TicketLifecycleService $ticketLifecycleService,
        private readonly TicketAuditLogger $ticketAuditLogger,
    ) {
        parent::__construct();
    }

    protected function configure(): void
    {
        $this
            ->addOption('ticket', null, InputOption::VALUE_REQUIRED | InputOption::VALUE_IS_ARRAY, 'Begränsa till en eller flera ärendereferenser, t.ex. --ticket=ABC-1001.')
            ->addOption('all', null, InputOption::VALUE_NONE, 'Tillåt uppdatering av samtliga säkra träffar.')
            ->addOption('apply', null, InputOption::VALUE_NONE, 'Spara ändringarna. Utan flaggan görs endast en förhandsvisning.');
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $io = new SymfonyStyle($input, $output);
        $apply = (bool) $input->getOption('apply');
        $all = (bool) $input->getOption('all');
        $references = array_values(array_unique(array_filter(array_map(
            static fn (mixed $reference): string => mb_strtoupper(trim((string) $reference)),
            (array) $input->getOption('ticket'),
        ))));

        if ($apply && [] === $references && !$all) {
            $io->error('Ange minst ett --ticket eller använd --all tillsammans med --apply. Ingen data ändrades.');

            return Command::INVALID;
        }

        if ($all && [] !== $references) {
            $io->error('Använd antingen --all eller --ticket, inte båda. Ingen data ändrades.');

            return Command::INVALID;
        }

        $queryBuilder = $this->entityManager->getRepository(Ticket::class)
            ->createQueryBuilder('ticket')
            ->andWhere('ticket.status IN (:closedStatuses)')
            ->andWhere('LOWER(ticket.subject) LIKE :swedishPrefix OR LOWER(ticket.subject) LIKE :englishPrefix')
            ->setParameter('closedStatuses', $this->ticketLifecycleService->closedStatuses())
            ->setParameter('swedishPrefix', '[utkast]%')
            ->setParameter('englishPrefix', '[draft]%')
            ->orderBy('ticket.id', 'ASC');

        if ([] !== $references) {
            $queryBuilder
                ->andWhere('ticket.reference IN (:references)')
                ->setParameter('references', $references);
        }

        /** @var list<Ticket> $tickets */
        $tickets = $queryBuilder->getQuery()->getResult();
        $rows = [];
        $eligibleTickets = [];
        $skippedPending = 0;

        foreach ($tickets as $ticket) {
            $pendingReviewCount = (int) $this->entityManager->getRepository(DraftTicketReview::class)->count([
                'draftTicket' => $ticket,
                'status' => DraftTicketReviewStatus::PENDING,
            ]);
            $newSubject = $this->withoutDraftPrefix($ticket->getSubject());
            $eligible = 0 === $pendingReviewCount && '' !== $newSubject;

            $rows[] = [
                $ticket->getReference(),
                $ticket->getStatus()->label(),
                $eligible ? 'Ja' : 'Nej, väntar på granskning',
                $ticket->getSubject(),
                $newSubject,
            ];

            if (!$eligible) {
                ++$skippedPending;
                continue;
            }

            $eligibleTickets[] = [$ticket, $newSubject];
        }

        if ([] !== $rows) {
            $io->table(['Referens', 'Status', 'Säker att rensa', 'Nuvarande rubrik', 'Ny rubrik'], $rows);
        }

        if (!$apply) {
            $io->note(sprintf('%d ärenden kan rensas. Detta var endast en förhandsvisning; ingen data ändrades.', \count($eligibleTickets)));

            return Command::SUCCESS;
        }

        foreach ($eligibleTickets as [$ticket, $newSubject]) {
            $oldSubject = $ticket->getSubject();
            $ticket->rename($newSubject);
            $this->ticketAuditLogger->log(
                $ticket,
                'legacy_draft_subject_normalized',
                'Gammalt utkastprefix togs bort från ett avslutat ärende via underhållskommandot.',
                null,
                ['oldSubject' => $oldSubject, 'newSubject' => $newSubject],
            );
        }

        $io->success(sprintf('%d ärenden uppdaterades. %d väntande utkast hoppades över.', \count($eligibleTickets), $skippedPending));

        return Command::SUCCESS;
    }

    private function withoutDraftPrefix(string $subject): string
    {
        return trim((string) preg_replace('/^\[(?:utkast|draft)\]\s*/iu', '', $subject));
    }
}
