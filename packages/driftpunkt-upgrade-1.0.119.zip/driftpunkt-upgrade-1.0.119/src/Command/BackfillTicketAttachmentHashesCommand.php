<?php

declare(strict_types=1);

namespace App\Command;

use App\Module\Ticket\Entity\TicketCommentAttachment;
use App\Module\Ticket\Service\TicketAttachmentDeduplicator;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\Console\Attribute\AsCommand;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Style\SymfonyStyle;

#[AsCommand(
    name: 'app:ticket-attachments:backfill-hashes',
    description: 'Fyller content hash på befintliga lokala ärendebilagor för dubblettskydd.',
)]
final class BackfillTicketAttachmentHashesCommand extends Command
{
    public function __construct(
        private readonly EntityManagerInterface $entityManager,
        private readonly TicketAttachmentDeduplicator $ticketAttachmentDeduplicator,
    ) {
        parent::__construct();
    }

    protected function configure(): void
    {
        $this
            ->addOption('dry-run', null, InputOption::VALUE_NONE, 'Visa hur många bilagor som kan uppdateras utan att spara.')
            ->addOption('limit', null, InputOption::VALUE_REQUIRED, 'Max antal bilagor att granska i denna körning.')
            ->addOption('batch-size', null, InputOption::VALUE_REQUIRED, 'Antal bilagor per databasbatch.', '100')
            ->addOption('ticket', null, InputOption::VALUE_REQUIRED, 'Begränsa körningen till ett ärende, t.ex. DP-1001.');
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $io = new SymfonyStyle($input, $output);
        $dryRun = (bool) $input->getOption('dry-run');
        $limitOption = $input->getOption('limit');
        $ticketReference = mb_strtoupper(trim((string) $input->getOption('ticket')));
        $batchSize = max(1, min(1000, (int) $input->getOption('batch-size')));
        $limit = null !== $limitOption && '' !== trim((string) $limitOption)
            ? max(1, (int) $limitOption)
            : null;

        $updated = 0;
        $skipped = 0;
        $reviewed = 0;
        $lastId = 0;

        while (null === $limit || $reviewed < $limit) {
            $currentBatchSize = null === $limit ? $batchSize : min($batchSize, $limit - $reviewed);
            $attachments = $this->findBatch($lastId, $currentBatchSize, $ticketReference);
            if ([] === $attachments) {
                break;
            }

            foreach ($attachments as $attachment) {
                $lastId = max($lastId, (int) $attachment->getId());
                ++$reviewed;
                $contentHash = $this->ticketAttachmentDeduplicator->resolveContentHashForAttachment($attachment);
                if (null === $contentHash) {
                    ++$skipped;
                    continue;
                }

                ++$updated;
                if (!$dryRun) {
                    $attachment->setContentHash($contentHash);
                }
            }

            if (!$dryRun) {
                $this->entityManager->flush();
            }

            $this->entityManager->clear();
        }

        $io->success(sprintf(
            'Hash-backfill klar. %d bilagor granskades. %d bilagor %s hash. %d bilagor hoppades över.',
            $reviewed,
            $updated,
            $dryRun ? 'skulle få' : 'fick',
            $skipped,
        ));

        return Command::SUCCESS;
    }

    /**
     * @return list<TicketCommentAttachment>
     */
    private function findBatch(int $lastId, int $batchSize, string $ticketReference): array
    {
        $queryBuilder = $this->entityManager->getRepository(TicketCommentAttachment::class)
            ->createQueryBuilder('attachment')
            ->innerJoin('attachment.comment', 'comment')->addSelect('comment')
            ->innerJoin('comment.ticket', 'ticket')->addSelect('ticket')
            ->andWhere('attachment.id > :lastId')
            ->andWhere('attachment.contentHash IS NULL')
            ->andWhere('attachment.externalUrl IS NULL')
            ->setParameter('lastId', $lastId)
            ->orderBy('attachment.id', 'ASC')
            ->setMaxResults($batchSize);

        if ('' !== $ticketReference) {
            $queryBuilder
                ->andWhere('ticket.reference = :ticketReference')
                ->setParameter('ticketReference', $ticketReference);
        }

        /** @var list<TicketCommentAttachment> $attachments */
        $attachments = $queryBuilder->getQuery()->getResult();

        return $attachments;
    }
}
