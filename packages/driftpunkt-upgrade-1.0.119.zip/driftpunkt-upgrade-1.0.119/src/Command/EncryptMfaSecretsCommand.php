<?php

declare(strict_types=1);

namespace App\Command;

use App\Module\Identity\Entity\User;
use App\Module\Identity\Service\MfaKeyManager;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\Console\Attribute\AsCommand;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Style\SymfonyStyle;

#[AsCommand(name: 'app:mfa:encrypt-secrets', description: 'Krypterar kvarvarande MFA-hemligheter med installationens aktiva nyckel.')]
final class EncryptMfaSecretsCommand extends Command
{
    public function __construct(private readonly EntityManagerInterface $entityManager, private readonly MfaKeyManager $keyManager)
    {
        parent::__construct();
    }

    protected function configure(): void
    {
        $this->addOption('batch-size', null, InputOption::VALUE_REQUIRED, 'Högsta antal hemligheter per körning', '100');
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $io = new SymfonyStyle($input, $output);
        if (!$this->keyManager->isConfigured()) {
            $io->error('Konfigurera MFA-krypteringsnyckeln i superadmin först.');
            return Command::FAILURE;
        }
        $batchSize = filter_var($input->getOption('batch-size'), \FILTER_VALIDATE_INT, [
            'options' => ['min_range' => 1, 'max_range' => 1000],
        ]);
        if (false === $batchSize) {
            $io->error('--batch-size måste vara mellan 1 och 1000.');
            return Command::INVALID;
        }
        $count = 0;
        $hasMore = false;
        $query = $this->entityManager->createQuery(sprintf(
            'SELECT u FROM %s u WHERE u.mfaSecret IS NOT NULL ORDER BY u.id ASC',
            User::class,
        ));
        foreach ($query->toIterable() as $user) {
            $secret = $user->getMfaSecret();
            if (!\is_string($secret) || '' === $secret || !$this->keyManager->needsEncryptionWithActiveKey($secret)) {
                continue;
            }
            if ($count >= $batchSize) {
                $hasMore = true;
                break;
            }
            $plaintext = $this->keyManager->decryptSecret($secret);
            $user->setMfaSecret($this->keyManager->encryptSecret($plaintext));
            ++$count;
        }
        $this->entityManager->flush();
        if (!$hasMore) {
            $this->keyManager->completeRotation();
        }
        $io->success(sprintf(
            '%d MFA-hemligheter krypterades%s.',
            $count,
            $hasMore ? '; kör kommandot igen för nästa batch' : '; migrationen är slutförd',
        ));

        return Command::SUCCESS;
    }
}
