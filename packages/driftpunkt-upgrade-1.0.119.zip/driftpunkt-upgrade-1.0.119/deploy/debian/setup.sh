#!/usr/bin/env bash
set -euo pipefail

APP_DIR="${APP_DIR:-/var/www/driftpunkt}"
APP_USER="${APP_USER:-www-data}"
APP_GROUP="${APP_GROUP:-www-data}"
DOMAIN="${DOMAIN:-driftpunkt.example.com}"
PHP_BIN="${PHP_BIN:-php}"

if [[ "${EUID}" -ne 0 ]]; then
  echo "Kor scriptet med sudo eller som root."
  exit 1
fi

if [[ ! -f "${APP_DIR}/composer.json" ]]; then
  echo "Hittar inte ${APP_DIR}/composer.json."
  echo "Kopiera repot till ${APP_DIR} eller kor med APP_DIR=/din/sokvag sudo -E bash deploy/debian/setup.sh"
  exit 1
fi

echo "Installerar Debian-paket..."
apt-get update
apt-get install -y \
  apache2 \
  git \
  unzip \
  curl \
  logrotate \
  mariadb-client \
  mariadb-server \
  php \
  php-cli \
  php-common \
  php-curl \
  php-intl \
  php-mbstring \
  php-mysql \
  php-opcache \
  php-xml \
  php-zip \
  libapache2-mod-php

PHP_VERSION="$(${PHP_BIN} -r 'echo PHP_VERSION;' 2>/dev/null || true)"
if [[ -z "${PHP_VERSION}" ]]; then
  echo "PHP kunde inte koras."
  exit 1
fi

if ! "${PHP_BIN}" -r 'exit(version_compare(PHP_VERSION, "8.4.0", ">=") ? 0 : 1);'; then
  echo "Driftpunkt kraver PHP 8.4 eller senare. Installerad version: ${PHP_VERSION}"
  echo "Installera PHP 8.4+ och kor scriptet igen."
  exit 1
fi

if ! command -v composer >/dev/null 2>&1; then
  echo "Installerar Composer..."
  curl -fsSL https://getcomposer.org/installer | "${PHP_BIN}" -- --install-dir=/usr/local/bin --filename=composer
fi

if [[ ! -f "${APP_DIR}/.env.local" ]]; then
  cp "${APP_DIR}/deploy/debian/app.env.example" "${APP_DIR}/.env.local"
  sed -i "s#https://driftpunkt.example.com#https://${DOMAIN}#g" "${APP_DIR}/.env.local"
  sed -i "s#driftpunkt.example.com#${DOMAIN}#g" "${APP_DIR}/.env.local"
  echo "Skapade ${APP_DIR}/.env.local. Oppna filen och byt APP_SECRET, DATABASE_URL och mailinstallningar."
fi

echo "Installerar Composer-beroenden..."
cd "${APP_DIR}"
mkdir -p "${APP_DIR}/var/cache" "${APP_DIR}/var/log" "${APP_DIR}/var/share" "${APP_DIR}/htdocs/assets/branding"
chown -R "${APP_USER}:${APP_GROUP}" "${APP_DIR}"
runuser -u "${APP_USER}" -- env COMPOSER_HOME=/tmp/driftpunkt-composer composer install --no-dev --optimize-autoloader

echo "Installerar logrotation..."
cp "${APP_DIR}/deploy/debian/driftpunkt-logrotate" /etc/logrotate.d/driftpunkt
sed -i "s#/var/www/driftpunkt#${APP_DIR}#g" /etc/logrotate.d/driftpunkt

echo "Installerar Apache-site..."
cp "${APP_DIR}/deploy/debian/apache-driftpunkt.conf" /etc/apache2/sites-available/driftpunkt.conf
sed -i "s#driftpunkt.example.com#${DOMAIN}#g" /etc/apache2/sites-available/driftpunkt.conf
sed -i "s#/var/www/driftpunkt#${APP_DIR}#g" /etc/apache2/sites-available/driftpunkt.conf
a2enmod rewrite
a2ensite driftpunkt.conf
apache2ctl configtest
systemctl reload apache2

echo "Installerar systemd-timers..."
cp "${APP_DIR}/deploy/debian/driftpunkt-"*.service /etc/systemd/system/
cp "${APP_DIR}/deploy/debian/driftpunkt-"*.timer /etc/systemd/system/
for service_name in driftpunkt-mail-poll driftpunkt-attachment-archive; do
  service_file="/etc/systemd/system/${service_name}.service"
  sed -i "s#/var/www/driftpunkt#${APP_DIR}#g" "${service_file}"
  sed -i "s#^User=www-data$#User=${APP_USER}#" "${service_file}"
  sed -i "s#^Group=www-data$#Group=${APP_GROUP}#" "${service_file}"
  sed -i "s#^ExecStart=/usr/bin/php #ExecStart=${PHP_BIN} #" "${service_file}"
done
systemctl daemon-reload

echo
echo "Kvar att gora:"
echo "1. Redigera ${APP_DIR}/.env.local med riktiga hemligheter och databasuppgifter."
echo "2. Skapa MariaDB-databasen och anvandaren."
echo "3. Kor: sudo -u ${APP_USER} ${PHP_BIN} ${APP_DIR}/bin/console app:install:fresh --env=prod"
echo "4. Kor: sudo -u ${APP_USER} ${PHP_BIN} ${APP_DIR}/bin/console app:create-admin admin@example.com --first-name=Fornamn --last-name=Efternamn --type=super_admin --env=prod"
echo "5. Aktivera jobben: systemctl enable --now driftpunkt-mail-poll.timer driftpunkt-attachment-archive.timer"
echo "6. Skapa TLS, till exempel med certbot."
echo "7. Kontrollera att Apache DocumentRoot pekar pa ${APP_DIR}/htdocs."
