<?php

declare(strict_types=1);

namespace App\Module\Ticket\Service;

use App\Module\Identity\Entity\Company;
use App\Module\Identity\Entity\User;
use App\Module\Ticket\Entity\Ticket;
use App\Module\Ticket\Enum\TicketStatus;
use App\Module\Ticket\Enum\TicketVisibility;
use Doctrine\ORM\EntityManagerInterface;

final class CustomerTicketQuery
{
    public function __construct(
        private readonly EntityManagerInterface $entityManager,
        private readonly TicketAccessPolicy $ticketAccessPolicy,
    ) {
    }

    /**
     * @param list<TicketStatus>|null $statuses
     * @return list<Ticket>
     */
    public function findAccessibleTickets(User $user, ?array $statuses = null): array
    {
        if ([] === $statuses) {
            return [];
        }

        $queryBuilder = $this->baseCustomerTicketQueryBuilder();

        $sharedAccessCompanies = $this->accessibleCompanies($user);
        $allAccessCompanies = $this->allTicketAccessCompanies($user);
        $accessConditions = ['ticket.requester = :requester'];
        $queryBuilder->setParameter('requester', $user);

        if ([] !== $allAccessCompanies) {
            $accessConditions[] = 'ticket.company IN (:allAccessCompanies)';
            $queryBuilder->setParameter('allAccessCompanies', $allAccessCompanies);
        }

        if ([] !== $sharedAccessCompanies) {
            $accessConditions[] = '(ticket.visibility = :companyShared AND ticket.company IN (:sharedAccessCompanies))';
            $queryBuilder
                ->setParameter('companyShared', TicketVisibility::COMPANY_SHARED)
                ->setParameter('sharedAccessCompanies', $sharedAccessCompanies);
        }

        $queryBuilder->andWhere('('.implode(' OR ', $accessConditions).')');

        if (null !== $statuses) {
            $queryBuilder
                ->andWhere('ticket.status IN (:statuses)')
                ->setParameter('statuses', $statuses);
        }

        /** @var list<Ticket> $tickets */
        $tickets = $queryBuilder->getQuery()->getResult();

        return $tickets;
    }

    /**
     * @param list<TicketStatus>|null $statuses
     * @return list<Ticket>
     */
    public function findOwnTickets(User $user, ?array $statuses = null): array
    {
        if ([] === $statuses) {
            return [];
        }

        $queryBuilder = $this->baseCustomerTicketQueryBuilder()
            ->andWhere('ticket.requester = :requester')
            ->setParameter('requester', $user);

        if (null !== $statuses) {
            $queryBuilder
                ->andWhere('ticket.status IN (:statuses)')
                ->setParameter('statuses', $statuses);
        }

        /** @var list<Ticket> $tickets */
        $tickets = $queryBuilder->getQuery()->getResult();

        return $tickets;
    }

    /**
     * @param list<TicketStatus>|null $statuses
     * @return list<Ticket>
     */
    public function findCompanyTicketsForAllowedCustomer(User $user, ?array $statuses = null): array
    {
        if ([] === $statuses) {
            return [];
        }

        $viewerCompany = $user->getCompany();
        if (!$viewerCompany instanceof Company) {
            return [];
        }

        $allAccessCompanies = $this->allTicketAccessCompanies($user);
        if ([] !== $allAccessCompanies) {
            $sharedAccessCompanies = $this->accessibleCompanies($user);
            $companyConditions = ['ticket.company IN (:allAccessCompanies)'];
            $queryBuilder = $this->baseCustomerTicketQueryBuilder()
                ->setParameter('allAccessCompanies', $allAccessCompanies);

            if ([] !== $sharedAccessCompanies) {
                $companyConditions[] = '(ticket.visibility = :companyShared AND ticket.company IN (:sharedAccessCompanies))';
                $queryBuilder
                    ->setParameter('companyShared', TicketVisibility::COMPANY_SHARED)
                    ->setParameter('sharedAccessCompanies', $sharedAccessCompanies);
            }

            $queryBuilder->andWhere('('.implode(' OR ', $companyConditions).')');

            if (null !== $statuses) {
                $queryBuilder
                    ->andWhere('ticket.status IN (:statuses)')
                    ->setParameter('statuses', $statuses);
            }

            /** @var list<Ticket> $tickets */
            $tickets = $queryBuilder->getQuery()->getResult();

            return $tickets;
        }

        return array_values(array_filter(
            $this->findAccessibleTickets($user, $statuses),
            static fn (Ticket $ticket): bool => $ticket->getRequester()?->getId() !== $user->getId(),
        ));
    }

    /**
     * @return list<Company>
     */
    public function findCompaniesForAllowedCustomerTicketFilter(User $user): array
    {
        $viewerCompany = $user->getCompany();
        if (!$viewerCompany instanceof Company) {
            return [];
        }

        /** @var list<Company> $availableCompanies */
        $availableCompanies = $this->entityManager->getRepository(Company::class)->findAll();
        $companiesById = [];
        foreach ($availableCompanies as $company) {
            if (
                null !== $company->getId()
                && (
                    $this->ticketAccessPolicy->customerCompanyCanAccessCompanyTickets($viewerCompany, $company)
                    || $this->ticketAccessPolicy->customerCompanyCanAccessAllTickets($user, $company)
                )
            ) {
                $companiesById[$company->getId()] = $company;
            }
        }

        $companies = array_values($companiesById);
        usort($companies, static fn (Company $left, Company $right): int => strnatcasecmp($left->getName(), $right->getName()));

        return $companies;
    }

    private function baseCustomerTicketQueryBuilder(): \Doctrine\ORM\QueryBuilder
    {
        return $this->entityManager
            ->getRepository(Ticket::class)
            ->createQueryBuilder('ticket')
            ->leftJoin('ticket.company', 'company')->addSelect('company')
            ->leftJoin('ticket.requester', 'requester')->addSelect('requester')
            ->leftJoin('ticket.assignee', 'assignee')->addSelect('assignee')
            ->leftJoin('ticket.assignedTeam', 'assignedTeam')->addSelect('assignedTeam')
            ->andWhere('ticket.visibility != :internalOnly')
            ->setParameter('internalOnly', TicketVisibility::INTERNAL_ONLY)
            ->orderBy('ticket.updatedAt', 'DESC')
            ->addOrderBy('ticket.id', 'DESC');
    }

    /**
     * @return list<Company>
     */
    private function accessibleCompanies(User $user): array
    {
        $viewerCompany = $user->getCompany();
        if (!$viewerCompany instanceof Company) {
            return [];
        }

        /** @var list<Company> $companies */
        $companies = $this->entityManager->getRepository(Company::class)->findAll();

        return array_values(array_filter(
            $companies,
            fn (Company $company): bool => $this->ticketAccessPolicy->customerCompanyCanAccessCompanyTickets($viewerCompany, $company),
        ));
    }

    /**
     * @return list<Company>
     */
    private function allTicketAccessCompanies(User $user): array
    {
        if (!$this->ticketAccessPolicy->customerCanAccessAllCompanyTickets($user)) {
            return [];
        }

        /** @var list<Company> $companies */
        $companies = $this->entityManager->getRepository(Company::class)->findAll();

        return array_values(array_filter(
            $companies,
            fn (Company $company): bool => $this->ticketAccessPolicy->customerCompanyCanAccessAllTickets($user, $company),
        ));
    }
}
