<?php

declare(strict_types=1);

namespace App\Module\Mail\Service;

use App\Module\Identity\Entity\Company;
use App\Module\Identity\Entity\User;
use App\Module\Identity\Enum\UserType;
use App\Module\Mail\Entity\IncomingMail;
use App\Module\Mail\Entity\IncomingMailAlias;
use App\Module\Mail\Entity\SupportMailbox;

final class AutomaticCustomerRegistration
{
    public function __construct(
        private readonly ?CompanySenderDomainResolver $companySenderDomainResolver = null,
    ) {
    }

    public function applies(?SupportMailbox $mailbox): bool
    {
        return null !== $mailbox && $mailbox->hasAutomaticCustomerRegistration()
            && null !== $mailbox->getCompany()
            && null === $mailbox->getCompany()->getLegacyMailHandlingSource();
    }

    public function validateConfiguration(SupportMailbox $mailbox): void
    {
        if ($mailbox->hasAutomaticCustomerRegistration()
            && (!$mailbox->getCompany()?->isActive() || !$mailbox->allowsUnknownSenders() || !$this->hasAnyRegistrationDomain($mailbox))) {
            throw new \InvalidArgumentException('Automatisk kundregistrering kräver ett aktivt företag, tillåtna domäner på inkorgen eller mejldomäner på företaget/dotterbolagen och att inkorgen tillåter okända avsändare.');
        }
    }

    public function reviewReason(IncomingMail $mail, ?User $user, ?IncomingMailAlias $alias): ?string
    {
        $mailbox = $mail->getMailbox();
        if (!$this->applies($mailbox)) {
            return null;
        }
        if (!$mailbox->isActive() || !$mailbox->getCompany()->isActive() || !$mailbox->allowsUnknownSenders()) {
            return 'Automatisk kundregistrering är inte tillgänglig för denna inkorg eller detta företag.';
        }
        $company = $mailbox->getCompany();
        if (null !== $user && (!$user->isActive() || UserType::CUSTOMER !== $user->getType()
            || !$this->belongsToMailboxBranch($company, $user->getCompany()))) {
            return 'Befintlig avsändare saknar rätt företagskoppling eller är inte en aktiv företagskund.';
        }
        $aliasCompany = $alias?->getCompany() ?? $alias?->getUser()?->getCompany();
        if (null !== $alias && (!$this->belongsToMailboxBranch($company, $aliasCompany)
            || (null !== $alias->getUser() && $alias->getUser()->getId() !== $user?->getId()))) {
            return 'Avsändaralias har en motstridig företags- eller kundkoppling.';
        }

        return null;
    }

    public function canRegister(IncomingMail $mail): bool
    {
        $mailbox = $mail->getMailbox();
        $email = $mail->getFromEmail();
        if (!$this->applies($mailbox) || null !== $this->reviewReason($mail, null, null)
            || strlen($email) > 180 || false === filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return false;
        }

        return $this->registrationCompany($mail) instanceof Company;
    }

    /**
     * Ett dotterbolag vars mejldomän matchar går före inkorgens egna tillåtna domäner,
     * så att nya personer hamnar på rätt bolag i koncernen.
     */
    public function registrationCompany(IncomingMail $mail): ?Company
    {
        $mailbox = $mail->getMailbox();
        if (!$this->applies($mailbox)) {
            return null;
        }

        $domainCompany = $this->companySenderDomainResolver?->resolve($mailbox, $mail->getFromEmail());
        if ($domainCompany instanceof Company) {
            // Bolag med tidigare mejlhantering får inga automatiskt skapade kunder; mejlet går till granskning.
            return null === $domainCompany->getLegacyMailHandlingSource() ? $domainCompany : null;
        }

        $domain = CompanySenderDomainResolver::domainOf($mail->getFromEmail());

        return null !== $domain && in_array($domain, $mailbox->getAllowedSenderDomains(), true)
            ? $mailbox->getCompany()
            : null;
    }

    public function createCustomer(IncomingMail $mail): User
    {
        if (!$this->canRegister($mail)) {
            throw new \LogicException('Avsändaren får inte registreras automatiskt.');
        }
        $name = trim($mail->getFromName() ?? '');
        $parts = preg_split('/\s+/u', $name, 2) ?: [];
        $user = new User(
            $mail->getFromEmail(),
            mb_substr('' !== $name ? ($parts[0] ?? $mail->getFromEmail()) : $mail->getFromEmail(), 0, 80),
            mb_substr($parts[1] ?? '', 0, 80),
            UserType::CUSTOMER,
        );

        return $user->setCompany($this->registrationCompany($mail))->setPortalAccessEnabled(false);
    }

    private function belongsToMailboxBranch(Company $mailboxCompany, ?Company $company): bool
    {
        if (!$company instanceof Company) {
            return false;
        }

        return null !== $this->companySenderDomainResolver
            ? $this->companySenderDomainResolver->isInBranch($mailboxCompany, $company)
            : $company->getId() === $mailboxCompany->getId();
    }

    private function hasAnyRegistrationDomain(SupportMailbox $mailbox): bool
    {
        if ([] !== $mailbox->getAllowedSenderDomains()) {
            return true;
        }

        $company = $mailbox->getCompany();

        return $company instanceof Company
            && true === $this->companySenderDomainResolver?->branchHasEmailDomains($company);
    }
}
