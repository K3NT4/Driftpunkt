<?php

declare(strict_types=1);

namespace App\Module\Mail\Service;

use App\Module\Mail\Enum\IncomingMailAutomaticKind;

final class EmailMimeParser
{
    private const ORIGINAL_BODY_MAX_LENGTH = 200000;

    /**
     * @return array{
     *     from: string,
     *     from_name: ?string,
     *     message_id: ?string,
     *     subject: string,
     *     body: string,
     *     original_body: ?string,
     *     automatic_kind: ?IncomingMailAutomaticKind,
     *     attachments: list<array{
     *         displayName: string,
     *         mimeType: ?string,
     *         content: string
     *     }>
     * }
     */
    public function parse(string $rawMessage): array
    {
        [$headerBlock, $body] = $this->splitHeaderAndBody($rawMessage);
        $headers = $this->parseHeaders($headerBlock);
        $parts = $this->parseEntity($headers, $body);

        $plainBodies = [];
        $htmlBodies = [];
        $attachments = [];

        foreach ($parts as $part) {
            if ('text/plain' === $part['kind']) {
                $plainBodies[] = $part['content'];
                continue;
            }

            if ('text/html' === $part['kind']) {
                $htmlBodies[] = $part['content'];
                continue;
            }

            if ('attachment' === $part['kind']) {
                $attachments[] = [
                    'displayName' => $part['displayName'],
                    'mimeType' => $part['mimeType'],
                    'content' => $part['content'],
                    'contentId' => $part['contentId'],
                    'disposition' => $part['disposition'],
                ];
            }
        }

        [$fromName, $fromEmail] = $this->parseFromHeader($headers['from'] ?? '');
        $subject = $this->decodeMimeHeader($headers['subject'] ?? '');
        $plainBodyText = trim(implode("\n\n", array_filter($plainBodies, static fn (string $value): bool => '' !== trim($value))));
        $htmlBody = trim(implode("\n\n", array_filter($htmlBodies, static fn (string $value): bool => '' !== trim($value))));
        $bodyText = $this->selectImportedBodyText($plainBodyText, $htmlBody, $this->isForwardedSubject($subject));

        $referencedContentIds = '' !== $htmlBody ? $this->referencedContentIdsBeforeSignature($htmlBody) : [];
        $attachments = $this->filterSignatureInlineAttachments($attachments, $referencedContentIds, '' !== $htmlBody);

        return [
            'from' => $fromEmail,
            'from_name' => $fromName,
            'message_id' => $this->normalizeMessageId($headers['message-id'] ?? ''),
            'subject' => $subject,
            'body' => $bodyText,
            'original_body' => $this->buildOriginalBodyText($plainBodyText, $htmlBody, $bodyText),
            'automatic_kind' => $this->detectAutomaticKind($headers, $fromEmail, $subject),
            'attachments' => array_map(
                static fn (array $attachment): array => [
                    'displayName' => $attachment['displayName'],
                    'mimeType' => $attachment['mimeType'],
                    'content' => $attachment['content'],
                ],
                $attachments,
            ),
        ];
    }

    /**
     * RFC 3834 headers plus the common vendor variants used by Exchange, Gmail and autoresponders.
     *
     * @param array<string, string> $headers
     */
    private function detectAutomaticKind(array $headers, string $fromEmail, string $subject): ?IncomingMailAutomaticKind
    {
        $autoSubmitted = mb_strtolower(trim($headers['auto-submitted'] ?? ''));
        [$contentType, $contentTypeParams] = $this->parseHeaderValueWithParams($headers['content-type'] ?? '');
        $isDeliveryReport = 'multipart/report' === $contentType
            && \in_array(mb_strtolower((string) ($contentTypeParams['report-type'] ?? '')), ['delivery-status', 'disposition-notification'], true);

        if ('auto-replied' === $autoSubmitted
            || isset($headers['x-autoreply'])
            || isset($headers['x-autorespond'])
            || isset($headers['x-auto-reply'])
            || $isDeliveryReport
            || 1 === preg_match('/^(?:mailer-daemon|postmaster)@/i', $fromEmail)
            || 1 === preg_match('/^\s*(?:automatiskt svar|autosvar|automatic reply|auto(?:matic)?[- ]?reply|out of office|frånvaro(?:meddelande)?)\s*:/iu', $subject)) {
            return IncomingMailAutomaticKind::AUTO_REPLY;
        }

        $precedence = mb_strtolower(trim($headers['precedence'] ?? ''));
        if (('' !== $autoSubmitted && 'no' !== $autoSubmitted) || \in_array($precedence, ['bulk', 'junk', 'list', 'auto_reply'], true)) {
            return 'auto_reply' === $precedence ? IncomingMailAutomaticKind::AUTO_REPLY : IncomingMailAutomaticKind::AUTO_GENERATED;
        }

        return null;
    }

    private function normalizeMessageId(string $messageId): ?string
    {
        $normalized = mb_strtolower(trim($messageId));

        return '' !== $normalized ? mb_substr($normalized, 0, 255) : null;
    }

    /**
     * @param array<string, string> $headers
     * @return list<array{
     *     kind: 'text/plain'|'text/html'|'attachment',
     *     content: string,
     *     mimeType: ?string,
     *     displayName: string,
     *     contentId: ?string,
     *     disposition: ?string
     * }>
     */
    private function parseEntity(array $headers, string $body): array
    {
        $contentTypeHeader = $headers['content-type'] ?? 'text/plain';
        [$contentType, $contentTypeParams] = $this->parseHeaderValueWithParams($contentTypeHeader);
        [$disposition, $dispositionParams] = $this->parseHeaderValueWithParams($headers['content-disposition'] ?? '');
        $transferEncoding = mb_strtolower(trim($headers['content-transfer-encoding'] ?? ''));

        if (str_starts_with($contentType, 'multipart/')) {
            $boundary = $contentTypeParams['boundary'] ?? null;
            if (!\is_string($boundary) || '' === trim($boundary)) {
                return [];
            }

            $parts = [];
            foreach ($this->splitMultipartBody($body, $boundary) as $partBody) {
                [$nestedHeaderBlock, $nestedBody] = $this->splitHeaderAndBody($partBody);
                $parts = [...$parts, ...$this->parseEntity($this->parseHeaders($nestedHeaderBlock), $nestedBody)];
            }

            return $parts;
        }

        $decodedBody = $this->decodeTransferEncoding($body, $transferEncoding);
        $filename = $this->resolveAttachmentDisplayName($contentType, $contentTypeParams, $dispositionParams, $headers);
        $isTextPart = str_starts_with($contentType, 'text/');
        $isAttachment = 'attachment' === $disposition
            || ('inline' === $disposition && '' !== $filename)
            || !$isTextPart;

        if ($isAttachment) {
            return [[
                'kind' => 'attachment',
                'content' => $decodedBody,
                'mimeType' => '' !== $contentType ? $contentType : null,
                'displayName' => '' !== $filename ? $filename : $this->fallbackAttachmentDisplayName($contentType, $headers),
                'contentId' => $this->normalizeContentId($headers['content-id'] ?? ''),
                'disposition' => '' !== $disposition ? $disposition : null,
            ]];
        }

        if ('text/html' === $contentType) {
            return [[
                'kind' => 'text/html',
                'content' => $this->normalizeTextContent($decodedBody, $contentTypeParams['charset'] ?? null),
                'mimeType' => $contentType,
                'displayName' => '',
                'contentId' => null,
                'disposition' => null,
            ]];
        }

        return [[
            'kind' => 'text/plain',
            'content' => $this->normalizeTextContent($decodedBody, $contentTypeParams['charset'] ?? null),
            'mimeType' => $contentType,
            'displayName' => '',
            'contentId' => null,
            'disposition' => null,
        ]];
    }

    private function selectImportedBodyText(string $plainBodyText, string $htmlBody, bool $isForwarded): string
    {
        [$plainCandidate, $plainKeptForwarded] = '' !== trim($plainBodyText) ? $this->cleanImportedBodyText($plainBodyText, $isForwarded) : ['', false];
        [$htmlCandidate, $htmlKeptForwarded] = '' !== trim($htmlBody) ? $this->cleanImportedBodyText($this->convertHtmlToText($htmlBody), $isForwarded) : ['', false];

        if ('' === $plainCandidate) {
            return $htmlCandidate;
        }

        if ('' === $htmlCandidate) {
            return $plainCandidate;
        }

        // The HTML part may already be cut at an Outlook signature block, which hides forwarded content.
        if ($plainKeptForwarded !== $htmlKeptForwarded) {
            return $plainKeptForwarded ? $plainCandidate : $htmlCandidate;
        }

        if ($this->bodyLooksCleanerThan($htmlCandidate, $plainCandidate)) {
            return $htmlCandidate;
        }

        return $plainCandidate;
    }

    private function bodyLooksCleanerThan(string $candidate, string $current): bool
    {
        $candidateScore = $this->importedBodyNoiseScore($candidate);
        $currentScore = $this->importedBodyNoiseScore($current);

        if ($candidateScore !== $currentScore) {
            return $candidateScore < $currentScore;
        }

        return substr_count($candidate, "\n") + 2 < substr_count($current, "\n")
            && mb_strlen($candidate) <= mb_strlen($current);
    }

    private function importedBodyNoiseScore(string $body): int
    {
        $score = 0;
        foreach ([
            '/^\[image\](?:<[^>]+>)?$/im',
            '/^_{8,}$/m',
            '/^kontor\s*:/imu',
            '/^mobil\s*:/imu',
        ] as $pattern) {
            if (preg_match($pattern, $body)) {
                ++$score;
            }
        }

        return $score;
    }

    /**
     * Full message text without signature or history removal, kept so technicians can read what was actually sent.
     */
    private function buildOriginalBodyText(string $plainBodyText, string $htmlBody, string $cleanedBody): ?string
    {
        $text = '' !== trim($plainBodyText) ? $plainBodyText : ('' !== trim($htmlBody) ? $this->convertHtmlToText($htmlBody, false) : '');
        $text = $this->normalizeImportedSpacing($this->removeInvisibleFormattingCharacters($this->normalizeLineEndings($text)));
        $lines = $this->collapseBlankLines(array_map(static fn (string $line): string => rtrim($line), explode("\n", $text)));
        $text = implode("\n", $lines);

        if (mb_strlen($text) > self::ORIGINAL_BODY_MAX_LENGTH) {
            $text = mb_substr($text, 0, self::ORIGINAL_BODY_MAX_LENGTH)."\n\n[Originalet kortades efter 200 000 tecken. Hela mejlet finns i .eml-filen.]";
        }

        return '' !== $text && $text !== $cleanedBody ? $text : null;
    }

    private function convertHtmlToText(string $html, bool $truncateAtSignature = true): string
    {
        $text = $this->normalizeLineEndings($html);
        $text = preg_replace('/<(head|script|style)\b[^>]*>.*?<\/\1>/is', '', $text) ?? $text;
        if ($truncateAtSignature) {
            $text = $this->truncateHtmlAtSignatureBlock($text);
        }
        $text = preg_replace('/<!--.*?-->/s', '', $text) ?? $text;
        $text = preg_replace('/<\s*hr\b[^>]*>/i', "\n", $text) ?? $text;
        $text = preg_replace('/<\s*br\s*\/?>/i', "\n", $text) ?? $text;
        $text = preg_replace('/<\s*\/\s*(p|div|li|tr|h[1-6]|blockquote|section|article|table|ul|ol)\s*>/i', "\n", $text) ?? $text;
        $text = preg_replace('/<\s*(p|div|li|tr|h[1-6]|blockquote|section|article|table|ul|ol)\b[^>]*>/i', "\n", $text) ?? $text;
        $text = preg_replace('/<[^>]+>/', ' ', $text) ?? $text;
        $text = html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $text = str_replace("\xc2\xa0", ' ', $text);
        $text = preg_replace('/[ \t]+/', ' ', $text) ?? $text;

        $lines = array_map('trim', explode("\n", $text));
        $lines = array_values(array_filter($lines, static fn (string $line): bool => '' !== $line));

        return implode("\n", $lines);
    }

    private function truncateHtmlAtSignatureBlock(string $html): string
    {
        if (preg_match('/<[^>]+\b(?:id|class)\s*=\s*(["\'])(?:(?!\1).)*\bsignature\b(?:(?!\1).)*\1[^>]*>/iu', $html, $matches, PREG_OFFSET_CAPTURE)) {
            return substr($html, 0, $matches[0][1]);
        }

        return $html;
    }

    /**
     * @return array<string, true>
     */
    private function referencedContentIdsBeforeSignature(string $html): array
    {
        $html = $this->truncateHtmlAtSignatureBlock($this->normalizeLineEndings($html));
        preg_match_all('/\bcid:([^"\'>\s]+)/i', $html, $matches);

        $ids = [];
        foreach ($matches[1] ?? [] as $match) {
            $id = $this->normalizeContentId(rawurldecode((string) $match));
            if (null !== $id) {
                $ids[$id] = true;
            }
        }

        return $ids;
    }

    /**
     * @param list<array{
     *     displayName: string,
     *     mimeType: ?string,
     *     content: string,
     *     contentId: ?string,
     *     disposition: ?string
     * }> $attachments
     * @param array<string, true> $referencedContentIds
     * @return list<array{
     *     displayName: string,
     *     mimeType: ?string,
     *     content: string,
     *     contentId: ?string,
     *     disposition: ?string
     * }>
     */
    private function filterSignatureInlineAttachments(array $attachments, array $referencedContentIds, bool $hasHtmlBody): array
    {
        if (!$hasHtmlBody) {
            return $attachments;
        }

        return array_values(array_filter(
            $attachments,
            function (array $attachment) use ($referencedContentIds): bool {
                $mimeType = mb_strtolower((string) $attachment['mimeType']);
                $contentId = $attachment['contentId'];

                if ('inline' !== $attachment['disposition'] || null === $contentId || !str_starts_with($mimeType, 'image/')) {
                    return true;
                }

                return isset($referencedContentIds[$contentId]);
            },
        ));
    }

    /**
     * @param array<string, string> $contentTypeParams
     * @param array<string, string> $dispositionParams
     * @param array<string, string> $headers
     */
    private function resolveAttachmentDisplayName(string $contentType, array $contentTypeParams, array $dispositionParams, array $headers): string
    {
        $filename = $this->decodeContinuedHeaderParameter($dispositionParams, 'filename');
        if ('' === $filename) {
            $filename = $this->decodeContinuedHeaderParameter($contentTypeParams, 'name');
        }

        if ('' === $filename) {
            $filename = $this->decodeHeaderParameter($dispositionParams['filename*'] ?? $contentTypeParams['name*'] ?? '');
        }

        if ('' === $filename) {
            $filename = $this->decodeMimeHeader($dispositionParams['filename'] ?? $contentTypeParams['name'] ?? '');
        }

        if ('' === trim($filename)) {
            return '';
        }

        return $this->sanitizeAttachmentDisplayName($filename, $contentType);
    }

    /**
     * @param array<string, string> $params
     */
    private function decodeContinuedHeaderParameter(array $params, string $name): string
    {
        $segments = [];
        for ($index = 0; ; ++$index) {
            $encodedKey = sprintf('%s*%d*', $name, $index);
            $plainKey = sprintf('%s*%d', $name, $index);

            if (isset($params[$encodedKey])) {
                $segments[] = ['value' => $params[$encodedKey], 'encoded' => true];
                continue;
            }

            if (isset($params[$plainKey])) {
                $segments[] = ['value' => $params[$plainKey], 'encoded' => false];
                continue;
            }

            break;
        }

        if ([] === $segments) {
            return '';
        }

        $charset = 'UTF-8';
        $firstSegment = (string) $segments[0]['value'];
        if (true === $segments[0]['encoded'] && 3 === \count(explode("'", $firstSegment, 3))) {
            $parts = explode("'", $firstSegment, 3);
            $charset = '' !== trim($parts[0]) ? $parts[0] : 'UTF-8';
            $segments[0]['value'] = $parts[2];
        }

        $joined = '';
        foreach ($segments as $segment) {
            $value = trim((string) $segment['value'], " \t\n\r\0\x0B\"");
            $joined .= true === $segment['encoded'] ? rawurldecode($value) : $value;
        }

        return trim($this->normalizeTextContent($joined, $charset));
    }

    private function decodeHeaderParameter(string $value): string
    {
        $value = trim($value, " \t\n\r\0\x0B\"");
        if ('' === $value) {
            return '';
        }

        $parts = explode("'", $value, 3);
        if (3 === \count($parts)) {
            $charset = '' !== trim($parts[0]) ? $parts[0] : 'UTF-8';
            $decoded = rawurldecode($parts[2]);

            return trim($this->normalizeTextContent($decoded, $charset));
        }

        return $this->decodeMimeHeader(rawurldecode($value));
    }

    /**
     * @param array<string, string> $headers
     */
    private function fallbackAttachmentDisplayName(string $contentType, array $headers): string
    {
        $contentId = $this->normalizeContentId($headers['content-id'] ?? '');
        if (null !== $contentId) {
            $candidate = preg_replace('/@.*$/', '', $contentId) ?? $contentId;
            $candidate = $this->sanitizeAttachmentDisplayName(rawurldecode($candidate), $contentType);
            if ('' !== $candidate) {
                return $candidate;
            }
        }

        $extension = $this->extensionForMimeType($contentType);
        $baseName = str_starts_with($contentType, 'image/') ? 'bild' : 'bilaga';

        return $baseName.('' !== $extension ? '.'.$extension : '.bin');
    }

    private function normalizeContentId(string $contentId): ?string
    {
        $contentId = trim($contentId, " \t\n\r\0\x0B<>");
        if ('' === $contentId) {
            return null;
        }

        return mb_strtolower($contentId);
    }

    private function sanitizeAttachmentDisplayName(string $displayName, string $contentType): string
    {
        $displayName = trim($this->removeInvisibleFormattingCharacters($displayName));
        $displayName = basename(str_replace('\\', '/', $displayName));
        $displayName = preg_replace('/[\x00-\x1F\/\\\\:*?"<>|]+/u', '_', $displayName) ?? '';
        $displayName = trim($displayName, " \t\n\r\0\x0B._");
        if ('' === $displayName) {
            return '';
        }

        if ('' === pathinfo($displayName, \PATHINFO_EXTENSION)) {
            $extension = $this->extensionForMimeType($contentType);
            if ('' !== $extension) {
                $displayName .= '.'.$extension;
            }
        }

        return $displayName;
    }

    private function extensionForMimeType(string $contentType): string
    {
        return match (mb_strtolower(trim($contentType))) {
            'image/jpeg', 'image/jpg' => 'jpg',
            'image/png' => 'png',
            'image/gif' => 'gif',
            'image/webp' => 'webp',
            'image/bmp' => 'bmp',
            'image/svg+xml' => 'svg',
            'application/pdf' => 'pdf',
            'text/plain' => 'txt',
            'text/csv' => 'csv',
            'application/zip' => 'zip',
            default => '',
        };
    }

    /**
     * @return array{0: string, 1: bool} cleaned body and whether forwarded content was kept
     */
    private function cleanImportedBodyText(string $bodyText, bool $isForwarded = false): array
    {
        $bodyText = $this->normalizeImportedSpacing($this->removeInvisibleFormattingCharacters($this->normalizeLineEndings($bodyText)));
        $lines = array_map(static fn (string $line): string => trim($line), explode("\n", $bodyText));
        $lines = $this->removeLeadingMailboxArtifacts($lines);
        [$lines, $quotedLines] = $this->splitQuotedReplyHistory($lines);
        $lines = $this->removeTrailingSeparatorLines($this->removeSignatureFooter($lines));

        $keepForwarded = [] !== $quotedLines
            && ($isForwarded || $this->isForwardedMarker($quotedLines[0]) || $this->quotedHistoryIsDeliveryFailure($quotedLines));
        if ($keepForwarded) {
            $lines = [...$lines, '', ...$this->removeTrailingSeparatorLines($this->removeRawMessageCopy($quotedLines))];
        }

        $lines = $this->collapseBlankLines($lines);

        return [trim(implode("\n", $lines)), $keepForwarded];
    }

    private function isForwardedSubject(string $subject): bool
    {
        return 1 === preg_match('/^\s*(?:(?:re|sv|aw)\s*:\s*)*(?:fw|fwd|vb|vs|wg|tr)\s*:/iu', $subject);
    }

    private function isForwardedMarker(string $line): bool
    {
        return 1 === preg_match('/^-{2,}\s*(?:forwarded message|vidarebefordrat meddelande)\s*-{2,}$/iu', trim($line));
    }

    /**
     * @param list<string> $quotedLines
     */
    private function quotedHistoryIsDeliveryFailure(array $quotedLines): bool
    {
        foreach (array_slice($quotedLines, 0, 12) as $line) {
            if ($this->isReplyHeaderLine($line, ['from', 'från'])
                && 1 === preg_match('/mailer-daemon|postmaster|mail delivery (?:system|subsystem)/iu', $line)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Bounce reports append the full original message with headers and encoded body, which is only noise in a ticket.
     *
     * @param list<string> $lines
     * @return list<string>
     */
    private function removeRawMessageCopy(array $lines): array
    {
        foreach ($lines as $index => $line) {
            if (1 === preg_match('/^-*\s*(?:this is a copy of the message|original message headers)/iu', $line)) {
                return array_slice($lines, 0, $index);
            }
        }

        return $lines;
    }

    /**
     * @param list<string> $lines
     * @return list<string>
     */
    private function removeTrailingSeparatorLines(array $lines): array
    {
        while ([] !== $lines && 1 === preg_match('/^(?:[-_=*]{3,})?$/u', trim($lines[array_key_last($lines)]))) {
            array_pop($lines);
        }

        return $lines;
    }

    private function normalizeImportedSpacing(string $value): string
    {
        $value = str_replace(["\xc3\x82\xc2\xa0", "\xc3\x82 "], ' ', $value);

        return preg_replace('/[\x{00A0}\x{202F}]/u', ' ', $value) ?? $value;
    }

    private function removeInvisibleFormattingCharacters(string $value): string
    {
        return preg_replace('/[\x{200B}\x{200C}\x{200D}\x{FEFF}]/u', '', $value) ?? $value;
    }

    /**
     * @param list<string> $lines
     * @return list<string>
     */
    private function removeLeadingMailboxArtifacts(array $lines): array
    {
        while ([] !== $lines && '' === trim($lines[0])) {
            array_shift($lines);
        }

        if ([] !== $lines && preg_match('/^driftpunkt(?:test)?$/i', trim($lines[0]))) {
            array_shift($lines);
        }

        // Outlook "first contact safety tip" banner.
        while ([] !== $lines && preg_match('/^$|^(?:du får inte ofta e-post från|you don\'t often get email from)\s|^(?:läs om varför det här är viktigt|learn why this is important)$/iu', trim($lines[0]))) {
            array_shift($lines);
        }

        while ([] !== $lines && '' === trim($lines[0])) {
            array_shift($lines);
        }

        return array_values($lines);
    }

    /**
     * @param list<string> $lines
     * @return list<string>
     */
    /**
     * @param list<string> $lines
     * @return array{0: list<string>, 1: list<string>} own content and quoted history
     */
    private function splitQuotedReplyHistory(array $lines): array
    {
        $hasContentBeforeMarker = false;

        foreach ($lines as $index => $line) {
            $trimmed = trim($line);
            if ('' === $trimmed) {
                continue;
            }

            if ($hasContentBeforeMarker && $this->isQuotedReplyStart($lines, $index)) {
                return [array_slice($lines, 0, $index), array_slice($lines, $index)];
            }

            $hasContentBeforeMarker = true;
        }

        return [$lines, []];
    }

    /**
     * @param list<string> $lines
     */
    private function isQuotedReplyStart(array $lines, int $index): bool
    {
        $line = trim($lines[$index] ?? '');

        if (1 === preg_match('/^-{2,}\s*(ursprungligt meddelande|original message|forwarded message|vidarebefordrat meddelande)?\s*-{2,}$/iu', $line)) {
            return $this->replyHeaderBlockStartsNear($lines, $index + 1);
        }

        if (1 === preg_match('/^_{8,}$/u', $line)) {
            return $this->replyHeaderBlockStartsNear($lines, $index + 1);
        }

        if (1 === preg_match('/^(on .+ wrote:|den .+ skrev.+:|på .+ skrev.+:)$/iu', $line)) {
            return true;
        }

        return $this->isReplyHeaderLine($line, ['from', 'från']) && $this->replyHeaderBlockStartsNear($lines, $index);
    }

    /**
     * @param list<string> $lines
     */
    private function replyHeaderBlockStartsNear(array $lines, int $startIndex): bool
    {
        $seenHeaders = [];
        $checked = 0;

        for ($index = $startIndex; $index < \count($lines) && $checked < 8; ++$index) {
            $line = trim($lines[$index]);
            if ('' === $line) {
                continue;
            }

            ++$checked;
            $isHeaderLine = false;
            foreach (['from', 'från', 'sent', 'skickat', 'to', 'till', 'subject', 'ämne', 'cc', 'kopia'] as $headerName) {
                if ($this->isReplyHeaderLine($line, [$headerName])) {
                    $seenHeaders[$headerName] = true;
                    $isHeaderLine = true;
                    break;
                }
            }

            // The header block must follow the marker directly, otherwise a plain separator above a signature matches.
            if (1 === $checked && !$isHeaderLine) {
                return false;
            }
        }

        $hasSender = isset($seenHeaders['from']) || isset($seenHeaders['från']);
        $hasContext = isset($seenHeaders['sent'])
            || isset($seenHeaders['skickat'])
            || isset($seenHeaders['to'])
            || isset($seenHeaders['till'])
            || isset($seenHeaders['subject'])
            || isset($seenHeaders['ämne']);

        return $hasSender && $hasContext;
    }

    /**
     * @param list<string> $headerNames
     */
    private function isReplyHeaderLine(string $line, array $headerNames): bool
    {
        foreach ($headerNames as $headerName) {
            if (1 === preg_match('/^'.preg_quote($headerName, '/').'\s*:/iu', $line)) {
                return true;
            }
        }

        return false;
    }

    /**
     * @param list<string> $lines
     * @return list<string>
     */
    private function removeSignatureFooter(array $lines): array
    {
        $hasContentBeforeMarker = false;

        foreach ($lines as $index => $line) {
            $trimmed = trim($line);
            if ('' === $trimmed) {
                continue;
            }

            if ($hasContentBeforeMarker && $this->isSignatureStartLine($trimmed)) {
                return array_slice($lines, 0, $index);
            }

            $hasContentBeforeMarker = true;
        }

        return $lines;
    }

    private function isSignatureStartLine(string $line): bool
    {
        $line = trim($line);
        if (1 === preg_match('/^--\s*$/u', $line)) {
            return true;
        }

        $line = trim($line, " \t\n\r\0\x0B.,!");
        $signoffPattern = 'med vänlig(?:a)? hälsning(?:ar)?(?:\/best regards)?|med vanlig(?:a)? halsning(?:ar)?|med vanliga halsningar|vänlig(?:a)? hälsning(?:ar)?|vanlig(?:a)? halsning(?:ar)?|bästa hälsningar|basta halsningar|best regards|kind regards|warm regards|regards|hilsen|mvh|vh|vänligen|vanligen';

        if (1 !== preg_match('/^('.$signoffPattern.')(.*)$/iu', $line, $matches)) {
            return false;
        }

        $tail = trim($matches[2] ?? '', " \t\n\r\0\x0B.,:;-–—!");

        return '' === $tail || 1 === preg_match('/^[\p{Lu}][\p{L}\p{M}.\'-]*(?:\s+[\p{Lu}][\p{L}\p{M}.\'-]*){0,5}$/u', $tail);
    }

    /**
     * @param list<string> $lines
     * @return list<string>
     */
    private function collapseBlankLines(array $lines): array
    {
        $collapsed = [];
        $previousWasBlank = false;

        foreach ($lines as $line) {
            $isBlank = '' === trim($line);
            if ($isBlank && $previousWasBlank) {
                continue;
            }

            $collapsed[] = $line;
            $previousWasBlank = $isBlank;
        }

        while ([] !== $collapsed && '' === trim($collapsed[0])) {
            array_shift($collapsed);
        }

        while ([] !== $collapsed && '' === trim($collapsed[array_key_last($collapsed)])) {
            array_pop($collapsed);
        }

        return array_values($collapsed);
    }

    /**
     * @return array{0: string, 1: string}
     */
    private function splitHeaderAndBody(string $rawMessage): array
    {
        if (preg_match("/\r\n\r\n|\n\n|\r\r/", $rawMessage, $matches, PREG_OFFSET_CAPTURE)) {
            $delimiter = $matches[0][0];
            $position = $matches[0][1];

            return [
                substr($rawMessage, 0, $position),
                substr($rawMessage, $position + \strlen($delimiter)),
            ];
        }

        return [$rawMessage, ''];
    }

    /**
     * @return array<string, string>
     */
    private function parseHeaders(string $headerBlock): array
    {
        $headers = [];
        $currentHeader = null;

        foreach (preg_split('/\r\n|\r|\n/', $headerBlock) ?: [] as $line) {
            if (preg_match('/^[ \t]+/', $line) && \is_string($currentHeader)) {
                $headers[$currentHeader] .= ' '.trim($line);
                continue;
            }

            $parts = explode(':', $line, 2);
            if (2 !== \count($parts)) {
                continue;
            }

            $currentHeader = mb_strtolower(trim($parts[0]));
            $headers[$currentHeader] = trim($parts[1]);
        }

        return $headers;
    }

    /**
     * @return array{0: string, 1: array<string, string>}
     */
    private function parseHeaderValueWithParams(string $value): array
    {
        $parts = array_map('trim', explode(';', $value));
        $mainValue = mb_strtolower(array_shift($parts) ?? '');
        $params = [];

        foreach ($parts as $part) {
            $pair = explode('=', $part, 2);
            if (2 !== \count($pair)) {
                continue;
            }

            $params[mb_strtolower(trim($pair[0]))] = trim($pair[1], " \t\n\r\0\x0B\"");
        }

        return [$mainValue, $params];
    }

    /**
     * @return list<string>
     */
    private function splitMultipartBody(string $body, string $boundary): array
    {
        $normalizedBody = str_replace("\r\n", "\n", $body);
        $marker = '--'.$boundary;
        $chunks = explode($marker, $normalizedBody);
        $parts = [];

        foreach ($chunks as $chunk) {
            $trimmed = ltrim($chunk, "\n");
            if ('' === $trimmed || '--' === trim($trimmed)) {
                continue;
            }

            if (str_starts_with(trim($trimmed), '--')) {
                continue;
            }

            $parts[] = rtrim($trimmed, "\n");
        }

        return $parts;
    }

    private function decodeTransferEncoding(string $body, string $encoding): string
    {
        return match ($encoding) {
            'base64' => base64_decode(preg_replace('/\s+/', '', $body) ?? '', true) ?: '',
            'quoted-printable' => quoted_printable_decode($body),
            default => $body,
        };
    }

    private function normalizeTextContent(string $content, ?string $charset): string
    {
        $charset = trim((string) $charset);
        if ('' === $charset && mb_check_encoding($content, 'UTF-8')) {
            return $this->normalizeLineEndings($content);
        }

        $sourceEncoding = $this->normalizeCharset($charset);
        if (null !== $sourceEncoding) {
            $converted = @mb_convert_encoding($content, 'UTF-8', $sourceEncoding);
            if (\is_string($converted) && mb_check_encoding($converted, 'UTF-8')) {
                return $this->normalizeLineEndings($converted);
            }
        }

        if (mb_check_encoding($content, 'UTF-8')) {
            return $this->normalizeLineEndings($content);
        }

        $converted = @mb_convert_encoding($content, 'UTF-8', 'Windows-1252');
        if (\is_string($converted) && mb_check_encoding($converted, 'UTF-8')) {
            return $this->normalizeLineEndings($converted);
        }

        return $this->normalizeLineEndings(mb_convert_encoding($content, 'UTF-8', 'UTF-8'));
    }

    private function normalizeCharset(string $charset): ?string
    {
        $normalized = strtolower(trim($charset, " \t\n\r\0\x0B\"'"));
        if ('' === $normalized) {
            return null;
        }

        return match ($normalized) {
            'utf-8', 'utf8' => 'UTF-8',
            'iso-8859-1', 'latin1', 'latin-1' => 'ISO-8859-1',
            'windows-1252', 'cp1252' => 'Windows-1252',
            'us-ascii', 'ascii' => 'ASCII',
            default => $charset,
        };
    }

    private function normalizeLineEndings(string $content): string
    {
        return str_replace(["\r\n", "\r"], "\n", $content);
    }

    /**
     * @return array{0: ?string, 1: string}
     */
    private function parseFromHeader(string $header): array
    {
        $decoded = $this->decodeMimeHeader($header);
        if (preg_match('/^(.*)<([^>]+)>$/', $decoded, $matches)) {
            $name = trim($matches[1], " \t\n\r\0\x0B\"'");
            $email = mb_strtolower(trim($matches[2]));

            return [
                '' !== $name ? $name : null,
                $email,
            ];
        }

        return [null, mb_strtolower(trim($decoded))];
    }

    private function decodeMimeHeader(string $value): string
    {
        if ('' === trim($value)) {
            return '';
        }

        if (\function_exists('iconv_mime_decode')) {
            $decoded = @iconv_mime_decode($value, \ICONV_MIME_DECODE_CONTINUE_ON_ERROR, 'UTF-8');
            if (\is_string($decoded) && '' !== trim($decoded)) {
                return trim($decoded);
            }
        }

        return trim($value);
    }
}
