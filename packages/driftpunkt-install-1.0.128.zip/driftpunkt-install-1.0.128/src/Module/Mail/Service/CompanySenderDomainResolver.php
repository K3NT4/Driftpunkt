<?php

declare(strict_types=1);

namespace App\Module\Mail\Service;

use App\Module\Identity\Entity\Company;
use App\Module\Mail\Entity\SupportMailbox;
use Doctrine\ORM\EntityManagerInterface;

/**
 * Kopplar en avsändares mejldomän till ett företag inom inkorgens koncern.
 *
 * Bara inkorgens eget företag och dess dotterbolag (i alla led) kan matchas, så att
 * en inkorg aldrig styr mejl till ett bolag utanför sin egen koncerngren.
 */
final class CompanySenderDomainResolver
{
    public function __construct(
        private readonly EntityManagerInterface $entityManager,
    ) {
    }

    public function resolve(?SupportMailbox $mailbox, string $senderEmail): ?Company
    {
        $mailboxCompany = $mailbox?->getCompany();
        $domain = self::domainOf($senderEmail);
        if (!$mailboxCompany instanceof Company || null === $domain) {
            return null;
        }

        foreach ($this->companiesInBranch($mailboxCompany) as $company) {
            if ($company->isActive() && $company->hasEmailDomain($domain)) {
                return $company;
            }
        }

        return null;
    }

    public function branchHasEmailDomains(Company $mailboxCompany): bool
    {
        foreach ($this->companiesInBranch($mailboxCompany) as $company) {
            if ($company->isActive() && [] !== $company->getEmailDomains()) {
                return true;
            }
        }

        return false;
    }

    public function isInBranch(Company $mailboxCompany, ?Company $company): bool
    {
        if (!$company instanceof Company) {
            return false;
        }

        return $company === $mailboxCompany
            || (null !== $company->getId() && $company->getId() === $mailboxCompany->getId())
            || $company->isDescendantOf($mailboxCompany);
    }

    public static function domainOf(string $email): ?string
    {
        $email = strtolower(trim($email));
        $at = strrpos($email, '@');
        if (false === $at || $at === \strlen($email) - 1) {
            return null;
        }

        return substr($email, $at + 1);
    }

    /**
     * Inkorgens företag först, därefter dess dotterbolag.
     *
     * @return list<Company>
     */
    private function companiesInBranch(Company $mailboxCompany): array
    {
        $companies = [$mailboxCompany];
        foreach ($this->entityManager->getRepository(Company::class)->findAll() as $company) {
            if ($company !== $mailboxCompany && $company->isDescendantOf($mailboxCompany)) {
                $companies[] = $company;
            }
        }

        return $companies;
    }
}
