<?php

declare(strict_types=1);

namespace App\Module\Mail\Enum;

enum IncomingMailAutomaticKind: string
{
    /** Out-of-office replies and delivery failures; never turned into tickets. */
    case AUTO_REPLY = 'auto_reply';
    /** Alerts, newsletters and other machine-sent mail; imported but never answered automatically. */
    case AUTO_GENERATED = 'auto_generated';

    public function label(): string
    {
        return match ($this) {
            self::AUTO_REPLY => 'Autosvar eller studs',
            self::AUTO_GENERATED => 'Automatiskt utskick',
        };
    }
}
