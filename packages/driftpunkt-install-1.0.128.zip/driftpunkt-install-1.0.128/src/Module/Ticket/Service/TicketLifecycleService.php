<?php

declare(strict_types=1);

namespace App\Module\Ticket\Service;

use App\Module\Identity\Entity\TechnicianTeam;
use App\Module\Identity\Entity\User;
use App\Module\Ticket\Entity\Ticket;
use App\Module\Ticket\Enum\TicketPriority;
use App\Module\Ticket\Enum\TicketStatus;

final class TicketLifecycleService
{
    /**
     * @return list<TicketStatus>
     */
    public function activeStatuses(): array
    {
        return [
            TicketStatus::NEW,
            TicketStatus::OPEN,
            TicketStatus::IN_PROGRESS,
            TicketStatus::PENDING_CUSTOMER,
            TicketStatus::ON_HOLD,
        ];
    }

    /**
     * @return list<TicketStatus>
     */
    public function closedStatuses(): array
    {
        return [
            TicketStatus::RESOLVED,
            TicketStatus::CLOSED,
        ];
    }

    public function hasInternalRouting(Ticket $ticket): bool
    {
        return $ticket->getAssignee() instanceof User
            || $ticket->getAssignedTeam() instanceof TechnicianTeam
            || [] !== $ticket->getAdditionalTechnicians();
    }

    public function isActive(Ticket $ticket): bool
    {
        return \in_array($ticket->getStatus(), $this->activeStatuses(), true);
    }

    public function isClosed(Ticket $ticket): bool
    {
        return \in_array($ticket->getStatus(), $this->closedStatuses(), true);
    }

    public function closeTicket(Ticket $ticket, string $resolutionSummary): bool
    {
        $this->assertTicketIsWritable($ticket);

        if (TicketStatus::CLOSED === $ticket->getStatus()) {
            return false;
        }

        $resolutionSummary = trim($resolutionSummary);
        if ('' === $resolutionSummary) {
            throw new \DomainException('Ange en lösning innan ärendet stängs.');
        }

        $ticket->setResolutionSummary($resolutionSummary);
        $ticket->setStatus(TicketStatus::CLOSED);

        return true;
    }

    public function updatePriority(Ticket $ticket, TicketPriority $priority): bool
    {
        $this->assertTicketIsWritable($ticket);

        if ($ticket->getPriority() === $priority) {
            return false;
        }

        $ticket->setPriority($priority);

        return true;
    }

    public function markOpenWhenRouted(Ticket $ticket): ?TicketStatus
    {
        if (TicketStatus::NEW !== $ticket->getStatus() || !$this->hasInternalRouting($ticket)) {
            return null;
        }

        $previousStatus = $ticket->getStatus();
        $ticket->setStatus(TicketStatus::OPEN);

        return $previousStatus;
    }

    public function markInProgressWhenTechnicianWorks(Ticket $ticket): ?TicketStatus
    {
        if (
            !\in_array($ticket->getStatus(), [TicketStatus::NEW, TicketStatus::OPEN], true)
            || !$this->hasInternalRouting($ticket)
        ) {
            return null;
        }

        $previousStatus = $ticket->getStatus();
        $ticket->setStatus(TicketStatus::IN_PROGRESS);

        return $previousStatus;
    }

    private function assertTicketIsWritable(Ticket $ticket): void
    {
        if ($ticket->isMerged()) {
            throw new \DomainException('Ett sammanslaget källärende är skrivskyddat. Fortsätt i huvudärendet.');
        }
    }
}
