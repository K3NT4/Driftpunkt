<?php

declare(strict_types=1);

namespace App\Module\Identity\Entity;

use App\Module\Shared\Entity\TimestampableTrait;
use App\Module\System\Locale\AppLocale;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Uid\Uuid;

#[ORM\Entity]
#[ORM\Table(name: 'companies')]
#[ORM\HasLifecycleCallbacks]
class Company
{
    use TimestampableTrait;

    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(type: 'uuid', unique: true)]
    private Uuid $publicId;

    #[ORM\Column(length: 180, unique: true)]
    private string $name;

    #[ORM\Column(length: 255, nullable: true)]
    private ?string $primaryEmail = null;

    #[ORM\Column(options: ['default' => false])]
    private bool $monthlyReportEnabled = false;

    #[ORM\Column(length: 180, nullable: true)]
    private ?string $monthlyReportRecipientEmail = null;

    #[ORM\Column(length: 16, nullable: true)]
    private ?string $preferredLocale = null;

    #[ORM\Column(nullable: true)]
    private ?\DateTimeImmutable $monthlyReportLastSentAt = null;

    #[ORM\Column(options: ['default' => true])]
    private bool $reportAccessRestricted = true;

    /**
     * @var Collection<int, User>
     */
    #[ORM\ManyToMany(targetEntity: User::class)]
    #[ORM\JoinTable(name: 'company_report_allowed_users')]
    #[ORM\JoinColumn(name: 'company_id', referencedColumnName: 'id', onDelete: 'CASCADE')]
    #[ORM\InverseJoinColumn(name: 'user_id', referencedColumnName: 'id', onDelete: 'CASCADE')]
    private Collection $reportAllowedUsers;

    /**
     * @var Collection<int, User>
     */
    #[ORM\ManyToMany(targetEntity: User::class)]
    #[ORM\JoinTable(name: 'company_ticket_allowed_users')]
    #[ORM\JoinColumn(name: 'company_id', referencedColumnName: 'id', onDelete: 'CASCADE')]
    #[ORM\InverseJoinColumn(name: 'user_id', referencedColumnName: 'id', onDelete: 'CASCADE')]
    private Collection $ticketAllowedUsers;

    #[ORM\Column]
    private bool $isActive = true;

    #[ORM\Column(options: ['default' => false])]
    private bool $legacyMailHandling = false;

    #[ORM\Column]
    private bool $allowSharedTickets = true;

    #[ORM\Column(options: ['default' => false])]
    private bool $allowParentCompanyAccessToSharedTickets = false;

    #[ORM\Column(options: ['default' => false])]
    private bool $allowParentCompanyAccessToAllTickets = false;

    #[ORM\Column(options: ['default' => false])]
    private bool $useCustomTicketSequence = false;

    #[ORM\Column(length: 16, nullable: true)]
    private ?string $ticketReferencePrefix = null;

    #[ORM\Column(options: ['default' => 1001])]
    private int $ticketSequenceNextNumber = 1001;

    /**
     * Mejldomäner som hör till företaget. Används för att koppla okända avsändare
     * till rätt bolag när de mejlar en inkorg som tillhör företaget eller ett moderbolag.
     *
     * @var list<string>
     */
    #[ORM\Column(type: 'json', options: ['default' => '[]'])]
    private array $emailDomains = [];

    #[ORM\ManyToOne(targetEntity: self::class)]
    #[ORM\JoinColumn(name: 'parent_company_id', referencedColumnName: 'id', onDelete: 'SET NULL', nullable: true)]
    private ?self $parentCompany = null;

    /** @var Collection<int, CompanyTechnicianResponsibility> */
    #[ORM\OneToMany(mappedBy: 'company', targetEntity: CompanyTechnicianResponsibility::class, cascade: ['persist'], orphanRemoval: true)]
    #[ORM\OrderBy(['isPrimary' => 'DESC', 'id' => 'ASC'])]
    private Collection $technicianResponsibilities;

    /**
     * @var Collection<int, User>
     */
    #[ORM\OneToMany(mappedBy: 'company', targetEntity: User::class)]
    private Collection $users;

    public function __construct(string $name)
    {
        $this->publicId = Uuid::v7();
        $this->name = $name;
        $this->users = new ArrayCollection();
        $this->reportAllowedUsers = new ArrayCollection();
        $this->ticketAllowedUsers = new ArrayCollection();
        $this->technicianResponsibilities = new ArrayCollection();
    }

    public function usesLegacyMailHandling(): bool
    {
        return $this->legacyMailHandling;
    }

    public function setLegacyMailHandling(bool $enabled): self
    {
        $this->legacyMailHandling = $enabled;

        return $this;
    }

    public function getLegacyMailHandlingSource(): ?self
    {
        $company = $this;
        $seen = [];
        while (null !== $company) {
            $key = spl_object_id($company);
            if (isset($seen[$key])) {
                throw new \LogicException('Företagshierarkin innehåller en cykel.');
            }
            $seen[$key] = true;
            if ($company->usesLegacyMailHandling()) {
                return $company;
            }
            $company = $company->getParentCompany();
        }

        return null;
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getPublicId(): Uuid
    {
        return $this->publicId;
    }

    public function getName(): string
    {
        return $this->name;
    }

    public function rename(string $name): self
    {
        $this->name = $name;

        return $this;
    }

    public function getPrimaryEmail(): ?string
    {
        return $this->primaryEmail;
    }

    public function setPrimaryEmail(?string $primaryEmail): self
    {
        $this->primaryEmail = $primaryEmail;

        return $this;
    }

    /** @return list<string> */
    public function getEmailDomains(): array
    {
        return $this->emailDomains;
    }

    /** @param list<string> $domains */
    public function setEmailDomains(array $domains): self
    {
        $normalized = [];
        foreach ($domains as $domain) {
            $domain = strtolower(trim($domain));
            if ('' === $domain) {
                continue;
            }
            if (!str_contains($domain, '.') || \strlen($domain) > 253
                || false === filter_var($domain, \FILTER_VALIDATE_DOMAIN, \FILTER_FLAG_HOSTNAME)) {
                throw new \InvalidArgumentException(sprintf('Ogiltig mejldomän "%s". Ange exempelvis foretag.se, utan @ eller jokertecken.', $domain));
            }
            $normalized[] = $domain;
        }
        $this->emailDomains = array_values(array_unique($normalized));

        return $this;
    }

    public function hasEmailDomain(string $domain): bool
    {
        return \in_array(strtolower(trim($domain)), $this->emailDomains, true);
    }

    public function isMonthlyReportEnabled(): bool
    {
        return $this->monthlyReportEnabled;
    }

    public function setMonthlyReportEnabled(bool $monthlyReportEnabled): self
    {
        $this->monthlyReportEnabled = $monthlyReportEnabled;

        return $this;
    }

    public function getMonthlyReportRecipientEmail(): ?string
    {
        return $this->monthlyReportRecipientEmail;
    }

    public function setMonthlyReportRecipientEmail(?string $monthlyReportRecipientEmail): self
    {
        $normalized = null !== $monthlyReportRecipientEmail ? mb_strtolower(trim($monthlyReportRecipientEmail)) : null;
        $this->monthlyReportRecipientEmail = '' !== (string) $normalized ? $normalized : null;

        return $this;
    }

    public function getPreferredLocale(): ?string
    {
        return $this->preferredLocale;
    }

    public function setPreferredLocale(?string $preferredLocale): self
    {
        $preferredLocale = null !== $preferredLocale ? trim($preferredLocale) : null;
        $this->preferredLocale = '' !== (string) $preferredLocale ? AppLocale::normalize($preferredLocale) : null;

        return $this;
    }

    public function getMonthlyReportLastSentAt(): ?\DateTimeImmutable
    {
        return $this->monthlyReportLastSentAt;
    }

    public function markMonthlyReportSent(?\DateTimeImmutable $sentAt = null): self
    {
        $this->monthlyReportLastSentAt = $sentAt ?? new \DateTimeImmutable();

        return $this;
    }

    public function isReportAccessRestricted(): bool
    {
        return $this->reportAccessRestricted;
    }

    public function setReportAccessRestricted(bool $reportAccessRestricted): self
    {
        $this->reportAccessRestricted = $reportAccessRestricted;

        return $this;
    }

    /**
     * @return Collection<int, User>
     */
    public function getReportAllowedUsers(): Collection
    {
        return $this->reportAllowedUsers;
    }

    public function addReportAllowedUser(User $user): self
    {
        if (!$this->reportAllowedUsers->contains($user)) {
            $this->reportAllowedUsers->add($user);
        }

        return $this;
    }

    public function clearReportAllowedUsers(): self
    {
        $this->reportAllowedUsers->clear();

        return $this;
    }

    /**
     * @return Collection<int, User>
     */
    public function getTicketAllowedUsers(): Collection
    {
        return $this->ticketAllowedUsers;
    }

    public function addTicketAllowedUser(User $user): self
    {
        if (!$this->ticketAllowedUsers->contains($user)) {
            $this->ticketAllowedUsers->add($user);
        }

        return $this;
    }

    public function clearTicketAllowedUsers(): self
    {
        $this->ticketAllowedUsers->clear();

        return $this;
    }

    public function isActive(): bool
    {
        return $this->isActive;
    }

    public function activate(): self
    {
        $this->isActive = true;

        return $this;
    }

    public function deactivate(): self
    {
        $this->isActive = false;

        return $this;
    }

    public function allowsSharedTickets(): bool
    {
        return $this->allowSharedTickets;
    }

    public function setAllowSharedTickets(bool $allowSharedTickets): self
    {
        $this->allowSharedTickets = $allowSharedTickets;

        return $this;
    }

    public function allowsParentCompanyAccessToSharedTickets(): bool
    {
        return $this->allowParentCompanyAccessToSharedTickets;
    }

    public function setAllowParentCompanyAccessToSharedTickets(bool $allowParentCompanyAccessToSharedTickets): self
    {
        $this->allowParentCompanyAccessToSharedTickets = $allowParentCompanyAccessToSharedTickets;

        return $this;
    }

    public function allowsParentCompanyAccessToAllTickets(): bool
    {
        return $this->allowParentCompanyAccessToAllTickets;
    }

    public function setAllowParentCompanyAccessToAllTickets(bool $allowParentCompanyAccessToAllTickets): self
    {
        $this->allowParentCompanyAccessToAllTickets = $allowParentCompanyAccessToAllTickets;

        return $this;
    }

    public function usesCustomTicketSequence(): bool
    {
        return $this->useCustomTicketSequence;
    }

    public function setUseCustomTicketSequence(bool $useCustomTicketSequence): self
    {
        $this->useCustomTicketSequence = $useCustomTicketSequence;

        return $this;
    }

    public function getTicketReferencePrefix(): ?string
    {
        return $this->ticketReferencePrefix;
    }

    public function setTicketReferencePrefix(?string $ticketReferencePrefix): self
    {
        $normalized = null !== $ticketReferencePrefix ? strtoupper(trim($ticketReferencePrefix)) : null;
        $this->ticketReferencePrefix = '' !== (string) $normalized ? $normalized : null;

        return $this;
    }

    public function getTicketSequenceNextNumber(): int
    {
        return max(1, $this->ticketSequenceNextNumber);
    }

    public function setTicketSequenceNextNumber(int $ticketSequenceNextNumber): self
    {
        $this->ticketSequenceNextNumber = max(1, $ticketSequenceNextNumber);

        return $this;
    }

    public function reserveNextTicketNumber(): int
    {
        $nextNumber = $this->getTicketSequenceNextNumber();
        $this->ticketSequenceNextNumber = $nextNumber + 1;

        return $nextNumber;
    }

    public function getParentCompany(): ?self
    {
        return $this->parentCompany;
    }

    public function getRootCompany(): self
    {
        $company = $this;
        $seen = [];
        while ($company->parentCompany instanceof self) {
            $key = spl_object_id($company);
            if (isset($seen[$key])) {
                throw new \LogicException('Företagshierarkin innehåller en cykel.');
            }
            $seen[$key] = true;
            $company = $company->parentCompany;
        }

        return $company;
    }

    /** @return Collection<int, CompanyTechnicianResponsibility> */
    public function getTechnicianResponsibilities(): Collection
    {
        return $this->technicianResponsibilities;
    }

    /** @return Collection<int, CompanyTechnicianResponsibility> */
    public function getEffectiveTechnicianResponsibilities(): Collection
    {
        return $this->getRootCompany()->getTechnicianResponsibilities();
    }

    public function clearTechnicianResponsibilities(): self
    {
        $this->technicianResponsibilities->clear();

        return $this;
    }

    public function addTechnicianResponsibility(CompanyTechnicianResponsibility $responsibility): self
    {
        if (!$this->technicianResponsibilities->contains($responsibility)) {
            $this->technicianResponsibilities->add($responsibility);
        }

        return $this;
    }

    public function setParentCompany(?self $parentCompany): self
    {
        if ($this->parentCompany === $parentCompany) {
            return $this;
        }

        if ($parentCompany === $this) {
            throw new \InvalidArgumentException('Ett företag kan inte vara sitt eget moderbolag.');
        }

        if ($parentCompany?->isDescendantOf($this)) {
            throw new \InvalidArgumentException('Ett företag kan inte flyttas under sitt eget dotterbolag.');
        }

        $this->parentCompany = $parentCompany;

        return $this;
    }

    public function isDescendantOf(self $company): bool
    {
        $parent = $this->parentCompany;
        while ($parent instanceof self) {
            if ($parent === $company) {
                return true;
            }

            $parent = $parent->getParentCompany();
        }

        return false;
    }

    public function getHierarchyDepth(): int
    {
        $depth = 0;
        $parent = $this->parentCompany;

        while ($parent instanceof self) {
            ++$depth;
            $parent = $parent->getParentCompany();
        }

        return $depth;
    }

    /**
     * @return Collection<int, User>
     */
    public function getUsers(): Collection
    {
        return $this->users;
    }
}
