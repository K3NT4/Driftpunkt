<?php

declare(strict_types=1);

namespace App\Command;

use App\Module\Mail\Entity\IncomingMail;
use App\Module\Mail\Entity\SupportMailbox;
use App\Module\Mail\Service\EmailMimeParser;
use App\Module\Mail\Service\IncomingMailAttachmentStorage;
use App\Module\Mail\Service\IncomingMailProcessor;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\Console\Attribute\AsCommand;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Style\SymfonyStyle;

#[AsCommand(
    name: 'app:mail:ingest',
    description: 'Behandlar ett enskilt inkommande e-postmeddelande som ärende, svar, utkastgranskning eller avslag.',
)]
final class IngestIncomingMailCommand extends Command
{
    public function __construct(
        private readonly EntityManagerInterface $entityManager,
        private readonly IncomingMailProcessor $incomingMailProcessor,
        private readonly EmailMimeParser $emailMimeParser,
        private readonly IncomingMailAttachmentStorage $incomingMailAttachmentStorage,
    ) {
        parent::__construct();
    }

    protected function configure(): void
    {
        $this
            ->addArgument('mailbox', InputArgument::REQUIRED, 'Inkorgens e-postadress eller namn')
            ->addArgument('from', InputArgument::OPTIONAL, 'Avsändarens e-postadress')
            ->addArgument('subject', InputArgument::OPTIONAL, 'Ämne')
            ->addArgument('body', InputArgument::OPTIONAL, 'Brödtext i ren text')
            ->addOption('eml', null, InputOption::VALUE_REQUIRED, 'Läs in ett komplett mejl från en .eml-fil i stället för från, ämne och brödtext');
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $io = new SymfonyStyle($input, $output);
        $mailboxIdentifier = trim((string) $input->getArgument('mailbox'));

        $mailbox = $this->entityManager->getRepository(SupportMailbox::class)->findOneBy([
            'emailAddress' => mb_strtolower($mailboxIdentifier),
        ]);

        if (!$mailbox instanceof SupportMailbox) {
            $mailbox = $this->entityManager->getRepository(SupportMailbox::class)->findOneBy([
                'name' => $mailboxIdentifier,
            ]);
        }

        if (!$mailbox instanceof SupportMailbox) {
            $io->error('Kunde inte hitta angiven inkorg.');

            return Command::FAILURE;
        }

        $emlPath = trim((string) $input->getOption('eml'));
        if ('' !== $emlPath) {
            $rawMessage = is_file($emlPath) ? (string) file_get_contents($emlPath) : '';
            if ('' === trim($rawMessage)) {
                $io->error('Kunde inte läsa .eml-filen.');

                return Command::FAILURE;
            }

            $parsedMessage = $this->emailMimeParser->parse($rawMessage);
            $incomingMail = new IncomingMail($parsedMessage['from'], $parsedMessage['subject'], $parsedMessage['body']);
            $incomingMail
                ->setMailbox($mailbox)
                ->setMessageId($parsedMessage['message_id'])
                ->setFromName($parsedMessage['from_name'])
                ->setOriginalBody($parsedMessage['original_body'])
                ->setAutomaticKind($parsedMessage['automatic_kind']);
            $this->entityManager->persist($incomingMail);
            $this->entityManager->flush();
            $incomingMail->setRawMessagePath($this->incomingMailAttachmentStorage->storeRawMessage($incomingMail, $rawMessage));
            if ($mailbox->allowsAttachments() && [] !== $parsedMessage['attachments']) {
                $incomingMail->setAttachmentMetadata($this->incomingMailAttachmentStorage->storeIncomingMailAttachments($incomingMail, $parsedMessage['attachments']));
            }
            $this->entityManager->flush();
        } else {
            foreach (['from', 'subject', 'body'] as $argument) {
                if ('' === trim((string) $input->getArgument($argument))) {
                    $io->error('Ange från, ämne och brödtext, eller använd --eml.');

                    return Command::FAILURE;
                }
            }

            $incomingMail = new IncomingMail(
                (string) $input->getArgument('from'),
                (string) $input->getArgument('subject'),
                (string) $input->getArgument('body'),
            );
            $incomingMail->setMailbox($mailbox);

            $this->entityManager->persist($incomingMail);
            $this->entityManager->flush();
        }

        $this->incomingMailProcessor->process($incomingMail);

        $io->success(sprintf(
            'E-postmeddelande behandlat: %s. %s',
            $incomingMail->getProcessingResult()?->label() ?? 'okänt resultat',
            $incomingMail->getProcessingNote() ?? 'Ingen notering',
        ));

        return Command::SUCCESS;
    }
}
