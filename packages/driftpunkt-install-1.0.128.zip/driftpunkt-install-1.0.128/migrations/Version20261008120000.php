<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

final class Version20261008120000 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Stores original text and raw .eml of incoming mail, and flags auto-replies and auto-generated mail';
    }

    public function up(Schema $schema): void
    {
        $table = $schema->getTable('incoming_mails');
        $table->addColumn('original_body', 'text', ['notnull' => false]);
        $table->addColumn('raw_message_path', 'string', ['length' => 500, 'notnull' => false]);
        $table->addColumn('automatic_kind', 'string', ['length' => 255, 'notnull' => false]);
    }

    public function down(Schema $schema): void
    {
        $table = $schema->getTable('incoming_mails');
        $table->dropColumn('original_body');
        $table->dropColumn('raw_message_path');
        $table->dropColumn('automatic_kind');
    }
}
