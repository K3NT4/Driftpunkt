<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

final class Version20261001120000 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Adds company email domains for routing unknown mail senders to subsidiaries';
    }

    public function up(Schema $schema): void
    {
        $schema->getTable('companies')->addColumn('email_domains', 'json', ['default' => '[]']);
    }

    public function down(Schema $schema): void
    {
        $schema->getTable('companies')->dropColumn('email_domains');
    }
}
