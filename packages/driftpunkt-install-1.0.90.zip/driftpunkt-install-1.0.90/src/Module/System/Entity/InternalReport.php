<?php

declare(strict_types=1);

namespace App\Module\System\Entity;

use App\Module\Identity\Entity\User;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity]
#[ORM\Table(name: 'internal_reports')]
#[ORM\Index(columns: ['status', 'created_at'], name: 'idx_internal_reports_status_created')]
#[ORM\HasLifecycleCallbacks]
class InternalReport
{
    public const TYPE_BUG = 'bug';
    public const TYPE_IMPROVEMENT = 'improvement';
    public const TYPE_MISSING_CUSTOMER = 'missing_customer';

    public const STATUS_OPEN = 'open';
    public const STATUS_IN_PROGRESS = 'in_progress';
    public const STATUS_RESOLVED = 'resolved';

    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\ManyToOne(targetEntity: User::class)]
    #[ORM\JoinColumn(nullable: true, onDelete: 'SET NULL')]
    private ?User $reporter;

    #[ORM\Column(length: 180)]
    private string $reporterEmail;

    #[ORM\Column(length: 180)]
    private string $reporterName;

    #[ORM\Column(length: 32)]
    private string $type;

    #[ORM\Column(length: 180)]
    private string $subject;

    #[ORM\Column(type: 'text')]
    private string $description;

    #[ORM\Column(length: 24)]
    private string $status = self::STATUS_OPEN;

    #[ORM\Column(type: 'text', nullable: true)]
    private ?string $adminNote = null;

    #[ORM\Column]
    private \DateTimeImmutable $createdAt;

    #[ORM\Column]
    private \DateTimeImmutable $updatedAt;

    #[ORM\Column(nullable: true)]
    private ?\DateTimeImmutable $resolvedAt = null;

    #[ORM\Column(length: 180, nullable: true)]
    private ?string $resolvedByEmail = null;

    public function __construct(User $reporter, string $type, string $subject, string $description)
    {
        if (!\in_array($type, self::types(), true)) {
            throw new \InvalidArgumentException('Okänd intern rapporttyp.');
        }

        $this->reporter = $reporter;
        $this->reporterEmail = $reporter->getEmail();
        $this->reporterName = $reporter->getDisplayName();
        $this->type = $type;
        $this->subject = trim($subject);
        $this->description = trim($description);
        $this->createdAt = new \DateTimeImmutable();
        $this->updatedAt = $this->createdAt;
    }

    /** @return list<string> */
    public static function types(): array
    {
        return [self::TYPE_BUG, self::TYPE_IMPROVEMENT, self::TYPE_MISSING_CUSTOMER];
    }

    /** @return list<string> */
    public static function statuses(): array
    {
        return [self::STATUS_OPEN, self::STATUS_IN_PROGRESS, self::STATUS_RESOLVED];
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getReporter(): ?User
    {
        return $this->reporter;
    }

    public function getReporterEmail(): string
    {
        return $this->reporterEmail;
    }

    public function getReporterName(): string
    {
        return $this->reporterName;
    }

    public function getType(): string
    {
        return $this->type;
    }

    public function getTypeLabel(): string
    {
        return match ($this->type) {
            self::TYPE_BUG => 'Fel',
            self::TYPE_IMPROVEMENT => 'Förbättring eller önskemål',
            self::TYPE_MISSING_CUSTOMER => 'Saknad kund',
            default => 'Intern rapport',
        };
    }

    public function getSubject(): string
    {
        return $this->subject;
    }

    public function getDescription(): string
    {
        return $this->description;
    }

    public function getStatus(): string
    {
        return $this->status;
    }

    public function getStatusLabel(): string
    {
        return match ($this->status) {
            self::STATUS_OPEN => 'Ny',
            self::STATUS_IN_PROGRESS => 'Pågår',
            self::STATUS_RESOLVED => 'Klar',
            default => 'Okänd',
        };
    }

    public function getAdminNote(): ?string
    {
        return $this->adminNote;
    }

    public function getCreatedAt(): \DateTimeImmutable
    {
        return $this->createdAt;
    }

    public function getUpdatedAt(): \DateTimeImmutable
    {
        return $this->updatedAt;
    }

    public function getResolvedAt(): ?\DateTimeImmutable
    {
        return $this->resolvedAt;
    }

    public function getResolvedByEmail(): ?string
    {
        return $this->resolvedByEmail;
    }

    public function updateStatus(string $status, ?string $adminNote, string $actorEmail): self
    {
        if (!\in_array($status, self::statuses(), true)) {
            throw new \InvalidArgumentException('Okänd status för intern rapport.');
        }

        $this->status = $status;
        $normalizedNote = null !== $adminNote ? trim($adminNote) : null;
        $this->adminNote = '' !== (string) $normalizedNote ? $normalizedNote : null;
        $this->updatedAt = new \DateTimeImmutable();

        if (self::STATUS_RESOLVED === $status) {
            $this->resolvedAt = $this->updatedAt;
            $this->resolvedByEmail = mb_strtolower(trim($actorEmail));
        } else {
            $this->resolvedAt = null;
            $this->resolvedByEmail = null;
        }

        return $this;
    }
}
