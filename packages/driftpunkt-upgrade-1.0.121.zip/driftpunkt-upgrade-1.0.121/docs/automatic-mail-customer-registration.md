# Automatisk kundregistrering från e-post

Funktionen skapar kundpersoner utan portalåtkomst när de skickar sitt första nya ärende till företagets inkorg. Den är avstängd som standard och ändrar inte befintliga kundkonton, ärenden eller granskningsutkast.

## Installation och aktivering

Ta en databasbackup enligt installationens ordinarie uppgraderingsrutin. Installera koden och kör migrationerna innan webb och mejlbevakning använder den nya versionen:

```bash
php bin/console doctrine:migrations:migrate --dry-run --env=prod
php bin/console doctrine:migrations:migrate --no-interaction --env=prod
php bin/console cache:clear --env=prod
```

Det andra kommandot ändrar databasschemat. Migration `Version20260907120000` lägger till inkorgens automatik och domänlista, företagets undantag och användarens portalåtkomst. Den har ingen automatisk nedmigration eftersom borttagning av portalspärren annars skulle kunna ge mejlkunder oavsiktlig åtkomst. Avstängning av inkorgsautomatiken är det normala sättet att återgå till tidigare flöde.

Superadmin öppnar inkorgens inställningar, kopplar ett aktivt företag, tillåter okända avsändare och slår på **Automatisk kundregistrering**. Ange tillåtna avsändardomäner, en per rad, exempelvis `foretag.se`. Komma och semikolon fungerar också. Ange inte `@`, adresser eller jokertecken. Underdomäner måste anges separat.

Aktivera först på en testinkorg. Skicka från en ny adress på en tillåten domän och kontrollera att en företagskund och ett privat ärende skapas. Skicka igen och kontrollera att samma kund återanvänds. Kontrollera även att en annan domän går till granskning.

## Företagsgrupper och prioritet

På företagssidan kan endast superadmin spara **Behåll tidigare mejlhantering**. Undantaget gäller företaget och alla dess underföretag på alla nivåer. Företagssidan och inkorgsformuläret visar vilket företag som orsakar undantaget.

1. Undantag på företaget eller något moderföretag innebär tidigare mejlhantering, inklusive tidigare matchning mellan företag och befintliga regler för okända avsändare.
2. Utan undantag används inkorgens automatik om den är påslagen och giltigt konfigurerad.
3. Utan automatik används tidigare mejlhantering.

Underföretag kan inte upphäva moderföretagets undantag. Ändra inställningen på det företag som aktiverade den. När undantaget tas bort gäller inkorgens sparade inställningar igen, om inget annat moderföretag fortfarande har undantag. Efter flytt i företagshierarkin följer kommande mejl den nya kedjan. Befintlig historik ändras inte.

## Matchning och portalåtkomst

Befintliga kunder och avsändaralias återanvänds först. Under aktiv automatik går konflikter mellan kund, alias och inkorgsföretag till granskning. Befintliga kunder flyttas aldrig automatiskt, och personer utan företagskoppling granskas. Svar och vidarebefordringar får inte registrera nya kunder för att kringgå ärendebehörigheter.

Nya kundpersoner har typen företagskund och får inkorgens företag. Namnet hämtas från mejlets visningsnamn, annars används e-postadressen. Ärendet får privat synlighet och inkorgens vanliga standardinställningar.

Mejlkunder är aktiva för ärendehantering men saknar portalåtkomst. Ingen inbjudan skickas. Inloggning, befintliga sessioner, inloggningslänkar och lösenordsåterställning blockeras. Administratören kan aktivera **Portalåtkomst** i kundens användarformulär. Därefter kan kunden använda den vanliga lösenordsåterställningen. Befintliga konton behåller sin tidigare åtkomst.

Domänmatchning är en företagskopplingsregel, inte verifierad identitet. Mejltjänstens avsändar- och skräppostkontroller ska fortsatt användas.

## Drift och felsökning

Automatisk registrering loggas som `incoming_mail.customer_registered`, granskning som `incoming_mail.review_created` och företagsundantag som `company.mail_handling_updated` i systemloggen. Ärende, inkorg och företag finns i loggmeddelandena. Kontrollera ärvt undantag, inkorgens domänlista, företagsstatus och avsändarens befintliga kund/alias vid oväntad granskning.

Mejlbehandlingen använder det gemensamma Symfony-låset `incoming-mail-processing` eftersom kundadresser och standardärendeserien delas mellan inkorgar. Standardkonfigurationen använder `var/lock`, som måste delas mellan webb och scheduler. Installationer med flera servrar måste konfigurera `LOCK_DSN` till en gemensam låstjänst. Automatisk kund- och ärenderegistrering sparas i en transaktion. Notifieringar skickas efter att registreringen har sparats. Återkörning av ett färdigbehandlat mejl skapar inte ett nytt ärende.

Vid databasfel kan transaktionen rullas tillbaka och Doctrine stänga sin EntityManager. Starta då om mejlkommandot för ett nytt försök efter att grundfelet rättats. Redan behandlade mejl ska inte nollställas för att försöka skicka om en notifiering.

## Tester

```bash
php bin/phpunit --filter 'AutomaticCustomerRegistrationTest|AutomaticRegistrationMigrationTest|AutomaticRegistrationAdminFlowTest|IncomingMailCommandTest|LoginSecurityFlowTest|PasswordResetFlowTest|PortalLoginLinkFlowTest|SessionSecurityFlowTest|AdminMailFlowTest'
```

Funktionstesterna använder projektets testdatabas. Kör dem separat från andra testprocesser som bygger om samma databas. Testet för samtidiga mejl startar själv två kontrollerade processer mot testdatabasen.
