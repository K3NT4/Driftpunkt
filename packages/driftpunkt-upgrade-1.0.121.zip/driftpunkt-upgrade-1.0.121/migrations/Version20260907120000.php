<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

final class Version20260907120000 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Adds opt-in mail customer registration, inherited company exceptions and separate portal access';
    }

    public function up(Schema $schema): void
    {
        $schema->getTable('companies')->addColumn('legacy_mail_handling', 'boolean', ['default' => false]);
        $schema->getTable('users')->addColumn('portal_access_enabled', 'boolean', ['default' => true]);
        $schema->getTable('support_mailboxes')->addColumn('automatic_customer_registration', 'boolean', ['default' => false]);
        $schema->getTable('support_mailboxes')->addColumn('allowed_sender_domains', 'json', ['default' => '[]']);
    }

    public function down(Schema $schema): void
    {
        $this->throwIrreversibleMigrationException('Portal access must not be silently enabled for mail-only customers.');
    }
}
