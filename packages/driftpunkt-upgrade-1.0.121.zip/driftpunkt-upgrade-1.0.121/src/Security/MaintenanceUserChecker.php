<?php

declare(strict_types=1);

namespace App\Security;

use App\Module\Identity\Entity\User;
use App\Module\Maintenance\Service\MaintenanceMode;
use Symfony\Component\Security\Core\Authentication\Token\TokenInterface;
use Symfony\Component\Security\Core\Exception\CustomUserMessageAccountStatusException;
use Symfony\Component\Security\Core\User\UserCheckerInterface;
use Symfony\Component\Security\Core\User\UserInterface;

final class MaintenanceUserChecker implements UserCheckerInterface
{
    public function __construct(
        private readonly MaintenanceMode $maintenanceMode,
    ) {
    }

    public function checkPreAuth(UserInterface $user): void
    {
        if (!$user instanceof User) {
            return;
        }

        if (!$user->isPortalAccessEnabled()) {
            throw new CustomUserMessageAccountStatusException('Portalåtkomst är inte aktiverad. Kontakta administratören.');
        }

        if (!$user->isActive()) {
            throw new CustomUserMessageAccountStatusException('Kontot är inaktiverat. Kontakta administratör om du behöver åtkomst.');
        }

        if (!$this->maintenanceMode->getState()['effectiveEnabled']) {
            return;
        }

        if (\in_array('ROLE_ADMIN', $user->getRoles(), true)) {
            return;
        }

        throw new CustomUserMessageAccountStatusException(
            'Inloggningen är tillfälligt pausad medan Driftpunkt är i underhållsläge. Försök igen senare eller följ driftinformationen.',
        );
    }

    public function checkPostAuth(UserInterface $user, ?TokenInterface $token = null): void
    {
    }
}
