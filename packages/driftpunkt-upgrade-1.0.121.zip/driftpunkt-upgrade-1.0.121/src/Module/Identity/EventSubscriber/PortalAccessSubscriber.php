<?php

declare(strict_types=1);

namespace App\Module\Identity\EventSubscriber;

use App\Module\Identity\Entity\User;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpKernel\Event\RequestEvent;
use Symfony\Component\HttpKernel\KernelEvents;
use Symfony\Component\Routing\Generator\UrlGeneratorInterface;
use Symfony\Component\Security\Core\Authentication\Token\Storage\TokenStorageInterface;

final class PortalAccessSubscriber implements EventSubscriberInterface
{
    public function __construct(
        private readonly TokenStorageInterface $tokenStorage,
        private readonly UrlGeneratorInterface $urlGenerator,
    ) {
    }

    public static function getSubscribedEvents(): array
    {
        return [KernelEvents::REQUEST => ['onKernelRequest', -4]];
    }

    public function onKernelRequest(RequestEvent $event): void
    {
        if (!$event->isMainRequest()) {
            return;
        }
        $user = $this->tokenStorage->getToken()?->getUser();
        if (!$user instanceof User || $user->isPortalAccessEnabled()) {
            return;
        }
        $this->tokenStorage->setToken(null);
        if ($event->getRequest()->hasSession()) {
            $event->getRequest()->getSession()->invalidate();
        }
        $event->setResponse(new RedirectResponse($this->urlGenerator->generate('app_login')));
    }
}
