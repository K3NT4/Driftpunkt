<?php

declare(strict_types=1);

namespace App\Module\Mail\Service;

use App\Module\Identity\Entity\User;
use App\Module\Identity\Enum\UserType;
use App\Module\Mail\Entity\IncomingMail;
use App\Module\Mail\Entity\IncomingMailAlias;
use App\Module\Mail\Entity\SupportMailbox;

final class AutomaticCustomerRegistration
{
    public function applies(?SupportMailbox $mailbox): bool
    {
        return null !== $mailbox && $mailbox->hasAutomaticCustomerRegistration()
            && null !== $mailbox->getCompany()
            && null === $mailbox->getCompany()->getLegacyMailHandlingSource();
    }

    public function validateConfiguration(SupportMailbox $mailbox): void
    {
        if ($mailbox->hasAutomaticCustomerRegistration()
            && (!$mailbox->getCompany()?->isActive() || !$mailbox->allowsUnknownSenders() || [] === $mailbox->getAllowedSenderDomains())) {
            throw new \InvalidArgumentException('Automatisk kundregistrering kräver ett aktivt företag, tillåtna domäner och att inkorgen tillåter okända avsändare.');
        }
    }

    public function reviewReason(IncomingMail $mail, ?User $user, ?IncomingMailAlias $alias): ?string
    {
        $mailbox = $mail->getMailbox();
        if (!$this->applies($mailbox)) {
            return null;
        }
        if (!$mailbox->isActive() || !$mailbox->getCompany()->isActive() || !$mailbox->allowsUnknownSenders()) {
            return 'Automatisk kundregistrering är inte tillgänglig för denna inkorg eller detta företag.';
        }
        $company = $mailbox->getCompany();
        if (null !== $user && (!$user->isActive() || UserType::CUSTOMER !== $user->getType()
            || $user->getCompany()?->getId() !== $company->getId())) {
            return 'Befintlig avsändare saknar rätt företagskoppling eller är inte en aktiv företagskund.';
        }
        $aliasCompany = $alias?->getCompany() ?? $alias?->getUser()?->getCompany();
        if (null !== $alias && ($aliasCompany?->getId() !== $company->getId()
            || (null !== $alias->getUser() && $alias->getUser()->getId() !== $user?->getId()))) {
            return 'Avsändaralias har en motstridig företags- eller kundkoppling.';
        }

        return null;
    }

    public function canRegister(IncomingMail $mail): bool
    {
        $mailbox = $mail->getMailbox();
        $email = $mail->getFromEmail();
        if (!$this->applies($mailbox) || null !== $this->reviewReason($mail, null, null)
            || strlen($email) > 180 || false === filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return false;
        }
        $domain = strtolower(substr($email, strrpos($email, '@') + 1));

        return in_array($domain, $mailbox->getAllowedSenderDomains(), true);
    }

    public function createCustomer(IncomingMail $mail): User
    {
        if (!$this->canRegister($mail)) {
            throw new \LogicException('Avsändaren får inte registreras automatiskt.');
        }
        $name = trim($mail->getFromName() ?? '');
        $parts = preg_split('/\s+/u', $name, 2) ?: [];
        $user = new User(
            $mail->getFromEmail(),
            mb_substr('' !== $name ? ($parts[0] ?? $mail->getFromEmail()) : $mail->getFromEmail(), 0, 80),
            mb_substr($parts[1] ?? '', 0, 80),
            UserType::CUSTOMER,
        );

        return $user->setCompany($mail->getMailbox()->getCompany())->setPortalAccessEnabled(false);
    }
}
