<?php

declare(strict_types=1);

namespace App\Module\Mail\Service;

use App\Module\Identity\Entity\User;
use App\Module\Identity\Enum\UserType;
use App\Module\Mail\Entity\DraftTicketReview;
use App\Module\Mail\Entity\IncomingMail;
use App\Module\Mail\Entity\IncomingMailAlias;
use App\Module\Mail\Entity\SupportMailbox;
use App\Module\Mail\Enum\IncomingMailProcessingResult;
use App\Module\Mail\Enum\DraftTicketReviewKind;
use App\Module\Ticket\Entity\Ticket;
use App\Module\Ticket\Entity\TicketComment;
use App\Module\Ticket\Entity\ImportedTicketPerson;
use App\Module\Ticket\Enum\ImportedTicketPersonRole;
use App\Module\Ticket\Enum\TicketEscalationLevel;
use App\Module\Ticket\Enum\TicketImpactLevel;
use App\Module\Ticket\Enum\TicketPriority;
use App\Module\Ticket\Enum\TicketRequestType;
use App\Module\Ticket\Enum\TicketStatus;
use App\Module\Ticket\Enum\TicketVisibility;
use App\Module\Ticket\Service\AttachmentCopyResult;
use App\Module\Ticket\Service\TicketAuditLogger;
use App\Module\Ticket\Service\TicketLifecycleService;
use App\Module\Ticket\Service\TicketMergeService;
use App\Module\Ticket\Service\TicketReferenceGenerator;
use App\Module\Ticket\Service\TicketResponseNotifier;
use App\Module\System\Service\SystemSettings;
use App\Module\System\Service\InternalReportNotifier;
use App\Module\System\Service\SystemAuditLogger;
use App\Module\System\Entity\InternalReport;
use App\Module\System\Entity\InternalReportResponse;
use Doctrine\ORM\EntityManagerInterface;

final class IncomingMailProcessor
{
    public function __construct(
        private readonly EntityManagerInterface $entityManager,
        private readonly TicketAuditLogger $ticketAuditLogger,
        private readonly TicketLifecycleService $ticketLifecycleService,
        private readonly TicketMergeService $ticketMergeService,
        private readonly TicketReferenceGenerator $ticketReferenceGenerator,
        private readonly TicketResponseNotifier $ticketResponseNotifier,
        private readonly SystemSettings $systemSettings,
        private readonly IncomingMailAttachmentStorage $incomingMailAttachmentStorage,
        private readonly InternalReportNotifier $internalReportNotifier,
        private readonly SystemAuditLogger $systemAuditLogger,
    ) {
    }

    public function process(IncomingMail $incomingMail): IncomingMail
    {
        if (null !== $incomingMail->getProcessingResult()) {
            return $incomingMail;
        }

        $matchedInternalReport = $this->findInternalReportReply($incomingMail);
        if ($matchedInternalReport instanceof InternalReport && '' !== trim($incomingMail->getBody())) {
            $this->appendResponseToInternalReport($matchedInternalReport, $incomingMail);

            return $incomingMail;
        }

        $matchedUser = $this->entityManager->getRepository(User::class)->findOneBy([
            'email' => $incomingMail->getFromEmail(),
        ]);
        $matchedAlias = null;
        if (!$matchedUser instanceof User) {
            $matchedAlias = $this->entityManager->getRepository(IncomingMailAlias::class)->findOneBy([
                'email' => IncomingMailAlias::normalizeEmail($incomingMail->getFromEmail()),
            ]);
            if ($matchedAlias instanceof IncomingMailAlias) {
                $aliasUser = $matchedAlias->getUser();
                $matchedUser = $aliasUser instanceof User && \in_array($aliasUser->getType(), [UserType::CUSTOMER, UserType::PRIVATE_CUSTOMER], true)
                    ? $aliasUser
                    : null;
            }
        }
        $matchedTicket = $this->findTicketBySubject($incomingMail->getSubject());
        $matchedSourceReference = $matchedTicket?->getReference();
        if ($matchedTicket instanceof Ticket) {
            $matchedTicket = $this->ticketMergeService->effectiveTicket($matchedTicket);
        }
        $matchedCompany = $matchedUser?->getCompany() ?? ($matchedAlias instanceof IncomingMailAlias ? $matchedAlias->getCompany() : null);

        $incomingMail
            ->setMatchedUser($matchedUser instanceof User ? $matchedUser : null)
            ->setMatchedCompany($matchedCompany)
            ->setMatchedTicket($matchedTicket);

        if ($matchedTicket instanceof Ticket) {
            if ($matchedUser instanceof User && $this->userCanReplyToTicket($matchedUser, $matchedTicket)) {
                $this->appendCommentToTicket($matchedTicket, $matchedUser, $incomingMail, $matchedSourceReference);

                return $incomingMail;
            }

            $reason = $matchedUser instanceof User
                ? 'Avsändaren matchade inte någon behörig person på ärendet.'
                : 'Okänd avsändare försökte svara på ett befintligt ärende.';

            $this->createDraftReview($incomingMail, $reason, $matchedTicket, $matchedUser, $matchedAlias instanceof IncomingMailAlias);

            return $incomingMail;
        }

        if ($matchedUser instanceof User) {
            $this->createTicketFromKnownSender($incomingMail, $matchedUser);

            return $incomingMail;
        }

        $mailbox = $incomingMail->getMailbox();
        if (!$mailbox instanceof SupportMailbox || (!$mailbox->allowsUnknownSenders() && !($matchedCompany instanceof \App\Module\Identity\Entity\Company))) {
            $incomingMail->markProcessed(IncomingMailProcessingResult::REJECTED, 'Avsändaren är okänd och inkorgen tillåter inte okända avsändare.');
            $this->entityManager->persist($incomingMail);
            $this->entityManager->flush();

            return $incomingMail;
        }

        $reason = $matchedCompany instanceof \App\Module\Identity\Entity\Company
            ? 'Avsändaren matchade ett företag men ingen kundperson och kräver manuell granskning.'
            : 'Okänd avsändare kräver manuell granskning innan ärendet kan kopplas.';
        $this->createDraftReview($incomingMail, $reason, null, null, $matchedAlias instanceof IncomingMailAlias);

        return $incomingMail;
    }

    private function findInternalReportReply(IncomingMail $incomingMail): ?InternalReport
    {
        $authorizedSender = $this->systemSettings->getInternalReportSettings()['recipient'];
        if ('' === $authorizedSender || mb_strtolower(trim($incomingMail->getFromEmail())) !== $authorizedSender) {
            return null;
        }

        if (1 !== preg_match('/\[DRIFTPUNKT-RAPPORT\s+([0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12})\]/i', $incomingMail->getSubject(), $matches)) {
            return null;
        }

        $report = $this->entityManager->getRepository(InternalReport::class)->findOneBy([
            'publicReference' => mb_strtolower($matches[1]),
        ]);

        return $report instanceof InternalReport ? $report : null;
    }

    private function appendResponseToInternalReport(InternalReport $report, IncomingMail $incomingMail): void
    {
        $originalBody = trim($incomingMail->getBody());
        $responseBody = mb_substr($originalBody, 0, 20000);
        $wasTruncated = mb_strlen($originalBody) > 20000;
        $contentHash = InternalReportResponse::buildContentHash($report, $incomingMail->getFromEmail(), $responseBody);
        $existingResponse = null !== $incomingMail->getMessageId()
            ? $this->entityManager->getRepository(InternalReportResponse::class)->findOneBy(['incomingMail' => $incomingMail])
            : $this->entityManager->getRepository(InternalReportResponse::class)->findOneBy(['contentHash' => $contentHash]);

        if ($existingResponse instanceof InternalReportResponse) {
            $incomingMail->markProcessed(
                IncomingMailProcessingResult::INTERNAL_REPORT_RESPONSE_ADDED,
                sprintf('Dubblett av svar till intern rapport %s ignorerades.', $report->getPublicReference()),
            );
            $this->entityManager->flush();

            return;
        }

        $response = new InternalReportResponse(
            $report,
            $incomingMail,
            $incomingMail->getFromEmail(),
            $responseBody,
        );
        $report->markInProgressFromResponse();
        $attachmentNote = [] !== $incomingMail->getAttachmentMetadata()
            ? ' Bilagor ignorerades för rapportsvaret.'
            : '';
        $truncationNote = $wasTruncated ? ' Svaret kortades till 20 000 tecken; originalet finns kvar i inkommande e-post.' : '';
        $incomingMail->markProcessed(
            IncomingMailProcessingResult::INTERNAL_REPORT_RESPONSE_ADDED,
            sprintf('Svar lades till i intern rapport %s.%s%s', $report->getPublicReference(), $attachmentNote, $truncationNote),
        );

        $this->entityManager->persist($response);
        $this->entityManager->flush();
        $this->systemAuditLogger->log(
            null,
            'internal_report.response_imported',
            'E-postsvar kopplat till intern rapport',
            sprintf('Svar från %s kopplades till rapport %s.', $incomingMail->getFromEmail(), $report->getPublicReference()),
        );
        $this->internalReportNotifier->notifyReporterOfResponse($report, $response);
    }

    private function createTicketFromKnownSender(IncomingMail $incomingMail, User $requester): void
    {
        $mailbox = $incomingMail->getMailbox();
        $resolvedCompany = $requester->getCompany() ?? $mailbox?->getCompany();

        $ticket = new Ticket(
            $this->ticketReferenceGenerator->nextReference($resolvedCompany),
            $incomingMail->getSubject(),
            $incomingMail->getBody(),
            TicketStatus::NEW,
            TicketVisibility::PRIVATE,
            $mailbox?->getDefaultPriority() ?? TicketPriority::NORMAL,
            TicketRequestType::INCIDENT,
            TicketImpactLevel::SINGLE_USER,
            TicketEscalationLevel::NONE,
        );
        $ticket
            ->setRequester($requester)
            ->setCompany($resolvedCompany)
            ->setCategory($mailbox?->getDefaultCategory())
            ->setAssignedTeam($mailbox?->getDefaultTeam());
        $automaticStatusChange = $this->markTicketOpenWhenRouted($ticket, 'inkommande e-post routades');

        $this->entityManager->persist($ticket);
        $this->entityManager->persist($incomingMail);
        $this->entityManager->flush();

        $attachmentResult = AttachmentCopyResult::empty();
        if ([] !== $incomingMail->getAttachmentMetadata()) {
            $comment = new TicketComment($ticket, $requester, $incomingMail->getBody(), false);
            $ticket->addComment($comment);
            $this->entityManager->persist($comment);
            $attachmentResult = $this->attachIncomingMailAttachmentsToComment($incomingMail, $ticket, $comment);
        }

        $incomingMail
            ->setMatchedTicket($ticket)
            ->markProcessed(
                IncomingMailProcessingResult::TICKET_CREATED,
                sprintf(
                    'Nytt ärende %s skapades från känd avsändare%s.',
                    $ticket->getReference(),
                    $this->formatAttachmentProcessingSuffix($attachmentResult),
                ),
            );

        $this->entityManager->flush();
        $this->ticketAuditLogger->log(
            $ticket,
            'incoming_mail_ticket_created',
            sprintf(
                'Ärende skapades från inkommande e-post via %s%s.',
                $mailbox?->getEmailAddress() ?? 'okänd inkorg',
                $this->formatAttachmentAuditSuffix($attachmentResult),
            ),
            $requester,
        );
        if (null !== $automaticStatusChange) {
            $this->ticketAuditLogger->log($ticket, 'ticket_updated', $automaticStatusChange.'.', $requester);
        }

        $this->ticketResponseNotifier->notifyIncomingMailTicketReceived(
            $ticket,
            $incomingMail->getFromEmail(),
            $requester->getDisplayName(),
            $requester,
        );
        try {
            $this->ticketResponseNotifier->notifyTicketCreatedForTriage($ticket);
        } catch (\Throwable) {
            // Ärendet och kundbekräftelsen ska inte påverkas om triage-notisen misslyckas.
        }
    }

    private function appendCommentToTicket(Ticket $ticket, User $author, IncomingMail $incomingMail, ?string $matchedSourceReference = null): void
    {
        $comment = new TicketComment($ticket, $author, $incomingMail->getBody(), false);
        $ticket->addComment($comment);
        $ticket->setStatus(TicketStatus::OPEN);

        $this->entityManager->persist($comment);
        $attachmentResult = $this->attachIncomingMailAttachmentsToComment($incomingMail, $ticket, $comment);
        $this->entityManager->persist($incomingMail);
        $this->entityManager->flush();

        $incomingMail->markProcessed(
            IncomingMailProcessingResult::COMMENT_ADDED,
            sprintf(
                'Svar lades till i ärende %s%s.',
                $ticket->getReference(),
                $this->formatAttachmentProcessingSuffix($attachmentResult),
            ),
        );
        $this->entityManager->flush();

        $this->ticketAuditLogger->log(
            $ticket,
            'incoming_mail_comment_added',
            sprintf(
                'Inkommande e-post från %s lades till som kundsvar%s%s.',
                $incomingMail->getFromEmail(),
                null !== $matchedSourceReference && $matchedSourceReference !== $ticket->getReference()
                    ? sprintf(' via sammanslaget ärende %s', $matchedSourceReference)
                    : '',
                $this->formatAttachmentAuditSuffix($attachmentResult),
            ),
            $author,
        );

        if ($ticket->getAssignee() instanceof User && $ticket->getAssignee()->getId() !== $author->getId()) {
            $this->ticketResponseNotifier->notifyTechnicianWaitingForReply($ticket, $comment);
        }
    }

    private function createDraftReview(IncomingMail $incomingMail, string $reason, ?Ticket $matchedTicket, ?User $matchedUser, bool $knownAlias = false): void
    {
        $mailbox = $incomingMail->getMailbox();
        $draftTicket = null;
        $reviewKind = $matchedUser instanceof User
            ? DraftTicketReviewKind::UNAUTHORIZED_REPLY
            : DraftTicketReviewKind::UNKNOWN_SENDER;

        if ($mailbox instanceof SupportMailbox && (DraftTicketReviewKind::UNKNOWN_SENDER === $reviewKind || $mailbox->createsDraftTicketsForUnknownSenders())) {
            $draftCompany = $matchedUser?->getCompany() ?? $incomingMail->getMatchedCompany() ?? $mailbox->getCompany();
            $draftTicket = new Ticket(
                $this->ticketReferenceGenerator->nextReference($draftCompany),
                sprintf('[Utkast] %s', $incomingMail->getSubject()),
                $incomingMail->getBody(),
                TicketStatus::NEW,
                TicketVisibility::INTERNAL_ONLY,
                $mailbox->getDefaultPriority() ?? TicketPriority::NORMAL,
                TicketRequestType::INCIDENT,
                TicketImpactLevel::SINGLE_USER,
                TicketEscalationLevel::NONE,
            );
            $draftTicket
                ->setCompany($draftCompany)
                ->setCategory($mailbox->getDefaultCategory())
                ->setAssignedTeam($mailbox->getDefaultTeam());

            if (DraftTicketReviewKind::UNKNOWN_SENDER === $reviewKind && !$knownAlias) {
                $senderEmail = mb_strtolower(trim($incomingMail->getFromEmail()));
                $senderName = trim((string) $incomingMail->getFromName());
                $draftTicket->addImportedPerson(new ImportedTicketPerson(
                    $draftTicket,
                    ImportedTicketPersonRole::REQUESTER,
                    '' !== $senderName ? $senderName : $senderEmail,
                    'incoming_mail',
                    $senderEmail,
                ));
            }

            $this->entityManager->persist($draftTicket);
        }

        $review = new DraftTicketReview($incomingMail, $reason, $reviewKind);
        $review
            ->setMailbox($mailbox)
            ->setDraftTicket($draftTicket)
            ->setMatchedTicket($matchedTicket)
            ->setMatchedCompany($matchedUser?->getCompany() ?? $incomingMail->getMatchedCompany() ?? $mailbox?->getCompany());

        $incomingMail->markProcessed(
            IncomingMailProcessingResult::DRAFT_REVIEW_CREATED,
            $draftTicket instanceof Ticket
                ? sprintf('Utkastgranskning skapades tillsammans med internt ärende %s.', $draftTicket->getReference())
                : 'Utkastgranskning skapades utan automatiskt ärende.',
        );

        $this->entityManager->persist($incomingMail);
        $this->entityManager->persist($review);
        $this->entityManager->flush();

        if ($draftTicket instanceof Ticket) {
            $this->ticketAuditLogger->log(
                $draftTicket,
                'incoming_mail_draft_review_created',
                sprintf('Utkastärende skapades för manuell granskning: %s', $reason),
            );
        }
    }

    private function findTicketBySubject(string $subject): ?Ticket
    {
        if (!preg_match($this->ticketReferenceGenerator->ticketReferenceRegex(), $subject, $matches)) {
            return null;
        }

        $reference = strtoupper($matches[1]);

        $ticket = $this->entityManager->getRepository(Ticket::class)->findOneBy(['reference' => $reference]);

        return $ticket instanceof Ticket ? $ticket : null;
    }

    private function userCanReplyToTicket(User $user, Ticket $ticket): bool
    {
        if (\in_array('ROLE_ADMIN', $user->getRoles(), true) || \in_array('ROLE_TECHNICIAN', $user->getRoles(), true)) {
            return true;
        }

        if (TicketVisibility::INTERNAL_ONLY === $ticket->getVisibility()) {
            return false;
        }

        if ($ticket->getRequester()?->getId() === $user->getId()) {
            return true;
        }

        if (UserType::PRIVATE_CUSTOMER === $user->getType()) {
            return false;
        }

        return TicketVisibility::COMPANY_SHARED === $ticket->getVisibility()
            && null !== $ticket->getCompany()
            && $ticket->getCompany()->getId() === $user->getCompany()?->getId();
    }

    /**
     */
    private function attachIncomingMailAttachmentsToComment(IncomingMail $incomingMail, Ticket $ticket, TicketComment $comment): AttachmentCopyResult
    {
        if ([] === $incomingMail->getAttachmentMetadata()) {
            return AttachmentCopyResult::empty();
        }

        $result = $this->incomingMailAttachmentStorage->copyIncomingMailAttachmentsToTicketComment(
            $incomingMail,
            $ticket,
            $comment,
            $this->systemSettings->getTicketAttachmentSettings(),
        );

        foreach ($result->getCreatedAttachments() as $attachment) {
            $comment->addAttachment($attachment);
            $this->entityManager->persist($attachment);
        }

        return $result;
    }

    private function formatAttachmentProcessingSuffix(AttachmentCopyResult $result): string
    {
        $parts = [];
        $createdCount = $result->getCreatedAttachmentCount();
        if ($createdCount > 0) {
            $parts[] = sprintf('med %d bilag%s', $createdCount, 1 === $createdCount ? 'a' : 'or');
        }

        if ($result->hasSkippedDuplicates()) {
            $parts[] = sprintf(
                '%s%d dubblettbilag%s hoppades över',
                0 === $createdCount ? 'och ' : '',
                $result->getSkippedDuplicateCount(),
                1 === $result->getSkippedDuplicateCount() ? 'a' : 'or',
            );
        }

        return [] !== $parts ? ' '.implode(' och ', $parts) : '';
    }

    private function formatAttachmentAuditSuffix(AttachmentCopyResult $result): string
    {
        $parts = [];
        $createdCount = $result->getCreatedAttachmentCount();
        if ($createdCount > 0) {
            $parts[] = sprintf('%d bilag%s kopierades in', $createdCount, 1 === $createdCount ? 'a' : 'or');
        }

        if ($result->hasSkippedDuplicates()) {
            $parts[] = sprintf('%d dubblettbilag%s hoppades över', $result->getSkippedDuplicateCount(), 1 === $result->getSkippedDuplicateCount() ? 'a' : 'or');
        }

        return [] !== $parts ? ' och '.implode(' och ', $parts) : '';
    }

    private function markTicketOpenWhenRouted(Ticket $ticket, string $reason): ?string
    {
        $previousStatus = $this->ticketLifecycleService->markOpenWhenRouted($ticket);
        if (!$previousStatus instanceof TicketStatus) {
            return null;
        }

        return sprintf('status %s -> %s, %s', $previousStatus->label(), $ticket->getStatus()->label(), $reason);
    }
}
